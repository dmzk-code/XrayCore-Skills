# Xray-core Skills — r6 / 6.0.0

**17 скиллов: девять транспортных и восемь общих.** Основа: Xray-core `v26.9.30` (pre-release), commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Ревизия от 7 октября 2026 года. Полная замена r5; это пакет конфигурационных знаний и проверок, не патч ядра.

## Установка

Python 3.10+; генерация лабораторных сертификатов использует OpenSSL. На Windows вместо `python` использовать `py -3`. Проверить доверенный SHA256 ZIP до исполнения файлов архива, распаковать вне целевого каталога.

```bash
python verify_package.py
# Выполнить один из вариантов:
python install.py --target "/absolute/path/to/project/.claude/skills" --replace
python install.py --target "/absolute/path/to/project/.agents/skills" --replace
```

Устанавливать все **17** каталогов вместе. Установщик проверяет manifest, делает backup одноимённых скиллов, не удаляет посторонние скиллы и не перезаписывает AGENTS.md/CLAUDE.md. [Пример правил проекта](AGENTS.example.md). Проверка hashes означает согласованность файлов, не подпись независимого издателя. Активация в UI агента не измерялась.

Для X25519 peer-check доступен необязательный backend:

```bash
python -m pip install -r requirements-crypto.txt
```

Без него соответствие ключей получает предупреждение UNVERIFIED; пакет не устанавливает зависимости автоматически.

## Доработки r6

| Направление | Что изменено |
|---|---|
| SOCKS/mixed/HTTP | Поля по ролям, aliases accounts/users, endpoint cardinality, реальные credentials, ограничения SOCKS5, HTTP headers и UDP association. Добавлены семь объектов registry. |
| Авторизация | Выявлен и воспроизведён открытый HTTP CONNECT на SOCKS/mixed при auth=password и пустом accounts. Валидатор отвергает опасную запись; учитывает регистр auth, пустой alias и переопределение Proxy-Authorization. |
| Топология | Новый явный --direct-peer: port/IP/family/physical network/security/PROXY preamble. Проверка пересечений listeners, XHTTP session-owner, virtual tag owners и dialerProxy анонимного outbound. |
| gRPC / Finalmask | Непустой JSON объект больше не считается доказательством созданного FinalMask. Пустые маски и quicParams-only не устраняют известную reconnect-ветку. |
| Изоляция стенда | Удаляются dotted и underscore XRAY/V2RAY/HYSTERIA environment names; локальные native controls подтвердили отсутствие подмешанного confdir. |
| Согласованность знаний | Исправлены устаревшие r2 версия общего контракта и r3 числа внутри index.counts; добавлены автоматические проверки, чтобы summary не отставал от реестра. |
| Диагностика | Не выводятся неизвестные пользовательские имена полей через null/shadow-ошибки. Новый runner и CI разделяют ожидаемые регрессии и работоспособность ядра. |

Реестр: **97 объектов, 584 позиции полей, 128 исходных файлов или явно отмеченных диапазонов**. Значения «объект/поле» — inventory описанных типов, не число протестированных комбинаций. Это не полная JSON Schema каждого стороннего протокола и зависимости. В архиве сохранены 45 полных базовых шаблонов для 22 схем; дополнительные варианты генерируются runners. Бинарников, generated private keys, сырых runtime logs и реквизитов внешних аккаунтов в поставке нет.

## Использование

Основная точка входа — **xray-config-orchestrator**. Общий контракт подключается один раз, затем только релевантные transport/protocol/security references.

> Используй xray-config-orchestrator и необходимые транспортные скиллы. Сохрани закреплённые версии и существующую архитектуру. Получи эффективные настройки из всех исходных файлов, составь схему физических плеч и владельцев listeners. Проверь обе стороны, включая HTTP-ветку SOCKS, действующие credentials, DNS и known-issues. Выдай полные конфиги, минимальный diff и результаты действительно выполненных проверок. Не объявляй L0 успешным handshake и не меняй рабочие сервисы без разрешения.

[Общий контракт](skills/xray-config-orchestrator/references/contract.md) · [Карта знаний](skills/xray-config-orchestrator/references/knowledge-map.md) · [Proxy edges](skills/xray-protocol-composition/references/local-proxy-edges.md) · [Топология](skills/xray-config-orchestrator/references/topology-and-listeners.md) · [Совместимость](skills/xray-config-orchestrator/references/compatibility.md) · [Источники](skills/xray-source-audit/references/provenance.json).

## Команды проверки

```bash
# Протокольная сверка; не предполагает прямой путь через неизвестную сеть:
python skills/xray-source-audit/scripts/validate.py client.json --peer server.json --json

# Только при явном прямом соединении без NAT / frontend / TLS termination:
python skills/xray-source-audit/scripts/validate.py client.json --peer server.json --direct-peer --json

# При нескольких endpoint выбрать нужные tags:
python skills/xray-source-audit/scripts/validate.py client.json --peer server.json --outbound-tag PROXY --inbound-tag INBOUND --direct-peer --json

# Несколько исходных файлов: Config.Override, не произвольный deep merge:
python skills/xray-source-audit/scripts/compose_config.py -c 00-base.json -c 20-proxy.json --confdir ./conf.d
```

По умолчанию composer не выводит содержащий секреты merged JSON. Его запись разрешается только отдельным `--write-merged new-file.json`. [Composition](skills/xray-config-orchestrator/references/composition.md). Ошибка AUTHORING_POLICY может быть намеренно строже permissive core; статус PASS_STATIC_ONLY не означает завершённую сетевую проверку.

## Испытания

```bash
python -m unittest discover -s tests -v
python skills/xray-source-audit/scripts/run_r6_regressions.py --xray /absolute/path/xray --sha256 TRUSTED_SHA256 --execute --out /new/private/r6-run
python ci/verify.py --out /new/private/ci-run --xray /absolute/path/xray --xray-sha256 TRUSTED_SHA256 --run-r6-regressions
```

Другие runners/CI-флаги сохранены: --run-r5-regressions, --run-regressions (r4), --run-core, --run-extended, --run-dns, --run-control. Go/build требуют отдельных явных флагов и доверенного checkout. [Изоляция и статусы](skills/xray-runtime-validation/references/lab-environment.md).

**Фактически в r6:** 564 unit-теста; новая серия 8 parser + 8 auth edge + 8 proxy pairs + 2 env controls; повтор прежнего runner — 21 wire + 9 composition + 10 parser expectations. Два gRPC server-only restart вновь дали известный FAIL, с успешным контролем после client restart. В диагностическом runner PASS_EXPECTATIONS_WITH_KNOWN_RUNTIME_FAILURES означает совпадение ожидаемых наблюдений, не отсутствие ошибок ядра.

[Отчёт и границы текущих проверок](VALIDATION.md) · [Изменения](CHANGELOG.md) · [Known issues](skills/xray-runtime-validation/references/known-issues.md). Исторические 22/40 baseline/extended результаты сохранены, но не переименованы в новый запуск. Конкретную пользовательскую топологию, WAN/CDN, другие ОС и длительную нагрузку надо подтверждать её собственными результатами; эта лаборатория не даёт универсальной гарантии всех сочетаний.
