"""Manifest consistency, not publisher authentication. Does not execute package code.
A trusted detached ZIP digest/signature must be checked separately before executing
any downloaded Python file. Ignore only Python cache output produced by tests.
"""
from __future__ import annotations
import hashlib
import re
from pathlib import Path, PurePosixPath


def shipped(path: Path) -> bool:
    return '__pycache__' not in path.parts and path.suffix != '.pyc' and path.as_posix() != 'SHA256SUMS.txt'


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def verify_integrity(root: Path) -> list[str]:
    errors: list[str] = []
    if root.is_symlink():
        return ['package root is a symlink']
    root = root.resolve(strict=True)
    manifest = root / 'SHA256SUMS.txt'
    if manifest.is_symlink() or not manifest.is_file():
        return ['SHA256SUMS.txt is missing or a symlink']
    if manifest.stat().st_size > 4 * 1024 * 1024:
        return ['checksum manifest too large']
    expected: dict[str, str] = {}
    try:
        for line in manifest.read_text(encoding='utf-8').splitlines():
            match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
            if not match:
                errors.append('malformed checksum entry'); continue
            name = match[2]; rel = PurePosixPath(name)
            if rel.is_absolute() or '..' in rel.parts or '\\' in name or ':' in name or rel.as_posix() != name or not shipped(Path(name)):
                errors.append('unsafe checksum path'); continue
            if name in expected:
                errors.append('duplicate checksum entry'); continue
            expected[name] = match[1]
    except (UnicodeError, OSError):
        return ['checksum manifest unreadable']
    if not expected:
        errors.append('empty checksum manifest')
    actual: set[str] = set()
    for path in root.rglob('*'):
        rel = path.relative_to(root)
        if path.is_symlink():
            errors.append('symlink in package: ' + rel.as_posix()); continue
        if path.is_file() and shipped(rel):
            actual.add(rel.as_posix())
    for name in sorted(set(expected) - actual):
        errors.append('missing manifest file: ' + name)
    for name in sorted(actual - set(expected)):
        errors.append('unlisted package file: ' + name)
    for name in sorted(set(expected) & actual):
        path = root / name
        if any(p.is_symlink() for p in (path, *path.parents) if p.is_relative_to(root)):
            errors.append('symlink in checksum path'); continue
        if digest(path) != expected[name]:
            errors.append('checksum mismatch: ' + name)
    return errors
