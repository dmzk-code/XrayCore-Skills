# CI без неявного развёртывания

`verify.py` — исполняемый entry point, а не уже запущенный GitHub workflow. По умолчанию только offline package checks и собственные tests. Новый output directory обязателен.

```bash
python ci/verify.py --out /absolute/path/to/new-ci-output
```

С локальным доверенным ядром (нужен OpenSSL; для split-схемы Nginx):
```bash
python ci/verify.py --out /absolute/path/to/new-ci-output --run-core --xray /absolute/path/to/xray --xray-sha256 REPLACE_WITH_EXPECTED_SHA256 --nginx /absolute/path/to/nginx
```

С отдельным **неизменённым checkout** точного commit:
```bash
python ci/verify.py --out /absolute/path/to/new-ci-output --source /absolute/path/to/Xray-core --build-core --run-go-tests --run-core --nginx /absolute/path/to/nginx
```

Go должен уметь использовать версию из pinned go.mod (1.27). Build/tests по явным флагам могут скачивать toolchain/modules; используются `-mod=readonly` и отдельный output, не git reset/checkout и не исправление рабочего проекта. Целевые Go packages перечислены в скрипте. В этой сессии Go unit suite и сборка из source не выполнялись; тестировался официальный binary.

Core runner реально проверяет негативный auth, TCP/UDP, reconnect и небольшой stress. В свежем прогоне r3 известны непройденные runtime этапы: CI может корректно вернутьFAIL, даже когда package/unit зелёные. Не добавлять `|| true` и не скрывать эти результаты. [Измеренные проблемы](../skills/xray-runtime-validation/references/known-issues.md).

Файлы лаборатории и logs могут содержать случайные тестовые ключи и network metadata. Не публиковать целый output folder как публичный CI artifact; публиковать только обезличенный report. Скрипт не настраивает cron, не отправляет изменения в GitHub и не устанавливает системные пакеты.


## Расширенные проверки r3
```bash
python ci/verify.py --out /absolute/path/to/new-ci-output --run-core --run-extended --run-dns --xray /absolute/path/to/xray --xray-sha256 TRUSTED_BINARY_SHA256 --nginx /absolute/path/to/nginx
```

`--run-extended` запускает 40 вариантов; `--run-dns` — 4 DNS/cache эксперимента. Они доступны также без `--run-core`. Непройденный базовый runtime не превращается в PASS, но независимые дополнительные эксперименты продолжаются, если исходные package/source/binary prerequisites были корректны. Без явных флагов сетевой и Go код не исполняется.

## r4
Дополнительные явные флаги: `--run-regressions` и `--run-control`; требуют доверенный бинарник и SHA256 наравне с другими native checks. DefaultCI всё ещё не исполняет Xray и не загружает Go modules. SHA256SUMS проверяется перед установкой и offline-релизом; это контроль согласованности пакета, не подпись издателя.
