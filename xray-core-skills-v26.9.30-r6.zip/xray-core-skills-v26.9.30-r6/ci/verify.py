#!/usr/bin/env python3
"""Explicit CI entry point. Default: package + unit tests only.
Core/source execution requires flags and trusted files. Creates a NEW private output directory.
Building/testing Go may fetch the Go toolchain and Go modules; it is never automatic.
"""
from __future__ import annotations
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPTS=ROOT/'skills/xray-source-audit/scripts'
sys.path.insert(0,str(SCRIPTS))
from run_lab import capture
from source_probe import probe

GO_PACKAGES=['./infra/conf','./transport/internet/tcp','./transport/internet/splithttp','./transport/internet/kcp','./transport/internet/grpc','./transport/internet/websocket','./transport/internet/httpupgrade','./transport/internet/hysteria','./transport/internet/masque','./transport/internet/xdrive','./transport/internet/finalmask/...','./app/dns','./app/router','./app/observatory/...']

def main() -> int:
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--out',type=Path,required=True);a.add_argument('--source',type=Path)
    a.add_argument('--xray',type=Path);a.add_argument('--xray-sha256');a.add_argument('--nginx',type=Path)
    a.add_argument('--run-r6-regressions',action='store_true')
    a.add_argument('--run-r5-regressions',action='store_true');a.add_argument('--run-regressions',action='store_true');a.add_argument('--run-control',action='store_true');a.add_argument('--run-extended',action='store_true');a.add_argument('--run-dns',action='store_true');a.add_argument('--run-core',action='store_true');a.add_argument('--run-go-tests',action='store_true');a.add_argument('--build-core',action='store_true')
    args=a.parse_args();out=args.out.absolute()
    if out.exists() or out.is_symlink():a.error('--out must be a NEW directory')
    if (args.run_go_tests or args.build_core) and not args.source:a.error('trusted --source required')
    if args.build_core and args.xray:a.error('choose local build OR supplied binary')
    if (args.run_core or args.run_extended or args.run_dns or args.run_regressions or args.run_control or args.run_r5_regressions or args.run_r6_regressions) and not args.build_core and (not args.xray or not args.xray_sha256):a.error('--run-core requires trusted --xray + --xray-sha256 or --build-core')
    out.mkdir(parents=True,mode=0o700);report={'status':'RUNNING','steps':[],'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    failed=False
    def step(label,argv,cwd=ROOT,timeout=90):
        nonlocal failed
        r=capture(argv,cwd,out/(label+'.log'),timeout);r['name']=label;report['steps'].append(r)
        if r['status']!='PASS':failed=True
        return r['status']=='PASS'
    try:
        step('package',[sys.executable,str(ROOT/'verify_package.py')])
        step('unit-tests',[sys.executable,'-m','unittest','discover','-s','tests','-v'])
        if args.source:
            source=args.source.resolve(strict=True);provenance=json.loads((SCRIPTS.parent/'references/provenance.json').read_text())
            r=probe(source,provenance);(out/'source-probe.json').write_text(json.dumps(r,indent=2));report['steps'].append({'name':'source-probe','status':'PASS' if r['status']=='MATCH' else 'FAIL'})
            if r['status']!='MATCH':failed=True
        binary=args.xray.resolve(strict=True) if args.xray else None;digest=args.xray_sha256
        if not failed and (args.build_core or args.run_go_tests):
            go=shutil.which('go')
            if not go:raise ValueError('Go executable unavailable')
            # No shell; no git checkout/reset, no mutation of tracked source (-mod=readonly).
            if args.run_go_tests:step('go-tests',[go,'test','-mod=readonly','-count=1','-timeout=120s',*GO_PACKAGES],source,900)
            if args.build_core:
                binary=out/('xray.exe' if os.name=='nt' else 'xray')
                if step('go-build',[go,'build','-mod=readonly','-trimpath','-o',str(binary),'./main'],source,900):digest=hashlib.sha256(binary.read_bytes()).hexdigest()
        ready=not failed
        if args.run_core and ready:
            lab=out/'lab'
            if step('build-lab',[sys.executable,str(SCRIPTS/'build_lab.py'),'--out',str(lab),'--all'],timeout=180):
                cmd=[sys.executable,str(SCRIPTS/'run_lab.py'),str(lab),'--xray',str(binary),'--sha256',digest,'--allow-lab-execution','--load-requests','12','--report',str(out/'runtime.json')]
                if args.nginx:cmd+=['--nginx',str(args.nginx.resolve())]
                step('core-config-cases',[sys.executable,str(SCRIPTS/'core_config_cases.py'),str(lab),'--xray',str(binary),'--sha256',digest,'--allow-core-test','--out',str(out/'core-config-cases')],timeout=180)
                step('core-lab',cmd,timeout=1800)
        else:report['steps'].append({'name':'core-lab','status':'NOT_RUN','reason':'not requested or prior check failed'})
        for requested,label,filename in [(args.run_r6_regressions,'r6-regressions','run_r6_regressions.py'),(args.run_r5_regressions,'r5-regressions','run_r5_regressions.py'),(args.run_extended,'extended-lab','run_extended_lab.py'),(args.run_dns,'dns-lab','run_dns_lab.py'),(args.run_regressions,'r4-regressions','run_r4_regressions.py'),(args.run_control,'control-lab','run_control_lab.py')]:
            if requested and ready:
                step(label,[sys.executable,str(SCRIPTS/filename),'--xray',str(binary),'--sha256',digest,'--execute','--out',str(out/label)],timeout=900)
            else:report['steps'].append({'name':label,'status':'NOT_RUN','reason':'not requested or prerequisite failed'})
        diagnostic=out/'r6-regressions/report.json'
        known_runtime=False
        if diagnostic.is_file():
            detail=json.loads(diagnostic.read_text())
            known_runtime=detail.get('status')=='PASS_EXPECTATIONS_WITH_KNOWN_RUNTIME_FAILURES'
            report['r6_observations_status']=detail.get('status')
        report['runtime_acceptance']='KNOWN_FAILURES' if known_runtime else 'NOT_CERTIFIED'
        report['status']='FAIL' if failed else ('PASS_CHECKS_WITH_KNOWN_RUNTIME_FAILURES' if known_runtime else 'PASS_REQUESTED_CHECKS')
    except (OSError,ValueError,subprocess.TimeoutExpired) as e:
        report.update(status='FAIL_PRECONDITION',reason=type(e).__name__);failed=True
    finally:
        p=out/'ci-report.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');p.chmod(0o600)
    print(report['status']+' — '+str(p));return 1 if failed else 0
if __name__=='__main__':raise SystemExit(main())
