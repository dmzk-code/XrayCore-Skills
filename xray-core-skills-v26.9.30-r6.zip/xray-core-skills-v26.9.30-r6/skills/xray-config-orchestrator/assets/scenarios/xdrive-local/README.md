# xdrive-local

XDRIVE в общей локальной тестовой папке; не cloud benchmark.

server.json/client.json — **полные структуры, но TEMPLATE_NOT_DEPLOYABLE до подстановки `{{...}}`**. Локальный runnable вариант: `build_lab.py --scenario xdrive-local --out <новая папка>`. Генератор выбирает порты, выпускает свежие тестовые credentials/cert и negative-auth.json. Порты в текстовых assets примерные и независимые между сценариями; не запускать все шаблоны без генератора.

Этот renderer испытан реальным pinned ядром: [таблица и ограничения](../../../../xray-runtime-validation/references/known-issues.md). Новая материализация получает NOT_RUN до своего запуска. Лабораторные finalRules разрешают только127.0.0.1 high ports, затем блокируют остальное. MASQUE дополнительно перенаправляет виртуальное назначение198.18.0.1 к loopback echo. Не переносить эти правила/секреты в production.
