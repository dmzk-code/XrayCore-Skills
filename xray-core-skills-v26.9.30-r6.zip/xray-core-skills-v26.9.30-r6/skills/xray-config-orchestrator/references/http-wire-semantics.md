# HTTP wire-семантика: не сравнивать JSON буквально

Источники: [XHTTP Build](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go), [формирование запросов](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/config.go), [server](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/hub.go), [padding](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/xpadding.go), [Host](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/internet.go), [MASQUE client](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/dialer.go), [MASQUE listener/matcher](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/hub.go).

## XHTTP: активные и неактивные поля
Сначала вычислить эффективный объект после `extra`, затем mode. Auto обычно даёт packet-up; с REALITY — stream-one, а с downloadSettings — stream-up. Для stream-one нет sessionID/seq. Для stream-up есть sessionID, но нет packet seq. Сравнивать placement/key следует только у реально отправляемых метаданных. При этом даже неактивная placement может влиять на добавление завершающего `/` в нормализованный base path — учитывать отдельно.

HTTP header имена не чувствительны к регистру: `X-Session` и `x-session` эквивалентны. Cookie и query keys регистрозависимы. Для placement=path поле key не используется и может различаться без изменения wire. Непустой пользовательский sessionIDTable должен быть пригоден для выбранного размещения и иметь достаточную энтропию; JSON Build ещё не подтверждает прохождение любых символов через CDN/HTTP library.

Клиентский uplinkDataPlacement=auto передаёт данные в body. Сервер auto пробует поддерживаемые места и объединяет payload; сервер body совместим с клиентом auto. Для packet header/cookie согласовать **эффективный** dataKey, включая default X-Data/x_data. Эти правила не требуют одинакового значения строкового поля на обеих сторонах.

`scMaxEachPostBytes` при отсутствии/нулевом значении —1000000, это не более маленькое скрытое значение для cookie/header. Для переноса данных в headers/cookies лимиты сервера/прокси нужно задавать и проверять явно. POST-limit не является проверкой stream-one/stream-up, где packet-up отправитель не работает.

## Padding
Default xPaddingBytes=100..1000; если одна сторона опустила поле, её диапазон **всё равно участвует** в проверке. Repeat-x измеряется количеством bytes строки, tokenish — HPACK Huffman encoded length с допуском±2. Разные методы нельзя подтверждать простым сравнением двух чисел. Legacy и obfs имеют разные ветки извлечения, а наличие Referer может иметь приоритет над другими полями.

В obfs сервер проверяет cookie по key, затем заданный header, затем query. Поле xPaddingPlacement у сервера меняет трактовку header (raw либо URL+query), но само по себе не запрещает cookie/query. Поэтому клиент cookie и сервер query могут быть согласованы. Для header важны совпадающие header name и способ декодирования; для queryInHeader — также key. Клиентские произвольные headers могут создавать коллизии с метаданными/padding: результаты сверки стандартно сформированных запросов не являются симулятором всех перезаписей в HTTP-прокси.

## Host
RAW/XHTTP/WebSocket/HTTPUpgrade не имеют одного общего универсального Host механизма. Для HTTP-транспортов, где вызывается IsValidHTTPHost, сравнение case-insensitive; порт удаляется **только из request Host**, не из server config host. На сервере не писать host:port и не ожидать wildcard `*.example`. Клиентский fallback: explicit host → security serverName → адрес protocol endpoint. У WebSocket старый headers.Host мигрирует в host, если самостоятельное поле пустое.

Обычный RAW dialer получает destination от protocol handler; его streamSettings.address не следует объявлять универсальным переключателем адреса. XHTTP downloadSettings и XDRIVE storage имеют собственные consumer-ветки. Для Browser Dialer сформированный URL и нестандартный порт проверять отдельно.

## MASQUE
Пустой path означает `/.well-known/masque/ip/*/*/`. Builder подставляет target/ipproto в поддерживаемые URI-шаблоны, затем server matcher сравнивает **decoded path и всю query-map**. Это не wildcard-префикс. Перестановка query keys эквивалентна, порядок значений повторяющегося ключа — значим. Не отбрасывать query при peer-check.

Клиент выбирает h2 только если ALPN содержит h2 и **не содержит h3**. Иначе h3. Сервер создаёт h2 listener при наличии h2, h3 listener при наличии h3 или отсутствии h2. Таким образом сервер с [h2,h3] открывает TCP и UDP, а клиент с тем же списком выбирает h3, независимо от первого элемента. Это отличается от правил XHTTP ALPN. Для h2 MASQUE использует uTLS/Go TLS согласно fingerprint; h3 использует QUIC TLS. Не переносить uTLS minVersion-политику на QUIC автоматически.

`validate.py --peer` проверяет прямую пару. При TLS termination, URI rewrite, раздельном download endpoint, Browser Dialer или стороне другого ядра нужны явно описанные physical hops и самостоятельные wire-тесты.
