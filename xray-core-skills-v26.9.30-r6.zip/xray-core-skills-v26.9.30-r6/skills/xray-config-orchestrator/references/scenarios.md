# Полные пары и генератор лаборатории

22 сценария, 45 конфигурационных файлов Xray в assets (22 пары + relay). Токены в assets не скрывают отсутствие production credentials: они намеренно обязательны. `build_lab.py` материализует рабочие входные JSON для теста в новой приватной папке и запускает статическую проверку; это не запуск Xray.

| Имя | Назначение |
|---|---|
| `raw-none` | VLESS RAW, только loopback; без защиты |
| `raw-tls` | VLESS RAW TLS с pin |
| `raw-vision-tls` | VLESS Vision RAW TLS1.3 |
| `raw-reality` | VLESS Vision RAW REALITY с локальным TLS target |
| `raw-fragment-tls` | RAW TLS с клиентской fragmentation ClientHello |
| `xhttp-packet-h1` | XHTTP packet-up HTTP/1.1 loopback |
| `xhttp-stream-h2` | XHTTP stream-up HTTP/2 |
| `xhttp-one-h2` | XHTTP stream-one HTTP/2 |
| `xhttp-packet-h3` | XHTTP packet-up HTTP/3 UDP |
| `xhttp-header-h2` | XHTTP packet-up payload в header, небольшие POST |
| `xhttp-split-nginx` | Два HTTP frontend плеча к одному XHTTP listener; loopback |
| `mkcp-tls` | VLESS mKCP TLS поверх UDP |
| `grpc-tls` | VLESS gRPC Tun с TLS |
| `grpc-multi-tls` | VLESS gRPC TunMulti с TLS |
| `websocket-tls` | VLESS WebSocket с TLS |
| `websocket-ed-tls` | WebSocket early data, ed=2048 |
| `httpupgrade-tls` | VLESS HTTPUpgrade с TLS |
| `hysteria2` | Нативный Hysteria2, два блока version=2 |
| `masque-h2` | Нативный MASQUE CONNECT-IP HTTP/2 |
| `masque-h3` | Нативный MASQUE CONNECT-IP HTTP/3 |
| `xdrive-local` | XDRIVE в общей локальной тестовой папке; не cloud benchmark |
| `chain-raw-tls` | Два RAW TLS узла, второй через dialerProxy первого |

## Команды из корня пакета
```bash
python skills/xray-source-audit/scripts/build_lab.py --out ./lab-new --all
python skills/xray-source-audit/scripts/validate.py ./lab-new/raw-tls/client.json --peer ./lab-new/raw-tls/server.json --json
python skills/xray-source-audit/scripts/run_lab.py ./lab-new --xray /absolute/path/to/xray --allow-lab-execution --report ./runtime-report-new.json
```

Для split-nginx добавить `--nginx /absolute/path/to/nginx`; иначе ровно этот сценарий NOT_RUN. REALITY использует OpenSSL s_server на loopback; OpenSSL нужен генератору. `--load-requests 40` включает короткую проверку с4 workers, это не benchmark.

В lab root нельзя заранее создавать папку: генератор отказывается перезаписывать существующую. После генерации не редактировать fixture вручную для того же manifest: runner сравнивает SHA256. Для иной конфигурации создать отдельный сценарий/manifest, явно расширив безопасную модель стенда.

## Что именно доказывает каждый уровень
Static validation подтверждает реализованные авторские проверки. run -test отдельный, listener-start не равен data transmission. Runner проверяет payload TCP и UDP, неверный auth с положительным контролем, новые соединения после рестарта server. Не сохраняет существующие сессии через рестарт, не испытывает CDN, packet loss/netem или ОС смартфона. Эти результаты остаются NOT_RUN до отдельных испытаний.
