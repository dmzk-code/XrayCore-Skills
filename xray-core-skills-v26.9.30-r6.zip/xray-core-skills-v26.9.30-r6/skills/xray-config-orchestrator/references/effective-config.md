# Эффективная конфигурация: где параметры действительно работают

| Объект | Приоритет / семантика |
|---|---|
| StreamConfig | `method`, если не null, заменяет `network`; отсутствие выбора → RAW/TCP |
| RAW/TCP | `rawSettings` заменяет весь `tcpSettings`, не сливает |
| XHTTP | `xhttpSettings` заменяет весь `splithttpSettings` |
| XHTTP extra | Присутствующий `extra`, включая JSON null, декодируется в новый SplitHTTPConfig; только внешние host/path/mode возвращаются сверху. Остальные внешние расширенные поля исчезают |
| Security | `security` выбирает ровно одну реализацию. Наличие tlsSettings/realitySettings без соответствующего выбора не включает защиту |
| REALITY | target заменяет dest; client password при непустом значении заменяет publicKey. Ветка server/client определяется наличием dest/target, не местом в inbounds/outbounds |
| VLESS/Hysteria/MASQUE inbound | clients, если не nil, заменяет users, включая пустой массив |
| VLESS outbound | верхнее address включает simplified style и заменяет vnext; иначе ровно один vnext и один user |
| Routing | outboundTag выигрывает у balancerTag; domains заменяет domain; sourceIP выигрывает у source |
| DNS | непустой expectedIPs выигрывает; иначе используется expectIPs. server-specific pointer bool может переопределять глобальную настройку false |
| Sudoku | пустые camelCase строки/списки и нулевые padding используют legacy snake_case fallback; одновременно не писать |
| XHTTP XMUX | defaults всей группы только при полностью нулевом объекте; частичное заполнение не означает merge с preset |
| XDRIVE | runtime ограничивает concurrency до 64, segmentBytes до 16 MiB; нули включают defaults. Template concurrency — отдельный лимит 256 |

Значение `0` не универсально означает «выключить»: tcpFastOpen=false явно отключает опцию, missing не вызывает setsockopt; mKCP pointer=0 участвует в проверках; QUIC keepalive=0 имеет разные defaults у транспортов. `null` для указателя и `null` для числового Go-поля тоже нельзя моделировать одной схемой. Для безопасного авторинга избегать null, кроме явно изученных случаев; валидатор помечает это как AUTHORING_POLICY.

Ошибки распознавания и неактивность различаются. Go encoding/json часто игнорирует незнакомые имена; отсутствие ошибки не означает действие параметра. Неизвестное значение некоторых enum становится default (например routing.domainStrategy), поэтому генератор проверяет опечатки строже.

`Int32Range` в JSON — integer или строка `a-b`, не `{from,to}`. Границы сортируются helper, отрицательные числа синтаксически возможны; допустимость определяется полем. Не полагаться на переполнение/negative cast. `StringList` может быть массивом или comma-separated строкой; в новых файлах использовать массив.

Транспортные settings, даже не выбранные network, могут пройти собственный Build и вызвать ошибку. Ненужные блоки удалять, а не сохранять как выключенные комментарии. JSON-дубликаты запрещены нашим авторингом, даже если один парсер выбирает последнее значение.


## Первичные источники pinned commit
- [infra/conf/transport_internet.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_internet.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [infra/conf/transport_security.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_security.go)
- [infra/conf/vless.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/vless.go)
- [infra/conf/router.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/router.go)
- [infra/conf/dns.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/dns.go)
- [infra/conf/common.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/common.go)


## Полная конфигурация и merge файлов
MASQUE transport связан с masque protocol и на client, и на server. Native masque запрещает enabled Mux. Root reverse nonnil возвращает removed-feature error; глобальный transport с непустой map также удалён.

В Config.Override новые inbounds/outbounds с совпавшим tag заменяют запись. Новые outbounds обычно вставляются в начало; если имя входящего файла содержит `tail` (case-insensitive), добавляются в конец. Порядок меняет default outbound. Routing/DNS/Policy при merge заменяются целыми блоками, не deep-merge полей; env map накладывается по ключам. Перед аудитом нескольких JSON получить эффективный объединённый конфиг и не считать независимые файловые проверки достаточными.

Config.Build применяет root env через os.Setenv. Поэтому даже `run -test` выполняется отдельным процессом в лаборатории, а env из произвольного конфига не разрешается менять родительский агент.


## Основание на закреплённом commit
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)
`extra:null` — json.RawMessage, а не Go pointer: декодируется в нулевую новую структуру и так же теряет внешние advanced fields. В отличие от этого method:null, rawSettings:null, xhttpSettings:null не активируют pointer alias. Normalization в checker выполняется на копии, исходный JSON не изменяется.

## несколько файлов и parse-time env
[Composition](composition.md) · [HTTP wire](http-wire-semantics.md) · [VMess/Trojan и Encryption](../../xray-protocol-composition/references/vmess-trojan.md). В r5 эти правила реализованы в composer/peer-check и отдельных native regressions.
