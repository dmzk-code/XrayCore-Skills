# Совместимость v26.9.30: Build не равен runtime

Все строки ниже — выводы из указанного кода, не сетевые PASS. Реальные L1–L5 сохраняются отдельно.

| Transport | Внешнее соединение | none | TLS | REALITY | Основная оговорка |
|---|---|---|---|---|---|
| RAW/TCP | TCP | Есть | Есть | Есть | Header authenticator поверх security; не HTTP reverse proxy |
| XHTTP | TCP H1/H2 или UDP H3 | Native client H1 | H1/H2/H3 по алгоритму ALPN | Native H2 | H3 только ровно [h3], auto — не negotiation/failover |
| mKCP | UDP + надёжный поток | Есть | Оборачивает KCP session TLS с обеих сторон | Build запрещает | tls.Client, не TCP uTLS-путь; `seed/header` устаревшего блока inert |
| gRPC | TCP/H2 | Есть, для доверенного backend | Есть | Есть | Deprecated warning; listener запускает bind асинхронно |
| WebSocket | TCP/H1.1 | Есть | Есть | Build запрещает | Native не становится H2 по одному ALPN |
| HTTPUpgrade | TCP/H1.1 | Есть | Есть | Build запрещает | Не WebSocket framing; строгие Upgrade/Connection |
| Hysteria v2 | UDP/QUIC/H3 | Не генерировать: нужен TLS runtime | Есть | Build запрещает | native protocol и transport version/auth раздельны |
| MASQUE | TCP/H2 и/или UDP/H3 | Runtime требует TLS | Есть | Build запрещает | Native masque inbound обязателен; CONNECT-IP, не VLESS stream |
| XDRIVE | storage API / local | Не значит отсутствие HTTPS к API | Управляет HTTPS API | Build запрещает | HTTPS storage != end-to-end шифрование объектов |

## VLESS / Vision / Encryption
VLESS с encryption=none без stream security не допускается к публичному IP/domain согласно `validateOutboundTransportSecurity`; private classification делается geodata ядра. Статический Python `ipaddress.is_private` не является его точной заменой. В loopback fixtures plain разрешается только как тест. Trojan имеет аналогичный public/no-TLS guard.

VLESS Vision — не transport/security. Без VLESS Encryption код требует непосредственно TLS/REALITY connection при TCP/Rvs/Mux. Для обычных RAW TLS/REALITY это ожидаемая обёртка; для XHTTP/WS/gRPC/HTTPUpgrade поверх TLS наружу возвращается другой transport connection и простой Vision не следует считать совместимым. У mKCP TLS действительно возвращается TLS wrapper, поэтому нельзя объявить тотальный запрет лишь по network=mkcp; splice/производительность этой комбинации отдельно не подтверждены.

При VLESS Encryption сначала создаётся `encryption.CommonConn`, который Vision обрабатывает отдельной веткой: наличие non-RAW или XOR запрещает проникновение splice, но не автоматически весь Vision. Такие схемы требуют согласованных encryption/decryption и теста, а не запрета «любой non-RAW» и не обещания zero-copy. TLS Vision inbound проверяет TLS 1.3.

Inbound flow: пусто или `xtls-rprx-vision`; outbound дополнительно `xtls-rprx-vision-udp443`. Суффикс — клиентская политика UDP/443, не значение для server account. Обычный TCP Mux для Vision конфликтует с серверной веткой; XUDP — отдельный UDP-путь, не тот же запрет. Без необходимости outbound.mux не добавлять.

MASQUE transport не универсальный net.Conn stream: inbound Build прямо запрещает его вне protocol=masque. Hysteria native users проверяются native handler; transport auth для инкапсулируемого протокола и native auth имеют разные назначения.

## HTTP и инфраструктура
`[h2,h3]` у XHTTP означает выбор H2, у MASQUE клиента H3, у MASQUE сервера TCP+UDP listeners. Не называть список ALPN резервированием. REALITY через обычное HTTP TLS-termination несовместим с сохранением end-to-end handshake: frontend должен быть L4 passthrough или схема должна быть иной.

Split XHTTP: upload/download должны сходиться в одну session map одного Listener. Даже два inbounds одного процесса нельзя считать общей session map. Разные внешние домены/порты допустимы как маршруты к одному backend listener; sticky routing должно учитывать session ID placement, а не только IP.

Таблица не утверждает совместимость сторонних клиентов. Проверять их ядро, поддерживаемый JSON/URI import и возможность передать расширения (extra, downloadSettings, Finalmask). Панель может отбрасывать поля ещё до Xray.


## Первичные источники pinned commit
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)
- [infra/conf/vless.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/vless.go)
- [proxy/vless/outbound/outbound.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vless/outbound/outbound.go)
- [proxy/vless/inbound/inbound.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vless/inbound/inbound.go)
- [transport/internet/kcp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/dialer.go)
- [transport/internet/kcp/listener.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/listener.go)
- [transport/internet/masque/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/dialer.go)
- [transport/internet/masque/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/hub.go)
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
