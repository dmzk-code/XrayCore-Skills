# Контракт согласования пары — r4

`validate.py client.json --peer server.json --outbound-tag TAG --inbound-tag TAG` — **read-only static check**, не попытка сетевого соединения. Указать теги обязательно, если выбор неоднозначен. Сначала проверить каждый файл самостоятельно; peer-check не подменяет полную структурную проверку.

## Что сравнивается

Протокол, транспорт, эффективные настройки и flow; VLESS ID после нормализации; native Hysteria/MASQUE auth; XHTTP path/mode/metadata/payload key и диапазоны POST; gRPC реальные RPC-пути; WebSocket/HTTPUpgrade host/path; REALITY role, shortId, SNI, X25519-пара; пересечение TLS-версий; порядок декодирующих масок и параметры выбранных масок.

VLESS короткая строка 1..30 **UTF-8 bytes** превращается в UUIDv5 через SHA1 нулевого 16-байтового namespace и исходных байтов. Регистр короткой строки значим. 31 byte не принимается. Это формат идентификатора Xray, не общее правило Python UUID; UUID и эквивалентная короткая строка должны сопоставляться. Checker намеренно не допускает неканонические строки с хвостом, которые permissive legacy-парсер может прочитать частично. Источник: [uuid.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/common/uuid/uuid.go).

REALITY shortId дополняется нулями до 8 bytes, поэтому `ab` и `ab00000000000000` эквивалентны. Клиентский `password` имеет приоритет только когда непуст; иначе используется legacy `publicKey`. SNI при пропуске берётся из адреса назначения. Публичная часть выводится из приватной через библиотеку `cryptography`, а не самописную реализацию X25519. Нет зависимости — выводится `PEER_CRYPTO_UNVERIFIED`, **не PASS ключей**. Для локальной сверки установить optional `requirements-crypto.txt` из корня пакета. Проверенный вариант — cryptography 46.0.4. Никакие приватные значения не печатаются. ML-DSA seed/verify требует отдельной проверки; X25519 его не подтверждает.

У gRPC `serviceName` с начальным `/` задаёт custom RPC paths. На сервере последняя часть может быть `TunName|MultiName`; клиенту нужен соответствующий реальный путь, а не буквальное равенство serviceName. URL-escaping воспроизводится отдельно. Источник: [grpc/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/config.go).

Для Finalmask выбирается **физическая сеть**, в частности MASQUE/H2 — TCP, MASQUE/H3 — UDP. Исключаются из требования двустороннего равенства fragment/noise/клиентский udphop. Декодирующие маски должны совпасть по порядку; проверяются пароли, Salamander-vs-Gecko, normalized Sudoku table set и ASCII, legacy mKCP framing, определения custom header, XMC profiles. Разное padding Sudoku допустимо. Эквивалентные, но записанные по-разному custom expressions могут потребовать ручного wire-теста, поэтому их не следует молча объявлять несовместимыми ядром.

## Чего не означает отсутствие ERROR

Checker не открывает `certificateFile`, не проверяет SAN/срок/цепочку/pin из файлов; для этого нужен реальный TLS handshake в доверенной лаборатории. Не выполняются скрытые HTTP-запросы, DNS-запросы и чтение переменных окружения. При сертификатах, ML-DSA, неопределённом frontend или carrier-топологии сохраняется предупреждение COVERAGE.

Изменяющий Host/path/HTTP-version обратный прокси моделируется отдельным узлом. Нельзя применять прямое сравнение wire-параметров к неизвестному преобразованию и выдавать ERROR за доказанный запрет схемы. `downloadSettings` второго XHTTP-плеча сравнивать с его фактическим endpoint и тем же session-owner.

Не объявлять, что «всё учтено» по числу тестов или полей. Для конкретного результата выводить: `STATIC`, `KEY_PAIR`, `CORE_CONFIG`, `TCP`, `UDP`, `RECONNECT`, `NEGATIVE_AUTH`, `LOAD`, `ENVIRONMENT`, каждое со статусом и источником. `NOT_RUN` не заменять на PASS, а известные runtime FAIL не подавлять.

## TLS copyConfig: результат отрицательного теста
RAW с пустым fingerprint использует Chrome uTLS. В copyConfig не переносятся MinVersion/MaxVersion, CipherSuites, CurvePreferences и session-resumption settings. Поэтому пересечение JSON min/max не является доказательством ни ограничения, ни несовместимости uTLS-клиента. r4 обнаружил это реальным соединением: клиент minVersion=1.3 успешно передал данные серверу maxVersion=1.2. При fingerprint=unsafe (ветка обычного Go TLS, не отключение проверки сертификата) несогласованная пара отвергается. Checker помечает неприменённую policy предупреждением UTLS_FIELDS_NOT_COPIED, а не ошибкой якобы невозможного handshake. Не использовать это как совет понижать безопасность: ограничение TLS при необходимости обеспечить сервером и проверить negotiated version.

Это правило подтверждено для GetFingerprint→UClient в RAW, gRPC, WebSocket, HTTPUpgrade и XHTTP/H1–H2. Не переносить его без проверки на QUIC/H3 и mKCP, которые используют другие ветки. Источник: [tls.go copyConfig/GetFingerprint](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tls/tls.go).

## HTTP wire-семантика и protocol auth
[Composition](composition.md) · [HTTP wire](http-wire-semantics.md) · [VMess/Trojan и Encryption](../../xray-protocol-composition/references/vmess-trojan.md). В r5 эти правила реализованы в composer/peer-check и отдельных native regressions.
