# Единый контракт r6

## Что является результатом
Рабочая единица — согласованный комплект сторон и проверяемая топология, а не большой JSON. Формат финального набора: `client.json`, `server.json` (для цепочки — каждый relay), `topology.json`, `peer-map.md`, `ASSUMPTIONS.md`, `VALIDATION.json`, `rollout.md`. Frontend-конфигурация включается, когда он участвует в схеме. Для правки существующего решения приложить diff; не менять остальную архитектуру без необходимости.

## Версионность
Пакет знаний 6.0.0/r6; core v26.9.30, pre-release; commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`; дата ревизии 2026-10-07. go.mod закрепляет Go 1.27, grpc-go 1.84.0, apernet/quic-go commit 184d081eef3e, REALITY commit 8cdf7bf9c7f0. Default зависимой библиотеки нельзя переносить из другой версии.

Версия панели, приложения и вшитого ядра — три отдельных факта. Сохранить `xray version`, SHA256 бинарника, GOOS/GOARCH, даты и отметку модифицированной сборки. Одинаковая версия на баннере не доказывает одинаковые байты. Snapshot не обновляется сам: сначала diff исходников и тестов, затем новая ревизия знаний.

## Доказательства без смешения уровней
`SOURCE_BUILD` — правило JSON → Build; `SOURCE_RUNTIME` — прочитана ветка потребителя; `OBSERVED_RUNTIME` — результат конкретного исполняемого стенда, не обобщённая гарантия; `INFERENCE` — вывод из кода с условиями; `AUTHORING_POLICY` — намеренно более строгая инженерная рекомендация; `NOT_RUN` — проверка не запускалась. `PASS` допустим только у реально запущенного теста, с командой, датой, средой и exit code. Не повышать SOURCE до PASS.

L0: строгий JSON, дубли ключей, статические межполевые проверки, граф и peer-map. L1: точный Xray `run -test`. L2: запуск и фактические listeners. L3: handshake + полезный TCP и UDP + отрицательный auth. L4: restart/reconnect, отказ upload/download/frontend/relay и переключение. L5: длительная нагрузка, CPU/RSS/FD, latency/error rate, квоты и целевая ОС. Каждый уровень хранится отдельно; непройденный L1 не позволяет записать L3=PASS. L0 пакета может быть строже и неполнее Go-парсера.

## Карточка каждого поля
Полный JSON path; scope (client/server/both); Go/JSON type; unit; enum/range; отличие missing/null/zero/false/empty; alias and priority; применяющий consumer; зависимые поля; Build-error против inert/runtime-error; минимальный позитивный и негативный пример. Не делать вывод о поддержке по одному proto/комментарию. Для глобальной настройки учитывать, какой транспорт читает её, а не только успешный Build.

## Режим безопасного создания
Не использовать пользовательские privateKey, auth, OAuth refresh token и полный subscription URL в логах. Тестовые секреты генерировать локально; отчёты должны содержать только путь, код ошибки и обезличенный контекст. Не изменять системный resolver, routing table, firewall, сервисы, чужие процессы и рабочий git checkout. Loopback-стенд — изоляция endpoints, не аппаратная песочница: запускать доверенный core.

Полностью конкретный пример может быть лабораторным, но не production-ready. В шаблонах незаданные значения маркировать `{{...}}` или `REPLACE_...`, статус `TEMPLATE_NOT_DEPLOYABLE`; статические проверки не превращают placeholders в реальные credentials. Для публичного endpoint обязательны проверенная транспортная защита или валидное VLESS Encryption и отдельный анализ identity. Публичный SOCKS без auth запрещён политикой генератора.

## Приёмка сложной схемы
Peer-map содержит protocol/auth, transport, path/authority/host, TLS identity/REALITY keys, ALPN и фактическую версию HTTP, маски/их порядок, upload/download session-owner, DNS bootstrap, outbound tags. Не все поля должны быть симметричны: разделять локальный лимит и peer-параметр. Пустой server Host допускает больше запросов, а `client.host != server.host` не всегда означает сравнение побайтовых строк: учитывать конкретный matcher.

Management access не должен зависеть от тестируемого туннеля. До rollout сохранить рабочий набор и команды rollback; проверять не только достижимость сервера, но и полезный трафик и наблюдаемость. Без отдельного разрешения не перезапускать production.


## Первичные источники pinned commit
- [go.mod](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/go.mod)
- [infra/conf/transport_internet.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_internet.go)
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)

Результаты опубликованного набора: [runtime evidence](../../xray-runtime-validation/references/runtime-evidence.json) и [known issues](../../xray-runtime-validation/references/known-issues.md). Для новой пользовательской схемы эти статусы не наследуются.

## Дополнительные обязательные проверки r6
[Топология, PROXY REQUIRE, пересечения и виртуальные tags](topology-and-listeners.md); [proxy edges и действующая авторизация](../../xray-protocol-composition/references/local-proxy-edges.md). Для нового решения публичный noauth HTTP-край запрещён так же, как SOCKS. Внутренние числа объектов/полей сверяются с registry, а не копируются из прошлого релиза; отчёты исторических запусков не переименовываются в текущие.
