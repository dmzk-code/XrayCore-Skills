# Общая конфигурация: управление, ресурсы и наблюдаемость

Область: исходники Xray-core v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Это результат чтения кода, не обещание работоспособности внешней среды. Типы полей находятся также в `../../xray-source-audit/references/knowledge-index.json`.

## Корень и контейнеры inbound/outbound

`inbounds`/`outbounds` — массивы объектов. `protocol` и `tag` — строки, `settings` — объект конкретного протокола, `streamSettings` — сосед `settings`, не его содержимое. `listen`, `port`, `sniffing` относятся к inbound. `sendThrough`, `mux`, `targetStrategy` — к outbound. Не переносить опции одного направления в другое.

`listen` принимает IP, `localhost`, абсолютный Unix-путь или `@`-имя абстрактного сокета. Произвольный домен сервером не принимается. IP-listener требует `port`. Unix-listener игнорирует заданный `port`. TUN не требует порта. `port` — число либо строка портов/диапазонов через запятую, **не массив**. Для безопасного авторинга используйте 1..65535, непустые возрастающие диапазоны. Парсер PortList местами более permissive: запрет нуля/переполнения в нашем checker — защитное правило, не утверждение, что все такие числа отклоняет Build.

Список зарегистрированных inbound: `tunnel`, `dokodemo-door`, `http`, `shadowsocks`, `mixed`, `socks`, `vless`, `vmess`, `trojan`, `wireguard`, `hysteria`, `masque`, `tun`. Outbound: `block`, `blackhole`, `loopback`, `direct`, `freedom`, `http`, `shadowsocks`, `socks`, `vless`, `vmess`, `trojan`, `hysteria`, `masque`, `dns`, `wireguard`. Регистрация протокола не означает поддержку каждого транспорта. `tun` — протокол/интерфейс, `udp` — физическая сеть; не создавать для них фиктивный десятый транспортный скилл.

`env:NAME` распознаётся Address/PortList при JSON-декодировании. Корневой `env` применяется в Config.Build позже. Не предполагать, что поздняя запись в корневом `env` подставит адрес, уже прочитанный парсером. Offline-checker намеренно не читает окружение агента и помечает эти значения как неразрешённые.

Источники: [xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go), [common.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/common.go).

## Sniffing

Поля: `enabled`, `metadataOnly`, `routeOnly` — boolean; `destOverride`, `domainsExcluded`, `ipsExcluded` — StringList. StringList допускает массив строк или разделённую запятыми строку; пробелы автоматически не удаляются. У `destOverride` принимаются `http`, `tls`, `https`, `ssl`, `quic`, `fakedns`, `fakedns+others`; TLS-алиасы нормализуются в `tls`, оба FakeDNS-значения — в `fakedns`.

Не путать идентификацию назначения для маршрутизации с его фактической подменой. `metadataOnly` не даёт распознавания TLS/HTTP из payload. Для FakeDNS одновременно согласовать пул адресов, DNS, перехват и обратное восстановление имени. Включение `destOverride` само по себе не создаёт этот тракт. Отрицательный тест должен включать обычный IP, неизвестный fake-IP и исключённое имя; sniffing не использовать как авторизацию пользователя.

## API: два взаимоисключающих способа доступа

Поля `api.tag` и `api.listen` — строки, `api.services` — массив строк. `tag` обязателен даже при наличии `listen`. Распознаются без учёта регистра: `HandlerService`, `LoggerService`, `StatsService`, `ObservatoryService`, `RoutingService`, `ReflectionService`. Неизвестное имя Build **молча пропускает**; наш валидатор выдаёт ERROR, чтобы исключить ложное ожидание зарегистрированной службы.

При непустом `listen` Commander создаёт самостоятельный TCP/Unix-listener и возвращается **до** создания виртуального outbound. Поэтому маршрут `outboundTag: api.tag` в такой схеме не появляется автоматически. При отсутствии `listen` создаётся виртуальный handler с `api.tag`; его можно достичь отдельным локальным inbound и routing. Совпадающий пользовательский outbound удаляется при старте Commander — теги должны быть уникальны.

Commander создаёт `grpc.NewServer()` без собственных параметров TLS/auth. Не выставлять API в публичную сеть, не считать приватный IP достаточной авторизацией. Использовать loopback/Unix и отдельно контролируемый административный доступ. `ReflectionService` облегчает обнаружение RPC, но не создаёт контроль доступа.

Источники: [api.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/api.go), [commander.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/commander/commander.go).

## Metrics — не копия API

`metrics` требует `tag` или `listen`. Пустой tag при непустом listen заменяется на `Metrics`. Прямой listen — **TCP**, Unix-путь этим полем не поддерживается. При наличии tag виртуальный handler создаётся **и при прямом listen**. Учитывать `Metrics` в графе и проверять конфликт с API/реальными outbounds.

Доступны `/debug/vars`, `/debug/pprof/`, `cmdline`, `profile`, `symbol`, `trace`. Не обещать Prometheus `/metrics`: это другой интерфейс. Pprof может содержать чувствительные сведения и создавать нагрузку; listener должен быть закрыт от недоверенных пользователей. Факт приёма JSON не подтверждает bind или доступность HTTP-ручек.

Источники: [metrics JSON](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/metrics.go), [runtime Metrics](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/metrics/metrics.go).

## Политики ресурсов и статистика

`policy.levels` — словарь uint32-уровней, записанных строковыми ключами; значения — объекты или null (null-уровень пропускается). Поля уровня:

| Поле | Тип/единица | Значение для генератора |
|---|---|---|
| handshake, connIdle, uplinkOnly, downlinkOnly | optional uint32, секунды | Пропуск и явный 0 не одно и то же. Не придумывать глобальный timeout по имени транспорта. |
| statsUserUplink, statsUserDownlink, statsUserOnline | boolean | Согласовать с stats:{}, уровнем пользователя и идентификатором его счётчика. |
| bufferSize | optional int32, KiB | Неотрицательное умножается на 1024 в int32; отрицательное превращается в -1. Нельзя считать отрицательное значение экономией памяти. |

Защитная верхняя граница без int32-переполнения: 2097151 KiB; это **не рекомендуемый размер**. Для конкретной нагрузки выбрать гораздо меньший обоснованный бюджет. Пропуск параметра сохраняет нижележащую policy; не путать его с нулевым буфером.

`policy.system`: четыре boolean `statsInboundUplink`, `statsInboundDownlink`, `statsOutboundUplink`, `statsOutboundDownlink`. `stats:{}` создаёт компонент статистики, а не включает все категории счётчиков. `StatsService` — интерфейс чтения/управления, не автоматическое включение счётчиков. Проверять реальную передачу и появление нужных счётчиков, а не только список services. Не включать reset счётчиков в диагностический запрос без необходимости.

Источник: [policy.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/policy.go).

## Логи

`log` отсутствует: access отключён, error в консоль, уровень warning. **`log:{}`: access уже в консоль.** Пустые access/error выбирают консоль; `none` выключает соответствующий поток, непустая другая строка — путь к файлу. `loglevel` неизвестного значения превращается в warning; `none` отключает access и error. `dnsLog` — boolean; `maskAddress` — строка, не boolean.

Не включать debug, DNS-журнал и TLS masterKeyLog по умолчанию. Не писать логи по пользовательскому пути при offline-валидации: checker читает только явно выбранный JSON. При развёртывании отдельно проверить права, ротацию и свободное место.

Источник: [log.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/log.go).

## Mux, граф и доказательства

`mux.concurrency` и `mux.xudpConcurrency` — int16; `xudpProxyUDP443` строго `reject|allow|skip`, по умолчанию reject. Отрицательная TCP-concurrency не равна запрету XUDP. Не путать mux с XHTTP XMUX, HTTP/2 или QUIC multiplexing.

В граф включать `sockopt.dialerProxy`, ECH `echSockopt.dialerProxy`, эффективное наследование sockopt в XHTTP downloadSettings при `penetrate`, виртуальные API/Metrics tags и loopback. Отсутствие статического цикла ещё не исключает DNS bootstrap/TUN-петлю в ОС.

До заявления «пара согласована» прочитать [контракт peer-check](peer-validation.md). В заключении разделять: SOURCE_BUILD, SOURCE_RUNTIME, AUTHORING_POLICY, COVERAGE, NATIVE_CONFIG, WIRE_TEST. Покрытие типов — не покрытие всех runtime-веток. Не включать необследованные протокольные settings под обещание полной проверки транспорта.

## FakeDNS, version и geodata

Корневой `fakeDns` принимает один объект `{ipPool, poolSize}` **или массив** таких объектов. `ipPool` — CIDR-строка, `poolSize` — int64. Если DNS-сервер `fakedns` используется, а корневой пул не задан, postprocessor создаёт его автоматически: при обеих семьях по 32768 записей на семью, при одной — 65535. Это не создаёт правил перехвата на хосте. При отсутствии включённого FakeDNS sniffing ядро предупреждает. Проверять коллизии пула с реальными маршрутами; не путать FakeDNS с произвольным публичным DNS.

`version` содержит строки `min` и `max`; Build передаёт их и фактическую версию ядра в компонент version. Это ограничение запуска, **не скачивание и не обновление ядра**. Статический checker проверяет типы, нативный запуск — выполнение ограничения.

`geodata`: optional строка `cron`, строка `outbound`, массив `assets`. Каждый asset содержит строки `url` и `file`; Build требует HTTPS URL с host и доступный `StatAsset(file)`. Cron разбирается `cron.ParseStandard`, не произвольным диалектом системного cron. Checker не скачивает asset и не открывает file из входного JSON; эти части явно отмечаются непроверенными. Обновление geodata не заменяет закрепление версии ядра и может менять результаты маршрутизации независимо от JSON. Для воспроизводимости сохранять версии/hash используемых баз.

Источники: [fakedns.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/fakedns.go), [version.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/version.go), [geodata.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/geodata.go).

### Фактическая проверка счётчиков r4
Четыре сочетания direct/virtual API и Metrics передали payload и показали ненулевые uplink/downlink. Мгновенное чтение сразу после закрытия клиентского socket давало нулевой downlink; bounded polling до3s дождался обновления. Это асинхронность наблюдения, а не доказательство потери трафика. Не объявлять статистику сломанной по одному моментальному чтению.
