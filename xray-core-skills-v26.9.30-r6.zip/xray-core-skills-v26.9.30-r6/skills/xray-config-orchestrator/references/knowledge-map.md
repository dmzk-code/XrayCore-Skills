# Карта общей библиотеки r6

Закреплённый commit: `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Все17 входных скиллов используют единый контракт и эту карту. Загружать только нужный раздел: не вкладывать целую базу в каждый prompt.

## Замкнутые маршруты чтения
Транспорт → fields + implementation + runtime-peer; security → security + ECH; socket → socket-runtime + dial-chain-runtime; маска → finalmask + mask-runtime (+ realm/xmc при выборе); DNS → dns-runtime + cache-runtime; балансировка → balancer-runtime + observatory-runtime; XDRIVE → storage-runtime.

В index отражены все поля основных9 transport structs, общие Stream/TLS/REALITY/Socket, зарегистрированные маски и перечисленные вложенные структуры. Это **конечная область инвентаризации**, а не обещание проверки каждого JSON объекта всего репозитория. Общие значения/роли/несовместимости изложены в связанных документах; live-возможности provider/OS не выводятся из наличия поля.

[Машинный индекс](../../xray-source-audit/references/knowledge-index.json). Объектов: 97; полей по объектам (включая повторно используемые определения): 584.

| Объект | Полей | Справочник |
|---|---:|---|
| `streamSettings.rawSettings` | 2 | [xray-transport-raw](../../xray-transport-raw/references/fields.md) |
| `streamSettings.xhttpSettings` | 30 | [xray-transport-xhttp](../../xray-transport-xhttp/references/fields.md) |
| `streamSettings.kcpSettings` | 8 | [xray-transport-mkcp](../../xray-transport-mkcp/references/fields.md) |
| `streamSettings.grpcSettings` | 8 | [xray-transport-grpc](../../xray-transport-grpc/references/fields.md) |
| `streamSettings.wsSettings` | 5 | [xray-transport-websocket](../../xray-transport-websocket/references/fields.md) |
| `streamSettings.httpupgradeSettings` | 4 | [xray-transport-httpupgrade](../../xray-transport-httpupgrade/references/fields.md) |
| `streamSettings.hysteriaSettings` | 4 | [xray-transport-hysteria](../../xray-transport-hysteria/references/fields.md) |
| `streamSettings.masqueSettings` | 5 | [xray-transport-masque](../../xray-transport-masque/references/fields.md) |
| `streamSettings.xdriveSettings` | 12 | [xray-transport-xdrive](../../xray-transport-xdrive/references/fields.md) |
| `streamSettings.tlsSettings` | 18 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/security.md) |
| `streamSettings.realitySettings` | 22 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/security.md) |
| `TLSCertConfig` | 8 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/security.md) |
| `LimitFallback` | 3 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/security.md) |
| `streamSettings.sockopt` | 20 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/sockopt.md) |
| `CustomSockopt` | 6 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/sockopt.md) |
| `HappyEyeballs` | 4 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/sockopt.md) |
| `streamSettings` | 20 | [xray-config-orchestrator](../../xray-config-orchestrator/references/effective-config.md) |
| `streamSettings.xhttpSettings.xmux` | 6 | [xray-transport-xhttp](../../xray-transport-xhttp/references/fields.md) |
| `streamSettings.rawSettings.header` | 3 | [xray-transport-raw](../../xray-transport-raw/references/implementation.md) |
| `AuthenticatorRequest` | 4 | [xray-transport-raw](../../xray-transport-raw/references/implementation.md) |
| `AuthenticatorResponse` | 4 | [xray-transport-raw](../../xray-transport-raw/references/implementation.md) |
| `HysteriaMasquerade` | 9 | [xray-transport-hysteria](../../xray-transport-hysteria/references/implementation.md) |
| `finalmask.tcp[type=header-custom].settings` | 3 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=header-custom].settings` | 3 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.tcp[type=fragment].settings` | 6 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=mkcp-legacy].settings` | 2 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=noise].settings` | 2 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=salamander].settings` | 2 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.tcp[type=sudoku].settings` | 10 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=sudoku].settings` | 10 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=xdns].settings` | 3 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=xicmp].settings` | 2 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=realm].settings` | 5 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.udp[type=udphop].settings` | 4 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `finalmask.tcp[type=xmc].settings` | 3 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `TCPItem` | 8 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `UDPItem` | 7 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `CustomTransform` | 2 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `CustomTransformArg` | 6 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `NoiseItem` | 5 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `XDNSDomain` | 5 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `XDNSResolver` | 2 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `XDNSResolverSettings` | 1 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/finalmask.md) |
| `RealmPortMapping` | 3 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/realm-runtime.md) |
| `XMCProfile` | 4 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/xmc-runtime.md) |
| `finalmask.quicParams` | 17 | [xray-security-sockopt-finalmask](../../xray-security-sockopt-finalmask/references/quic.md) |
| `XDriveStorageTemplate` | 8 | [xray-transport-xdrive](../../xray-transport-xdrive/references/storage-runtime.md) |
| `XDriveAuth` | 8 | [xray-transport-xdrive](../../xray-transport-xdrive/references/storage-runtime.md) |
| `XDriveOperation` | 5 | [xray-transport-xdrive](../../xray-transport-xdrive/references/storage-runtime.md) |
| `XDriveRetry` | 2 | [xray-transport-xdrive](../../xray-transport-xdrive/references/storage-runtime.md) |
| `dns` | 12 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/dns-runtime.md) |
| `NameServer` | 15 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/dns-runtime.md) |
| `routing` | 3 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/routing.md) |
| `BalancingRule` | 4 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/routing.md) |
| `StrategyConfig` | 2 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/routing.md) |
| `LeastLoadStrategy` | 5 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/routing.md) |
| `Cost` | 3 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/routing.md) |
| `observatory` | 4 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/observatory-runtime.md) |
| `burstObservatory` | 2 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/observatory-runtime.md) |
| `HealthCheckSettings` | 6 | [xray-dns-routing-balancing](../../xray-dns-routing-balancing/references/observatory-runtime.md) |

| `RouterRule` | 21 | [routing](../../xray-dns-routing-balancing/references/routing.md) |
| `WebhookRule` | 3 | [routing](../../xray-dns-routing-balancing/references/routing.md) |

## Как понимать статус
SOURCE_BUILD означает проверенный разбор/преобразование; SOURCE_RUNTIME — найденный consumer; LAB_PASS — конкретный измеренный сценарий с указанным binary SHA; EXTERNAL_PRECONDITION — права, NAT, CDN или реальные учётные данные. Успешная лаборатория не меняет SOURCE_RUNTIME в гарантию всех значений.

## Не смешивать исторические и новые тесты
R2:22 исходные схемы, с известными gRPC reconnect и XHTTP/H1 результатами. R3: дополнительные изолированные тесты масок/HTTP placements/storage mock и семантические регрессии. Подробности и точные числа — в корневом VALIDATION.md.

## Дополнение r4
Общие JSON-блоки: [operations](operations.md). Сверка сторон и границы статического результата: [peer-validation](peer-validation.md). Фактическое покрытие типов в knowledge-index и результаты измерений — разные реестры.

## добавления r5
[Composition](composition.md) · [HTTP wire](http-wire-semantics.md) · [VMess/Trojan и Encryption](../../xray-protocol-composition/references/vmess-trojan.md). В r5 эти правила реализованы в composer/peer-check и отдельных native regressions.

## Добавленные protocol objects

| Объект | Полей | Справочник |
|---|---:|---|
| `VMessUser` | 5 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `VMessDefault` | 1 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `VMessInbound` | 3 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `VMessTarget` | 3 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `VMessOutbound` | 8 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `TrojanUser` | 4 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `TrojanTarget` | 6 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `TrojanOutbound` | 7 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `TrojanFallback` | 6 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |
| `TrojanInbound` | 3 | [protocol settings](../../xray-protocol-composition/references/vmess-trojan.md) |

## Proxy edges и общая топология r6
[SOCKS/mixed/HTTP](../../xray-protocol-composition/references/local-proxy-edges.md) · [listeners / direct-peer](topology-and-listeners.md) · [lab environment](../../xray-runtime-validation/references/lab-environment.md).

| Объект | Полей | Справочник |
|---|---:|---|
| `ProxyAccount` | 2 | [proxy edges](../../xray-protocol-composition/references/local-proxy-edges.md) |
| `ProxyRemoteAccount` | 4 | [proxy edges](../../xray-protocol-composition/references/local-proxy-edges.md) |
| `ProxyRemoteServer` | 3 | [proxy edges](../../xray-protocol-composition/references/local-proxy-edges.md) |
| `SocksProxyInbound` | 6 | [proxy edges](../../xray-protocol-composition/references/local-proxy-edges.md) |
| `HttpProxyInbound` | 4 | [proxy edges](../../xray-protocol-composition/references/local-proxy-edges.md) |
| `SocksProxyOutbound` | 7 | [proxy edges](../../xray-protocol-composition/references/local-proxy-edges.md) |
| `HttpProxyOutbound` | 8 | [proxy edges](../../xray-protocol-composition/references/local-proxy-edges.md) |
