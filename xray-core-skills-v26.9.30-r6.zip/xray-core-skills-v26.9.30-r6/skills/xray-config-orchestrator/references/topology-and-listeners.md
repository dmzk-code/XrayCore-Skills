# Топология, listener и границы peer-check

Ревизия r6, Xray-core v26.9.30. Данный раздел обязателен при сборке нескольких процессов, цепочек, reverse, отдельных плеч XHTTP и локальных прокси-входов.

## Два разных утверждения

`--peer` сравнивает выбираемые стороны по параметрам protocol/transport/auth. Он не подтверждает DNS, NAT, ingress, port forwarding, сертификаты внешнего CDN и конфигурацию frontend. В отчёте `peer_topology=UNDECLARED`.

`--direct-peer` — **явное утверждение пользователя/топологии**, что выбранный клиент непосредственно соединяется с выбранным listener, без port/IP rewrite и TLS termination. Доступен только с `--peer` и полными конфигурациями. Checker проверяет client endpoint port относительно server port list, конкретные IP и семейства, физический TCP/UDP, security и необходимость PROXY preamble. `peer_topology=DIRECT_DECLARED` отражает предпосылку, а не выполненный socket test.

```bash
python skills/xray-source-audit/scripts/validate.py client.json --peer server.json --outbound-tag PROXY --inbound-tag INBOUND --direct-peer --json
```

Реальные адреса берутся из protocol settings и их aliases, а не автоматически из вложенного `streamSettings.address/port`, который может использоваться отдельной возможностью вроде XHTTP downloadSettings. Для вложенных плеч составлять отдельные edge-карточки.

## Когда direct-проверка не делает вывода

DNS и `env:` не разрешаются; `[::]` с IPv4-клиентом без v6only зависит от ОС; UDS сравниваются отдельно; dialerProxy/SRV/TXT могут изменить путь. XDRIVE и UDP carriers, управляющие другим socket, не покрываются обычным port/IP-check. Такие случаи получают конкретный UNVERIFIED, а не ложный зелёный результат.

Если между клиентом и сервером есть frontend, не включать `--direct-peer` ради увеличения числа проверок. Описать каждое плечо: protocol, network, адрес, порт, termination, маршрутизация, проверка личности и владелец session map. Затем тестировать выбранную конечную схему.

## Физические listeners

| Транспорт / механизм | Проверяемый socket footprint |
|---|---|
| RAW, gRPC, WebSocket, HTTPUpgrade | TCP; для разрешённых Unix-схем — отдельный UDS путь. |
| mKCP, Hysteria | UDP, если Finalmask carrier не меняет тип/назначение socket. |
| XHTTP | Соответствующая H1/H2 TCP или H3 UDP ветка; способ выбора HTTP-версии проверяется отдельно. |
| MASQUE | Server ALPN может включать TCP/H2 и UDP/H3 одновременно; выбор клиента не обязан повторять всю server ALPN list. |
| SOCKS/mixed | Основной listener TCP; каждый UDP ASSOCIATE создаёт отдельный динамический UDP socket, не port главного listener. |
| API / Metrics direct | Собственный TCP listener; API также поддерживает указанный UDS. Не считать его частью proxy inbound. |

Один номер TCP и UDP порта сам по себе не конфликт. Совпадение конкретных адресов или wildcard внутри одного семейства и пересечение port ranges — повод проверить владение. Checker не разворачивает диапазоны в 65535 объектов; сравнение ограничено 1024 footprints. Превышение выдаёт предупреждение и не считается полной проверкой.

## SO_REUSEPORT и XHTTP session-owner

В проверенном `DefaultListener.getControlFunc` вызывается `setReusePort`. Поэтому две конфигурации на совпадающем TCP/UDP адресе могут не получить обычную ошибку bind. Успешный старт не доказывает, что запросы попадают в нужный обработчик.

Отдельные XHTTP listeners с разными session maps на одном endpoint не заменяют HTTP-aware frontend. Upload/download должны сходиться в согласованного владельца сессии; распределение новых соединений ядром ОС может разнести их. `XHTTP_LISTENER_OVERLAP` — ERROR авторинга. Для остальных обычных listeners пересечение — WARNING `LISTENER_OVERLAP`, а не утверждение «bind точно завершится ошибкой». При осознанном use-case необходимы отдельные доказательства распределения и восстановления.

Проверяется только одна переданная конфигурация/процесс. Нужна отдельная инвентаризация существующих процессов, контейнерных network namespaces и системных сервисов; инструмент не запускает `ss`, не убивает процессы и не редактирует firewall.

## Теги и служебные handlers

API без direct listen создаёт виртуальный outbound с `api.tag`. API с прямым listen его не создаёт. Metrics с tag, в том числе default `Metrics` при заданном listen, имеет отдельную ветку virtual handler. Один tag для разных служебных владельцев — неоднозначная подмена, не маршрутизация. VLESS Reverse не должен совпадать с обычным static outbound tag.

Проверка `dialerProxy` обязательна и для анонимного/default outbound: отсутствие tag у отправителя не отменяет существование тега назначения. Основной граф проверяет циклы именованных dialerProxy; loopback/routing и специальные carriers имеют отдельные ограничения. Не объявлять этот граф полным анализатором произвольной runtime-диспетчеризации.

## PROXY protocol

`acceptProxyProtocol=true` в согласованной listener-ветке означает **REQUIRE**, а не «попробовать распознать и принять обычное соединение при отсутствии». Обычный прямой клиент должен иметь перед собой согласованный отправитель preamble. Только наличие bool на сервере не делает пару совместимой. При пользовательской wrapper/mask-последовательности checker не доказывает содержимое preamble; это отдельный тест.

## Источники и результаты

Изменения покрыты unit-тестами r6. Восемь новых прямых SOCKS/HTTP пар реально передали данные в loopback-лаборатории. Полная межпроцессная topology-матрица, remote NAT и все OS bind-варианты не испытывались в этой серии.
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)
- [transport/internet/system_listener.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/system_listener.go)
- [transport/internet/memory_settings.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/memory_settings.go)
- [transport/internet/masque/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/hub.go)
- [transport/internet/masque/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/dialer.go)
- [proxy/socks/protocol.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/socks/protocol.go)
- [app/commander/commander.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/commander/commander.go)
- [app/metrics/metrics.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/metrics/metrics.go)
- [transport/internet/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/dialer.go)
