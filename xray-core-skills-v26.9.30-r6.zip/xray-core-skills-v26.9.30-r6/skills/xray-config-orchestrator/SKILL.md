---
name: xray-config-orchestrator
description: "Создание, исправление и аудит сложных Xray-core конфигураций. Общий контракт всех xray-скиллов: согласование сторон, транспорта, защиты, DNS, routing, Finalmask, ресурсов и тестов; версия v26.9.30."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# Общий сборщик Xray-core

## Точка входа
Прочитай [контракт](references/contract.md), [матрицу совместимости](references/compatibility.md) и [порядок полей](references/effective-config.md). Это общие требования для всех скиллов; не загружай сразу всю библиотеку. Не вызывай себя рекурсивно из транспортного скилла: общий контракт достаточно прочитать один раз.

## Выполнение задачи
1. Прочитай исходные файлы и извлеки версии обеих сторон, wrapper/панель, ОС, существующие tags, endpoints и требования TCP/UDP. Не повторяй вопросы, ответы на которые есть в файлах. Рабочие файлы не переключай на другую ветку/релиз.
2. Зафиксируй отдельно версию пакета знаний и целевого бинарника. При несовпадении выполни `../xray-source-audit/scripts/source_probe.py` на отдельном checkout; не выдавай знания r6 за знания любой версии.
3. Составь `topology.json`: процессы, listeners, endpoints, физические плечи TCP/UDP, логические session-owner, TLS termination, DNS bootstrap и границы доверия. Разделённые XHTTP-плечи должны сходиться в один listener/session-owner, не просто в один процесс.
4. Выбери protocol → transport → security → masks. Подключи только соответствующие транспортные SKILL.md; для VLESS/Vision/encryption — `../xray-protocol-composition/SKILL.md`, для DNS/routing/failover — `../xray-dns-routing-balancing/SKILL.md`, для frontend — `../xray-frontend-topology/SKILL.md`.
5. Начни с согласованной пары из `assets/scenarios/` либо создай её через `../xray-source-audit/scripts/build_lab.py`. Лабораторные credentials и адреса не переносить в production. Полный каталог: [сценарии](references/scenarios.md).
6. Добавляй по одному усложнению. После каждого пересчитывай эффективные настройки, peer-map, граф dialerProxy/loopback и бюджет. Не генерируй все поля подряд. Не теряй несвязанные настройки существующего проекта.
7. Если файлов несколько, сначала примени [точную семантику composition](references/composition.md) и `../xray-source-audit/scripts/compose_config.py`; не используй deep merge. Затем запусти `../xray-source-audit/scripts/validate.py` на каждом итоговом JSON; для пары добавь `--peer server.json`; только при явно прямом соединении — `--direct-peer` по [правилам топологии](references/topology-and-listeners.md). ERROR устранить, WARNING разобрать. Это статическая проверка, не доказательство успешного соединения.
8. Выполни доступные уровни из `../xray-runtime-validation/SKILL.md`. Конфиг-тест ядра, bind, TCP, UDP, повторное соединение, неправильный auth, отказ одного плеча и нагрузка — разные результаты. Все команды и NOT_RUN записать.
9. Выдай полные файлы, минимальный diff, peer-map, ASSUMPTIONS, VALIDATION, rollout/rollback. Deployment/firewall/restart разрешены только в согласованной среде; тестовый runner не трогает production.

## Остановить опасную генерацию
Не выдумывать поля, ключи или поддержку клиентов; не превращать предупреждение deprecated в удаление; не обходить TLS-проверку; не включать debug/masterKeyLog в обычной эксплуатации; не путать недоступный probe с неработающим туннелем. Если данных мало, выпустить явно помеченный TEMPLATE и точный список замен, а не притворно рабочий production-конфиг.

Опубликованные фактические ограничения — [known issues](../xray-runtime-validation/references/known-issues.md). Не скрывать FAIL gRPC restart или нестабильность H1 stress в сводном SUCCESS.

## Индекс согласованной библиотеки r6
[Карта знаний и границ доказательства](../xray-config-orchestrator/references/knowledge-map.md). Версию поля проверять по pinned источнику, внешнюю среду — отдельным bounded тестом.

## Эксплуатационный и проверочный контракт r4
При общих настройках прочитать [API, Metrics, policy, logs, sniffing](references/operations.md). При согласовании сторон — [peer-validation](references/peer-validation.md). Без crypto backend отсутствие ERROR не подтверждает REALITY key pair.

VMess/Trojan и проверки Encryption: [protocol semantics](../xray-protocol-composition/references/vmess-trojan.md). HTTP peer-map: [wire semantics](references/http-wire-semantics.md).

## Обязательная проверка внешних краёв
Для SOCKS/mixed/HTTP прочитать [фактическую auth-семантику](../xray-protocol-composition/references/local-proxy-edges.md). Проверить HTTP-ветку SOCKS listener, aliases accounts/users и действующий Proxy-Authorization. Сопоставить listeners и служебные владельцы tags; анонимный outbound не исключать из проверки dialerProxy. Новую лабораторию запускать с [очищенным окружением](../xray-runtime-validation/references/lab-environment.md).
