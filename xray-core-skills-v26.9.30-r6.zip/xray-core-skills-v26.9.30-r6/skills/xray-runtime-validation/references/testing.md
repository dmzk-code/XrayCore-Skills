# Воспроизводимая проверка

`build_lab.py` создаёт новый пустой каталог с согласованными server/client конфигами, сгенерированными UUID/auth и self-signed TLS только для localhost. Для TLS client применяется собственный pinnedPeerCertSha256, не allowInsecure. Не использовать эти ключи в production.

`run_lab.py` требует явный доверенный executable. Выполняет `version`, SHA256 и `run -test`, запускает отдельные Xray процессы, TCP/UDP echo на loopback, SOCKS5 запросы, проверяет полезные байты, reconnect после перезапуска server и negative auth. Ограничивает время каждого этапа, завершает только свои Popen процессы. Отсутствующий executable даёт NOT_RUN, не фиктивный PASS. Запуск тестов не изменяет UFW, sysctl, systemd, DNS или рабочие конфиги.

До запуска: Python 3.10+, OpenSSL для генерации сертификата, pinned Xray и разрешение loopback sockets. Для frontend fixtures нужен Nginx; отдельный prefix и конфиг, без reload системного сервиса. DNS-тест не должен обращаться к случайному внешнему резолверу без указания сценария.

Негативные сценарии: неверный UUID/password, несовпадающий path, конфликт alias/extra, Vision на неподходящей обёртке, неверный cert pin, некорректный downloadSettings, ссылка на отсутствующий tag, dialerProxy цикл, устаревший proxySettings и неправильно размещённая Finalmask. L0 может отвергнуть их до ядра; хранить отдельно EXPECTED_REJECT_STATIC и реальное CORE_REJECT.

Нагрузочный тест ограничить локальным стендом, задать длительность/concurrency/payload и baseline. Отдельно записать soak duration и RSS/FD до/после cooldown; краткий smoke-test не назвать leak-test. Внешние storage/CDN/REALITY-target и kernel-specific masks требуют индивидуальной среды; не подменять их local service=local.

CI entry point `ci/verify.py` принимает подготовленный pinned source или доверенный binary и запускает проверки только по явным флагам. Автоматический GitHub workflow не устанавливался. Перед production deployment требуется фактический зелёный отчёт именно вашей сборки.

Опубликованные результаты r2: [known issues](known-issues.md), [runtime JSON](runtime-evidence.json), [24 build cases](core-config-cases.json). Сценарии MASQUE используют inner198.18.0.1 и loopback redirect, а не запрещённый gVisor inner-loopback. Restart budget45s; нагрузка12 запросов,4 workers,4096 bytes,timeout5s — только короткий стресс после восстановления.


## Свежие серии r3
[22 базовые схемы](r3-baseline.json), [40 расширенных вариантов](r3-extended.json), [DNS cache/disableCache/stale](r3-dns.json), [24 проверки core-config](r3-core-config-cases.json). Запуск дополнительных серий описан в корневом README. В отчётах разделены native config, TCP, UDP, parallel и failure recovery; нельзя подменять один статус другим.

`run_extended_lab.py` и `run_dns_lab.py` проверяют обязательный SHA256 до исполнения. Реальные keys/логи остаются в приватной новой директории, в пакет переносится только обезличенный report. Диапазон вариантов XDNS — локальные TXT/AAAA; storage — собственный HTTP mock none/static/basic/oauth2/retry; долгий provider/NAT тест этим не подразумевается.
