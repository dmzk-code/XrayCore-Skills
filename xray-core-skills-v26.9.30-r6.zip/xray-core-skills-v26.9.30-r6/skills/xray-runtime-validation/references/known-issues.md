# Дополнение r6 — 7 октября 2026

[Новая отдельная серия](r6-regressions.json) не переписывает r5 baseline. `finalmask:{}` и объект только с quicParams не создают runtime FinalMask: gRPC server-only recovery в 5-секундном бюджете вновь **FAIL_KNOWN**, client-restart control **PASS**. Это уточнение конфигурационных условий известной регрессии, не патч ядра.

Новая auth-проверка воспроизвела незащищённый HTTP CONNECT на SOCKS/mixed listener при пустом accounts и auth=password. [Правила безопасной генерации и алиасов](../../xray-protocol-composition/references/local-proxy-edges.md). Исправленный валидатор отвергает этот шаблон; само поведение pinned core не менялось.

Устранён отдельный дефект **стенда**, не Xray: наследуемые dotted core-env больше не обходят очистку окружения. Два нативных controls подтверждают, что дополнительные конфиги confdir не подмешиваются. [Границы изоляции](lab-environment.md).

---

# Дополнение r4 — проверено7 октября2026

Последний полный прогон: [r4-baseline](r4-baseline.json), статус **FAIL**. Два gRPC restart вновь не прошли. Короткая нагрузка: 20PASS, 0FAIL, 2NOT_RUN; история H1 не аннулируется успешным новым прогоном.

## TLS policy uTLS — фактический consumer
`copyConfig` не переносит min/maxVersion, CipherSuites, CurvePreferences и session policy. Default fingerprint выбирает Chrome uTLS на соответствующих TCP-ветках. RAW client minVersion1.3 успешно соединился с server maxVersion1.2; ordinary Go TLS variant отверг несовместимость. [Доказательства](r4-regressions.json), [подробный контракт](../../xray-config-orchestrator/references/peer-validation.md). Не обещать клиентское ограничение протокола на основании наличия поля JSON.

## API/Metrics и counters
API прямой listen не создаёт virtual tag; Metrics создаёт. Проверены4 сочетания и появление обоих счётчиков с bounded polling3s: [control](r4-control.json). Нулевой downlink при моментальном чтении сам по себе не доказывает потерю статистики.

Ниже сохранены прежние результаты и объяснения, без переписывания исторических FAIL.

---

# Известные особенности закреплённого ядра — состояние r3

Проверяемый бинарник: Xray26.9.30/b26a91d, Linux/amd64. SHA256 `96efb28b8b2086275598dc46e73b5dc340da948b4e1ccc4f1719f83f67b793a7`. [Новый полный прогон](r3-baseline.json), [предыдущие наблюдения r2](known-issues-r2.md).

## gRPC: Tun/TunMulti reconnect — подтверждённая регрессия
В r3 повторены TCP/UDP/auth PASS и отказ восстановления обеих gRPC TLS схем в 45-секундном бюджете после перезапуска только сервера. Базовые конфиги не отвергаются ядром: ошибка возникает позже при повторном подключении.

Причина теперь подтверждена [upstream PR6877](https://github.com/XTLS/Xray-core/pull/6877): non-Finalmask ContextDialer использует захваченный контекст первого запроса вместо свежего gctx. Исправляющий commit `9d9a7a1c00d1af4a9d4147ca2cb56289fd95fd3b` находится после базы пакета. [Детальный разбор](grpc-upstream-fix.md). Не заявлять наличие исправления в v26.9.30; пакет навыков не модифицировал ядро. Требование устойчивого reconnect должно учитывать этот факт до выбора gRPC. Не добавлять фиктивную маску или бесконечные retries ради зелёного отчёта.

## XHTTP packet-up HTTP/1.1: короткая нагрузка после restart
Новый прогон вновь дал один непройденный запрос из 12 при четырёх workers, 4096bytes и timeout5s. Первичное TCP/UDP, auth и новый connect после restart прошли. Предыдущие повторные измерения также содержат PASS и FAIL: [история](xhttp-repeat-evidence.json).

Причина не установлена. Скилл не считает все XHTTP режимы неисправными и не объявляет увеличение тайм-аута исправлением. Применение H1 при строгом требовании recovery/load должно иметь отдельный положительный результат целевой сборки и сети.

## Hysteria: reconnect не обязательно мгновенный
В базовых сериях восстановление укладывается в 45-секундный бюджет; таймеры обнаружения умершей QUIC-сессии могут давать заметную задержку. Точное время каждого прогона есть в JSON. Не переносить результат на оптимизацию батареи или мобильную сеть без измерений.

## MASQUE и Freedom: корректная среда испытаний
Для CONNECT-IP нельзя считать блокировку внутреннего loopback со стороны gVisor поломкой транспорта. Лаборатория использует inner198.18.0.1 с узким локальным redirect; маршруты ОС не меняются. Freedom private-target policy также учитывается отдельным ограниченным lab allow, а не универсальным доступом к private-сетям в production. [Подробности Freedom](../../xray-protocol-composition/references/freedom.md).

## Полезная информация из расширенной серии
Все 40 дополнительных вариантов прошли конкретные core/TCP/UDP/parallel checks: [report](r3-extended.json). Storage mock не подтверждает права, квоты и доступность реального provider; локальный XDNS — путь через публичные DNS; perConnRemote — миграцию активной сессии. Кодовые возможности и измеренная комбинация остаются разными уровнями доказательств.

## Повторная проверка r5 — 7 октября2026
В [новом baseline](r5-baseline.json) gRPC Tun/TunMulti снова не восстановились в45s после server restart. XHTTP packet-up/H1 восстановился, но один из12 последующих параллельных запросов не прошёл.19 workload cases PASS,1FAIL,2NOT_RUN. Это не объявлено исправленным новой базой знаний. Все22 первоначальных TCP/UDP, auth и positive-control cases прошли.

[r5-regressions](r5-regressions.json) отдельно подтверждает исправленные ожидания XHTTP/MASQUE/VMess/Trojan/Encryption и composition; это не опровергает FAIL базового reconnect/load. [Первый запуск нового runner](r5-discovery-harness.json) содержит ошибки стенда exclusive log и MASQUE probe target, исправленные до итогового прогона.
