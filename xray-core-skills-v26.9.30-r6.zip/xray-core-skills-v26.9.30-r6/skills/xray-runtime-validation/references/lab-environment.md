# Изоляция запуска и статус измерений r6

Loopback-лаборатория не является security sandbox для недоверенного бинарника. Запускать только явно выбранный binary после проверки ожидаемого SHA256; совпадение version string не заменяет digest. Не читать credentials внешних аккаунтов и не использовать production configs.

## Что исправлено в окружении

Xray `platform.NewEnvFlag` сначала проверяет исходное имя, например `xray.location.confdir`, и лишь затем нормализованный alias `XRAY_LOCATION_CONFDIR`. Фильтра только по верхнему регистру с underscore недостаточно: наследуемая dotted переменная могла подключить чужой confdir даже к запуску с явным `-c`.

`run_lab.clean_env()` теперь нормализует имя для сравнения (`strip`, uppercase, замена `.` на `_`) и удаляет обе формы семейств XRAY/V2RAY/HYSTERIA. Также удаляет proxy environment в обоих регистрах. Общая функция используется Child/capture и импортирующими их runners. Она не является универсальным allowlist системного окружения и не обезвреживает произвольные настройки загрузчика ОС; доверие к executable и среде всё ещё требуется.

Нативный контроль r6: процесс Xray с переданным dotted confdir увидел локальный тестовый overlay при `run -dump`; тот же запуск через очищенный runner увидел только base config. Повторено для underscore alias. Overlay создан самим тестом, не взят из файлов пользователя. Runtime-конфиги, логи и новые private keys остаются в приватном test directory и не входят в архив.

## Запуск новой серии

```bash
python skills/xray-source-audit/scripts/run_r6_regressions.py --xray /absolute/path/xray --sha256 TRUSTED_SHA256 --execute --out /new/private/r6-run
python ci/verify.py --out /new/private/ci-run --xray /absolute/path/xray --xray-sha256 TRUSTED_SHA256 --run-r6-regressions
```

`--execute` обязателен; существующий output directory и неверный digest отвергаются. Стенд не открывает public listeners, не редактирует маршруты, DNS ОС, firewall, сервисы или git checkout. Собственные процессы останавливаются через сохранённые PID/объекты, не поиском по имени.

## Что измеряет серия

8 parser/build expectations; 8 auth edge-cases с реальным HTTP CONNECT; 8 proxy-пар с неправильными credentials и последующим положительным контролем; 2 варианта env-isolation; 2 gRPC-проверки empty/quicParams-only Finalmask. Число UDP PASS относится только к SOCKS-парам: HTTP outbound сообщает UNSUPPORTED_BY_HTTP_OUTBOUND.

У опасного auth-fixture PASS означает «ожидаемое небезопасное поведение воспроизведено». Корректная конфигурация имеет собственные проверки отказа без/с неверным паролем и успешного payload с правильным.

Итог `PASS_EXPECTATIONS_WITH_KNOWN_RUNTIME_FAILURES` **не означает успешное восстановление gRPC**. В отчёте остаётся `server_only_recovery=FAIL_KNOWN`, budget 5 seconds; после перезапуска клиента положительный контроль PASS. Иной результат должен рассматриваться как изменившееся наблюдение, не автоматически переписанная история. CI отдельно сохраняет наличие известных runtime failures; состояние сложной пользовательской схемы нельзя наследовать из этих лабораторных результатов.

## Новое и историческое

[r6-regressions.json](r6-regressions.json) — текущая отдельная серия. [known-issues](known-issues.md) содержит историю прежних 45-секундных gRPC restart и XHTTP/H1 stress failures. Полные 22/40 baseline/extended схемы и Go-suite не записывать как повторно запущенные без нового отчёта. Все сохранённые исторические JSON остаются неизменными.
- [common/platform/platform.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/common/platform/platform.go)
- [main/run.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/main/run.go)
- [transport/internet/memory_settings.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/memory_settings.go)
- [transport/internet/grpc/dial.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/dial.go)
