# gRPC reconnect: подтверждение upstream

Для закреплённого v26.9.30 проблема из r2 соответствует исправлению upstream PR6877.

В `transport/internet/grpc/dial.go` closure WithContextDialer получает `gctx,s`, но ветка без FinalMask вызывала DialSystem с захваченными `ctx,dest` первой пользовательской сессии. После её отмены повторные подключения cached grpc.ClientConn используют уже отменённый context. Это объясняет наблюдение `operation was canceled` и восстановление после перезапуска клиента.

PR6877 закрыт и merged; его base — b26a91de4f3294e26a0ad0a970b81a386a41f789, merge commit — 9d9a7a1c00d1af4a9d4147ca2cb56289fd95fd3b. Исправление заменяет вызов:

```go
// Закреплённый релиз:
c, err = internet.DialSystem(ctx, dest, streamSettings.SocketSettings)
// Upstream fix:
c, err = internet.DialSystem(gctx, net.TCPDestination(address, port), streamSettings.SocketSettings)
```

Это изменение НЕ содержится в испытываемом бинарнике b26a91d. Скилл не исправляет его JSON-параметром и не заявляет, что kernel был пропатчен. При требовании надёжного reconnect не выбирать этот gRPC release без отдельного решения: закреплённая проверенная сборка с исправлением либо другой проверенный транспорт. Переход на другой commit требует новой проверки полей и сетевых тестов; пакет сам production не обновляет.

[Исходный pinned dial.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/dial.go) · [Upstream PR6877](https://github.com/XTLS/Xray-core/pull/6877) · [Merge commit](https://github.com/XTLS/Xray-core/commit/9d9a7a1c00d1af4a9d4147ca2cb56289fd95fd3b).
