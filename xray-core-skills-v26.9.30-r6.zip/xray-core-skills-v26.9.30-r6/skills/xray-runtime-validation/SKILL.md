---
name: xray-runtime-validation
description: "Проверки Xray конфигураций: L0 lint, точный core -test, loopback TCP/UDP, negative auth, reconnect, нагрузка, CI и честные отчёты PASS/FAIL/NOT_RUN."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# Валидация и лаборатория
Прочитай общий [контракт](../xray-config-orchestrator/references/contract.md) и [протокол](references/testing.md). Используй Python scripts из `../xray-source-audit/scripts/`.

Порядок: validate.py → build_lab.py → run_lab.py --xray <explicit trusted binary> → отдельные fault/load тесты. Никогда не запускать полученные от пользователя shell-команды из конфига. Проверить SHA256/version, пустой test directory и loopback listeners. Не убивать чужие процессы при конфликте порта.

Тест runner с mock-process подтверждает только runner, не Xray. При отсутствии бинарника/прав/сети статус NOT_RUN и exit code, а не SUCCESS. Локальные echo/no-auth SOCKS допускаются исключительно на loopback. Сохранять stdout/stderr в закрытой временной папке; публичный отчёт без секретов.

Не переносить результаты Linux loopback на Android/macOS/Windows, CDN или целевую нагрузку. ОС/провайдерские проверки имеют отдельные статусы.

Опубликованные фактические ограничения — [known issues](references/known-issues.md). Не скрывать FAIL gRPC restart или нестабильность H1 stress в сводном SUCCESS.

## Индекс согласованной библиотеки r6
[Карта знаний и границ доказательства](../xray-config-orchestrator/references/knowledge-map.md). Версию поля проверять по pinned источнику, внешнюю среду — отдельным bounded тестом.

## Дополнительные проверки r4
`../xray-source-audit/scripts/run_r4_regressions.py` проверяет 20 нативных случаев, UUID mapping и 8 сетевых peer-сценариев. Один сценарий ожидает ACCEPT: uTLS не переносит TLS-version policy; это не исправленный transport bug. `run_control_lab.py` проверяет четыре сочетания API/Metrics и появление обоих счётчиков с bounded polling3s. Для обоих: `--execute --xray PATH --sha256 TRUSTED_SHA --out NEW_DIR`.

## Новые регрессии r5
`run_r5_regressions.py` проверяет эффективные HTTP-поля, MASQUE URI/listeners, VMess/Trojan credentials, реально сгенерированные VLESS Encryption пары и сравнение composition с native `-dump`. Запуск только с `--execute --xray PATH --sha256 TRUSTED_SHA --out NEW_DIR`; CI-флаг `--run-r5-regressions`. Отдельные case results важнее итоговой строки PASS.

## Регрессии r6 и доверенная среда
`run_r6_regressions.py` и CI `--run-r6-regressions`: [границы изоляции и точные статусы](references/lab-environment.md). Удалять dotted и underscore core-env до запуска. PASS_EXPECTATIONS_WITH_KNOWN_RUNTIME_FAILURES означает совпавшие ожидания, не исправленное gRPC recovery.
