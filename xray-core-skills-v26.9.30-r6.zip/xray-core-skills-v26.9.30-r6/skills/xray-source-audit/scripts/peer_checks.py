"""Extra read-only peer checks. No network, subprocess, secret printing or file lookup.
Cryptographic REALITY public-key consistency uses optional `cryptography`; without
it the key check is explicitly unverified. Never implements home-grown crypto.
"""
from __future__ import annotations
import base64
import copy
import hashlib
import ipaddress
import json
import re
import uuid
from urllib.parse import quote


def canonical_id(value):
    """Match common/uuid.ParseString on short IDs and canonical UUID forms.
    This helper only canonicalizes IDs; SHA-1 here is Xray's specified identifier
    mapping, not an authentication/hash construction recommended for new systems.
    """
    if not isinstance(value,str):raise ValueError('id must be string')
    data=value.encode('utf-8')
    if 1<=len(data)<=30:
        digest=bytearray(hashlib.sha1(bytes(16)+data).digest()[:16]);digest[6]=(digest[6]&15)|80;digest[8]=(digest[8]&63)|128
        return str(uuid.UUID(bytes=bytes(digest)))
    if not 32<=len(data)<=36:raise ValueError('invalid id length')
    result=b''
    for size in (8,4,4,4,12):
        if data.startswith(b'-'):data=data[1:]
        chunk=data[:size]
        if len(chunk)!=size or re.fullmatch(b'[a-fA-F0-9]+',chunk) is None:raise ValueError('invalid id')
        result+=bytes.fromhex(chunk.decode('ascii'));data=data[size:]
    # Source permits trailing bytes in this branch; authoring rejects them.
    if data:raise ValueError('noncanonical trailing data')
    return str(uuid.UUID(bytes=result))


def decode_key(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',value):raise ValueError('invalid key encoding')
    return base64.b64decode(value+'='*(-len(value)%4),altchars=b'-_',validate=True)


def public_from_private(value):
    # Returns None when the optional audited backend is unavailable.
    try:
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
        from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat
    except ImportError:return None
    data=decode_key(value)
    if len(data)!=32:raise ValueError('invalid private key size')
    return X25519PrivateKey.from_private_bytes(data).public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)


def sid(value):
    if not isinstance(value,str) or len(value)>16 or len(value)%2 or re.search('[^0-9A-Fa-f]',value):raise ValueError('invalid shortid')
    return bytes.fromhex(value).ljust(8,b'\x00')


def grpc_path(service, multi=False):
    escape=lambda s:quote(s,safe='$&+:=@')  # Go url.PathEscape segment safe set
    if not service.startswith('/'):
        return '/'+escape(service)+'/'+('TunMulti' if multi else 'Tun')
    last=max(1,service.rfind('/'));name='/'.join(escape(x) for x in service[1:last].split('/'))
    methods=service[service.rfind('/')+1:].split('|')
    method=methods[1] if multi and len(methods)>1 else methods[0]
    return '/'+name+'/'+escape(method)


def http_version(stream):
    from http_peer_checks import masque_client_version
    method=stream.get('method') if stream.get('method') is not None else stream.get('network')
    if isinstance(method,str) and method.lower()=='masque':return masque_client_version(stream)
    sec=(stream.get('security') or 'none').lower()
    if sec=='reality':return 'h2'
    if sec!='tls':return 'http/1.1'
    a=stream.get('tlsSettings',{}).get('alpn',[])
    if isinstance(a,str):a=a.split(',')
    return a[0] if a in (['h3'],['http/1.1']) else 'h2'


def effective_stream(stream):
    from semantic_checks import normalize_stream
    s=normalize_stream(stream)
    if not isinstance(s,dict):return {}
    return s


def check(v,c,b,cs,bs,ct,bt,cn):
    def emit(code,msg,field='',kind='AUTHORING_POLICY',severity='ERROR',source='infra/conf/transport_security.go'):
        v.issue(code,'$.peer'+('.'+field if field else ''),msg,kind,severity,source)
    csec=(cs.get('security') or 'none').lower();ssec=(bs.get('security') or 'none').lower()
    if csec=='reality' and ssec=='reality':
        cr=cs.get('realitySettings') or {};sr=bs.get('realitySettings') or {}
        if not isinstance(cr,dict) or not isinstance(sr,dict):return
        if cr.get('target') is not None or cr.get('dest') is not None:emit('PEER_REALITY_ROLE','Клиентские realitySettings выбирают серверную ветку.','realitySettings')
        if sr.get('target') is None and sr.get('dest') is None:emit('PEER_REALITY_ROLE','Серверные realitySettings не выбирают серверную ветку.','realitySettings')
        from validate import vless_account
        _,address=vless_account(c)
        server_name=cr.get('serverName') or address
        names=sr.get('serverNames',[])
        if isinstance(server_name,str) and isinstance(names,list) and server_name not in names:
            emit('PEER_REALITY_SNI','Эффективное имя клиента отсутствует в serverNames; wildcard не подразумевается.','realitySettings.serverName')
        try:
            short=sid(cr.get('shortId') or '')
            if not any(short==sid(x) for x in sr.get('shortIds',[])):emit('PEER_REALITY_SHORTID','Побайтовый shortId клиента отсутствует на сервере.','realitySettings.shortId')
        except (ValueError,TypeError):emit('PEER_REALITY_SHORTID','Некорректная форма shortId в проверяемой паре.','realitySettings.shortId')
        try:
            public=public_from_private(sr.get('privateKey'))
            if public is None:emit('PEER_CRYPTO_UNVERIFIED','Сверка X25519-пары не выполнена: установите optional cryptography либо подтвердите пару точным ядром.','realitySettings.password','COVERAGE','WARNING')
            elif public!=decode_key(cr.get('password') or cr.get('publicKey')):emit('PEER_REALITY_KEY','Публичная часть клиента не соответствует privateKey сервера; значения скрыты.','realitySettings.password')
        except (ValueError,TypeError):emit('PEER_REALITY_KEY','Ключи REALITY не прошли проверку формата/длины.','realitySettings.password')
        if cr.get('mldsa65Verify') and not sr.get('mldsa65Seed'):emit('PEER_MLDSA_SEED','Клиент требует ML-DSA, но серверный seed не задан.','realitySettings.mldsa65Verify')
        elif cr.get('mldsa65Verify'):emit('PEER_MLDSA_UNVERIFIED','Соответствие ML-DSA seed/verify требует отдельного handshake; X25519-проверка его не заменяет.','realitySettings.mldsa65Verify','COVERAGE','WARNING')
    if cn=='xhttp':
        if csec==ssec=='tls' and (http_version(cs)=='h3') != (http_version(bs)=='h3'):
            emit('PEER_XHTTP_HTTP_VERSION','Клиент и origin выбрали разные физические транспорты: HTTP/3 UDP и HTTP/1–2 TCP. Для преобразования нужен явный frontend.','tlsSettings.alpn',source='transport/internet/splithttp/dialer.go')
    if cn=='grpc':
        if grpc_path(ct.get('serviceName') or '',bool(ct.get('multiMode'))) != grpc_path(bt.get('serviceName') or '',bool(ct.get('multiMode'))):
            emit('PEER_GRPC_METHOD','Нормализованный клиентский RPC path отсутствует среди соответствующих методов сервера.','grpcSettings.serviceName',source='transport/internet/grpc/config.go')
    if cn=='hysteria' and c.get('protocol')!='hysteria' and ct.get('auth')!=bt.get('auth'):
        emit('PEER_TRANSPORT_AUTH','Transport auth Hysteria различается; это отдельная аутентификация от вложенного VLESS.','hysteriaSettings.auth',source='transport/internet/hysteria/hub.go')
    if csec==ssec=='tls':
        cc=cs.get('tlsSettings') or {};sc=bs.get('tlsSettings') or {}
        if not isinstance(cc,dict) or not isinstance(sc,dict):return
        utls=uses_utls(cs,cn)
        verified_go=cn=='mkcp' or cn in ('raw','grpc','websocket','httpupgrade','xhttp') and cc.get('fingerprint')=='unsafe' and http_version(cs)!='h3'
        if not utls and not verified_go and any(k in cc for k in ('minVersion','maxVersion')):
            emit('PEER_TLS_ENGINE_REVIEW','TLS-version policy этой ветки (QUIC/storage/специализированный dialer) не выводится из обычного TCP Go TLS сравнения. Требуется native handshake.','tlsSettings','COVERAGE','WARNING')
        pairs=[] if not verified_go else [(cc.get('minVersion') or '1.2',sc.get('maxVersion') or '1.3'),(sc.get('minVersion') or '1.2',cc.get('maxVersion') or '1.3')]
        if utls and any(k in cc for k in ('minVersion','maxVersion','cipherSuites','curvePreferences','enableSessionResumption')):
            emit('UTLS_FIELDS_NOT_COPIED','uTLS copyConfig не переносит min/maxVersion, cipherSuites, curvePreferences и session-resumption policy; явные JSON-настройки не подтверждают применённые TLS-ограничения.','tlsSettings','SOURCE_RUNTIME','WARNING','transport/internet/tls/tls.go')
        for low,high in pairs:
            if low in ('1.0','1.1','1.2','1.3') and high in ('1.0','1.1','1.2','1.3') and low>high:emit('PEER_TLS_VERSION','Диапазоны TLS-версий не пересекаются.','tlsSettings')
        if cc.get('pinnedPeerCertSha256') or cc.get('serverName'):
            # Certificate files are intentionally NOT opened as a side effect of --peer.
            emit('PEER_CERT_UNVERIFIED','Цепочка сертификатов/SAN/срок/pin не проверены этим сравнением JSON; файлы по путям из конфига не открываются. Нужен TLS handshake.','tlsSettings','COVERAGE','WARNING')
    if csec!=ssec:return  # direct wire comparison is not valid across an unknown frontend
    layer='udp' if cn in ('mkcp','hysteria') or (cn in ('xhttp','masque') and http_version(cs)=='h3') else 'tcp'
    if cn=='xdrive':return  # storage service TLS/masks are not a direct peer transport
    def masks(s):
        fm=s.get('finalmask') or {};arr=fm.get(layer,[]) if isinstance(fm,dict) else []
        return [x for x in arr if isinstance(x,dict) and x.get('type') not in ('fragment','noise','udphop')]
    cm,sm=masks(cs),masks(bs)
    if [x.get('type') for x in cm]!=[x.get('type') for x in sm]:
        emit('PEER_MASK_ORDER','Набор или порядок декодирующих масок сторон различается; fragment/noise/клиентский udphop исключены из сравнения.','finalmask.'+layer,source='transport/internet/finalmask/finalmask.go');return
    for a,z in zip(cm,sm):
        typ=a.get('type');x=a.get('settings') or {};y=z.get('settings') or {}
        if not isinstance(x,dict) or not isinstance(y,dict):continue
        if typ in ('salamander','sudoku','xmc') and x.get('password','')!=y.get('password',''):
            emit('PEER_MASK_SECRET','Секрет декодирующей маски различается; значения скрыты.','finalmask.'+layer)
        if typ=='salamander':
            from lint_config import range32
            if bool(range32(x.get('packetSize',0))[1]>0)!=bool(range32(y.get('packetSize',0))[1]>0):emit('PEER_SALAMANDER_FRAMING','Одна сторона включает Gecko, другая — обычный Salamander.','finalmask.'+layer)
        if typ=='sudoku':
            def norm(s):
                ascii=str(s.get('ascii','')).strip().lower();ascii='ascii' if ascii in ('ascii','prefer_ascii') else 'entropy'
                raw=s.get('customTables') or s.get('custom_tables') or [s.get('customTable') or s.get('custom_table') or '']
                tables=tuple(dict.fromkeys(a.strip().lower().replace(' ','') for a in raw)) if ascii=='entropy' else ()
                return ascii,tables
            if norm(x)!=norm(y):emit('PEER_SUDOKU_TABLES','Нормализованные ASCII/table set различаются; padding может отличаться.','finalmask.'+layer)
        if typ=='mkcp-legacy':
            aheader=x.get('header','').lower();bheader=y.get('header','').lower()
            if aheader!=bheader or (not aheader and x.get('value','')!=y.get('value','')):emit('PEER_MKCP_LEGACY','Различается legacy framing либо пароль AES.','finalmask.'+layer)
        if typ=='header-custom':
            if (x.get('mode')=='standalone') != (y.get('mode')=='standalone'):emit('PEER_CUSTOM_MODE','Prefix и standalone — разные framing.','finalmask.'+layer)
            keys=('clients','servers') if layer=='tcp' else ('client','server')
            def wire(s):
                def clean(item):
                    if isinstance(item,list):return [clean(t) for t in item]
                    if not isinstance(item,dict):return item
                    return {k:clean(t) for k,t in item.items() if k not in ('delay','randRange')}
                return {k:clean(s.get(k,[])) for k in keys}
            if wire(x)!=wire(y):emit('PEER_CUSTOM_SEQUENCE','Определения header-custom расходятся. Разные, но эквивалентные выражения требуют отдельного wire-теста.','finalmask.'+layer)
        if typ=='xmc':
            xs=x.get('profiles',[]);ys=y.get('profiles',[])
            if not all(p in ys for p in xs):emit('PEER_XMC_PROFILES','Не все случайно выбираемые клиентом профили есть на сервере.','finalmask.'+layer)
        if typ in ('xdns','xicmp','realm'):
            emit('PEER_CARRIER_TOPOLOGY','У carrier различаются роли client/server; локальное сравнение не проверяет DNS delegation, ICMP ACL или NAT/STUN.','finalmask.'+layer,'COVERAGE','WARNING')


def uses_utls(stream,net):
    tls=stream.get('tlsSettings') or {}
    if not isinstance(tls,dict) or tls.get('fingerprint')=='unsafe':return False
    return net in ('raw','grpc','websocket','httpupgrade') or net in ('xhttp','masque') and http_version(stream)!='h3'
