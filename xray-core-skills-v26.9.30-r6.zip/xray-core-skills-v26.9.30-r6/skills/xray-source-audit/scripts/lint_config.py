#!/usr/bin/env python3
"""Read-only, conservative transport lint for Xray-core v26.9.30.
Not a complete JSON Schema, core parser, runtime test or security audit.
Only Python >=3.10 standard library. Does not access network or run Xray.
"""
from __future__ import annotations
import argparse
import base64
import json
import math
import re
import sys
from pathlib import Path
from typing import Any

SHA = 'b26a91de4f3294e26a0ad0a970b81a386a41f789'
SOURCE = 'https://github.com/XTLS/Xray-core/blob/' + SHA + '/'
FIELDS = json.loads((Path(__file__).resolve().parent.parent / 'references/transport-fields.json').read_text(encoding='utf-8'))
ALIASES = {'raw':'raw', 'tcp':'raw', 'xhttp':'xhttp', 'splithttp':'xhttp', 'kcp':'mkcp', 'mkcp':'mkcp', 'grpc':'grpc', 'ws':'websocket', 'websocket':'websocket', 'httpupgrade':'httpupgrade', 'hysteria':'hysteria', 'masque':'masque', 'xdrive':'xdrive'}
KEYS = {'raw':'rawSettings','xhttp':'xhttpSettings','mkcp':'kcpSettings','grpc':'grpcSettings','websocket':'wsSettings','httpupgrade':'httpupgradeSettings','hysteria':'hysteriaSettings','masque':'masqueSettings','xdrive':'xdriveSettings'}
STREAM = {'address','port','method','network','security','finalmask','tlsSettings','realitySettings','sockopt','tcpSettings','splithttpSettings'} | set(FIELDS)
TLS = set('allowInsecure certificates serverName alpn enableSessionResumption disableSystemRoot minVersion maxVersion cipherSuites fingerprint rejectUnknownSni curvePreferences masterKeyLog pinnedPeerCertSha256 verifyPeerCertByName echServerKeys echConfigList echSockopt'.split())
SOCK = set('mark tcpFastOpen tproxy acceptProxyProtocol domainStrategy dialerProxy tcpKeepAliveInterval tcpKeepAliveIdle tcpCongestion tcpWindowClamp tcpMaxSeg penetrate tcpUserTimeout v6only interface tcpMptcp customSockopt addressPortStrategy happyEyeballs trustedXForwardedFor'.split())
REAL = set('masterKeyLog show target dest type xver serverNames privateKey minClientVer maxClientVer maxTimeDiff shortIds mldsa65Seed limitFallbackUpload limitFallbackDownload fingerprint serverName password publicKey shortId mldsa65Verify spiderX'.split())

def pairs(items: list[tuple[str,Any]]) -> dict[str,Any]:
    out = {}
    for k,v in items:
        if k in out:
            raise ValueError('Duplicate JSON key; name redacted')
        out[k] = v
    return out

def loads(text: str) -> Any:
    def bad_constant(_: str) -> None:
        raise ValueError('Non-standard JSON numeric constant')
    def finite_float(raw: str) -> float:
        value=float(raw)
        if not math.isfinite(value):raise ValueError('Nonfinite JSON number')
        return value
    return json.loads(text, object_pairs_hook=pairs, parse_constant=bad_constant, parse_float=finite_float)

def integer(v: Any) -> bool:
    return type(v) is int

def range32(v: Any) -> tuple[int,int]:
    """Safe authoring subset. Reject int32 overflow, do not emulate Go casts."""
    if integer(v): a=b=v
    elif isinstance(v,str):
        if v == '': a=b=0
        else:
            m=re.fullmatch(r'([+-]?\d+)(?:-([+-]?\d+))?',v)
            if not m: raise ValueError('Expected integer or range string')
            a=int(m[1]);b=int(m[2]) if m[2] is not None else a
    else: raise ValueError('Expected integer or range string')
    if min(a,b)<-(2**31) or max(a,b)>2**31-1: raise ValueError('Range outside safe int32 bounds')
    return min(a,b),max(a,b)

def strings(v: Any) -> bool:
    return isinstance(v,list) and all(isinstance(x,str) for x in v)

class Linter:
    def __init__(self) -> None:
        self.issues: list[dict[str,str]]=[]
    def emit(self,code: str,path: str,message: str,kind: str='SOURCE_BUILD',severity: str='ERROR',file: str='') -> None:
        if not file:
            file = 'infra/conf/transport_method.go'
            if code.startswith(('REALITY_','TLS_')) or code=='KEY_LOG':file='infra/conf/transport_security.go'
            if code in ('INACTIVE_SETTINGS','INACTIVE_SECURITY','NETWORK_TYPE','SECURITY_TYPE','PORT'):file='infra/conf/transport_internet.go'
            if code in ('XHTTP_POST_RANGE','XHTTP_DOWNLOAD_DEST'):file='transport/internet/splithttp/dialer.go'
            if code in ('XDRIVE_OPERATION','XDRIVE_LIST_REGEX'):file='transport/internet/xdrive/template.go'
            if code=='TPROXY_TYPO':file='infra/conf/transport_sockopt.go'
        self.issues.append(dict(severity=severity,code=code,path=path,category=kind,message=message,source=SOURCE+file))
    def unknown(self,obj: dict,allowed: set[str],path: str) -> None:
        for k in obj.keys()-allowed:
            self.emit('UNKNOWN_FIELD',path+'.<unknown-field>','Поле отсутствует в проверенном transport inventory; core может его проигнорировать.','AUTHORING_POLICY')
    def obj(self,v: Any,p: str) -> bool:
        if not isinstance(v,dict):
            self.emit('OBJECT',p,'Ожидается JSON object.','AUTHORING_POLICY');return False
        return True
    def types(self,obj: dict,schema: dict[str,str],p: str) -> None:
        self.unknown(obj,set(schema),p)
        for k,v in obj.items():
            if k not in schema:continue
            t=schema[k].rstrip('?');ok=True
            if v is None:
                self.emit('NULL',p+'.'+k,'Явный null требует отдельного анализа; генератору следует опустить поле либо задать типизированное значение.','AUTHORING_POLICY','WARNING');continue
            if t=='string':ok=isinstance(v,str)
            elif t=='boolean':ok=type(v) is bool
            elif t in ('object','StreamConfig'):ok=isinstance(v,dict)
            elif t=='array[string]':ok=strings(v)
            elif t=='map[string]string':ok=isinstance(v,dict) and all(isinstance(x,str) for x in v.values())
            elif t in ('uint32','int32','int64'):
                n=int(t[-2:]);lo=0 if t.startswith('u') else -(2**(n-1));hi=2**n-1 if t.startswith('u') else 2**(n-1)-1
                ok=integer(v) and lo<=v<=hi
            elif t=='range':
                try: range32(v)
                except ValueError:ok=False
            if not ok:self.emit('TYPE',p+'.'+k,'Неверный тип или значение вне безопасных границ '+t+'.','AUTHORING_POLICY')
    def rg(self,obj: dict,k: str,p: str) -> tuple[int,int]:
        try:return range32(obj.get(k,0))
        except ValueError:return (0,0) # types() already reports the malformed value
    def enum(self,obj: dict,k: str,values: set[str],p: str,lower: bool=False) -> None:
        v=obj.get(k,'')
        if isinstance(v,str) and (v.lower() if lower else v) not in values:
            self.emit('ENUM',p+'.'+k,'Значение не входит в enum этой версии.')
    def tls(self,o: Any,p: str) -> None:
        if not self.obj(o,p):return
        self.unknown(o,TLS,p)
        if o.get('allowInsecure') is True:self.emit('TLS_INSECURE_REMOVED',p+'.allowInsecure','allowInsecure=true удалён; настройте проверяемое доверие/сертификат.','SOURCE_BUILD',file='infra/conf/transport_security.go')
        pin=o.get('pinnedPeerCertSha256')
        if pin is not None:
            if not isinstance(pin,str):self.emit('TLS_PIN_TYPE',p+'.pinnedPeerCertSha256','Ожидается comma-separated hex string.','SOURCE_BUILD',file='infra/conf/transport_security.go')
            else:
                for part in pin.split(','):
                    if part.strip() and not re.fullmatch(r'[0-9a-fA-F]{64}',part.strip().replace(':','')):
                        self.emit('TLS_PIN_FORMAT',p+'.pinnedPeerCertSha256','Каждый непустой SHA256 pin должен декодироваться в32 bytes.','SOURCE_BUILD',file='infra/conf/transport_security.go');break
        if o.get('masterKeyLog'):self.emit('KEY_LOG',p+'.masterKeyLog','Лог ключей не включать в production.','AUTHORING_POLICY','WARNING')
    def reality(self,o: Any,p: str) -> None:
        if not self.obj(o,p):return
        self.unknown(o,REAL,p)
        server=o.get('target',o.get('dest')) is not None
        if server:
            for key in ('serverNames','shortIds','privateKey'):
                if not o.get(key):self.emit('REALITY_REQUIRED',p+'.'+key,'Обязательное непустое поле серверной ветки.','SOURCE_BUILD',file='infra/conf/transport_security.go')
            if o.get('xver',0) not in (0,1,2):self.emit('REALITY_XVER',p+'.xver','Допустимы0,1,2.')
            if o.get('mldsa65Seed') and o.get('mldsa65Seed')==o.get('privateKey'):self.emit('REALITY_SEED_REUSE',p,'MLDSA seed и privateKey не должны совпадать.')
        else:
            for key in ('serverNames','shortIds'):
                if o.get(key):self.emit('REALITY_SIDE',p+'.'+key,'В клиентской ветке требуется поле в единственном числе.')
            if not (o.get('password') or o.get('publicKey')):self.emit('REALITY_REQUIRED',p+'.password','Клиентская публичная часть обязательна.')
            if o.get('target') is not None:self.emit('REALITY_TARGET_CLIENT',p,'Наличие target переключает builder на серверную ветку.','AUTHORING_POLICY')
        for key,size in (('privateKey',32),('password',32),('publicKey',32),('mldsa65Seed',32),('mldsa65Verify',1952)):
            v=o.get(key)
            if not v:continue
            try:
                if not isinstance(v,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',v):raise ValueError()
                if len(base64.urlsafe_b64decode(v+'='*((-len(v))%4)))!=size:raise ValueError()
            except (ValueError,TypeError):self.emit('REALITY_KEY_FORMAT',p+'.'+key,'Требуется base64url без padding заданной длины; значения не выводятся.')
        ids=o.get('shortIds',[]) if server else [o.get('shortId','')]
        if isinstance(ids,list):
            for v in ids:
                if not isinstance(v,str) or len(v)>16 or len(v)%2 or re.search(r'[^0-9A-Fa-f]',v):self.emit('REALITY_SHORTID',p,'shortId должен быть корректной hex строкой длиной<=16.');break
    def transport(self,key: str,o: Any,p: str,stream: dict,active: bool,depth: int) -> None:
        if not self.obj(o,p):return
        self.types(o,FIELDS[key],p)
        if key=='xhttpSettings':
            if o.get('extra') is not None:
                ext=o['extra']
                if not isinstance(ext,dict):return
                shadow=(set(o) & set(FIELDS[key]))-{'host','path','mode','extra'}
                if shadow:self.emit('XHTTP_EXTRA_SHADOW',p,'Внешние расширенные параметры заменяются extra: '+', '.join(sorted(shadow)), 'SOURCE_SEMANTICS','WARNING')
                self.types(ext,FIELDS[key],p+'.extra')
                o={**ext,**{k:o.get(k,'') for k in ('host','path','mode')}}
            mode=o.get('mode','')
            self.enum(o,'mode',{'','auto','packet-up','stream-up','stream-one'},p)
            for k,vals in [('xPaddingPlacement',{'','cookie','header','query','queryInHeader'}),('xPaddingMethod',{'','repeat-x','tokenish'}),('sessionIDPlacement',{'','path','cookie','header','query'}),('seqPlacement',{'','path','cookie','header','query'}),('uplinkDataPlacement',{'','auto','body','cookie','header'})]:self.enum(o,k,vals,p)
            if o.get('uplinkDataPlacement') in ('cookie','header') and mode!='packet-up':self.emit('XHTTP_DATA_MODE',p+'.uplinkDataPlacement','cookie/header требуют явно заданный packet-up.')
            meth=o.get('uplinkHTTPMethod','')
            if isinstance(meth,str) and meth.upper()=='GET' and mode!='packet-up':self.emit('XHTTP_GET_MODE',p+'.uplinkHTTPMethod','GET требует явно заданный packet-up.')
            a,b=self.rg(o,'xPaddingBytes',p)
            if (a,b)!=(0,0) and (a<=0 or b<=0):self.emit('XHTTP_PADDING',p+'.xPaddingBytes','Ненулевой padding range не может содержать границу<=0.')
            a,b=self.rg(o,'scMaxEachPostBytes',p)
            packet_mode = mode=='packet-up' or (mode in ('','auto') and str(stream.get('security','')).lower()!='reality')
            if active and packet_mode and b!=0 and a<=0:self.emit('XHTTP_POST_RANGE',p+'.scMaxEachPostBytes','При packet-up consumer имеет panic для From<=0.','SOURCE_RUNTIME_RISK')
            if isinstance(o.get('serverMaxHeaderBytes'),int) and o['serverMaxHeaderBytes']<0:self.emit('XHTTP_HEADER_LIMIT',p+'.serverMaxHeaderBytes','Отрицательный лимит запрещён.')
            xm=o.get('xmux')
            if isinstance(xm,dict):
                self.types(xm,{k:'range' for k in ('maxConcurrency','maxConnections','cMaxReuseTimes','hMaxRequestTimes','hMaxReusableSecs')}|{'hKeepAlivePeriod':'int64'},p+'.xmux')
                if self.rg(xm,'maxConnections',p)[1]>0 and self.rg(xm,'maxConcurrency',p)[1]>0:self.emit('XHTTP_XMUX_CONFLICT',p+'.xmux','maxConnections и maxConcurrency не могут быть одновременно положительными.')
            down=o.get('downloadSettings')
            if down is not None:
                if mode=='stream-one':self.emit('XHTTP_DOWNLOAD_MODE',p+'.downloadSettings','downloadSettings запрещён при stream-one.')
                if isinstance(down,dict):
                    if active and (not down.get('address') or not down.get('port') or ALIASES.get(str(down.get('method',down.get('network','raw'))).lower())!='xhttp'):
                        self.emit('XHTTP_DOWNLOAD_DEST',p+'.downloadSettings','Укажите address,port и network=xhttp: consumer разыменовывает destination и приводит transport config к XHTTP.','SOURCE_RUNTIME_RISK')
                    self.stream(down,p+'.downloadSettings',depth+1)
            tls=stream.get('tlsSettings') or {};mask=stream.get('finalmask') or {}
            qp=mask.get('quicParams',{}) if isinstance(mask,dict) else {}
            if active and isinstance(tls,dict) and tls.get('alpn') in (['h3'],'h3') and isinstance(qp,dict) and str(qp.get('congestion','')).lower()=='brutal':
                self.emit('XHTTP_H3_BRUTAL',p,'XHTTP H3 client switch не поддерживает brutal, несмотря на общий Build enum.','SOURCE_RUNTIME_RISK',file='transport/internet/splithttp/dialer.go')
        if key in ('xhttpSettings','httpupgradeSettings','wsSettings'):
            h=o.get('headers')
            if isinstance(h,dict) and any(k.lower()=='host' for k in h):
                ws=key=='wsSettings'
                self.emit('HOST_HEADER',p+'.headers','Используйте отдельное host; WS делает deprecated перенос, XHTTP/HTTPUpgrade отклоняют Host.',severity='WARNING' if ws else 'ERROR')
        if key in ('wsSettings','httpupgradeSettings') and isinstance(o.get('path'),str):
            for m in re.finditer(r'(?:[?&])ed=([^&]*)',o['path']):
                if not re.fullmatch(r'\d+',m[1]) or int(m[1])>2**32-1:self.emit('EARLY_DATA_VALUE',p+'.path','ed должен быть явным неотрицательным uint32; не полагайтесь на ignored parse error/cast.','AUTHORING_POLICY')
        if key=='kcpSettings':
            for k in ('header','seed'):
                if k in o:self.emit('KCP_IGNORED',p+'.'+k,'Поле есть в struct, но этот Build не переносит его в transport config.','SOURCE_SEMANTICS','WARNING')
            def num(k: str,d: int) -> int:return o[k] if integer(o.get(k)) else d
            mtu=num('mtu',1350);tti=num('tti',50);cw=num('cwndMultiplier',1);sw=num('maxSendingWindow',2097152)
            if mtu<21:self.emit('KCP_MTU',p+'.mtu','MTU минимум21.')
            if not 10<=tti<=1000:self.emit('KCP_TTI',p+'.tti','TTI10..1000.')
            if cw<1:self.emit('KCP_CWND',p+'.cwndMultiplier','Минимум1.')
            if mtu>0 and sw//mtu==0:self.emit('KCP_WINDOW',p+'.maxSendingWindow','Окно должно вмещать хотя бы MTU.')
        if key=='hysteriaSettings':
            if o.get('version')!=2:self.emit('HYSTERIA_VERSION',p+'.version','Требуется version=2.')
            u=o.get('udpIdleTimeout',0)
            if integer(u) and u!=0 and not 2<=u<=600:self.emit('HYSTERIA_TIMEOUT',p+'.udpIdleTimeout','Не0 →2..600 секунд.')
        if key=='masqueSettings':
            h=o.get('headers',{})
            if isinstance(h,dict):
                for k in h:
                    if k.lower() in ('host','capsule-protocol') or (k.lower()=='authorization' and (o.get('user') or o.get('pass'))):self.emit('MASQUE_HEADER',p+'.headers.'+k,'Запрещённый или конфликтующий MASQUE header.')
            if isinstance(o.get('user'),str) and ':' in o['user']:self.emit('MASQUE_USER',p+'.user','Двоеточие запрещено.')
            if isinstance(o.get('path'),str) and o['path'] and not o['path'].startswith('/'):self.emit('MASQUE_PATH',p+'.path','Путь должен начинаться с /.')
        if key=='xdriveSettings':
            svc=o.get('service')
            if svc not in ('local','Google Drive','template'):self.emit('XDRIVE_SERVICE',p+'.service','Только local, Google Drive, template; регистр важен.')
            if svc=='Google Drive' and (not isinstance(o.get('secrets'),list) or len(o['secrets'])!=3):self.emit('XDRIVE_SECRETS',p+'.secrets','Нужны ровно3 secrets в установленном порядке.')
            if svc=='template':
                t=o.get('template')
                if not isinstance(t,dict):self.emit('XDRIVE_TEMPLATE',p+'.template','Нужен template object.')
                else:
                    for op in ('put','get','list','delete'):
                        if not isinstance(t.get(op),dict) or not t[op].get('url'):self.emit('XDRIVE_OPERATION',p+'.template.'+op,'Runtime требует URL операции.','SOURCE_RUNTIME_RISK')
                    if not isinstance(t.get('list'),dict) or not t['list'].get('namesRegex'):self.emit('XDRIVE_LIST_REGEX',p+'.template.list','Runtime требует namesRegex с capture group; Go regex проверять ядром.','SOURCE_RUNTIME_RISK')
    def stream(self,o: Any,p: str='$',depth: int=0) -> None:
        if depth>24:self.emit('DEPTH',p,'Превышена защитная глубина lint.','AUTHORING_POLICY');return
        if not self.obj(o,p):return
        self.unknown(o,STREAM,p)
        for a,b in (('method','network'),('rawSettings','tcpSettings'),('xhttpSettings','splithttpSettings')):
            if o.get(a) is not None and o.get(b) is not None:self.emit('ALIAS_SHADOW',p+'.'+a,a+' перекрывает '+b+'; используйте один вариант.','SOURCE_SEMANTICS','WARNING',file='infra/conf/transport_internet.go')
        raw=o.get('method',o.get('network','raw'))
        if not isinstance(raw,str):self.emit('NETWORK_TYPE',p+'.network','network/method должен быть строкой.');return
        raw=raw.lower();net=ALIASES.get(raw)
        if raw in ('quic','http','h2','h3'):self.emit('TRANSPORT_REMOVED',p+'.network','Старый транспорт удалён; это не режим нового XHTTP.','SOURCE_BUILD',file='infra/conf/transport_internet.go')
        elif net is None:self.emit('NETWORK_UNKNOWN',p+'.network','Неизвестный transport network.','SOURCE_BUILD',file='infra/conf/transport_internet.go')
        if net in ('grpc','websocket','httpupgrade'):self.emit('TRANSPORT_DEPRECATED',p+'.network','Транспорт поддержан, но builder выдаёт non-removal deprecated warning.','SOURCE_SEMANTICS','WARNING',file='infra/conf/transport_internet.go')
        security=o.get('security','')
        if not isinstance(security,str):self.emit('SECURITY_TYPE',p+'.security','security должен быть строкой.');security=''
        security=security.lower()
        if security not in ('','none','tls','reality'):self.emit('SECURITY_UNSUPPORTED',p+'.security','Разрешены none,tls,reality; legacy xtls удалён.','SOURCE_BUILD',file='infra/conf/transport_internet.go')
        if security=='reality':
            if net not in ('raw','xhttp','grpc'):self.emit('REALITY_TRANSPORT',p,'REALITY допускается только RAW,XHTTP,gRPC.','SOURCE_BUILD',file='infra/conf/transport_internet.go')
            if o.get('realitySettings') is None:self.emit('REALITY_EMPTY',p+'.realitySettings','Отсутствует realitySettings.')
            else:self.reality(o['realitySettings'],p+'.realitySettings')
        elif o.get('realitySettings') is not None:self.emit('INACTIVE_SECURITY',p+'.realitySettings','realitySettings не выбирается без security=reality.','SOURCE_SEMANTICS','WARNING')
        if o.get('tlsSettings') is not None:
            if security=='tls':self.tls(o['tlsSettings'],p+'.tlsSettings')
            else:self.emit('INACTIVE_SECURITY',p+'.tlsSettings','tlsSettings не выбирается без security=tls.','SOURCE_SEMANTICS','WARNING')
        if net in ('masque','hysteria') and security!='tls':self.emit('TLS_EXPECTED',p+'.security','Для этой схемы нужен подтверждённый TLS контекст; генератор требует security=tls.','AUTHORING_POLICY')
        effective=dict(o)
        if o.get('rawSettings') is None and o.get('tcpSettings') is not None:effective['rawSettings']=o['tcpSettings']
        if o.get('xhttpSettings') is None and o.get('splithttpSettings') is not None:effective['xhttpSettings']=o['splithttpSettings']
        for k in FIELDS:
            if effective.get(k) is not None:
                active=k==KEYS.get(net)
                if not active:self.emit('INACTIVE_SETTINGS',p+'.'+k,'Build обрабатывает этот объект, но активный network выбирает другой transport.','SOURCE_SEMANTICS','WARNING')
                self.transport(k,effective[k],p+'.'+k,o,active,depth)
        so=o.get('sockopt')
        if isinstance(so,dict):
            self.unknown(so,SOCK,p+'.sockopt')
            if isinstance(so.get('tproxy'),str) and so['tproxy'].lower() not in ('','off','tproxy','redirect'):self.emit('TPROXY_TYPO',p+'.sockopt.tproxy','Неизвестное значение станет Off; проверьте опечатку.','AUTHORING_POLICY')
        if 'port' in o and (not integer(o['port']) or not 0<=o['port']<=65535):self.emit('PORT',p+'.port','streamSettings.port должен быть uint16.')
    def config(self,o: Any,as_stream: bool=False) -> list[dict[str,str]]:
        if as_stream:self.stream(o)
        elif self.obj(o,'$'):
            for side in ('inbounds','outbounds'):
                arr=o.get(side,[])
                if not isinstance(arr,list):self.emit('ENDPOINT_LIST','$.'+side,'Требуется массив.','AUTHORING_POLICY');continue
                for i,entry in enumerate(arr):
                    if isinstance(entry,dict) and 'streamSettings' in entry:self.stream(entry['streamSettings'],f'$.{side}[{i}].streamSettings')
        return self.issues

def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('file',type=Path);ap.add_argument('--stream',action='store_true',help='Input is StreamConfig rather than full config');ap.add_argument('--json',action='store_true',help='Machine-readable issues');a=ap.parse_args()
    try:
        if a.file.stat().st_size>16*1024*1024:raise ValueError('File exceeds 16 MiB safety limit')
        obj=loads(a.file.read_text(encoding='utf-8-sig'));issues=Linter().config(obj,a.stream)
    except (OSError,ValueError,RecursionError,TypeError,AttributeError,KeyError,OverflowError):
        print('INPUT_ERROR: malformed or unreadable input; values redacted.',file=sys.stderr);return 2
    if a.json:print(json.dumps({'scope':'transport-only','version':'v26.9.30','core_test_run':False,'issues':issues},ensure_ascii=False,indent=2))
    else:
        print('Transport-only lint v26.9.30. Core/runtime/peer tests NOT RUN.')
        for it in issues:print(f"{it['severity']} {it['code']} {it['path']}: {it['message']}")
        print(f"{sum(i['severity']=='ERROR' for i in issues)} error(s), {sum(i['severity']=='WARNING' for i in issues)} warning(s).")
    return 1 if any(i['severity']=='ERROR' for i in issues) else 0
if __name__=='__main__':sys.exit(main())
