"""VMess/Trojan config semantics and scoped VLESS key-pair checks.
Read-only, pinned to b26a91d. Error messages never include credentials.
"""
from __future__ import annotations
from peer_checks import canonical_id, decode_key, public_from_private


def users(options):
    # nil (including JSON null) does not shadow users; [] does.
    return options.get('clients') if options.get('clients') is not None else options.get('users', [])


def account(endpoint, protocol):
    opts = endpoint.get('settings') or {}
    if opts.get('address') is not None:
        return opts
    key = 'vnext' if protocol == 'vmess' else 'servers'
    targets = opts.get(key)
    if not isinstance(targets, list) or len(targets) != 1 or not isinstance(targets[0], dict):
        raise ValueError('one endpoint required')
    if protocol == 'trojan':
        return targets[0]
    accounts = targets[0].get('users')
    if not isinstance(accounts, list) or len(accounts) != 1 or not isinstance(accounts[0], dict):
        raise ValueError('one account required')
    return accounts[0]


def check_options(v, opts, path, side, protocol):
    source = 'infra/conf/' + protocol + '.go'
    def issue(code, msg, suffix='', category='SOURCE_BUILD', severity='ERROR'):
        v.issue(code, path+suffix, msg, category, severity, source)
    issue('PROTOCOL_DEPRECATED', 'Протокол поддерживается, но ядро печатает предупреждение об устаревании. Это не ошибка удаления.', category='SOURCE_BUILD', severity='WARNING')
    active = []
    if side == 'inbounds':
        active = users(opts)
        if opts.get('clients') is not None and opts.get('users') is not None:
            issue('CLIENTS_SHADOW', 'clients целиком заменяет users; даже [] не дополняет список.', severity='WARNING')
        if not isinstance(active, list):
            issue('PROTOCOL_USERS', 'Требуется массив пользователей.');return
    else:
        key = 'vnext' if protocol == 'vmess' else 'servers'
        if opts.get('address') is not None:
            targets = [opts]
            if key in opts:
                issue('PROTOCOL_ENDPOINT_SHADOW', 'Указанный simplified address заменяет legacy-массив целиком.', severity='WARNING')
        else:
            targets = opts.get(key)
        if not isinstance(targets, list) or len(targets) != 1 or not isinstance(targets[0], dict):
            issue('PROTOCOL_ONE_ENDPOINT', 'Для outbound требуется ровно один endpoint; балансировку задавайте отдельными outbounds.');return
        target = targets[0]
        if not isinstance(target.get('address'), str) or not target['address']:
            issue('PROTOCOL_ADDRESS', 'Endpoint должен иметь непустой address.', category='AUTHORING_POLICY')
        if type(target.get('port')) is not int or not 1 <= target['port'] <= 65535:
            issue('PROTOCOL_PORT', 'Задайте порт endpoint в диапазоне 1..65535.', category='AUTHORING_POLICY')
        if protocol == 'trojan' or opts.get('address') is not None:
            active = [target]
        else:
            active = target.get('users')
            if not isinstance(active,list) or len(active)!=1:
                issue('PROTOCOL_ONE_ACCOUNT', 'Legacy VMess outbound требует ровно один users member.');return
    identities=set()
    for i, user in enumerate(active):
        suffix=f'.<active-user:{i}>'
        if not isinstance(user, dict):
            issue('PROTOCOL_USER_OBJECT', 'Элемент users не объект.',suffix);continue
        if protocol == 'vmess':
            try:
                identity=canonical_id(user.get('id'))
            except (ValueError,TypeError):
                issue('VMESS_ID','Неверная форма идентификатора.',suffix+'.id');continue
            security=user.get('security','')
            if isinstance(security,str) and security.lower() not in ('','auto','aes-128-gcm','chacha20-poly1305'):
                issue('VMESS_SECURITY_AUTO','Неизвестный security (включая none/zero) Build превращает в AUTO, а не в незашифрованный режим.',suffix+'.security',severity='WARNING')
            experiments=user.get('experiments','')
            if experiments:
                issue('VMESS_EXPERIMENTS','Флаги experiments определяются регистрозависимыми подстроками AuthenticatedLength и NoTerminationSignal; это не транспортные опции.',suffix+'.experiments',severity='WARNING')
        else:
            identity=user.get('password')
            if not isinstance(identity,str) or not identity:
                issue('TROJAN_PASSWORD','Задайте непустой password; пустые inbound credentials небезопасны.',suffix+'.password','AUTHORING_POLICY')
                continue
            if user.get('flow'):
                issue('TROJAN_FLOW_REMOVED','Непустой flow у Trojan удалён, Vision сюда переносить нельзя.',suffix+'.flow')
        if identity in identities:
            issue('PROTOCOL_DUPLICATE_CREDENTIAL','Повтор действующих credentials; устраните неоднозначную запись.',suffix,'AUTHORING_POLICY','WARNING')
        identities.add(identity)
    if protocol=='trojan' and side=='inbounds':
        fallbacks=opts.get('fallbacks') or []
        if isinstance(fallbacks,list):
            for fb in fallbacks:
                if not isinstance(fb,dict):continue
                fp=fb.get('path','')
                if isinstance(fp,str) and fp and not fp.startswith('/'):
                    issue('TROJAN_FALLBACK_PATH','fallback path должен начинаться с /.','.fallbacks.path')
                if type(fb.get('xver',0)) is int and fb.get('xver',0)>2:
                    issue('TROJAN_FALLBACK_XVER','Допустимы xver 0, 1, 2.','.fallbacks.xver')
                if not fb.get('dest'):
                    issue('TROJAN_FALLBACK_DEST','Нужен dest для fallback.','.fallbacks.dest','AUTHORING_POLICY')


def check_pair(v, client, server):
    protocol=client.get('protocol')
    if server.get('protocol') != protocol:
        return
    ca=account(client,protocol);us=users(server.get('settings') or {})
    if not isinstance(us,list):raise ValueError('invalid users')
    if protocol=='vmess':
        expected=canonical_id(ca.get('id'))
        matched=any(isinstance(u,dict) and canonical_id(u.get('id'))==expected for u in us)
    else:
        expected=ca.get('password')
        matched=isinstance(expected,str) and bool(expected) and any(isinstance(u,dict) and u.get('password')==expected for u in us)
    if not matched:
        v.issue('PEER_AUTH','$','Действующие credentials клиента не совпадают с выбранной серверной записью; значения скрыты.','SOURCE_RUNTIME',file='infra/conf/'+protocol+'.go')


def encryption_pair(v, encryption, decryption):
    """Prove only the single X25519 key form; no pretend ML-KEM verifier."""
    source='infra/conf/vless.go'
    c=encryption.split('.') if isinstance(encryption,str) else []
    s=decryption.split('.') if isinstance(decryption,str) else []
    if len(c)==len(s)==4 and c[0]==s[0]=='mlkem768x25519plus':
        try:
            if len(decode_key(s[3]))==32 and len(decode_key(c[3]))==32:
                public=public_from_private(s[3])
                if public is not None:
                    if public!=decode_key(c[3]):
                        v.issue('PEER_VLESS_ENCRYPTION_KEY','$','X25519 encryption/decryption ключи не образуют пару; значения скрыты.','SOURCE_RUNTIME',file=source)
                    if c[1]!=s[1]:
                        v.issue('PEER_VLESS_ENCRYPTION_MODE','$','Режимы native/xorpub/random различаются; требуется согласование.','AUTHORING_POLICY',file=source)
                    return
        except (ValueError,TypeError):
            pass
    v.issue('PEER_VLESS_ENCRYPTION_UNVERIFIED','$','Ненулевое encryption на обеих сторонах само по себе не подтверждает ключи. ML-KEM, цепочки ключей и padding требуют генерации точным ядром и handshake.','COVERAGE','WARNING',source)
