"""Read and verify an explicitly trusted local binary before any execution."""
from __future__ import annotations
import hashlib
import re
from pathlib import Path


def verify_binary(path: Path, expected_sha256: str) -> str:
    if not isinstance(expected_sha256, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected_sha256):
        raise ValueError("a trusted SHA256 is required")
    path = Path(path).resolve(strict=True)
    if not path.is_file():
        raise ValueError("binary must be a regular file")
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    observed = h.hexdigest()
    if observed != expected_sha256.lower():
        raise ValueError("binary checksum mismatch; nothing executed")
    return observed
