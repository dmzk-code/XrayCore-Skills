"""Preflight of the canonical local renderer; not a sandbox for a hostile binary.
SHA256 manifests alone cannot stop edited configs with recomputed digests. Rebuild
expected fixtures from bounded ports and credentials and reject every extra field,
including hidden api.listen/env/log paths, additional outbounds and storage roots.
"""
from __future__ import annotations
import copy
from pathlib import Path
from build_lab import make_pair, nginx_text
from lint_config import loads


def verify_fixture(directory: Path, name: str, topology: dict, hashes: dict) -> None:
    required={'server.json','client.json','negative-auth.json','topology.json','lab-cert.pem','lab-key.pem','static-validation.json'}
    if name=='raw-reality':required.add('reality-private.pem')
    if name=='chain-raw-tls':required.add('relay.json')
    if name=='xhttp-split-nginx':required.add('nginx.conf')
    if not required<=set(hashes):raise ValueError('manifest omits an executed fixture')
    client=loads((directory/'client.json').read_text(encoding='utf-8'))
    server=loads((directory/'server.json').read_text(encoding='utf-8'))
    try:
        primary=client['outbounds'][0]; inbound=server['inbounds'][0]
        cs=primary['streamSettings'];bs=inbound['streamSettings']
        cred={'uuid':primary['settings'].get('id',''), 'auth':'',
              'pin':cs.get('tlsSettings',{}).get('pinnedPeerCertSha256',''),
              'cert':str(directory/'lab-cert.pem'),'key':str(directory/'lab-key.pem'),
              'private':bs.get('realitySettings',{}).get('privateKey',''),
              'public':cs.get('realitySettings',{}).get('password',''),
              'shortid':cs.get('realitySettings',{}).get('shortId','')}
        if primary['protocol']=='hysteria':cred['auth']=cs['hysteriaSettings']['auth']
        elif primary['protocol']=='masque':cred['auth']=cs['masqueSettings']['pass']
        if any(not isinstance(x,str) or len(x)>8192 for x in cred.values()):raise ValueError('invalid fixture credential')
        ports=[topology[k] for k in ('server_port','client_socks','up_port','down_port','target_port','relay_port')]
        if len(set(ports))!=6:raise ValueError('duplicate lab port')
        expected=make_pair(name,str(directory),ports,cred)
        for filename,obj in expected.items():
            if loads((directory/filename).read_text(encoding='utf-8'))!=obj:raise ValueError('fixture differs from canonical local renderer')
        wrong=loads((directory/'negative-auth.json').read_text(encoding='utf-8'))
        negative=copy.deepcopy(client)
        if primary['protocol']=='vless':path=['outbounds',0,'settings','id']
        elif primary['protocol']=='hysteria':path=['outbounds',0,'streamSettings','hysteriaSettings','auth']
        else:path=['outbounds',0,'streamSettings','masqueSettings','pass']
        a=negative;b=wrong
        for k in path[:-1]:a=a[k];b=b[k]
        value=b[path[-1]]
        if not isinstance(value,str) or not value or len(value)>8192 or value==a[path[-1]]:raise ValueError('negative fixture is not a distinct credential')
        a[path[-1]]=value
        if wrong!=negative:raise ValueError('unexpected change in negative fixture')
        if name=='xhttp-split-nginx' and (directory/'nginx.conf').read_text(encoding='utf-8')!=nginx_text(str(directory),ports):raise ValueError('nginx fixture changed')
        if name=='xdrive-local' and (directory/'storage').is_symlink():raise ValueError('symlink storage root')
        static=loads((directory/'static-validation.json').read_text(encoding='utf-8'))
        if static.get('status')!='PASS_STATIC_ONLY':raise ValueError('lab did not pass static generation')
    except (KeyError, IndexError, TypeError, AttributeError) as err:
        raise ValueError('malformed canonical lab fixture') from err
