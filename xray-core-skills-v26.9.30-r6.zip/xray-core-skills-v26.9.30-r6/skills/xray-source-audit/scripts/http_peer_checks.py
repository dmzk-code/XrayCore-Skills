"""Pinned HTTP wire semantics for pair validation. No network or secret output.

Do not equate JSON spelling with effective request fields. XHTTP's active mode,
Go's Header.Get semantics, MASQUE's literal path/query and listener selection
are modeled here. This module is NOT an HTTP intermediary simulator.
"""
from __future__ import annotations
from urllib.parse import unquote, urlsplit, parse_qsl
import re
from lint_config import range32

MASQUE_DEFAULT_PATH = '/.well-known/masque/ip/*/*/'
MASQUE_REPLACEMENTS = (
    ('{target}', '*'), ('{ipproto}', '*'),
    ('{?target,ipproto}', '?target=*&ipproto=*'),
    ('{?ipproto,target}', '?ipproto=*&target=*'),
    ('{&target,ipproto}', '&target=*&ipproto=*'),
    ('{&ipproto,target}', '&ipproto=*&target=*'),
)


def xhttp_mode(config, security='none'):
    mode = config.get('mode') or 'auto'
    if mode != 'auto':
        return mode
    if security == 'reality':
        return 'stream-up' if config.get('downloadSettings') is not None else 'stream-one'
    return 'packet-up'


def xhttp_path(config):
    path = (config.get('path') or '').split('?', 1)[0]
    if not path.startswith('/'):
        path = '/' + path
    if any((config.get(key) or 'path') == 'path' for key in ('sessionIDPlacement', 'seqPlacement')):
        if not path.endswith('/'):
            path += '/'
    return path


def metadata(config, what):
    placement_key, key, default = (
        ('sessionIDPlacement', 'sessionIDKey', ('x_session', 'X-Session')) if what == 'session'
        else ('seqPlacement', 'seqKey', ('x_seq', 'X-Seq'))
    )
    placement = config.get(placement_key) or 'path'
    if placement == 'path':
        return placement, ''  # configured key is NOT consumed in this branch
    value = config.get(key) or (default[1] if placement == 'header' else default[0])
    return placement, value.lower() if placement == 'header' else value


def xhttp_data_placement(config, *, client):
    placement = config.get('uplinkDataPlacement') or 'auto'  # Build default
    return 'body' if client and placement == 'auto' else placement


def xhttp_padding_range(config):
    low, high = range32(config.get('xPaddingBytes', 0))
    return (100, 1000) if high == 0 else (low, high)


def valid_http_host(request, configured):
    """IsValidHTTPHost: lower-case; strip port from REQUEST only; no wildcard."""
    if not configured:
        return True
    request, configured = request.lower(), configured.lower()
    if ':' in request:
        if request.startswith('['):
            match = re.fullmatch(r'\[([^\]]+)\]:([^:]*)', request)
        else:
            match = re.fullmatch(r'([^:]*):([^:]*)', request)
        return bool(match and match.group(1) == configured)
    return request == configured


def explicit_host(config, transport):
    host = config.get('host') or ''
    if not host and transport == 'websocket':
        headers = config.get('headers') or {}
        values = [value for key, value in headers.items() if key.lower() == 'host']
        if len(values) == 1:
            host = values[0]
    return host


def destination_address(endpoint):
    # Normal protocol dialers pass their endpoint explicitly. The nested
    # streamSettings destination is consumed separately by XHTTP downloadSettings.
    settings = endpoint.get('settings') or {}
    if settings.get('address') is not None:
        return settings['address']
    for key in ('vnext', 'servers'):
        values = settings.get(key)
        if isinstance(values, list) and len(values) == 1 and isinstance(values[0], dict):
            return values[0].get('address')
    return None


def effective_http_host(endpoint, config, transport):
    stream = endpoint.get('streamSettings') or {}
    host = explicit_host(config, transport)
    if host:
        return host
    security = stream.get('security') or 'none'
    block = stream.get('tlsSettings' if security == 'tls' else 'realitySettings') or {}
    if security in ('tls', 'reality') and block.get('serverName'):
        return block['serverName']
    return destination_address(endpoint)


def masque_uri(path):
    path = path or MASQUE_DEFAULT_PATH
    for old, new in MASQUE_REPLACEMENTS:
        path = path.replace(old, new)
    if not path.startswith('/') or '{' in path or '}' in path:
        raise ValueError('invalid MASQUE path')
    if re.search(r'%(?![0-9a-fA-F]{2})', path):
        raise ValueError('invalid percent escape')
    u = urlsplit(path)
    if u.scheme or u.netloc or u.fragment:
        raise ValueError('unsupported URI form')
    query = {}
    for key, value in parse_qsl(u.query, keep_blank_values=True, encoding='utf-8', errors='strict'):
        query.setdefault(key, []).append(value)
    # Go URL.Path is decoded; URL.Query ignores ordering of keys, NOT of values.
    return unquote(u.path, errors='strict'), query


def alpn(stream):
    values = (stream.get('tlsSettings') or {}).get('alpn') or []
    return values.split(',') if isinstance(values, str) else values


def masque_client_version(stream):
    values = alpn(stream)
    return 'h3' if 'h3' in values or 'h2' not in values else 'h2'


def masque_server_versions(stream):
    values = alpn(stream)
    h2 = 'h2' in values
    return ({'h2'} if h2 else set()) | ({'h3'} if 'h3' in values or not h2 else set())


def check(v, client, server, cs, bs, ct, bt, transport):
    def issue(code, message, field='', category='SOURCE_RUNTIME', severity='ERROR', file=None):
        if file is None:
            file = 'transport/internet/splithttp/hub.go'
        v.issue(code, '$.' + field if field else '$', message, category, severity, file)

    if transport in ('xhttp', 'websocket', 'httpupgrade'):
        host = explicit_host(bt, transport)
        requested = effective_http_host(client, ct, transport)
        if host and isinstance(requested, str) and not requested.startswith('env:'):
            if not valid_http_host(requested, host):
                issue('PEER_HTTP_HOST', 'Эффективный Host не пройдёт проверку origin; серверный host не wildcard и не host:port.', 'host', file='transport/internet/internet.go')
        elif host:
            issue('PEER_HTTP_HOST_UNVERIFIED', 'Эффективный Host зависит от неизвестного endpoint/окружения; проверить его отдельно.', 'host', 'COVERAGE', 'WARNING')
    if transport == 'masque':
        try:
            if masque_uri(ct.get('path')) != masque_uri(bt.get('path')):
                issue('PEER_MASQUE_URI', 'MASQUE сравнивает декодированный path и весь query: URI сторон различается после подстановок.', 'masqueSettings.path', file='transport/internet/masque/hub.go')
        except (TypeError, ValueError):
            issue('PEER_MASQUE_URI', 'Форма MASQUE URI не прошла безопасный разбор.', 'masqueSettings.path', 'AUTHORING_POLICY')
        if cs.get('security') == bs.get('security') == 'tls':
            if masque_client_version(cs) not in masque_server_versions(bs):
                issue('PEER_MASQUE_VERSION', 'Клиент выбирает HTTP-версию, для которой сервер MASQUE не создаёт listener.', 'tlsSettings.alpn', file='transport/internet/masque/hub.go')
        return
    if transport != 'xhttp':
        return

    mode = xhttp_mode(ct, cs.get('security', 'none'))
    server_mode = bt.get('mode') or 'auto'
    if server_mode not in ('auto', mode) and not (server_mode == 'stream-up' and mode == 'stream-one'):
        issue('PEER_XHTTP_MODE', 'Сервер отвергнет выбранную клиентскую ветку.', 'xhttpSettings.mode')
    cp, sp = xhttp_path(ct), xhttp_path(bt)
    active = ['session'] if mode == 'stream-up' else (['session', 'seq'] if mode == 'packet-up' else [])
    any_path = any(metadata(c, key)[0] == 'path' for c in (ct, bt) for key in active)
    # With path metadata an extra prefix segment becomes a different session/seq.
    path_ok = cp == sp if any_path else cp.startswith(sp)
    if not path_ok:
        issue('PEER_PATH', 'Эффективные XHTTP path не согласованы с активным размещением метаданных.', 'xhttpSettings.path')
    for key in active:
        if metadata(ct, key) != metadata(bt, key):
            issue('PEER_META', 'Различаются активное размещение или эффективный ключ метаданных; регистр HTTP header учтён.', 'xhttpSettings.' + ('sessionIDKey' if key == 'session' else 'seqKey'))
    if mode == 'packet-up':
        placement = xhttp_data_placement(ct, client=True)
        accepted = xhttp_data_placement(bt, client=False)
        if accepted not in ('auto', placement):
            issue('PEER_DATA_PLACEMENT', 'Сервер не читает выбранное клиентом размещение payload.', 'xhttpSettings.uplinkDataPlacement')
        if placement in ('header', 'cookie'):
            ck = ct.get('uplinkDataKey') or ('x_data' if placement == 'cookie' else 'X-Data')
            sk = bt.get('uplinkDataKey') or ('x_data' if accepted == 'cookie' else 'X-Data')
            same = ck.lower() == sk.lower() if placement == 'header' else ck == sk
            if not same:
                issue('PEER_UPLINK_KEY', 'Ключ payload не совпадает; auto не принимает произвольные имена.', 'xhttpSettings.uplinkDataKey')
        client_max = range32(ct.get('scMaxEachPostBytes', 0))[1] or 1000000
        server_max = range32(bt.get('scMaxEachPostBytes', 0))[1] or 1000000
        if client_max > server_max:
            issue('PEER_POST_LIMIT', 'Клиент может отправить POST больше серверного лимита.', 'xhttpSettings.scMaxEachPostBytes')
    if ct.get('downloadSettings') is not None:
        issue('SESSION_OWNER_REQUIRED', 'Оба внешних плеча должны сходиться в один XHTTP listener/session map; frontend данным JSON не проверен.', 'xhttpSettings.downloadSettings', 'COVERAGE', 'WARNING')

    # Padding is checked for all XHTTP modes. A missing field means 100..1000.
    cr, sr = xhttp_padding_range(ct), xhttp_padding_range(bt)
    cm = (ct.get('xPaddingMethod') or 'repeat-x') if ct.get('xPaddingObfsMode') else 'repeat-x'
    sm = bt.get('xPaddingMethod') or 'repeat-x'
    if cm == sm or (cm == 'repeat-x' and sm == 'tokenish'):
        tolerance = 2 if sm == 'tokenish' and cm == 'repeat-x' else 0
        if cr[0] < sr[0] - tolerance or cr[1] > sr[1] + tolerance:
            issue('PEER_PADDING_RANGE', 'Диапазон padding клиента не гарантированно принимается сервером, включая значения по умолчанию.', 'xhttpSettings.xPaddingBytes', 'AUTHORING_POLICY', file='transport/internet/splithttp/xpadding.go')
    else:
        issue('PEER_PADDING_ENCODING_REVIEW', 'Длина tokenish проверяется иначе, чем repeat-x; нужна проверка фактического представления.', 'xhttpSettings.xPaddingMethod', 'COVERAGE', 'WARNING', 'transport/internet/splithttp/xpadding.go')
    if bool(ct.get('xPaddingObfsMode')) != bool(bt.get('xPaddingObfsMode')):
        issue('PEER_PADDING_MODE_REVIEW', 'Режимы padding отличаются; server legacy-ветка может иметь приоритет над obfs. Требуется wire-проверка.', 'xhttpSettings.xPaddingObfsMode', 'COVERAGE', 'WARNING')
    elif ct.get('xPaddingObfsMode'):
        cplace = ct.get('xPaddingPlacement') or 'queryInHeader'
        splace = bt.get('xPaddingPlacement') or 'queryInHeader'
        ckey, skey = ct.get('xPaddingKey') or 'x_padding', bt.get('xPaddingKey') or 'x_padding'
        ch, sh = (ct.get('xPaddingHeader') or 'X-Padding').lower(), (bt.get('xPaddingHeader') or 'X-Padding').lower()
        # Server always attempts cookie, then configured header, then query.
        # Its placement changes header parsing, not cookie/query acceptance.
        compatible = ((cplace in ('cookie', 'query') and ckey == skey) or
                      (cplace == 'header' and ch == sh and splace == 'header') or
                      (cplace == 'queryInHeader' and ch == sh and ckey == skey and splace != 'header'))
        if not compatible:
            issue('PEER_PADDING_FORMAT', 'Сервер не извлечёт сгенерированное представление padding по выбранным key/header.', 'xhttpSettings', file='transport/internet/splithttp/xpadding.go')
