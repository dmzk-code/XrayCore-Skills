#!/usr/bin/env python3
"""Additional pinned-source authoring rules; no network, mutation or process execution.
Rules are intentionally labelled SOURCE_* vs AUTHORING_POLICY. They are not a
replacement for the native parser, init, socket creation or end-to-end tests.
"""
from __future__ import annotations
import copy
import json
import math
import re
from urllib.parse import urlsplit

DNS_STRATEGIES = {'', 'useip','use_ip','use-ip','usesys','usesystem','use_sys','use_system','use-sys','use-system'}
for family in ('4','6'):
    DNS_STRATEGIES.update('use'+x+family for x in ('ip','ipv','_ip','_ipv','_ip_v','-ip','-ipv','-ip-v'))
PING_KEYS = {'destination','connectivity','interval','sampling','timeout','httpMethod'}
LEASTLOAD_KEYS = {'costs','baselines','expected','maxRTT','tolerance'}
TEMPLATE_KEYS = {'flatten','concurrency','auth','put','get','delete','list','retry'}
AUTH_KEYS = {'type','header','username','password','tokenUrl','form','tokenPath','expiryPath'}
OP_KEYS = {'method','url','headers','body','namesRegex'}
MASK_OWNER = {'udp':{'xicmp','realm','udphop'}, 'tcp':set()}
INT_MAX = 2**63-1


def duration(value):
    """Accept finite nonnegative Go-style duration strings, return seconds.
    Numeric durations are deliberately not guessed; constructors have different units.
    """
    if not isinstance(value,str):raise ValueError('duration string required')
    if value in ('0','0s',''):return 0.0
    parts=re.findall(r'(\d+(?:\.\d+)?|\.\d+)(ns|us|µs|μs|ms|s|m|h)',value)
    if not parts or ''.join(a+b for a,b in parts)!=value:raise ValueError('invalid duration')
    units={'ns':1e-9,'us':1e-6,'µs':1e-6,'μs':1e-6,'ms':1e-3,'s':1,'m':60,'h':3600}
    result=sum(float(a)*units[b] for a,b in parts)
    if not math.isfinite(result) or result>INT_MAX/1e9:raise ValueError('duration overflow')
    return result


def normalize_stream(obj):
    """Read-only normalization of selected *pointer* aliases and XHTTP RawMessage.
    Does not normalize arbitrary JSON: null is significant in RawMessage fields.
    """
    if not isinstance(obj,dict):return obj
    s=copy.deepcopy(obj)
    for key in ('method','network','rawSettings','tcpSettings','xhttpSettings','splithttpSettings'):
        if key in s and s[key] is None:s.pop(key)
    for key in ('xhttpSettings','splithttpSettings'):
        x=s.get(key)
        if not isinstance(x,dict):continue
        if 'extra' in x and x['extra'] is None:
            x['extra']={}
        if isinstance(x.get('downloadSettings'),dict):x['downloadSettings']=normalize_stream(x['downloadSettings'])
        if isinstance(x.get('extra'),dict) and isinstance(x['extra'].get('downloadSettings'),dict):
            x['extra']['downloadSettings']=normalize_stream(x['extra']['downloadSettings'])
    return s


def normalize_config(obj,as_stream=False):
    if as_stream:return normalize_stream(obj)
    if not isinstance(obj,dict):return obj
    out=copy.deepcopy(obj)
    for side in ('inbounds','outbounds'):
        for e in out.get(side,[]) if isinstance(out.get(side,[]),list) else []:
            if not isinstance(e,dict):continue
            if 'streamSettings' in e:e['streamSettings']=normalize_stream(e['streamSettings'])
            settings=e.get('settings')
            if isinstance(settings,dict) and 'clients' in settings and settings['clients'] is None:settings.pop('clients')
    return out


def _mapping(v):return v if isinstance(v,dict) else {}
def _array(v):return v if isinstance(v,list) else []
def _int(v):return type(v) is int


def check(v,obj):
    """Emit into an existing Validator; values containing secrets never interpolated."""
    if not isinstance(obj,dict):return
    def issue(code,path,msg,source='AUTHORING_POLICY',severity='ERROR',file='infra/conf/transport_finalmask.go'):
        v.issue(code,path,msg,source,severity,file)
    def typed(d,key,typ,path):
        if key not in d or d[key] is None:return
        value=d[key]
        ok=(type(value) is bool if typ=='bool' else type(value) is int if typ=='int' else isinstance(value,typ))
        if not ok:issue('NESTED_TYPE',path+'.'+key,'Неверный тип значения вложенного поля.')
    def dur(d,k,p,minval=None):
        if k not in d:return
        try:
            t=duration(d[k])
            if minval is not None and t!=0 and t<minval:raise ValueError()
        except (ValueError,TypeError):issue('DURATION',p+'.'+k,'Требуется неотрицательная duration-строка с допустимым диапазоном; единицы не угадываются.')
    def dictionary(d,k,p):
        if k in d and (not isinstance(d[k],dict) or not all(isinstance(a,str) and isinstance(b,str) for a,b in d[k].items())):issue('STRING_MAP',p+'.'+k,'Требуется объект string:string.')
    for key in ('dns',):
        dns=_mapping(obj.get(key))
        for p,d in [('$.dns',dns)]+[(f'$.dns.servers[{i}]',n) for i,n in enumerate(_array(dns.get('servers'))) if isinstance(n,dict)]:
            for k in ('disableCache','serveStale','skipFallback','finalQuery','enableParallelQuery','disableFallback','disableFallbackIfMatch','useSystemHosts'):typed(d,k,'bool',p)
            ttl=d.get('serveExpiredTTL')
            if ttl is not None and (not _int(ttl) or not 0<=ttl<=2**31-1):issue('STALE_RANGE',p+'.serveExpiredTTL','Авторинг ограничивает TTL signed int32 для безопасного преобразования cache.','AUTHORING_POLICY',file='app/dns/cache_controller.go')
            if d.get('serveStale',dns.get('serveStale')) and d.get('serveExpiredTTL',dns.get('serveExpiredTTL',0))==0:
                issue('STALE_UNBOUNDED',p,'serveStale+TTL0: неограниченный возраст и отсутствие периодической очистки этого cache.','SOURCE_RUNTIME','WARNING','app/dns/cache_controller.go')
            if p!='$.dns' and dns.get('queryStrategy','').lower() in ('useipv4','useip4') and str(d.get('queryStrategy','')).lower() in ('useipv6','useip6'):
                issue('DNS_FAMILY_CONFLICT',p,'Глобальное и локальное ограничения не оставляют доступного семейства.','SOURCE_RUNTIME',file='app/dns/dns.go')
            if p!='$.dns' and dns.get('queryStrategy','').lower() in ('useipv6','useip6') and str(d.get('queryStrategy','')).lower() in ('useipv4','useip4'):
                issue('DNS_FAMILY_CONFLICT',p,'Глобальное и локальное ограничения не оставляют доступного семейства.','SOURCE_RUNTIME',file='app/dns/dns.go')
        if dns and (not dns.get('servers') or dns.get('disableFallback')):
            issue('DNS_FIRST_FALLBACK','$.dns','Пустой итоговый список может выбрать первый resolver; disableFallback не является запретом DNS.','SOURCE_RUNTIME','WARNING','app/dns/dns.go')
    for key in ('observatory','burstObservatory'):
        o=_mapping(obj.get(key));p='$.'+key
        if not o:continue
        if not o.get('subjectSelector'):issue('OBSERVER_EMPTY',p,'Пустой subjectSelector не проверяет outbounds.','AUTHORING_POLICY','WARNING')
        if key=='observatory':dur(o,'probeInterval',p)
        else:
            ping=_mapping(o.get('pingConfig'));p+='.pingConfig'
            v.unknown(ping,PING_KEYS,p)
            for k in ('destination','connectivity','httpMethod'):typed(ping,k,str,p)
            for k in ('interval','timeout'):dur(ping,k,p,10 if k=='interval' else None)
            if 'sampling' in ping and (not _int(ping['sampling']) or not 0<=ping['sampling']<=10000):issue('PING_SAMPLING',p+'.sampling','sampling:0 выбирает default10; положительное ограничено10000 политикой ресурсов.')
            method=ping.get('httpMethod','')
            if isinstance(method,str) and method.strip() and method.strip() not in ('GET','HEAD'):
                issue('PING_METHOD',p+'.httpMethod','Для проверки body используйте точный GET; runtime не нормализует регистр метода.','SOURCE_RUNTIME','WARNING','app/observatory/burst/ping.go')
            issue('PROBE_STATUS_UNCHECKED',p,'Этот health probe не проверяет HTTP status; 404/500 может считаться живым.','SOURCE_RUNTIME','WARNING','app/observatory/burst/ping.go')
    for i,b in enumerate(_array(_mapping(obj.get('routing')).get('balancers'))):
        if not isinstance(b,dict):continue
        p=f'$.routing.balancers[{i}]';st=_mapping(b.get('strategy'));s=_mapping(st.get('settings'));typ=str(st.get('type','')).lower()
        if typ=='leastload':
            v.unknown(s,LEASTLOAD_KEYS,p+'.strategy.settings')
            for k in ('maxRTT',):dur(s,k,p+'.strategy.settings')
            for x in _array(s.get('baselines')):
                try:duration(x)
                except ValueError:issue('DURATION',p+'.strategy.settings.baselines','Некорректная baseline duration.')
            tol=s.get('tolerance',0)
            if type(tol) not in (int,float) or not math.isfinite(tol) or not 0<=tol<=1:issue('LOAD_TOLERANCE',p,'tolerance должен быть конечным числом0..1.')
            elif tol==0:issue('LOAD_ZERO_TOLERANCE',p,'tolerance0 отключает фильтр failure-ratio, а не требует нулевых потерь.','SOURCE_RUNTIME','WARNING','app/router/strategy_leastload.go')
            for j,cost in enumerate(_array(s.get('costs'))):
                q=f'{p}.strategy.settings.costs[{j}]'
                if not isinstance(cost,dict):issue('OBJECT',q,'Требуется объект cost.');continue
                v.unknown(cost,{'match','regexp','value'},q);typed(cost,'match',str,q);typed(cost,'regexp','bool',q)
                val=cost.get('value',0)
                if type(val) not in (int,float) or not math.isfinite(val):issue('COST_VALUE',q,'value должно быть конечным числом.')
                if cost.get('regexp'):
                    # Python regex is not claimed to validate the different Go/RE2 language.
                    issue('COST_REGEX_CORE',q,'Regexp компилируется Go/RE2; не считать Python regex доказательством совместимости.','AUTHORING_POLICY','WARNING','app/router/weight.go')
    storage={}
    for side in ('inbounds','outbounds'):
        for i,e in enumerate(_array(obj.get(side))):
            if not isinstance(e,dict):continue
            p=f'$.{side}[{i}].streamSettings';stream=_mapping(e.get('streamSettings'))
            n=str(stream.get('method') or stream.get('network') or 'raw').lower()
            fm=_mapping(stream.get('finalmask'))
            for layer in ('tcp','udp'):
                arr=_array(fm.get(layer))
                for j,m in enumerate(arr):
                    if not isinstance(m,dict):continue
                    typ=m.get('type');s=_mapping(m.get('settings'));q=f'{p}.finalmask.{layer}[{j}].settings'
                    if typ in MASK_OWNER[layer] and j!=len(arr)-1:issue('MASK_OWNER_POSITION',q,'Маска-владелец socket должна быть последней в JSON-массиве.','SOURCE_RUNTIME',file='transport/internet/finalmask/finalmask.go')
                    if typ=='udphop' and side=='inbounds':issue('UDPHOP_CLIENT_ONLY',q,'UDPHop реализован только на клиенте.','SOURCE_RUNTIME',file='transport/internet/finalmask/udphop/config.go')
                    if typ=='salamander' and len(str(s.get('password','')).encode('utf-8'))<4:issue('SALAMANDER_PASSWORD',q+'.password','Пароль должен содержать минимум4 UTF-8 bytes.','SOURCE_RUNTIME',file='transport/internet/finalmask/salamander/salamander.go')
                    if typ=='sudoku':
                        mode=str(s.get('ascii','')).strip().lower()
                        if mode not in ('','ascii','prefer_ascii','entropy','prefer_entropy'):issue('SUDOKU_ASCII',q+'.ascii','Неизвестный режим ASCII.','SOURCE_RUNTIME',file='transport/internet/finalmask/sudoku/table.go')
                        pats=s.get('customTables') or s.get('custom_tables') or [s.get('customTable') or s.get('custom_table') or '']
                        if mode in ('ascii','prefer_ascii') and any(pats):issue('SUDOKU_TABLE_IGNORED',q,'В ASCII режиме custom tables игнорируются.','SOURCE_RUNTIME','WARNING','transport/internet/finalmask/sudoku/table.go')
                        elif isinstance(pats,list):
                            for pat in pats:
                                a=pat.strip().lower().replace(' ','') if isinstance(pat,str) else '!'
                                if a and (len(a)!=8 or a.count('x')!=2 or a.count('p')!=2 or a.count('v')!=4):issue('SUDOKU_TABLE',q,'Pattern: ровно2x,2p,4v на8 символов.','SOURCE_RUNTIME',file='transport/internet/finalmask/sudoku/table.go')
                        for k in ('paddingMin','paddingMax','padding_min','padding_max'):
                            if k in s and (not _int(s[k]) or not 0<=s[k]<=100):issue('SUDOKU_PADDING_POLICY',q+'.'+k,'Авторинг требует проценты0..100; runtime clamp не используется как тюнинг.')
                    if typ=='realm':
                        v.enum(s,'ipMode',{'','dual','v4','v6'},q,True)
                        pm=_mapping(s.get('portMapping'))
                        for k in ('timeout','lifetime'):
                            if k in pm and (not _int(pm[k]) or not 0<=pm[k]<=INT_MAX//1000000000):issue('REALM_DURATION',q+'.portMapping.'+k,'Секунды:0 выбирает default; отрицательные/переполняющие Duration значения недопустимы.','SOURCE_RUNTIME',file='transport/internet/finalmask/realm/portmap.go')
                    if typ=='xdns':
                        if not s.get('domains'):issue('XDNS_DOMAINS',q,'Непустой domains обязателен на обеих сторонах.','SOURCE_RUNTIME',file='transport/internet/finalmask/xdns/client.go')
                        if side=='outbounds' and not s.get('resolvers'):issue('XDNS_CLIENT_RESOLVERS',q,'Клиент требует resolvers.','SOURCE_RUNTIME',file='transport/internet/finalmask/xdns/client.go')
                        for d in _array(s.get('domains')):
                            if not isinstance(d,dict):continue
                            types=d.get('types')
                            if not isinstance(types,list) or not types or any(type(t) is not int or t not in (1,5,16,28) for t in types):issue('XDNS_TYPES',q+'.domains','Допустим непустой массив типов1,5,16,28.','SOURCE_RUNTIME',file='transport/internet/finalmask/xdns/domain.go')
                            for k,hi in (('lenLimit',255),('labelLimit',63),('edns0',4096)):
                                z=d.get(k,0)
                                if not _int(z) or not 0<=z<=hi or (k=='edns0' and 0<z<512):issue('XDNS_LIMIT',q+'.domains.'+k,'Некорректный диапазон DNS carrier.','SOURCE_RUNTIME',file='transport/internet/finalmask/xdns/domain.go')
                    if typ=='noise':
                        for k in ('reset',):v.rng(s,k,q,0)
                        for item in _array(s.get('noise')):
                            if not isinstance(item,dict):continue
                            v.rng(item,'delay',q,0)
                            if item.get('type')=='exp':
                                exp=item.get('packet');ok=isinstance(exp,str)
                                tokens=re.findall(r'<\s*([a-z]+)(?:\s+([^>]*?))?\s*>',exp) if ok else []
                                if not tokens or re.sub(r'<\s*([a-z]+)(?:\s+([^>]*?))?\s*>','',exp).strip():ok=False
                                for key,arg in tokens:
                                    if key not in ('b','r','rc','rd','t','c','n') or (key in ('t','c','n') and arg.strip()):ok=False
                                    if key=='b':
                                        try:
                                            if not bytes.fromhex(''.join(arg.split()).removeprefix('0x').removeprefix('0X')):ok=False
                                        except ValueError:ok=False
                                    if key in ('r','rc','rd'):
                                        if not re.fullmatch(r'\d+(?:-\d+)?',arg.strip()):ok=False
                                        else:
                                            bounds=[int(a) for a in arg.strip().split('-')]
                                            if max(bounds)>65535 or bounds[-1]<bounds[0]:ok=False
                                if not ok:issue('NOISE_EXPRESSION',q,'Некорректная грамматика expression.','SOURCE_BUILD')
            sock=_mapping(stream.get('sockopt'))
            for c in _array(sock.get('customSockopt')):
                if not isinstance(c,dict):continue
                if c.get('system')=='windows' and c.get('type')=='str':issue('SOCK_WINDOWS_STRING',p+'.sockopt.customSockopt','Windows consumer не поддерживает str setsockopt.','SOURCE_RUNTIME',file='transport/internet/sockopt_windows.go')
                for k in ('level','opt'):
                    if k in c and (not isinstance(c[k],str) or not re.fullmatch(r'-?\d+',c[k])):issue('SOCK_DECIMAL',p+'.sockopt.customSockopt','level/opt — десятичные строки; ошибки Atoi нельзя использовать как fallback0.')
            if n=='xdrive':
                s=_mapping(stream.get('xdriveSettings'));t=_mapping(s.get('template'))
                for k in ('segmentBytes','flushIntervalMs','pollIntervalMs','maxPollIntervalMs','sessionTtlSeconds','concurrency','eagerWindowMs','holeTimeoutMs'):typed(s,k,'int',p+'.xdriveSettings')
                if s.get('service')=='template':
                    q=p+'.xdriveSettings.template';v.unknown(t,TEMPLATE_KEYS,q)
                    auth=_mapping(t.get('auth'));v.unknown(auth,AUTH_KEYS,q+'.auth');v.enum(auth,'type',{'','none','static','basic','oauth2'},q+'.auth')
                    for k in ('header','form'):dictionary(auth,k,q+'.auth')
                    if auth.get('type')=='oauth2' and not auth.get('tokenUrl'):issue('OAUTH_URL',q+'.auth','oauth2 требует tokenUrl.','SOURCE_RUNTIME',file='transport/internet/xdrive/template.go')
                    for op in ('put','get','delete','list'):
                        a=_mapping(t.get(op));v.unknown(a,OP_KEYS,q+'.'+op)
                        if not a.get('url'):issue('TEMPLATE_OPERATION',q+'.'+op,'Необходим URL каждой из4 операций.','SOURCE_RUNTIME',file='transport/internet/xdrive/template.go')
                        dictionary(a,'headers',q+'.'+op)
                    if not _mapping(t.get('list')).get('namesRegex'):issue('TEMPLATE_NAMES',q+'.list','list требует namesRegex с capture group.','SOURCE_RUNTIME',file='transport/internet/xdrive/template.go')
                    retry=_mapping(t.get('retry'));v.unknown(retry,{'status','rateReason'},q+'.retry')
                    if 'status' in retry and (not isinstance(retry['status'],list) or any(not _int(x) or not 100<=x<=599 for x in retry['status'])):issue('RETRY_STATUS',q+'.retry.status','Требуется массив HTTP status codes.')
                if s.get('service') in ('template','Google Drive'):
                    k=(s.get('service'),s.get('remoteFolder'),tuple(s.get('secrets') or []),stream.get('security',''),stream.get('address'),stream.get('port',0))
                    details=json.dumps({'template':t,'tls':stream.get('tlsSettings'),'sockopt':stream.get('sockopt')},sort_keys=True)
                    if k in storage and storage[k]!=details:issue('XDRIVE_SHARED_COLLISION',p,'Одинаковый sharedStorage key с разными template/TLS/sockopt: первый объект может скрыть следующий.','SOURCE_RUNTIME',file='transport/internet/xdrive/storage.go')
                    storage[k]=details
