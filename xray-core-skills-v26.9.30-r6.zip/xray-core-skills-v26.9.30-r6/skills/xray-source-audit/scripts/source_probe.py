#!/usr/bin/env python3
"""Read-only commit/blob/dirty-tree check. No source execution or network.
Syntactic JSON tag inventory is NOT semantic Go analysis. Python>=3.10 + git.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
REF=Path(__file__).resolve().parents[1]/'references/provenance.json'


def git(repo: Path,*args: str) -> str:
    env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env['GIT_OPTIONAL_LOCKS']='0'
    p=subprocess.run(['git','-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null','-C',str(repo),*args],text=True,capture_output=True,timeout=15,check=False,env=env)
    if p.returncode:raise ValueError('Git read failed: '+args[0])
    return p.stdout.strip()


def blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def probe(repo: Path,manifest: dict) -> dict:
    repo=repo.resolve(strict=True)
    head=git(repo,'rev-parse','HEAD');dirty=bool(git(repo,'status','--porcelain','--untracked-files=all','--ignore-submodules=none'))
    reports=[]
    for item in manifest['files']:
        relative=Path(item['path']);path=repo/relative
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe manifest path')
        if not path.is_file():reports.append({'path':item['path'],'status':'MISSING'});continue
        if path.is_symlink() or not path.resolve().is_relative_to(repo):raise ValueError('Source path escapes checkout')
        if path.stat().st_size>16*1024*1024:raise ValueError('Source file too large')
        data=path.read_bytes();blob=blob_sha(data);expected=item.get('git_blob_sha')
        status='UNPINNED' if not expected else ('MATCH' if expected==blob else 'CHANGED')
        tags=[]
        for n,line in enumerate(data.decode('utf-8').splitlines(),1):
            m=re.search(r'json:"([^",]+)',line)
            if m:tags.append({'line':n,'json_tag':m[1]})
        reports.append({'path':item['path'],'status':status,'actual_git_blob_sha':blob,'declared_review_scope':item.get('coverage','UNSPECIFIED'),'syntactic_json_tags':tags})
    match=head==manifest['commit'] and not dirty and bool(reports) and all(x['status']=='MATCH' for x in reports)
    return {'status':'MATCH' if match else 'REVIEW_REQUIRED','expected_commit':manifest['commit'],'actual_commit':head,'commit_matches':head==manifest['commit'],'any_tree_changes_including_untracked':dirty,'scope':'Pinned files only; regex is syntactic, not Go semantic or runtime analysis. Untracked files fail closed.','source_or_core_executed':False,'files':reports}


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('repo',type=Path);ap.add_argument('--manifest',type=Path,default=REF);a=ap.parse_args()
    try:
        out=probe(a.repo,json.loads(a.manifest.read_text(encoding='utf-8')))
        print(json.dumps(out,ensure_ascii=False,indent=2));return 0 if out['status']=='MATCH' else 1
    except (OSError,ValueError,KeyError,subprocess.TimeoutExpired):
        print('PROBE_ERROR: checkout или manifest не прошёл проверку.',file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
