#!/usr/bin/env python3
"""Bounded loopback regressions for r6. Trusted binary, explicit --execute.
No account access, external hosts, firewall edits or production modifications.
Creates only new local fixtures; reproducing an unsafe fixture is a test, not a recommendation.
"""
from __future__ import annotations
import argparse,base64,copy,json,os,re,secrets,socket,subprocess,time
from pathlib import Path
from unittest.mock import patch
from build_lab import unused_ports,write_json,create_lab
from lab_trust import verify_binary
from lint_config import SHA
from run_lab import Child,capture,echo_servers,tcp_probe,udp_probe,wait_tcp_probe,read_exact,save_report,clean_env
from validate import Validator,check_pair


def local_pair(cp,sp,ports,credential,legacy=False):
    spn,cpn=ports
    settings={'address':'127.0.0.1','port':spn,**credential}
    if legacy:settings={'servers':[{'address':'127.0.0.1','port':spn,'users':[credential]}]}
    client={'log':{'loglevel':'warning'},'inbounds':[{'tag':'local','protocol':'socks','listen':'127.0.0.1','port':cpn,'settings':{'udp':True}}],
            'outbounds':[{'tag':'proxy','protocol':cp,'settings':settings}]}
    server={'log':{'loglevel':'warning'},'inbounds':[{'tag':'remote','protocol':sp,'listen':'127.0.0.1','port':spn,
             'settings':{'accounts':[credential],**({'auth':'password','udp':True} if sp!='http' else {})}}],
            'outbounds':[{'tag':'direct','protocol':'freedom'}]}
    return client,server


def ready(port,child,seconds=4):
    until=time.monotonic()+seconds
    while time.monotonic()<until:
        if child.process.poll() is not None:raise RuntimeError('child exited')
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=.25):return
        except OSError:time.sleep(.03)
    raise TimeoutError('listener not ready')


def http_connect(port,target,credential=None):
    with socket.create_connection(('127.0.0.1',port),timeout=3) as c:
        c.settimeout(3)
        headers=f'CONNECT 127.0.0.1:{target} HTTP/1.1\r\nHost: 127.0.0.1:{target}\r\n'
        if credential:
            encoded=base64.b64encode((credential['user']+':'+credential['pass']).encode()).decode()
            headers+='Proxy-Authorization: Basic '+encoded+'\r\n'
        c.sendall((headers+'\r\n').encode());response=bytearray()
        while not response.endswith(b'\r\n\r\n'):
            response+=read_exact(c,1)
            if len(response)>8192:raise ValueError('header bound exceeded')
        status=int(response.split(b' ',2)[1])
        if status==200:
            data=secrets.token_bytes(2048);c.sendall(data)
            if read_exact(c,len(data))!=data:raise ConnectionError('payload mismatch')
        return status


def run(binary:Path,out:Path,digest:str):
    observed=verify_binary(binary,digest);binary=binary.resolve();out=out.absolute()
    if out.exists() or out.is_symlink() or any(p.is_symlink() for p in out.parents):raise ValueError('new private output directory required')
    out.mkdir(mode=0o700,parents=True)
    version=capture([str(binary),'version'],out,out/'version.log',8)
    text=(out/'version.log').read_text(errors='replace')
    if version['status']!='PASS' or not re.search(r'\b26\.9\.30\b',text):raise ValueError('version mismatch')
    report={'revision':'r6','core_commit':SHA,'binary_sha256':observed,'scope':'bounded loopback and local decoder; no WAN/OS qualification',
            'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'native':[],'auth_edges':[],'wire':[],'environment':[],'grpc':[],'status':'RUNNING'}
    credential={'user':'r6-user','pass':secrets.token_urlsafe(18)}
    # Parser/build acceptance is separate from authoring policies and actual auth.
    for name,protocol,opts,expected in [
        ('socks-empty-password-mode','socks',{'auth':'password','accounts':[]},True),
        ('socks-auth-case-fallback','socks',{'auth':'Password','accounts':[credential]},True),
        ('socks-udp-wrong-type','socks',{'udp':'true'},False),
        ('socks-accounts-wrong-type','socks',{'accounts':{}},False),
        ('socks-long-username','socks',{'auth':'password','accounts':[{'user':'a'*256,'pass':'test'}]},True),
        ('http-empty-accounts','http',{'accounts':[]},True),
        ('http-transparent-wrong-type','http',{'allowTransparent':'yes'},False),
        ('http-accounts-null-keeps-users','http',{'users':[credential],'accounts':None},True),
    ]:
        d=out/name;d.mkdir();c={'inbounds':[{'protocol':protocol,'listen':'127.0.0.1','port':unused_ports(1)[0],'settings':opts}]};write_json(d/'config.json',c)
        rr=capture([str(binary),'run','-test','-c',str(d/'config.json')],d,d/'test.log',10)
        actual=rr['exit_code']==0;status='PASS' if actual==expected and rr['exit_code'] in (0,23) else 'FAIL'
        report['native'].append({'name':name,'expected':'ACCEPT' if expected else 'REJECT','exit_code':rr['exit_code'],'status':status,'static_codes':sorted({x['code'] for x in Validator().config(c)})})
    # Prove both HTTP fallback behavior and the protective configuration on local listeners.
    edge_cases=[('socks-empty','socks',{'auth':'password','accounts':[]},200),
                ('mixed-empty','mixed',{'auth':'password','accounts':[]},200),
                ('socks-typo','socks',{'auth':'Password','accounts':[credential]},200),
                ('socks-empty-alias','socks',{'auth':'password','users':[credential],'accounts':[]},200),
                ('socks-null-alias','socks',{'auth':'password','users':[credential],'accounts':None},407),
                ('socks-protected','socks',{'auth':'password','accounts':[credential]},407),
                ('http-protected','http',{'accounts':[credential]},407),
                ('http-empty','http',{'accounts':[]},200)]
    with echo_servers() as (tp,up):
        for name,protocol,opts,expected in edge_cases:
            d=out/name;d.mkdir();port=unused_ports(1)[0]
            server={'log':{'loglevel':'warning'},'inbounds':[{'protocol':protocol,'listen':'127.0.0.1','port':port,'settings':opts}], 'outbounds':[{'protocol':'freedom'}]}
            write_json(d/'server.json',server);child=None;record={'name':name,'expected_unauth_http':expected,'status':'RUNNING'}
            try:
                child=Child([str(binary),'run','-c',str(d/'server.json')],d,d/'runtime.log');ready(port,child)
                got=http_connect(port,tp);record['observed_unauth_http']=got
                if got!=expected:raise ValueError('unexpected auth behavior')
                if expected==407:
                    bad={'user':credential['user'],'pass':'wrong-'+credential['pass']}
                    if http_connect(port,tp,bad)!=407:raise ValueError('bad password accepted')
                    if http_connect(port,tp,credential)!=200:raise ValueError('valid auth failed')
                    record['bad_auth_then_good_payload']='PASS'
                else:record['unauthenticated_payload']='OBSERVED'
                record['status']='PASS'
            except (OSError,RuntimeError,ValueError) as e:record.update(status='FAIL',reason=type(e).__name__)
            finally:
                if child:child.stop()
            report['auth_edges'].append(record)
        cases=[('socks-simple','socks','socks',False),('socks-legacy','socks','socks',True),
               ('http-simple','http','http',False),('http-legacy','http','http',True),
               ('http-via-mixed','http','mixed',False),('socks-via-mixed','socks','mixed',False),
               ('http-auth-header','http','http',False),('duplicate-user-last','socks','socks',False)]
        for name,cp,sp,legacy in cases:
            d=out/name;d.mkdir();ports=unused_ports(2);client,server=local_pair(cp,sp,ports,credential,legacy)
            if name=='http-auth-header':
                o=client['outbounds'][0]['settings'];o['pass']='ignored-wrong-password';o['headers']={'Proxy-Authorization':'Basic '+base64.b64encode((credential['user']+':'+credential['pass']).encode()).decode()}
            if name=='duplicate-user-last':server['inbounds'][0]['settings']['accounts'].insert(0,{'user':credential['user'],'pass':'overwritten'})
            record={'name':name,'status':'RUNNING'};children=[]
            try:
                issues=Validator().config(client)+Validator().config(server)+check_pair(client,server,'proxy','remote',direct=True)
                if any(x['severity']=='ERROR' for x in issues):raise ValueError('good pair rejected')
                bad=copy.deepcopy(client);o=bad['outbounds'][0]['settings']
                if name=='http-auth-header':o['headers']['Proxy-Authorization']='Basic '+base64.b64encode(b'invalid:invalid').decode()
                elif legacy:o['servers'][0]['users'][0]['pass']='wrong'
                else:o['pass']='wrong'
                if 'PEER_AUTH' not in {x['code'] for x in check_pair(bad,server,'proxy','remote')}:raise ValueError('missing negative static check')
                for file,config in [('server',server),('good',client),('bad',bad)]:
                    write_json(d/(file+'.json'),config)
                    rr=capture([str(binary),'run','-test','-c',str(d/(file+'.json'))],d,d/(file+'.test.log'),10)
                    if rr['exit_code']!=0:raise ValueError('native config rejected')
                def start(name,file):
                    child=Child([str(binary),'run','-c',str(d/(file+'.json'))],d,d/(name+'.runtime.log'));children.append(child);return child
                start('server','server');good=start('good','good');wait_tcp_probe(ports[1],tp,children,seconds=8)
                tcp_probe(ports[1],tp,32768);record['tcp']='PASS'
                if cp=='socks':udp_probe(ports[1],up);record['udp']='PASS'
                else:record['udp']='UNSUPPORTED_BY_HTTP_OUTBOUND'
                good.stop();children.remove(good);wrong=start('bad','bad');ready(ports[1],wrong)
                rejected=False
                try:tcp_probe(ports[1],tp,512,timeout=2)
                except OSError:rejected=True
                if not rejected or wrong.process.poll() is not None:raise ValueError('negative test invalid')
                wrong.stop();children.remove(wrong);start('control','good');wait_tcp_probe(ports[1],tp,children,seconds=8)
                tcp_probe(ports[1],tp,2048);record.update(negative_auth='PASS',positive_control='PASS',status='PASS')
            except (OSError,RuntimeError,ValueError,TypeError) as e:record.update(status='FAIL',reason=type(e).__name__)
            finally:
                for child in reversed(children):child.stop()
            report['wire'].append(record)
    # Dotted confdir is honored by core. The sanitized runner must ignore both forms.
    d=out/'env-control';d.mkdir();overlay=d/'tail-injected';overlay.mkdir()
    write_json(d/'base.json',{'outbounds':[{'tag':'base','protocol':'freedom'}]})
    write_json(overlay/'extra.json',{'outbounds':[{'tag':'injected','protocol':'blackhole'}]})
    for key in ('xray.location.confdir','XRAY_LOCATION_CONFDIR'):
        env=clean_env();env[key]=str(overlay)
        result=subprocess.run([str(binary),'run','-dump','-c',str(d/'base.json')],cwd=d,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
        native=json.loads(result.stdout);has_injected=any(x.get('tag')=='injected' for x in native.get('outbounds',[]))
        log=d/('sanitized-'+key.replace('.','_')+'.log')
        with patch.dict(os.environ,{key:str(overlay)}):rr=capture([str(binary),'run','-dump','-c',str(d/'base.json')],d,log,10)
        cleaned=json.loads(log.read_text());tags=[x.get('tag') for x in cleaned.get('outbounds',[])]
        report['environment'].append({'name':key,'control_core_read_overlay':has_injected,'sanitized_base_only':tags==['base'],'status':'PASS' if result.returncode==0 and rr['exit_code']==0 and has_injected and tags==['base'] else 'FAIL'})
    # The known reconnect regression is expected, never relabelled as successful recovery.
    create_lab(out/'grpc-lab',['grpc-tls'])
    base=out/'grpc-lab/grpc-tls';client=json.loads((base/'client.json').read_text());server=json.loads((base/'server.json').read_text());top=json.loads((base/'topology.json').read_text())
    for name,fm in [('empty-object',{}),('quic-params-only',{'quicParams':{'congestion':'bbr'}})]:
        d=out/('grpc-'+name);d.mkdir();c=copy.deepcopy(client);c['outbounds'][0]['streamSettings']['finalmask']=fm
        for file,obj in [('client',c),('server',server)]:write_json(d/(file+'.json'),obj)
        children=[];record={'name':name,'status':'RUNNING','recovery_budget_seconds':5}
        try:
            if 'GRPC_RECONNECT_OBSERVED' not in {x['code'] for x in Validator().config(c)}:raise ValueError('missing source warning')
            def start(label,file):
                x=Child([str(binary),'run','-c',str(d/(file+'.json'))],base,d/(label+'.runtime.log'));children.append(x);return x
            s=start('server','server');cl=start('client','client')
            with echo_servers() as (tp,up):
                wait_tcp_probe(top['client_socks'],tp,children,seconds=8);tcp_probe(top['client_socks'],tp,2048);record['initial_tcp']='PASS'
                s.stop();children.remove(s);start('restarted-server','server')
                recovered=True
                try:wait_tcp_probe(top['client_socks'],tp,children,seconds=5)
                except TimeoutError:recovered=False
                record['server_only_recovery']='PASS' if recovered else 'FAIL_KNOWN'
                cl.stop();children.remove(cl);start('restarted-client','client');wait_tcp_probe(top['client_socks'],tp,children,seconds=8);record['client_restart_control']='PASS'
                record['status']='MATCH_KNOWN_ISSUE' if not recovered else 'OBSERVATION_CHANGED'
        except (OSError,RuntimeError,ValueError) as e:record.update(status='FAIL_TEST',reason=type(e).__name__)
        finally:
            for child in reversed(children):child.stop()
        report['grpc'].append(record)
    passed=all(x['status']=='PASS' for group in ('native','auth_edges','wire','environment') for x in report[group])
    known=all(x['status']=='MATCH_KNOWN_ISSUE' for x in report['grpc'])
    report['status']='PASS_EXPECTATIONS_WITH_KNOWN_RUNTIME_FAILURES' if passed and known else 'FAIL'
    report['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    save_report(out/'report.json',report);return report


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--xray',required=True,type=Path);p.add_argument('--sha256',required=True);p.add_argument('--out',required=True,type=Path);p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:p.error('--execute required')
    try:r=run(a.xray,a.out,a.sha256)
    except (OSError,ValueError,RuntimeError,TypeError,subprocess.TimeoutExpired):print('FAIL_PRECONDITION_OR_RUNNER; private logs only');return 2
    print(r['status']+' — '+str(a.out/'report.json'));return 0 if r['status'].startswith('PASS_EXPECTATIONS') else 1
if __name__=='__main__':raise SystemExit(main())
