#!/usr/bin/env python3
"""Bounded real-Xray DNS cache tests with loopback UDP/TCP resolver. No Internet.
Requires --execute, trusted binary and a NEW output directory. No production edits.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,secrets,shutil,socketserver,struct,subprocess,sys,threading,time,uuid
from pathlib import Path
from build_lab import certificate,make_pair,unused_ports,write_json
from run_lab import Child,echo_servers,tcp_probe,wait_tcp_probe,clean_env,read_exact
from lab_trust import verify_binary
from lint_config import SHA

class State:
    def __init__(self):self.count=0;self.offline=False;self.lock=threading.Lock()
    def response(self,data):
        with self.lock:self.count+=1;offline=self.offline
        if offline:return None
        if len(data)<17:return None
        pos=12
        while pos<len(data) and data[pos]:pos+=data[pos]+1
        pos+=1
        if pos+4>len(data):return None
        qtype,qclass=struct.unpack('!HH',data[pos:pos+4]);question=data[12:pos+4]
        answer=b''
        if qtype==1 and qclass==1:answer=b'\xc0\x0c'+struct.pack('!HHIH',1,1,2,4)+b'\x7f\x00\x00\x01'
        return data[:2]+struct.pack('!HHHHH',0x8180,1,1 if answer else 0,0,0)+question+answer
class UDP(socketserver.BaseRequestHandler):
    def handle(self):
        data,s=self.request;reply=self.server.state.response(data)
        if reply:s.sendto(reply,self.client_address)
class TCP(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(3)
        try:
            while True:
                size=struct.unpack('!H',read_exact(self.request,2))[0]
                if size>4096:return
                reply=self.server.state.response(read_exact(self.request,size))
                if reply:self.request.sendall(struct.pack('!H',len(reply))+reply)
        except (OSError,ConnectionError):pass
class TCPServer(socketserver.ThreadingTCPServer):daemon_threads=True

def run(binary,root,expected_sha256=None):
    verified_hash=verify_binary(binary,expected_sha256)
    binary=binary.resolve()
    if root.exists() or root.is_symlink():raise ValueError('new directory only')
    root.mkdir(parents=True,mode=0o700)
    ver=subprocess.run([str(binary),'version'],capture_output=True,text=True,timeout=5,env=clean_env()).stdout.splitlines()[0]
    if '26.9.30' not in ver or 'b26a91d' not in ver:raise ValueError('wrong binary')
    cert,key,pin=certificate(root,shutil.which('openssl'));cred={'uuid':str(uuid.uuid4()),'auth':secrets.token_urlsafe(24),'pin':pin,'cert':cert,'key':key,'private':'','public':'','shortid':''}
    report={'revision':'r4','commit':SHA,'binary_sha256':verified_hash,'scope':'real binary; localhost DNS upstream counter; no external network','cases':[]}
    for name in ('udp-cache','tcp-cache','udp-no-cache','udp-stale'):
        d=root/name;d.mkdir(mode=0o700);state=State();srv=(TCPServer(('127.0.0.1',0),TCP) if name.startswith('tcp') else socketserver.UDPServer(('127.0.0.1',0),UDP));srv.state=state
        thread=threading.Thread(target=srv.serve_forever,kwargs={'poll_interval':.05},daemon=True);thread.start();children=[]
        ports=unused_ports(6);objs=make_pair('raw-tls',str(d),ports,cred);c=objs['client.json'];s=objs['server.json']
        c['outbounds'][0]['settings']['address']='lab.test';c['outbounds'][0]['streamSettings']['sockopt']={'domainStrategy':'ForceIPv4'}
        c['outbounds'].append({'tag':'dns-direct','protocol':'freedom','settings':{'finalRules':[{'action':'allow','ip':['127.0.0.1']},{'action':'block','blockDelay':0}]}})
        dnsport=srv.server_address[1];addr=('tcp://127.0.0.1:'+str(dnsport)) if name.startswith('tcp') else {'address':'127.0.0.1','port':dnsport}
        c['dns']={'servers':[addr],'tag':'lab-dns','queryStrategy':'UseIPv4','disableCache':name=='udp-no-cache','serveStale':name=='udp-stale','serveExpiredTTL':10}
        c['routing']={'rules':[{'inboundTag':['lab-dns'],'outboundTag':'dns-direct'}]}
        for file,obj in [('server.json',s),('client.json',c)]:write_json(d/file,obj)
        r={'name':name,'status':'FAIL'}
        try:
            with echo_servers() as (tp,_):
                for file in ('server.json','client.json'):children.append(Child([str(binary),'run','-c',str(d/file)],d,d/(file+'.log')))
                wait_tcp_probe(ports[1],tp,children,8);before=state.count
                tcp_probe(ports[1],tp,1024,3);tcp_probe(ports[1],tp,1024,3);after=state.count
                r.update(initial_queries=before,after_two_connections=after)
                if before==0:raise AssertionError('resolver bypassed')
                if name=='udp-no-cache' and after-before<2:raise AssertionError('expected new DNS queries')
                if name!='udp-no-cache' and after!=before:raise AssertionError('cache miss')
                if name=='udp-stale':
                    time.sleep(2.2);state.offline=True;start=time.monotonic();tcp_probe(ports[1],tp,1024,2);r['stale_connection_seconds']=round(time.monotonic()-start,3);time.sleep(.2)
                    r['queries_after_stale']=state.count
                    if state.count<=after:raise AssertionError('background refresh not observed')
                r['status']='PASS'
        except Exception as exc:r['error_class']=type(exc).__name__
        finally:
            for child in reversed(children):child.stop()
            srv.shutdown();srv.server_close();thread.join(1)
        report['cases'].append(r);print(name+': '+r['status'],flush=True)
    report['status']='PASS' if all(r['status']=='PASS' for r in report['cases']) else 'FAIL'
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n');return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--sha256',required=True);p.add_argument('--xray',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    if not a.execute:p.error('--execute required')
    try:return 0 if run(a.xray,a.out,a.sha256)['status']=='PASS' else 1
    except (OSError,ValueError,subprocess.SubprocessError):print('DNS_LAB_ERROR: no secrets printed',file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
