"""Bounded, read-only structural checks backed by the shipped field inventory.
No environment resolution, network or subprocesses. Not a JSON Schema for all Xray
protocols. Unknown/opaque protocol subtrees produce explicit COVERAGE diagnostics.
"""
from __future__ import annotations
import ipaddress
import json
import math
import re
from pathlib import Path
from urllib.parse import urlsplit

INDEX = json.loads((Path(__file__).resolve().parents[1]/'references/knowledge-index.json').read_text(encoding='utf-8'))['objects']
ALIASES = {'TLSConfig':'streamSettings.tlsSettings','SocketConfig':'streamSettings.sockopt',
 'REALITYConfig':'streamSettings.realitySettings','TCPConfig':'streamSettings.rawSettings',
 'SplitHTTPConfig':'streamSettings.xhttpSettings','TransportProtocol':'string'}
CHILDREN = {
 ('streamSettings.rawSettings','header'):'streamSettings.rawSettings.header',
 ('streamSettings.xhttpSettings','xmux'):'streamSettings.xhttpSettings.xmux',
 ('streamSettings.xhttpSettings','extra'):'streamSettings.xhttpSettings',
 ('streamSettings.xhttpSettings','downloadSettings'):'streamSettings',
 ('streamSettings.hysteriaSettings','masquerade'):'HysteriaMasquerade',
 ('streamSettings.xdriveSettings','template'):'XDriveStorageTemplate',
}
INBOUND = {'tunnel','dokodemo-door','http','shadowsocks','mixed','socks','vless','vmess','trojan','wireguard','hysteria','masque','tun'}
OUTBOUND = {'block','blackhole','loopback','direct','freedom','http','shadowsocks','socks','vless','vmess','trojan','hysteria','masque','dns','wireguard'}
API_SERVICES = {'reflectionservice','handlerservice','loggerservice','statsservice','observatoryservice','routingservice'}


def port_ranges(value):
    """Safe authoring subset of PortList, without enumerating huge ranges.
    Empty/zero port lists are rejected for authoring rather than reported as a
    universal rejection by Xray's permissive PortList.UnmarshalJSON.
    """
    if type(value) is int:
        if not 1 <= value <= 65535:raise ValueError('port out of range')
        return [(value,value)]
    if not isinstance(value,str) or not value.strip():raise ValueError('port/list required')
    if any(s.strip().startswith('env:') for s in value.split(',')):
        return None  # explicit unresolved environment, never use agent environment
    out=[]
    for s in value.split(','):
        s=s.strip()
        if not s:raise ValueError('empty port item')
        if not re.fullmatch(r'\d+(?:-\d+)?',s):raise ValueError('invalid port')
        a=s.split('-');lo=int(a[0]);hi=int(a[-1])
        if not 1<=lo<=hi<=65535:raise ValueError('invalid range')
        out.append((lo,hi))
    return out


def string_list(x):
    return x.split(',') if isinstance(x,str) else (x if isinstance(x,list) and all(isinstance(s,str) for s in x) else None)


def check(v, obj, as_stream=False, *, decode_only=False):
    def emit(code,p,msg,kind='AUTHORING_POLICY',severity='ERROR',file='infra/conf/xray.go'):
        if not any(x['code']==code and x['path']==p for x in v.issues):v.issue(code,p,msg,kind,severity,file)
    def walk(value,typ,p,depth=0):
        if depth>48:emit('SCHEMA_DEPTH',p,'Превышена глубина структурной проверки.');return
        optional=typ.endswith('?');typ=typ.removesuffix('?');typ=ALIASES.get(typ,typ)
        if value is None:
            if not optional:emit('EXPLICIT_NULL',p,'null не равен типизированному значению; безопасный авторинг предпочитает пропуск поля.','AUTHORING_POLICY','WARNING')
            return
        if typ=='FakeDNSUnion':
            walk(value,'array[FakeDNSPool]' if isinstance(value,list) else 'FakeDNSPool',p,depth+1);return
        if typ in INDEX:
            if not isinstance(value,dict):emit('SCHEMA_TYPE',p,'Ожидается объект '+typ+'.');return
            fields=INDEX[typ]['fields']
            for k,item in value.items():
                q=p+'.'+k if k in fields else p+'.<unknown-field>'
                if k not in fields:
                    emit('UNKNOWN_FIELD',q,'Имя поля отсутствует в закреплённой схеме '+typ+'. Неизвестное имя скрыто.');continue
                t=fields[k];target=CHILDREN.get((typ,k))
                if typ=='streamSettings' and t=='TransportSettings?':target='streamSettings.'+k
                if target:t=target+'?' if t.endswith('?') else target
                walk(item,t,q,depth+1)
            if typ=='Mask' and isinstance(value.get('type'),str):
                layer='udp' if '.udp[' in p else 'tcp'
                target=f'finalmask.{layer}[type={value["type"]}].settings'
                if target in INDEX:walk(value.get('settings',{}),target,p+'.settings',depth+1)
            if typ=='PolicyConfig' and isinstance(value.get('levels'),dict):
                for k in value['levels']:
                    if not re.fullmatch(r'\d+',k) or int(k)>2**32-1:emit('POLICY_LEVEL',p+'.levels.<level>','Уровень должен быть uint32, записанным строковым ключом.')
            return
        if typ.startswith('array[') and typ.endswith(']'):
            if not isinstance(value,list):emit('SCHEMA_TYPE',p,'Ожидается массив.');return
            for i,item in enumerate(value):walk(item,typ[6:-1],f'{p}[{i}]',depth+1)
            return
        if typ in ('map[string]string','map[StringList]','map[Policy]','map[IP|domain|array[IP]]'):
            if not isinstance(value,dict):emit('SCHEMA_TYPE',p,'Ожидается объект-словарь.');return
            child={'map[string]string':'string','map[StringList]':'StringList','map[Policy]':'Policy?','map[IP|domain|array[IP]]':'StringList'}[typ]
            for item in value.values():walk(item,child,p+'.<entry>',depth+1)
            return
        if typ=='RawMessage':return  # deliberately opaque, handled by contextual checks
        if typ=='string|NameServer':
            if not isinstance(value,str):walk(value,'NameServer',p,depth+1)
            return
        if typ in ('StringList','NetworkList'):
            xs=string_list(value)
            if xs is None:emit('SCHEMA_TYPE',p,'Ожидается строка либо массив строк.');return
            if typ=='NetworkList' and any(x.lower() not in ('tcp','udp','unix') for x in xs):emit('NETWORK_VALUE',p,'Неизвестное сетевое значение превращается в Unknown; исправьте опечатку.')
            return
        if typ=='PortList':
            try:
                if port_ranges(value) is None:emit('ENV_UNRESOLVED',p,'Порт зависит от env; эта проверка не читает окружение агента.','COVERAGE','WARNING')
            except ValueError:emit('PORT_LIST',p,'Используйте порт 1..65535 либо строку непустых упорядоченных диапазонов; массив не PortList.')
            return
        if typ in ('Address','string','enum','Bandwidth string','none|http','tcp|udp'):
            if not isinstance(value,str):emit('SCHEMA_TYPE',p,'Ожидается строка.');return
            if typ=='Address' and value.startswith('env:'):emit('ENV_UNRESOLVED',p,'Адрес зависит от env; значение не подставляется из среды агента.','COVERAGE','WARNING')
            return
        if typ in ('bool','boolean'):
            if type(value) is not bool:emit('SCHEMA_TYPE',p,'Ожидается JSON boolean, а не строка/число.')
            return
        if typ in ('object','StreamConfig'):
            if typ=='StreamConfig':walk(value,'streamSettings',p,depth+1)
            elif not isinstance(value,dict):emit('SCHEMA_TYPE',p,'Ожидается объект.')
            return
        if typ in ('int','integer','int64 seconds'):typ='int64'
        m=re.fullmatch(r'(u?int)(8|16|32|64)',typ)
        if m:
            bits=int(m[2]);lo=0 if m[1]=='uint' else -2**(bits-1);hi=2**bits-1 if m[1]=='uint' else 2**(bits-1)-1
            if type(value) is not int or not lo<=value<=hi:emit('SCHEMA_TYPE',p,'Целое число не соответствует '+typ+'.')
            return
        if typ=='bool|integer':
            if type(value) not in (bool,int):emit('SCHEMA_TYPE',p,'Ожидается bool либо целое.')
            return
        if typ=='range':
            from lint_config import range32
            try:range32(value)
            except ValueError:emit('SCHEMA_TYPE',p,'Ожидается безопасный Int32Range.')
            return
        if typ=='duration':
            from semantic_checks import duration
            try:duration(value)
            except ValueError:emit('SCHEMA_TYPE',p,'Ожидается неотрицательная Go duration-строка.')
            return
        if typ=='float64':
            if type(value) not in (int,float) or not math.isfinite(value):emit('SCHEMA_TYPE',p,'Ожидается конечное число.')
            return
        emit('SCHEMA_UNIMPLEMENTED',p,'Тип не покрыт структурным checker; результат не может подтверждать этот блок.','COVERAGE','WARNING')

    walk(obj,'streamSettings' if as_stream else 'Config','$')
    if decode_only or as_stream or not isinstance(obj,dict):return
    for side,allowed in [('inbounds',INBOUND),('outbounds',OUTBOUND)]:
        for i,e in enumerate(obj.get(side,[]) if isinstance(obj.get(side),list) else []):
            if not isinstance(e,dict):continue
            p=f'$.{side}[{i}]';protocol=e.get('protocol','')
            if not isinstance(protocol,str) or protocol not in allowed:emit('PROTOCOL_UNREGISTERED',p+'.protocol','Протокол не зарегистрирован для этого направления; используйте точное имя.','SOURCE_BUILD')
            if side=='inbounds':
                listen=e.get('listen')
                if isinstance(listen,str) and not listen.startswith(('/', '@','env:')) and listen not in ('','localhost'):
                    try:ipaddress.ip_address(listen)
                    except ValueError:emit('LISTEN_DOMAIN',p+'.listen','Inbound принимает IP, localhost либо Unix socket, не произвольный домен.','SOURCE_BUILD')
                if isinstance(e.get('sniffing'),dict):
                    sniff=e['sniffing'];dest=string_list(sniff.get('destOverride',[]))
                    if dest is not None and any(s.lower() not in ('http','tls','https','ssl','quic','fakedns','fakedns+others') for s in dest):emit('SNIFF_PROTOCOL',p+'.sniffing.destOverride','Неизвестный sniffing protocol.','SOURCE_BUILD')
                    if sniff.get('enabled') and sniff.get('metadataOnly') and dest and any(s.lower() in ('http','tls','https','ssl','quic') for s in dest):emit('SNIFF_METADATA_ONLY',p+'.sniffing','metadataOnly не анализирует payload: не ожидайте распознавания HTTP/TLS/QUIC из полезных данных.','AUTHORING_POLICY','WARNING')
                    if dest and any('fakedns' in x.lower() for x in dest) and obj.get('fakeDns') is None and not fake_dns_in_use(obj):emit('FAKEDNS_DEPENDENCY',p+'.sniffing','FakeDNS требует согласованного пула, DNS и перехвата; один destOverride их не создаёт.','AUTHORING_POLICY','WARNING')
            options=e.get('settings')
            if isinstance(options,dict) and protocol=='vless':
                walk_vless(options,p+'.settings',side,emit,walk)
            if isinstance(options,dict) and protocol in ('vmess','trojan'):
                import protocol_checks
                typ=('VMess' if protocol=='vmess' else 'Trojan')+('Inbound' if side=='inbounds' else 'Outbound')
                walk(options,typ,p+'.settings')
                protocol_checks.check_options(v,options,p+'.settings',side,protocol)
            if isinstance(options,dict) and protocol in ('socks','mixed','http'):
                typ=('HttpProxy' if protocol=='http' else 'SocksProxy')+('Inbound' if side=='inbounds' else 'Outbound')
                walk(options,typ,p+'.settings')
            if isinstance(options,dict) and protocol not in ('vless','vmess','trojan','hysteria','masque','freedom','direct','socks','mixed','http') and options:
                emit('PROTOCOL_SETTINGS_PARTIAL',p+'.settings','Транспорт проверен, но options этого протокола покрыты не полностью. Нужна нативная проверка.','COVERAGE','WARNING')
    log=obj.get('log')
    if isinstance(log,dict):
        level=log.get('loglevel','')
        if isinstance(level,str) and level.lower() not in ('','warning','info','debug','error','none'):emit('LOG_LEVEL_DEFAULT','$.log.loglevel','Неизвестный loglevel станет warning; исправьте опечатку.','SOURCE_BUILD','WARNING','infra/conf/log.go')
    policy=obj.get('policy')
    if isinstance(policy,dict):
        levels=policy.get('levels')
        if isinstance(levels,dict):
            for pl in levels.values():
                if not isinstance(pl,dict):continue
                size=pl.get('bufferSize')
                if type(size) is int and size>2097151:emit('POLICY_BUFFER_OVERFLOW','$.policy.levels.<level>.bufferSize','KiB умножаются на 1024 в int32; это значение переполнит байтовый размер.','SOURCE_BUILD','ERROR','infra/conf/policy.go')
                if any(pl.get(k) is True for k in ('statsUserUplink','statsUserDownlink','statsUserOnline')) and obj.get('stats') is None:emit('STATS_REQUIRED','$.policy','Включены пользовательские счётчики без stats:{}; счётчики не подтверждены.','AUTHORING_POLICY','WARNING','infra/conf/policy.go')
        system=policy.get('system')
        if isinstance(system,dict) and any(value is True for value in system.values()) and obj.get('stats') is None:emit('STATS_REQUIRED','$.policy','Включены системные счётчики без stats:{}.','AUTHORING_POLICY','WARNING','infra/conf/policy.go')
    for name in ('api','metrics'):
        block=obj.get(name)
        if not isinstance(block,dict):continue
        if name=='api':
            if not isinstance(block.get('tag'),str) or not block['tag']:emit('API_TAG','$.api.tag','API требует непустой tag даже при заданном listen.','SOURCE_BUILD','ERROR','infra/conf/api.go')
            services=block.get('services')
            if isinstance(services,list):
                for service in services:
                    if isinstance(service,str) and service.lower() not in API_SERVICES:emit('API_SERVICE_IGNORED','$.api.services','Неизвестная служба будет проигнорирована; исправьте имя.','SOURCE_BUILD','ERROR','infra/conf/api.go')
        elif not block.get('tag') and not block.get('listen'):emit('METRICS_ENDPOINT','$.metrics','Metrics требует tag или listen.','SOURCE_BUILD','ERROR','infra/conf/metrics.go')
        listen=block.get('listen')
        if isinstance(listen,str) and listen:
            if name=='metrics' and listen.startswith(('/', '@')):
                emit('METRICS_TCP_ONLY','$.metrics.listen','Metrics listen использует TCP, в отличие от API listen; Unix socket этим полем не выбирается.','SOURCE_RUNTIME','ERROR','app/metrics/metrics.go')
            elif not listen.startswith(('/', '@')):
                try:
                    u=urlsplit('//'+listen);host=u.hostname;port=u.port
                    if not host or port is None or not 1<=port<=65535:raise ValueError()
                    private=host=='localhost' or ipaddress.ip_address(host).is_loopback
                    if not private:emit('CONTROL_PLANE_EXPOSED','$.'+name+'.listen','Управляющий endpoint не loopback; нужны отдельно настроенные ACL/аутентификация, которых это поле не создаёт.','AUTHORING_POLICY','WARNING')
                except ValueError:emit('CONTROL_LISTEN','$.'+name+'.listen','Нужен IP:port либо абсолютный Unix socket; DNS listener требует явного анализа среды.')
    fake=obj.get('fakeDns')
    pools=fake if isinstance(fake,list) else ([fake] if isinstance(fake,dict) else [])
    for pool in pools:
        if not isinstance(pool,dict):
            emit('FAKEDNS_POOL','$.fakeDns','Элемент пула должен быть объектом, не null.');continue
        try:ipaddress.ip_network(pool.get('ipPool',''),strict=False)
        except (ValueError,TypeError):emit('FAKEDNS_CIDR','$.fakeDns.ipPool','Требуется корректный CIDR пула.')
        size=pool.get('poolSize')
        if size is not None and (type(size) is not int or size<=0):emit('FAKEDNS_SIZE','$.fakeDns.poolSize','Для явного пула задавайте положительный размер LRU; пропуск проверяется ядром.')
    gd=obj.get('geodata')
    if isinstance(gd,dict):
        if gd.get('cron') is not None:emit('GEODATA_CRON_NATIVE','$.geodata.cron','Cron проверяет robfig/cron.ParseStandard; checker не подменяет его интерпретацию.','COVERAGE','WARNING','infra/conf/geodata.go')
        for asset in gd.get('assets',[]) if isinstance(gd.get('assets',[]),list) else []:
            if not isinstance(asset,dict):emit('GEODATA_ASSET','$.geodata.assets','Asset должен быть объектом.');continue
            try:
                u=urlsplit(asset.get('url',''))
                if u.scheme!='https' or not u.netloc:raise ValueError()
            except (ValueError,TypeError):emit('GEODATA_URL','$.geodata.assets.url','Asset требует HTTPS URL.','SOURCE_BUILD','ERROR','infra/conf/geodata.go')
            if not isinstance(asset.get('file'),str) or not asset['file']:emit('GEODATA_FILE','$.geodata.assets.file','Требуется имя файла asset.')
            else:emit('GEODATA_FILE_UNVERIFIED','$.geodata.assets.file','Core проверяет файл через StatAsset; offline checker намеренно не читает пути из JSON.','COVERAGE','WARNING','infra/conf/geodata.go')
    if obj.get('version') is not None:emit('VERSION_RUNTIME_CHECK','$.version','Блок min/max ограничивает запуск ядра; принятие JSON не подтверждает runtime-совместимость версии.','COVERAGE','WARNING','infra/conf/version.go')


def fake_dns_in_use(obj):
    dns=obj.get('dns')
    if not isinstance(dns,dict) or not isinstance(dns.get('servers'),list):return False
    return any(isinstance(s,str) and s.lower()=='fakedns' or isinstance(s,dict) and str(s.get('address','')).lower()=='fakedns' for s in dns['servers'])


def walk_vless(o,p,side,emit,walk):
    # User/account are decoded by two structures in core, uint32 level (protobuf),
    # so no generic conf.User uint8 limit is incorrectly applied here.
    if side=='inbounds':
        users=o.get('clients') if o.get('clients') is not None else o.get('users',[])
        accounts=users if isinstance(users,list) else []
    elif o.get('address') is not None:
        for k,t in [('address','Address'),('port','uint16'),('id','string'),('encryption','string'),('flow','string'),('email','string'),('level','uint32')]:
            if k in o:walk(o[k],t,p+'.'+k)
        accounts=[o]
    else:
        accounts=[]
        for i,server in enumerate(o.get('vnext',[]) if isinstance(o.get('vnext'),list) else []):
            if not isinstance(server,dict):emit('SCHEMA_TYPE',p+'.vnext','Ожидается массив объектов.');continue
            for k,t in [('address','Address'),('port','uint16')]:
                if k in server:walk(server[k],t,p+'.vnext.'+k)
            us=server.get('users',[])
            if not isinstance(us,list):emit('SCHEMA_TYPE',p+'.vnext.users','Ожидается массив.');continue
            accounts.extend(us)
    seen=set()
    for acc in accounts:
        if not isinstance(acc,dict):emit('SCHEMA_TYPE',p+'.users','Ожидается объект пользователя.');continue
        for k,t in [('id','string'),('flow','string'),('email','string'),('level','uint32'),('encryption','string'),('testseed','array[uint32]')]:
            if k in acc:walk(acc[k],t,p+'.<account>.'+k)
        if not isinstance(acc.get('id'),str) or not acc['id']:emit('VLESS_ID',p+'.<account>.id','Нужен непустой id; значение не выводится.')
        from peer_checks import canonical_id
        try:
            ident=canonical_id(acc.get('id'))
            if ident in seen:emit('DUPLICATE_USER_ID',p+'.users','Повтор канонического ID пользователя; различная запись может давать один ID.')
            seen.add(ident)
        except ValueError:emit('VLESS_ID_FORMAT',p+'.<account>.id','Используйте UUID либо строку 1..30 UTF-8 bytes. 31 byte и некорректный UUID запрещены.')
        rv=acc.get('reverse')
        if rv is not None:
            if not isinstance(rv,dict):emit('SCHEMA_TYPE',p+'.reverse','Нужен объект.');continue
            if not isinstance(rv.get('tag'),str) or not rv['tag']:emit('REVERSE_TAG',p+'.reverse.tag','Требуется непустой tag.')
            if side=='outbounds' and 'sniffing' in rv:walk(rv['sniffing'],'SniffingConfig?',p+'.reverse.sniffing')
