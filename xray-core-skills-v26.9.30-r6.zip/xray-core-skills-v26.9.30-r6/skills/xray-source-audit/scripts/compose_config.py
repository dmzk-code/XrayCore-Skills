#!/usr/bin/env python3
"""Read-only Xray JSON/JSONC composition, pinned to v26.9.30 Config.Override.
Not a universal deep merge. No network, subprocess or environment substitution.
Default output is a redacted validation summary. --write-merged requires a NEW file.
Canonical JSON authoring subset only; native -dump/-test remains authoritative.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from lint_config import loads, SHA
from validate import Validator, ROOT_KEYS, safe_shape

MAX_BYTES = 16 * 1024 * 1024
MAX_FILES = 128
BLOCKS = ROOT_KEYS - {'env', 'inbounds', 'outbounds'}


def strip_comments(text: str) -> str:
    """Accept //, /* */, # outside double quoted strings, not JSON5.
    Unlike the permissive kernel comment filter, replace non-newline comment
    characters by spaces so that comments cannot splice numbers or identifiers.
    Unterminated block comments are rejected. Escapes/URLs inside strings survive.
    """
    chars=list(text);i=0;quoted=False
    while i<len(chars):
        if quoted:
            if chars[i]=='\\':i+=2;continue
            if chars[i]=='"':quoted=False
            i+=1;continue
        if chars[i]=='"':quoted=True;i+=1;continue
        if chars[i]=='#' or text.startswith('//',i):
            while i<len(chars) and chars[i] not in '\r\n':chars[i]=' ';i+=1
        elif text.startswith('/*',i):
            end=text.find('*/',i+2)
            if end<0:raise ValueError('unterminated comment')
            while i<end+2:
                if chars[i] not in '\r\n':chars[i]=' '
                i+=1
        else:i+=1
    return ''.join(chars)


def fragment_shape(obj: object) -> None:
    safe_shape(obj)
    if not isinstance(obj,dict) or set(obj)-ROOT_KEYS:
        raise ValueError('canonical known root fields required')
    for block in BLOCKS:
        if obj.get(block) is not None:
            acceptable=(dict,list) if block=='fakeDns' else (dict,)
            if not isinstance(obj[block],acceptable):raise ValueError('invalid root block')
    if obj.get('env') is not None and (not isinstance(obj['env'],dict) or any(not isinstance(v,str) for v in obj['env'].values())):
        raise ValueError('env must be a string map')
    for side in ('inbounds','outbounds'):
        endpoints=obj.get(side)
        if endpoints is None:continue
        if not isinstance(endpoints,list):raise ValueError('endpoint array required')
        for endpoint in endpoints:
            if not isinstance(endpoint,dict) or not isinstance(endpoint.get('tag',''),str):
                raise ValueError('endpoint object/string tag required')
    import schema_checks
    validator=Validator();schema_checks.check(validator,obj,decode_only=True)
    if any(i['severity']=='ERROR' for i in validator.issues):
        raise ValueError('typed fragment decoding rejected')
    # Config.Build is intentionally not called for fragments: a later file may
    # replace an entire invalid endpoint or block before Build ever sees it.


def merge_named(fragments: list[tuple[str,dict]]) -> tuple[dict,list[dict]]:
    if not fragments or len(fragments)>MAX_FILES:raise ValueError('invalid file count')
    for name,obj in fragments:
        if not isinstance(name,str):raise ValueError('name must be string')
        fragment_shape(obj)
    result=copy.deepcopy(fragments[0][1]);events=[]
    for index,(name,incoming) in enumerate(fragments[1:],1):
        overlay=copy.deepcopy(incoming)
        for key in BLOCKS:
            if overlay.get(key) is not None:
                result[key]=overlay[key]
                events.append({'input_index':index,'action':'replace-root-block','field':key})
        if overlay.get('env') is not None:
            existing=result.get('env') or {}
            result['env']={**existing,**overlay['env']}
            events.append({'input_index':index,'action':'merge-env-keys','count':len(overlay['env'])})
        for side in ('inbounds','outbounds'):
            if not overlay.get(side):continue
            current=result.get(side) or []
            prepends=[]
            # This is the entire argument supplied to Config.Override, NOT the
            # basename. A parent directory named 'retail' triggers append too.
            tail='tail' in name.lower()
            for endpoint in overlay[side]:
                tag=endpoint.get('tag','')
                existing=next((i for i,e in enumerate(current) if e.get('tag','')==tag),None)
                if existing is not None:
                    current[existing]=endpoint;action='replace-whole-endpoint'
                elif side=='inbounds' or tail:
                    current.append(endpoint);action='append-endpoint'
                else:
                    prepends.append(endpoint);action='prepend-endpoint'
                events.append({'input_index':index,'action':action,'field':side})
            result[side]=prepends+current
        safe_shape(result)
    return result,events


def collect_files(explicit: list[str], directory: str | None) -> list[str]:
    names=list(explicit)
    if directory is not None:
        d=Path(directory)
        reject_symlinks(d)
        if not d.is_dir():raise ValueError('confdir not found')
        names += [str(d/p.name) for p in sorted(d.iterdir(),key=lambda p:p.name)
                  if re.fullmatch(r'.+\.(json|jsonc)',p.name)]
    if not names or len(names)>MAX_FILES:raise ValueError('supply 1..128 files')
    return names


def reject_symlinks(path: Path) -> None:
    if any(p.is_symlink() for p in (path,*path.parents)):
        raise ValueError('symlinks are not accepted')


def load_files(names: list[str], *, strict: bool=False) -> tuple[list[tuple[str,dict]],list[dict]]:
    fragments=[];inputs=[];total=0
    for i,name in enumerate(names):
        if '://' in name or name=='stdin:':raise ValueError('only local files accepted')
        p=Path(name);reject_symlinks(p)
        if p.suffix not in ('.json','.jsonc') or not p.is_file():raise ValueError('local JSON file required')
        if p.stat().st_size>MAX_BYTES:raise ValueError('input too large')
        with p.open('rb') as f:raw=f.read(MAX_BYTES+1)
        total+=len(raw)
        if total>MAX_BYTES:raise ValueError('aggregate input limit exceeded')
        text=raw.decode('utf-8-sig');obj=loads(text if strict else strip_comments(text))
        fragment_shape(obj);fragments.append((name,obj))
        inputs.append({'index':i,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'tail_path_semantics':'tail' in name.lower()})
    return fragments,inputs


def compose(names: list[str], *, strict: bool=False) -> tuple[dict,dict]:
    fragments,inputs=load_files(names,strict=strict)
    merged,events=merge_named(fragments);v=Validator();issues=v.config(merged)
    # Root env executes after parsing Address/PortList, not as a templating engine.
    def has_env(x):
        if isinstance(x,str):return x.startswith('env:')
        if isinstance(x,dict):return any(has_env(v) for v in x.values())
        if isinstance(x,list):return any(has_env(v) for v in x)
        return False
    if merged.get('env') and has_env({k:x for k,x in merged.items() if k!='env'}):
        v.issue('ROOT_ENV_AFTER_PARSE','$','Root env применяется после разбора всех файлов и не подставляет env: в уже разобранные Address/PortList; настройте parse-time среду отдельно.','SOURCE_RUNTIME','WARNING','main/run.go')
    if any(i['tail_path_semantics'] for i in inputs[1:]):
        v.issue('OUTBOUND_TAIL_PATH','$','Порядок outbound зависит от подстроки tail во всём пути одного из overlay-файлов, не только в basename.','SOURCE_RUNTIME','WARNING','infra/conf/xray.go')
    errors=sum(x['severity']=='ERROR' for x in issues)
    report={'revision':'r6','core_commit':SHA,'status':'STATIC_ERRORS' if errors else 'STATIC_OK',
            'scope':'local canonical JSON composition; no Build, execution, key-file reads or env substitution',
            'input_count':len(inputs),'inputs':inputs,'operations':events,'issues':issues,
            'inbound_count':len(merged.get('inbounds') or []),'outbound_count':len(merged.get('outbounds') or []),
            'error_count':errors,'merged_written':False}
    return merged,report


def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('-c','--config',action='append',default=[])
    p.add_argument('--confdir');p.add_argument('--strict-json',action='store_true')
    p.add_argument('--write-merged',type=Path,help='NEW private output file; contains credentials')
    args=p.parse_args()
    try:
        names=collect_files(args.config,args.confdir);merged,report=compose(names,strict=args.strict_json)
        if args.write_merged and report['error_count']==0:
            dest=args.write_merged;reject_symlinks(dest)
            data=json.dumps(merged,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
            fd=os.open(dest,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w',encoding='utf-8') as f:f.write(data)
            report['merged_written']=True
        print(json.dumps(report,ensure_ascii=False,indent=2))
        return 1 if report['error_count'] else 0
    except (OSError,ValueError,TypeError,UnicodeError,RecursionError):
        # Exception text may carry fragments, file names and credentials.
        print(json.dumps({'revision':'r6','status':'INPUT_REJECTED','reason':'Invalid, oversized or unsupported local input; values hidden.'}))
        return 2

if __name__=='__main__':raise SystemExit(main())
