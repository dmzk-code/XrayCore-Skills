#!/usr/bin/env python3
"""Bounded r3 loopback transport/Finalmask and XDRIVE mock tests. No external APIs.
--execute explicitly permits starting a locally trusted Xray binary. New directory
only, fresh keys, no shell/firewall/service changes. Mock provider != real cloud.
"""
from __future__ import annotations
import argparse,base64,copy,hashlib,http.server,json,secrets,shutil,subprocess,sys,threading,uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from build_lab import certificate,make_pair,unused_ports,write_json
from run_lab import Child,capture,echo_servers,tcp_probe,udp_probe,wait_tcp_probe,clean_env
from lab_trust import verify_binary
from lint_config import SHA
from validate import Validator

def variants():
    cases=[]
    def add(n,b,c=None,s=None):cases.append({'name':n,'base':b,'client_patch':c or {},'server_patch':copy.deepcopy(c if s is None else s) or {}})
    def mask(n,b,t,s,layer='udp',one=False):add(n,b,{'finalmask':{layer:[{'type':t,'settings':s}]}},{} if one else None)
    mask('raw-custom-header','raw-tls','header-custom',{'clients':[[{'type':'str','packet':'LAB-HELLO'}]],'servers':[[{'type':'str','packet':'LAB-OK'}]]},'tcp')
    mask('raw-capture-reuse','raw-tls','header-custom',{'clients':[[{'rand':8,'capture':'challenge'}]],'servers':[[{'reuse':'challenge'}]]},'tcp')
    mask('raw-sudoku','raw-tls','sudoku',{'password':'LOCAL-LAB-ONLY','ascii':'prefer_ascii','paddingMin':5,'paddingMax':10},'tcp')
    add('raw-http-header','raw-tls',{'rawSettings':{'header':{'type':'http','request':{'path':['/lab'],'headers':{'Host':['localhost']}},'response':{'headers':{'Content-Type':['application/octet-stream']}}}}})
    for h in ('','dns','dtls','srtp','utp','wechat','wireguard'):mask('mkcp-legacy-'+(h or 'original'),'mkcp-tls','mkcp-legacy',{'header':h,'value':'lab.test' if h=='dns' else ''})
    mask('mkcp-legacy-aes','mkcp-tls','mkcp-legacy',{'value':'LOCAL-LAB-ONLY'})
    mask('mkcp-custom-udp','mkcp-tls','header-custom',{'client':[{'type':'str','packet':'LH'}],'server':[{'type':'str','packet':'LS'}]})
    mask('mkcp-custom-standalone','mkcp-tls','header-custom',{'mode':'standalone','client':[{'type':'str','packet':'LAB-Q'}],'server':[{'type':'str','packet':'LAB-A'}]})
    mask('mkcp-sudoku','mkcp-tls','sudoku',{'password':'LOCAL-LAB-ONLY','ascii':'prefer_ascii'})
    for side in ('client_patch','server_patch'):cases[-1][side]['kcpSettings']={'mtu':256}
    mask('hysteria-salamander','hysteria2','salamander',{'password':'LOCAL-LAB-ONLY'})
    mask('hysteria-gecko','hysteria2','salamander',{'password':'LOCAL-LAB-ONLY','packetSize':'700-1200'})
    mask('hysteria-noise','hysteria2','noise',{'reset':1,'noise':[{'type':'exp','packet':'<b 1122><r 4-8><t><c><n>','delay':0}]},one=True)
    mask('hysteria-udphop-once','hysteria2','udphop',{'mode':'perConnRemote','interval':5},one=True)
    for place in ('header','cookie'):
        add('xhttp-get-'+place,'xhttp-header-h2',{'xhttpSettings':{'mode':'packet-up','uplinkHTTPMethod':'GET','uplinkDataPlacement':place,'uplinkDataKey':'LabData','scMaxEachPostBytes':768,'uplinkChunkSize':1024,'serverMaxHeaderBytes':16384}})
    for place in ('header','cookie','query'):
        add('xhttp-meta-'+place,'xhttp-header-h2',{'xhttpSettings':{'mode':'packet-up','sessionIDPlacement':place,'seqPlacement':place,'sessionIDKey':'LabSession','seqKey':'LabSeq','sessionIDTable':'hex','sessionIDLength':16}})
    for place in ('header','cookie','query','queryInHeader'):
        add('xhttp-padding-'+place,'xhttp-header-h2',{'xhttpSettings':{'mode':'packet-up','xPaddingObfsMode':True,'xPaddingPlacement':place,'xPaddingMethod':'tokenish','xPaddingBytes':'64-128','xPaddingKey':'lp','xPaddingHeader':'X-Lab-Padding'}})
    for mode in ('stream-one','stream-up'):add('xhttp-h3-'+mode,'xhttp-packet-h3',{'xhttpSettings':{'mode':mode}})
    add('xhttp-extra-overlay','xhttp-header-h2',{'xhttpSettings':{'extra':{'scMaxEachPostBytes':768,'xmux':{'maxConnections':2}}}})
    add('websocket-heartbeat','websocket-tls',{'wsSettings':{'heartbeatPeriod':1}})
    add('grpc-custom-path','grpc-tls',{'grpcSettings':{'serviceName':'/lab/service/Send|Multi'}})
    for auth in ('none','static','basic','oauth2'):
        add('xdrive-template-'+auth,'xdrive-local');cases[-1]['storage_auth']=auth
    add('xdrive-template-retry','xdrive-local');cases[-1].update(storage_auth='static',retry_once=True)
    for qtype in (16,28):
        mask('mkcp-xdns-'+str(qtype),'mkcp-tls','xdns',{'domains':[{'name':'lab.test','types':[qtype],'edns0':4096}]})
        cases[-1]['xdns_resolver']=True
        for side in ('client_patch','server_patch'):cases[-1][side]['kcpSettings']={'mtu':256}
    return cases

def merge(d,p):
    """Local laboratory patch helper only, NOT Xray Config.Override semantics."""
    for k,v in p.items():
        if isinstance(v,dict) and isinstance(d.get(k),dict):merge(d[k],v)
        else:d[k]=copy.deepcopy(v)

class MockStorage(http.server.ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,auth,token,retry):
        super().__init__(('127.0.0.1',0),StorageHandler)
        self.auth=auth;self.token=token;self.retry_once=retry;self.data={};self.lock=threading.Lock();self.counts={};self.retries=0
class StorageHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def reply(self,status,data=b''):
        try:
            self.send_response(status);self.send_header('Content-Length',str(len(data)));self.end_headers()
            if data:self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError):pass
    def handle_op(self):
        if self.client_address[0]!='127.0.0.1':self.reply(403);return
        self.connection.settimeout(5);size=int(self.headers.get('Content-Length','0'))
        if size>8*1024*1024:self.reply(413);return
        data=self.rfile.read(size);path=self.path.split('?',1)[0];parts=path.split('/',2);op=parts[1] if len(parts)>1 else ''
        with self.server.lock:self.server.counts[op]=self.server.counts.get(op,0)+1
        if path=='/token':self.reply(200,json.dumps({'access_token':self.server.token,'expires_in':3600}).encode());return
        expected={'none':None,'static':'Bearer '+self.server.token,'oauth2':'Bearer '+self.server.token,'basic':'Basic '+base64.b64encode(('lab:'+self.server.token).encode()).decode()}[self.server.auth]
        if expected is not None and self.headers.get('Authorization')!=expected:self.reply(401);return
        if len(parts)<3:self.reply(404);return
        name=parts[2]
        with self.server.lock:
            if self.server.retry_once and self.server.retries==0 and op=='put':self.server.retries+=1;self.reply(429);return
            if op=='put':
                try:self.server.data[name]=base64.b64decode(data,validate=True)
                except ValueError:self.reply(400);return
                self.reply(201)
            elif op=='get':self.reply(200,self.server.data[name]) if name in self.server.data else self.reply(404)
            elif op=='list':
                prefix=name.rstrip('/')+'/'
                values=sorted({k[len(prefix):].split('/',1)[0] for k in self.server.data if k.startswith(prefix)})
                self.reply(200,''.join('<n>'+x+'</n>' for x in values).encode())
            elif op=='delete':
                for key in list(self.server.data):
                    if key==name or key.startswith(name.rstrip('/')+'/'):self.server.data.pop(key,None)
                self.reply(204)
            else:self.reply(404)
    do_GET=handle_op;do_PUT=handle_op;do_POST=handle_op;do_DELETE=handle_op

def template(server):
    base=f'http://127.0.0.1:{server.server_address[1]}';auth={'type':server.auth}
    if server.auth in ('static','oauth2'):auth['header']={'Authorization':'Bearer '+('{token}' if server.auth=='oauth2' else '{secret0}')}
    if server.auth=='oauth2':auth.update(tokenUrl=base+'/token',form={'grant_type':'refresh_token','refresh_token':'{secret0}'},tokenPath='access_token',expiryPath='expires_in')
    if server.auth=='basic':auth.update(username='lab',password='{secret0}')
    return {'service':'template','remoteFolder':'lab','secrets':[server.token],'segmentBytes':4096,'flushIntervalMs':5,'pollIntervalMs':25,'maxPollIntervalMs':50,'sessionTtlSeconds':30,'template':{'concurrency':8,'auth':auth,'put':{'method':'PUT','url':base+'/put/{folder}/{name}','body':'{data}'},'get':{'url':base+'/get/{folder}/{name}'},'delete':{'method':'DELETE','url':base+'/delete/{folder}/{name}'},'list':{'url':base+'/list/{folder}/{prefix}','namesRegex':'<n>([^<]+)</n>'},'retry':{'status':[429,500,503]}}}

def run(binary,root,names=None,expected_sha256=None):
    verified_hash=verify_binary(binary,expected_sha256)
    if root.exists() or root.is_symlink():raise ValueError('new destination required')
    binary=binary.resolve();root.mkdir(parents=True,mode=0o700)
    version=subprocess.run([str(binary),'version'],capture_output=True,text=True,timeout=5,env=clean_env()).stdout.splitlines()[0]
    if '26.9.30' not in version or 'b26a91d' not in version:raise ValueError('binary version mismatch')
    report={'revision':'r4','commit':SHA,'binary_version':version,'binary_sha256':verified_hash,'environment':'loopback Linux; mock HTTP storage, no external provider','tests':[]}
    cert,key,pin=certificate(root,shutil.which('openssl'))
    cred={'uuid':str(uuid.uuid4()),'auth':secrets.token_urlsafe(24),'pin':pin,'cert':cert,'key':key,'private':'','public':'','shortid':''}
    for case in variants():
        if names and case['name'] not in names:continue
        d=root/case['name'];d.mkdir(mode=0o700);ports=unused_ports(6);objects=make_pair(case['base'],str(d),ports,cred)
        c=objects['client.json'];s=objects['server.json'];cs=c['outbounds'][0]['streamSettings'];ss=s['inbounds'][0]['streamSettings']
        merge(cs,case['client_patch']);merge(ss,case['server_patch']);mock=None;thread=None;children=[]
        if case.get('xdns_resolver'):
            cs['finalmask']['udp'][0]['settings']['resolvers']=[{'type':'udp','settings':{'addr':f'127.0.0.1:{ports[0]}'}}]
        if case['base']=='xdrive-local':(d/'storage').mkdir(mode=0o700)
        if case.get('storage_auth'):
            mock=MockStorage(case['storage_auth'],secrets.token_urlsafe(18),case.get('retry_once',False));thread=threading.Thread(target=mock.serve_forever,kwargs={'poll_interval':.05},daemon=True);thread.start()
            cs['xdriveSettings']=template(mock);ss['xdriveSettings']=copy.deepcopy(cs['xdriveSettings'])
        for file,o in [('client.json',c),('server.json',s)]:write_json(d/file,o)
        r={'name':case['name'],'base':case['base'],'core_config':'NOT_RUN','tcp':'NOT_RUN','udp':'NOT_RUN','parallel_4':'NOT_RUN'}
        r['static_errors']=[x['code'] for x in Validator().config(c)+Validator().config(s) if x['severity']=='ERROR']
        try:
            checks=[capture([str(binary),'run','-test','-c',str(d/f)],d,d/(f+'.test.log'),8) for f in ('server.json','client.json')]
            r['core_config']='PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL'
            if r['core_config']!='PASS':raise ValueError('core rejected config')
            with echo_servers() as (tp,up):
                for file in ('server.json','client.json'):children.append(Child([str(binary),'run','-c',str(d/file)],d,d/(file+'.run.log')))
                host=objects['topology.json']['probe_destination'];wait_tcp_probe(ports[1],tp,children,10,host);tcp_probe(ports[1],tp,8192,6,host);r['tcp']='PASS'
                try:udp_probe(ports[1],up,6,host);r['udp']='PASS'
                except Exception as exc:r['udp']='FAIL';r['udp_error_class']=type(exc).__name__
                def one(_):
                    try:tcp_probe(ports[1],tp,2048,6,host);return True
                    except Exception:return False
                with ThreadPoolExecutor(max_workers=4) as pool:success=sum(pool.map(one,range(4)))
                r['parallel_4']='PASS' if success==4 else 'FAIL';r['parallel_passed']=success
        except Exception as exc:
            r['error_class']=type(exc).__name__
            if r['tcp']=='NOT_RUN' and r['core_config']=='PASS':r['tcp']='FAIL'
        finally:
            for child in reversed(children):child.stop()
            if mock:
                mock.shutdown();mock.server_close();thread.join(1);r['mock_requests']=dict(mock.counts);r['mock_retries_injected']=mock.retries
        r['status']='PASS' if all(r[x]=='PASS' for x in ('core_config','tcp','udp','parallel_4')) and not r['static_errors'] else 'FAIL'
        report['tests'].append(r);(root/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(case['name']+': '+r['status'],flush=True)
    report['passed']=sum(x['status']=='PASS' for x in report['tests']);report['total']=len(report['tests']);report['status']='PASS' if report['passed']==report['total'] else 'FAIL'
    (root/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');return report

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--xray',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--execute',action='store_true');ap.add_argument('--sha256');ap.add_argument('--case',action='append');ap.add_argument('--list',action='store_true');a=ap.parse_args()
    if a.list:print('\n'.join(c['name'] for c in variants()));return 0
    if not a.execute or not a.xray or not a.out or not a.sha256:ap.error('--execute --xray TRUSTED_BINARY --sha256 TRUSTED_SHA256 --out NEW_DIRECTORY required')
    if a.case and any(n not in {c['name'] for c in variants()} for n in a.case):ap.error('unknown case')
    try:return 0 if run(a.xray,a.out,a.case,a.sha256)['status']=='PASS' else 1
    except (OSError,ValueError,subprocess.SubprocessError):print('EXTENDED_LAB_FAILED; inspect local logs, no secrets printed',file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
