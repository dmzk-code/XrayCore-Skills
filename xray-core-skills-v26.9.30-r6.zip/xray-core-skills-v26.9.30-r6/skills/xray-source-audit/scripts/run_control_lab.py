#!/usr/bin/env python3
"""Native API/Metrics direct-vs-virtual and traffic-counter smoke test.
Trusted Xray SHA256 and --execute required. Fresh loopback-only generated configs.
"""
from __future__ import annotations
import argparse,json,re,sys,urllib.request,time
from pathlib import Path
from build_lab import unused_ports,write_json
from lab_trust import verify_binary
from lint_config import SHA
from validate import Validator
from run_lab import Child,capture,echo_servers,wait_tcp_probe,tcp_probe,save_report


def run(binary,out,sha):
    observed=verify_binary(binary,sha);binary=binary.resolve();out=out.absolute()
    if out.exists() or out.is_symlink():raise ValueError('new output directory required')
    out.mkdir(mode=0o700,parents=True);version=capture([str(binary),'version'],out,out/'version.log',8)
    if version['status']!='PASS' or not re.search(r'\b26\.9\.30\b',(out/'version.log').read_text()):raise ValueError('version mismatch')
    report={'revision':'r4','core_commit':SHA,'binary_sha256':observed,'scope':'loopback control endpoints, real traffic counters','cases':[]}
    for api_direct,metrics_direct in [(True,True),(False,True),(True,False),(False,False)]:
        name=('api-direct' if api_direct else 'api-virtual')+'_'+('metrics-direct' if metrics_direct else 'metrics-virtual');d=out/name;d.mkdir();socks,api,metrics=unused_ports(3)
        c={'log':{'loglevel':'warning','access':'none'},'stats':{},'policy':{'system':{'statsInboundUplink':True,'statsInboundDownlink':True,'statsOutboundUplink':True,'statsOutboundDownlink':True}},
          'api':{'tag':'api-admin','services':['StatsService']},'metrics':{'tag':'metrics-admin'},
          'inbounds':[{'tag':'client-socks','protocol':'socks','listen':'127.0.0.1','port':socks,'settings':{'auth':'noauth'}}],
          'outbounds':[{'tag':'direct','protocol':'freedom','settings':{}}],'routing':{'rules':[]}}
        for block,port,direct in [('api',api,api_direct),('metrics',metrics,metrics_direct)]:
            if direct:c[block]['listen']=f'127.0.0.1:{port}'
            else:
                tag=block+'-in';c['inbounds'].append({'tag':tag,'protocol':'dokodemo-door','listen':'127.0.0.1','port':port,'settings':{'address':'127.0.0.1'}})
                c['routing']['rules'].append({'inboundTag':[tag],'outboundTag':c[block]['tag']})
        write_json(d/'config.json',c);item={'name':name,'status':'RUNNING'};child=None
        try:
            issues=Validator().config(c)
            if any(x['severity']=='ERROR' for x in issues):raise ValueError('static validation failed')
            n=capture([str(binary),'run','-test','-config',str(d/'config.json')],d,d/'core-test.log',10)
            if n['status']!='PASS':raise ValueError('native config failed')
            child=Child([str(binary),'run','-config',str(d/'config.json')],d,d/'runtime.log')
            with echo_servers() as (tp,_):
                wait_tcp_probe(socks,tp,[child],seconds=10);tcp_probe(socks,tp,4096)
                opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
                deadline=time.monotonic()+3
                counters={}
                while time.monotonic()<deadline:
                    with opener.open(f'http://127.0.0.1:{metrics}/debug/vars',timeout=3) as response:data=json.loads(response.read(1024*1024))
                    counters=data['stats']['outbound']['direct']
                    if counters.get('uplink',0)>0 and counters.get('downlink',0)>0:break
                    time.sleep(.1)
                item['sampled_counters']=counters
                item['metrics_counter']=bool(counters.get('uplink',0)>0 and counters.get('downlink',0)>0)
                result=capture([str(binary),'api','statsquery','--server='+f'127.0.0.1:{api}'],d,d/'api-stats.log',8)
                output=(d/'api-stats.log').read_text();item['api_stats']=result['status']=='PASS' and 'outbound>>>direct>>>traffic>>>uplink' in output
                item['status']='PASS' if item['metrics_counter'] and item['api_stats'] else 'FAIL'
        except (OSError,ValueError,KeyError,TimeoutError,ConnectionError,RuntimeError) as err:item.update(status='FAIL',reason=type(err).__name__)
        finally:
            if child:child.stop()
        report['cases'].append(item)
    report['status']='PASS' if all(x['status']=='PASS' for x in report['cases']) else 'FAIL';save_report(out/'report.json',report);return report


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--xray',type=Path,required=True);ap.add_argument('--sha256',required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--execute',action='store_true');a=ap.parse_args()
    if not a.execute:ap.error('--execute required')
    try:r=run(a.xray,a.out,a.sha256);print(r['status']);return 0 if r['status']=='PASS' else 1
    except (OSError,ValueError) as e:print('FAIL_PRECONDITION: '+type(e).__name__,file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
