"""Pinned SOCKS/mixed and HTTP protocol edges, not transport lookalikes.
Read-only, no secrets in diagnostics, no DNS resolution or HTTP template execution.
The source permits unsafe fallbacks; AUTHORING_POLICY intentionally rejects them.
"""
from __future__ import annotations
import base64
import binascii
import re

LOCAL = {'socks', 'mixed', 'http'}
IN_FIELDS = {
    'socks': {'auth':'string','users':'array','accounts':'array','udp':'boolean','ip':'string','userLevel':'uint32'},
    'http': {'users':'array','accounts':'array','allowTransparent':'boolean','userLevel':'uint32'},
}
OUT_FIELDS = {k:'string' for k in ('address','email','user','pass')}
OUT_FIELDS.update(port='uint32',level='uint32',servers='array')
ACCOUNT_FIELDS = {'user':'string','pass':'string'}
REMOTE_USER_FIELDS = {**ACCOUNT_FIELDS, 'email':'string','level':'uint32'}
HEADER_NAME = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+\Z")


def accounts(options):
    """An explicitly empty accounts list overrides users; null does not."""
    return options.get('accounts') if options.get('accounts') is not None else options.get('users', [])


def endpoint_target(endpoint):
    options=endpoint.get('settings') or {}
    if not isinstance(options,dict):return None,None
    if options.get('address') is not None:return options.get('address'),options.get('port')
    for k in ('servers','vnext'):
        group=options.get(k)
        if isinstance(group,list) and len(group)==1 and isinstance(group[0],dict):
            return group[0].get('address'),group[0].get('port')
    return None,None


def client_account(options):
    if options.get('address') is not None:
        # Both builders create a protocol.User only when the simplified user is nonempty.
        return options if isinstance(options.get('user'),str) and options['user'] else None
    servers=options.get('servers')
    if isinstance(servers,list) and len(servers)==1 and isinstance(servers[0],dict):
        users=servers[0].get('users')
        if isinstance(users,list) and len(users)==1 and isinstance(users[0],dict):return users[0]
    return None


def compatible(client_protocol, server_protocol):
    return (client_protocol=='http' and server_protocol in LOCAL or
            client_protocol=='socks' and server_protocol in ('socks','mixed'))


def check_endpoint(v, endpoint, path, side):
    protocol=endpoint.get('protocol')
    if protocol not in LOCAL:return
    protocol='socks' if protocol=='mixed' else protocol
    o=endpoint.get('settings',{})
    if not isinstance(o,dict):return
    source='infra/conf/'+protocol+'.go'
    def issue(code,msg,suffix='',severity='ERROR',category='AUTHORING_POLICY',file=source):
        v.issue(code,path+'.settings'+suffix,msg,category,severity,file)
    def obj_types(value, fields, suffix):
        if not isinstance(value,dict):
            issue('PROXY_OBJECT','Требуется объект, не null.',suffix);return False
        v.types(value,fields,path+'.settings'+suffix)
        return True
    def validate_accounts(items, suffix, remote=False):
        if not isinstance(items,list):issue('PROXY_ACCOUNTS_TYPE','Требуется массив записей.',suffix);return
        seen=set()
        for i,item in enumerate(items):
            q=f'{suffix}[{i}]'
            if not obj_types(item,REMOTE_USER_FIELDS if remote else ACCOUNT_FIELDS,q):continue
            for k in ('user','pass'):
                val=item.get(k)
                if not isinstance(val,str) or not val:
                    issue('PROXY_EMPTY_CREDENTIAL','Для password-auth задайте непустые user и pass.',q+'.'+k);continue
                if protocol=='socks' and len(val.encode('utf-8'))>255:
                    issue('SOCKS_CREDENTIAL_BYTES','SOCKS5 длина user/pass должна быть 1..255 UTF-8 bytes.',q+'.'+k,file='proxy/socks/protocol.go')
                if protocol=='http' and k=='user' and ':' in val:
                    issue('HTTP_BASIC_USERNAME','Двоеточие в Basic username меняет границу user/pass.',q+'.user',file='proxy/http/server.go')
            name=item.get('user')
            if isinstance(name,str):
                if name in seen:issue('PROXY_DUPLICATE_USER','Повтор username: Build сохраняет последний password в map.',q,severity='WARNING',category='SOURCE_BUILD')
                seen.add(name)
    if side=='inbounds':
        v.types(o,IN_FIELDS[protocol],path+'.settings')
        us=accounts(o)
        if 'accounts' in o and o['accounts'] is not None and 'users' in o:
            issue('PROXY_ACCOUNTS_SHADOW','accounts целиком заменяет users, включая пустой массив.','.accounts',severity='WARNING',category='SOURCE_BUILD')
        if us is None:us=[]
        validate_accounts(us,'.accounts' if o.get('accounts') is not None else '.users')
        if protocol=='socks':
            auth=o.get('auth','')
            if isinstance(auth,str) and auth not in ('','noauth','password'):
                issue('SOCKS_AUTH_FALLBACK','Неизвестный или неверно регистрированный auth выбирает NO_AUTH в ядре. Исправьте значение.','.auth',file='infra/conf/socks.go')
            if auth=='password' and not us:
                issue('SOCKS_EMPTY_AUTH_HTTP_OPEN','password без действующих accounts закрывает SOCKS-auth, но HTTP-ветка того же listener остаётся без авторизации. Задайте хотя бы одну учётную запись.','.accounts',file='proxy/socks/server.go')
            elif auth!='password' and us:
                issue('SOCKS_ACCOUNTS_INACTIVE','Наличие users/accounts не включает пароль: без auth=password обе ветки обходятся без этих credentials.','.auth',file='proxy/socks/server.go')
            elif auth!='password':
                issue('PROXY_NO_AUTH','SOCKS и HTTP-ветка listener не требуют авторизации; используйте loopback/явные ACL.',severity='WARNING',file='proxy/socks/server.go')
            if o.get('udp') is True:
                issue('SOCKS_UDP_EPHEMERAL','UDP ASSOCIATE открывает отдельный динамический UDP-port; TCP control должен оставаться открытым. Один фиксированный UDP firewall-port недостаточен.','.udp',severity='WARNING',category='SOURCE_RUNTIME',file='proxy/socks/protocol.go')
                address=o.get('ip')
                if isinstance(address,str) and not address.startswith('env:'):
                    import ipaddress
                    try:ipaddress.ip_address(address)
                    except ValueError:issue('SOCKS_UDP_IP','ip используется для локального UDP bind; задавайте локальный IP literal, а не домен.','.ip',file='proxy/socks/protocol.go')
        elif not us:
            issue('PROXY_NO_AUTH','Пустая HTTP accounts map отключает Basic authentication; это не deny-all.',severity='WARNING',category='SOURCE_RUNTIME',file='proxy/http/server.go')
        return
    if side!='outbounds':return
    fields={**OUT_FIELDS}
    if protocol=='http':fields['headers']='map[string]string'
    v.types(o,fields,path+'.settings')
    if o.get('address') is not None:
        if o.get('servers') is not None:issue('PROXY_SIMPLIFIED_SHADOW','Simplified address заменяет servers целиком.',severity='WARNING',category='SOURCE_BUILD')
        servers=[o]
        if o.get('pass') and not o.get('user'):
            issue('PROXY_PASSWORD_IGNORED','Simplified pass без user не создаёт credentials; аутентификация не включена.','.pass')
        acc=client_account(o)
        if acc is not None:
            validate_accounts([{k:acc[k] for k in REMOTE_USER_FIELDS if k in acc}],'.<account>',True)
    else:
        servers=o.get('servers')
        if not isinstance(servers,list) or len(servers)!=1:
            issue('PROXY_ONE_SERVER','Требуется ровно один server либо simplified address/port.','.servers',category='SOURCE_BUILD');return
        for i,s in enumerate(servers):
            if not obj_types(s,{'address':'string','port':'uint32','users':'array'},f'.servers[{i}]'):continue
            us=s.get('users') or []
            if not isinstance(us,list) or len(us)>1:
                issue('PROXY_MAX_ONE_USER','Remote users принимает не более одного пользователя.','.servers.users',category='SOURCE_BUILD')
            else:validate_accounts(us,'.servers.users',True)
    for s in servers:
        if not isinstance(s,dict):continue
        if not isinstance(s.get('address'),str) or not s['address']:
            issue('PROXY_ENDPOINT_ADDRESS','Нужен непустой address.','.address')
        if type(s.get('port')) is not int or not 1<=s['port']<=65535:
            issue('PROXY_ENDPOINT_PORT','Нужен явный port 1..65535.','.port')
    if protocol=='http':
        headers=o.get('headers')
        if isinstance(headers,dict):
            seen=set()
            for k,val in headers.items():
                if not HEADER_NAME.fullmatch(k) or not isinstance(val,str) or any(ch in val for ch in ('\r','\n','\x00')):
                    issue('HTTP_HEADER_INVALID','Некорректное имя/значение HTTP header; данные скрыты.','.headers.<entry>')
                if k.lower() in seen:issue('HTTP_HEADER_DUPLICATE','Имена headers совпадают без учёта регистра; Go map iteration не задаёт приоритет.','.headers.<entry>')
                seen.add(k.lower())
                if k.lower()=='proxy-authorization':issue('HTTP_AUTH_HEADER_OVERRIDE','Этот header перекрывает Basic authorization из user/pass.', '.headers.<entry>',severity='WARNING',category='SOURCE_RUNTIME',file='proxy/http/client.go')
                if isinstance(val,str) and '{{' in val:issue('HTTP_HEADER_TEMPLATE','Go text/template подставляет Source/Target во время запроса; checker не исполняет шаблон.','.headers.<entry>',severity='WARNING',category='COVERAGE',file='proxy/http/client.go')
        issue('HTTP_OUTBOUND_TCP_ONLY','HTTP outbound не передаёт UDP: его нужно направить в другой outbound или явно блокировать.',severity='WARNING',category='SOURCE_RUNTIME',file='proxy/http/client.go')


def check_pair(v,client,server):
    cp=client.get('protocol');sp=server.get('protocol')
    if not compatible(cp,sp):return
    co=client.get('settings') or {};so=server.get('settings') or {}
    if not isinstance(co,dict) or not isinstance(so,dict):raise ValueError('bad options')
    us=accounts(so) or []
    if not isinstance(us,list):raise ValueError('bad accounts')
    # Last duplicate name wins, just like the two builders.
    table={u['user']:u.get('pass','') for u in us if isinstance(u,dict) and isinstance(u.get('user'),str)}
    needed=bool(table) if sp=='http' else so.get('auth')=='password'
    if cp=='http' and sp in ('socks','mixed'):
        needed=so.get('auth')=='password' and bool(table)
    if not needed:
        v.issue('PEER_PROXY_NO_AUTH','$','Серверная ветка не проверяет credentials; это не доказательство совпадения пароля.','SOURCE_RUNTIME','WARNING','proxy/http/server.go' if cp=='http' else 'proxy/socks/protocol.go')
        return
    acc=client_account(co)
    provided=(acc.get('user'),acc.get('pass','')) if acc else None
    if cp=='http':
        headers=co.get('headers') or {}
        if not isinstance(headers,dict):raise ValueError('bad headers')
        auth=[val for key,val in headers.items() if key.lower()=='proxy-authorization']
        if len(auth)>1:
            v.issue('PEER_PROXY_AUTH_UNVERIFIED','$','Несколько вариантов Proxy-Authorization: приоритет не определён.','COVERAGE','WARNING','proxy/http/client.go');return
        if auth:
            value=auth[0]
            if not isinstance(value,str):raise ValueError('bad auth')
            if '{{' in value:
                v.issue('PEER_PROXY_AUTH_UNVERIFIED','$','Proxy-Authorization вычисляется шаблоном в контексте запроса.','COVERAGE','WARNING','proxy/http/client.go');return
            try:
                scheme,encoded=value.split(' ',1)
                if scheme.lower()!='basic':raise ValueError()
                plain=base64.b64decode(encoded,validate=True).decode('utf-8');user,password=plain.split(':',1)
                provided=(user,password)
            except (ValueError,UnicodeError,binascii.Error):provided=None
    if provided is None or provided[0] not in table or table[provided[0]]!=provided[1]:
        v.issue('PEER_AUTH','$','Действующие proxy credentials не соответствуют серверной accounts map; значения скрыты.','SOURCE_RUNTIME',file='proxy/'+('http' if cp=='http' else 'socks')+'/server.go')
