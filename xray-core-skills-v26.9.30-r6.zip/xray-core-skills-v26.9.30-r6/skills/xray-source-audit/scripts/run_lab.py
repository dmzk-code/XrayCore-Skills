#!/usr/bin/env python3
"""Bounded loopback tests of a locally trusted Xray binary and generated lab.
Explicit opt-in required for process execution. This is NOT a sandbox for untrusted binaries.
No shell, firewall changes, package installation, pkill, or production configuration writes.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
import os
import platform
import re
import secrets
import shutil
import socket
import socketserver
import struct
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any
from build_lab import SCENARIOS
from lint_config import SHA,loads

MAX_LOG=2*1024*1024


def save_report(path: Path,report: dict) -> None:
    # Caller supplies a new report path; never clobber an existing file/symlink.
    with path.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
    path.chmod(0o600)


def read_exact(conn: socket.socket,n: int) -> bytes:
    b=bytearray()
    while len(b)<n:
        chunk=conn.recv(n-len(b))
        if not chunk:raise ConnectionError('unexpected EOF')
        b.extend(chunk)
    return bytes(b)


def socks_address(conn: socket.socket,atyp: int) -> tuple[str,int]:
    if atyp==1:address=socket.inet_ntop(socket.AF_INET,read_exact(conn,4))
    elif atyp==4:address=socket.inet_ntop(socket.AF_INET6,read_exact(conn,16))
    elif atyp==3:address=read_exact(conn,read_exact(conn,1)[0]).decode('ascii')
    else:raise ConnectionError('invalid SOCKS address type')
    return address,struct.unpack('!H',read_exact(conn,2))[0]


def socks_connect(port: int,target: int,command: int=1,timeout: float=4,target_host: str='127.0.0.1') -> tuple[socket.socket,tuple[str,int]]:
    c=socket.create_connection(('127.0.0.1',port),timeout=timeout)
    try:
        c.settimeout(timeout);c.sendall(b'\x05\x01\x00')
        if read_exact(c,2)!=b'\x05\x00':raise ConnectionError('SOCKS greeting rejected')
        c.sendall(b'\x05'+bytes([command])+b'\x00\x01'+socket.inet_aton(target_host)+struct.pack('!H',target))
        header=read_exact(c,4)
        if header[0]!=5 or header[1]!=0 or header[2]!=0:raise ConnectionError('SOCKS request rejected')
        bound=socks_address(c,header[3])
        return c,bound
    except BaseException:c.close();raise


def tcp_probe(socks_port: int,target: int,payload_bytes: int=16384,timeout: float=4,target_host: str='127.0.0.1') -> None:
    c,_=socks_connect(socks_port,target,timeout=timeout,target_host=target_host)
    with c:
        payload=secrets.token_bytes(payload_bytes);c.sendall(payload)
        if read_exact(c,len(payload))!=payload:raise ConnectionError('TCP payload mismatch')


def udp_probe(socks_port: int,target: int,timeout: float=4,target_host: str='127.0.0.1') -> None:
    c,bound=socks_connect(socks_port,0,command=3,timeout=timeout)
    with c, socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as u:
        u.settimeout(timeout);u.bind(('127.0.0.1',0))
        host,port=bound
        if host in ('0.0.0.0','::'):host='127.0.0.1'
        if host!='127.0.0.1' or not 0<port<=65535:raise ConnectionError('non-loopback SOCKS UDP relay')
        payload=secrets.token_bytes(512)
        packet=b'\x00\x00\x00\x01'+socket.inet_aton(target_host)+struct.pack('!H',target)+payload
        u.sendto(packet,(host,port));reply,source=u.recvfrom(65535)
        if source[0]!='127.0.0.1' or len(reply)<4 or reply[:3]!=b'\x00\x00\x00':raise ConnectionError('invalid SOCKS UDP reply')
        typ=reply[3]
        off=10 if typ==1 else (22 if typ==4 else (7+reply[4] if typ==3 and len(reply)>4 else 0))
        if not off or reply[off:]!=payload:raise ConnectionError('UDP payload mismatch')


class TCPHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        self.request.settimeout(5)
        total=0
        try:
            while total<2*1024*1024:
                b=self.request.recv(65536)
                if not b:return
                self.request.sendall(b);total+=len(b)
        except OSError:return


class TCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address=False
    daemon_threads=True


class UDPHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        data,s=self.request
        if self.client_address[0]=='127.0.0.1' and len(data)<=4096:s.sendto(data,self.client_address)


@contextlib.contextmanager
def echo_servers():
    tcp=TCPServer(('127.0.0.1',0),TCPHandler);udp=socketserver.UDPServer(('127.0.0.1',0),UDPHandler)
    threads=[]
    try:
        for srv in (tcp,udp):
            t=threading.Thread(target=srv.serve_forever,kwargs={'poll_interval':0.1},daemon=True);t.start();threads.append(t)
        yield tcp.server_address[1],udp.server_address[1]
    finally:
        for srv in (tcp,udp):srv.shutdown();srv.server_close()
        for t in threads:t.join(1)


class Child:
    """Tracks ONLY this directly created child and caps retained logs; drains remainder."""
    def __init__(self,args: list[str],cwd: Path,log: Path):
        self.log=log.open('xb');log.chmod(0o600)
        try:self.process=subprocess.Popen(args,cwd=cwd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=clean_env())
        except BaseException:self.log.close();raise
        self.truncated=False
        self.thread=threading.Thread(target=self._drain,daemon=True);self.thread.start()
    def _drain(self):
        saved=0
        try:
            while True:
                data=self.process.stdout.read(8192)
                if not data:break
                chunk=data[:max(0,MAX_LOG-saved)];self.log.write(chunk);saved+=len(chunk)
                if len(chunk)<len(data):self.truncated=True
        finally:
            self.log.close();self.process.stdout.close()
    def stop(self) -> None:
        if self.process.poll() is None:
            self.process.terminate()
            try:self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=3)
        self.thread.join(timeout=3)


def clean_env() -> dict[str,str]:
    # Xray accepts dotted names before their UPPER_UNDERSCORE aliases. Both
    # forms must be removed, otherwise inherited confdir changes generated labs.
    return {k:v for k,v in os.environ.items()
            if not k.strip().upper().replace('.', '_').startswith(('XRAY_','V2RAY_','HYSTERIA_'))
            and k.lower() not in ('http_proxy','https_proxy','all_proxy','no_proxy')}


def capture(args: list[str],cwd: Path,log: Path,timeout: float=20) -> dict:
    child=Child(args,cwd,log)
    try:
        try:code=child.process.wait(timeout=timeout);status='PASS' if code==0 else 'FAIL'
        except subprocess.TimeoutExpired:code=None;status='FAIL_TIMEOUT'
    finally:child.stop()
    return {'status':status,'exit_code':code,'log_file':log.name,'log_truncated':child.truncated}


def wait_tcp_probe(port: int,target: int,children: list[Child],seconds: float=15,target_host: str='127.0.0.1') -> None:
    deadline=time.monotonic()+seconds
    while time.monotonic()<deadline:
        if any(c.process.poll() is not None for c in children):raise RuntimeError('child exited')
        try:tcp_probe(port,target,1024,timeout=min(2,max(0.2,deadline-time.monotonic())),target_host=target_host);return
        except (OSError,ConnectionError):time.sleep(0.15)
    raise TimeoutError('positive payload test failed')


def check_free(ports: list[int]) -> None:
    for p in ports:
        for typ in (socket.SOCK_STREAM,socket.SOCK_DGRAM):
            with socket.socket(socket.AF_INET,typ) as s:
                if typ==socket.SOCK_STREAM:s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
                s.bind(('127.0.0.1',p))


def validate_manifest(root: Path) -> dict:
    if any(p.is_symlink() for p in (root,*root.parents)):raise ValueError('symlink lab root/parent')
    if (root/'lab-manifest.json').is_symlink() or (root/'lab-manifest.json').stat().st_size>4*1024*1024:raise ValueError('unsafe lab manifest')
    manifest=loads((root/'lab-manifest.json').read_text(encoding='utf-8'))
    if manifest.get('builder')!='xray-skills-r2' or manifest.get('core_commit')!=SHA or manifest.get('root')!=str(root.resolve()):raise ValueError('invalid lab provenance or moved laboratory')
    scenarios=manifest.get('scenarios')
    if not isinstance(scenarios,list) or not scenarios or len(scenarios)>len(SCENARIOS):raise ValueError('invalid scenarios')
    seen=set()
    for entry in scenarios:
        name=entry['name']
        if name not in SCENARIOS or name in seen:raise ValueError('unknown/duplicate scenario')
        seen.add(name);d=root/name
        if d.is_symlink():raise ValueError('symlink scenario')
        for fname,expected in entry['files_sha256'].items():
            path=d/fname
            if Path(fname).name!=fname or path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):raise ValueError('unsafe file path')
            if not path.is_file() or path.stat().st_size>16*1024*1024 or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise ValueError('lab fixture changed; regenerate it')
        t=loads((d/'topology.json').read_text())
        if t!=entry['topology'] or t.get('listeners_bind')!='127.0.0.1':raise ValueError('topology mismatch')
        if t.get('probe_destination','127.0.0.1') not in ('127.0.0.1','198.18.0.1'):raise ValueError('unsafe inner probe destination')
        for key in ('client_socks','server_port','up_port','down_port','target_port','relay_port'):
            if type(t.get(key)) is not int or not 1024<=t[key]<=65535:raise ValueError('invalid lab port')
        for fname in ('server.json','client.json','negative-auth.json'):
            cfg=loads((d/fname).read_text())
            if any(i.get('listen')!='127.0.0.1' for i in cfg.get('inbounds',[])):raise ValueError('non-loopback listener')
        from lab_fixture_guard import verify_fixture
        verify_fixture(d,name,t,entry['files_sha256'])
    return manifest


def run_scenario(binary: str,root: Path,entry: dict,logs: Path,nginx: str|None,openssl: str|None,requests: int=0) -> dict:
    name=entry['name'];d=root/name;t=entry['topology'];logs=logs/name;logs.mkdir(mode=0o700)
    checks={k:{'status':'NOT_RUN'} for k in ('config','tcp','udp','negative_auth','positive_control','restart','bounded_load')}
    result={'name':name,'status':'NOT_RUN','checks':checks}
    if t['requires_nginx'] and not nginx:result['reason']='nginx executable not provided';return result
    if t['requires_tls_target'] and not openssl:result['reason']='OpenSSL unavailable';return result
    children=[];server=None;client=None
    try:
        check_free([t[k] for k in ('client_socks','server_port','up_port','down_port','target_port','relay_port')])
        configfiles=['server.json','client.json','negative-auth.json']+(['relay.json'] if name=='chain-raw-tls' else [])
        checks['config']={'status':'PASS','files':[]}
        for filename in configfiles:
            r=capture([binary,'run','-test','-config',str(d/filename)],d,logs/(filename+'.test.log'))
            checks['config']['files'].append({'file':filename,**r})
            if r['status']!='PASS':checks['config']['status']='FAIL'
        if checks['config']['status']!='PASS':result['status']='FAIL';return result
        def start(label: str,argv: list[str]) -> Child:
            c=Child(argv,d,logs/(label+'.log'));children.append(c);return c
        def xray(label: str,file: str) -> Child:return start(label,[binary,'run','-config',str(d/file)])
        if t['requires_tls_target']:
            start('tls-target',[openssl,'s_server','-accept',f'127.0.0.1:{t["target_port"]}','-cert',str(d/'lab-cert.pem'),'-key',str(d/'lab-key.pem'),'-tls1_3','-alpn','h2','-www','-quiet'])
        if name=='chain-raw-tls':xray('relay','relay.json')
        server=xray('server','server.json')
        if t['requires_nginx']:
            n=capture([nginx,'-t','-p',str(d)+'/', '-c',str(d/'nginx.conf')],d,logs/'nginx-test.log')
            checks['frontend_syntax']=n
            if n['status']!='PASS':result['status']='FAIL';return result
            start('nginx',[nginx,'-p',str(d)+'/', '-c',str(d/'nginx.conf'),'-g','daemon off; master_process off;'])
        client=xray('client','client.json')
        with echo_servers() as (tcpport,udpport):
            target_host=t.get('probe_destination','127.0.0.1')
            checks['tcp']={'status':'RUNNING'}
            wait_tcp_probe(t['client_socks'],tcpport,children,target_host=target_host)
            tcp_probe(t['client_socks'],tcpport,target_host=target_host);checks['tcp']={'status':'PASS','payload_bytes':16384}
            try:udp_probe(t['client_socks'],udpport,target_host=target_host);checks['udp']={'status':'PASS','payload_bytes':512}
            except (OSError,ConnectionError):checks['udp']={'status':'FAIL','reason':'UDP round-trip failed'}
            # Negative auth after positive control and before another positive control.
            client.stop();children.remove(client)
            checks['negative_auth']={'status':'RUNNING'}
            negative=xray('negative-client','negative-auth.json')
            deadline=time.monotonic()+5
            while time.monotonic()<deadline:
                if negative.process.poll() is not None:raise RuntimeError('negative client failed to start')
                try:
                    with socket.create_connection(('127.0.0.1',t['client_socks']),timeout=.2):break
                except OSError:time.sleep(.1)
            accepted=False
            try:tcp_probe(t['client_socks'],tcpport,512,timeout=4,target_host=target_host);accepted=True
            except (OSError,ConnectionError):pass
            if negative.process.poll() is not None:checks['negative_auth']={'status':'FAIL','reason':'negative client exited; not an authentication proof'}
            else:checks['negative_auth']={'status':'FAIL' if accepted else 'PASS','meaning':'invalid credential failed to transmit TCP payload; positive control follows'}
            negative.stop();children.remove(negative)
            checks['positive_control']={'status':'RUNNING'}
            client=xray('client-positive-control','client.json');wait_tcp_probe(t['client_socks'],tcpport,children,target_host=target_host)
            checks['positive_control']={'status':'PASS'}
            # Restart only the lab server created above; do not locate/kill by process name.
            checks['restart']={'status':'RUNNING','budget_seconds':45}
            server.stop();children.remove(server);server=xray('server-restart','server.json')
            restart_start=time.monotonic()
            wait_tcp_probe(t['client_socks'],tcpport,children,seconds=45,target_host=target_host)
            checks['restart']={'status':'PASS','elapsed_seconds':round(time.monotonic()-restart_start,3),'budget_seconds':45,'meaning':'new TCP connection after server restart; not existing-session survival'}
            if requests:
                started=time.monotonic();failed=0
                def job(_):
                    try:tcp_probe(t['client_socks'],tcpport,4096,timeout=5,target_host=target_host);return True
                    except (OSError,ConnectionError):return False
                with ThreadPoolExecutor(max_workers=4) as pool:failed=sum(not x for x in pool.map(job,range(requests)))
                checks['bounded_load']={'status':'FAIL' if failed else 'PASS','requests':requests,'workers':4,'payload_bytes_each':4096,'failures':failed,'elapsed_seconds':round(time.monotonic()-started,3),'scope':'short loopback stress; NOT capacity benchmark'}
        result['status']='FAIL' if any(c['status'].startswith('FAIL') for c in checks.values()) else 'PASS'
    except (OSError,ValueError,RuntimeError,TimeoutError,ConnectionError,subprocess.TimeoutExpired) as e:
        result['status']='FAIL';result['reason']=type(e).__name__+'; inspect private logs'
        for check in checks.values():
            if check['status']=='RUNNING':check.update(status='FAIL',reason=type(e).__name__)
    finally:
        for child in reversed(children):child.stop()
    return result


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('lab',type=Path);ap.add_argument('--xray',type=Path)
    ap.add_argument('--sha256',help='Trusted SHA256 required before any binary execution')
    ap.add_argument('--nginx',type=Path);ap.add_argument('--openssl',type=Path)
    ap.add_argument('--allow-lab-execution',action='store_true');ap.add_argument('--report',type=Path,required=True)
    ap.add_argument('--scenario',action='append',choices=list(SCENARIOS));ap.add_argument('--load-requests',type=int,default=0)
    a=ap.parse_args()
    a.lab=a.lab.absolute()
    if not 0<=a.load_requests<=100:ap.error('--load-requests must be 0..100')
    report={'schema_version':1,'scope':'actual local execution only','expected_core_commit':SHA,'platform':platform.platform(),'python':platform.python_version(),'binary':None,'status':'NOT_RUN','scenarios':[]}
    code=3
    try:
        manifest=validate_manifest(a.lab)
        selected=[x for x in manifest['scenarios'] if not a.scenario or x['name'] in a.scenario]
        if not selected or (a.scenario and set(a.scenario)-{x['name'] for x in selected}):raise ValueError('selected scenario missing in lab')
        if not a.allow_lab_execution:report['reason']='execution not explicitly enabled'
        elif not a.xray or not a.xray.is_file():report['reason']='Xray binary unavailable'
        else:
            from lab_trust import verify_binary
            binary=a.xray.resolve();digest=verify_binary(binary,a.sha256)
            # Binary is user-trusted, but cap output via Child as for every spawned process.
            logroot=a.lab/('run-logs-'+secrets.token_hex(6));logroot.mkdir(mode=0o700)
            ver=capture([str(binary),'version'],a.lab,logroot/'version.log',timeout=8)
            text=(logroot/'version.log').read_text(errors='replace')[:1024]
            report['binary']={'sha256':digest,'hash_matched_expected':bool(a.sha256),'version_output':text[:256],'log_folder':str(logroot)}
            if ver['status']!='PASS' or not re.search(r'\b26\.9\.30\b',text):raise ValueError('binary version mismatch')
            nginx=str(a.nginx.resolve()) if a.nginx else None
            openssl=str(a.openssl.resolve()) if a.openssl else shutil.which('openssl')
            report['scenarios']=[run_scenario(str(binary),a.lab,x,logroot,nginx,openssl,a.load_requests) for x in selected]
            statuses=[x['status'] for x in report['scenarios']]
            report['status']='FAIL' if 'FAIL' in statuses else ('PARTIAL' if 'NOT_RUN' in statuses else 'PASS')
            code=1 if report['status']=='FAIL' else (3 if report['status']=='PARTIAL' else 0)
    except (OSError,ValueError,KeyError,TypeError,subprocess.TimeoutExpired) as e:
        report['status']='FAIL_PRECONDITION';report['reason']=type(e).__name__+'; check manifest, paths, binary version and hash';code=2
    try:save_report(a.report,report)
    except OSError:
        print('Cannot create a NEW report file; existing files are never overwritten.',file=sys.stderr);return 2
    print(report['status']+' — '+str(a.report));return code
if __name__=='__main__':raise SystemExit(main())
