"""Bounded local listener/explicit direct-edge checks for the pinned core.
No DNS, socket creation, subprocess, file I/O or inference of undeclared NAT.
SO_REUSEPORT means overlap does NOT necessarily cause a bind failure.
"""
from __future__ import annotations
import ipaddress
from urllib.parse import urlsplit
from schema_checks import port_ranges
from proxy_edge_checks import endpoint_target


def runtime_finalmask(stream):
    fm=stream.get('finalmask') if isinstance(stream,dict) else None
    return isinstance(fm,dict) and any(isinstance(fm.get(k),list) and bool(fm[k]) for k in ('tcp','udp'))


def transport(stream):
    from validate import network
    return network(stream)


def physical_networks(stream,server=False):
    from http_peer_checks import masque_client_version,masque_server_versions
    from peer_checks import http_version
    n=transport(stream)
    if n in ('raw','grpc','websocket','httpupgrade'):return {'tcp'}
    if n in ('mkcp','hysteria'):return {'udp'}
    if n=='xhttp':return {'udp' if http_version(stream)=='h3' else 'tcp'}
    if n=='masque':
        versions=masque_server_versions(stream) if server else {masque_client_version(stream)}
        return {'tcp' if x=='h2' else 'udp' for x in versions}
    return set()


def carrier_changes_socket(stream):
    fm=stream.get('finalmask') or {}
    if not isinstance(fm,dict):return False
    masks=fm.get('udp') or []
    return isinstance(masks,list) and 'udp' in physical_networks(stream,True) and any(isinstance(m,dict) and m.get('type') in ('realm','xicmp','xdns','udphop') for m in masks)


def _ip(value):
    if not isinstance(value,str):return None
    try:return ipaddress.ip_address(value.split('%',1)[0])
    except ValueError:return None


def _overlap(a,b):
    if a==b:return True
    ia,ib=_ip(a),_ip(b)
    if a=='localhost':return ib is not None and ib.is_loopback
    if b=='localhost':return ia is not None and ia.is_loopback
    return ia is not None and ib is not None and ia.version==ib.version and (ia==ib or ia.is_unspecified or ib.is_unspecified)


def listener_footprints(config):
    """Return concrete, locally declared bind ranges. No ephemeral UDP prediction."""
    result=[]
    for i,e in enumerate(config.get('inbounds') or []):
        if not isinstance(e,dict):continue
        if e.get('protocol') not in ('vless','vmess','trojan','http','socks','mixed','hysteria','masque'):continue
        s=e.get('streamSettings') or {}
        if not isinstance(s,dict) or carrier_changes_socket(s):continue
        networks=physical_networks(s,True)
        if not networks:continue
        address=e.get('listen') or '0.0.0.0'
        if not isinstance(address,str) or address.startswith('env:'):continue
        path=f'$.inbounds[{i}]'
        if address.startswith(('/', '@')):
            result.append({'path':path,'address':address.split(',',1)[0], 'ranges':[], 'network':'unix','transport':transport(s)})
            continue
        try:ranges=port_ranges(e.get('port'))
        except (TypeError,ValueError):continue
        if not ranges:continue
        for net in networks:result.append({'path':path,'address':address,'ranges':ranges,'network':net,'transport':transport(s)})
    for name in ('api','metrics'):
        block=config.get(name)
        if not isinstance(block,dict) or not isinstance(block.get('listen'),str) or not block['listen']:continue
        addr=block['listen']
        if name=='api' and addr.startswith(('/', '@')):
            result.append({'path':'$.api','address':addr.split(',',1)[0],'ranges':[], 'network':'unix','transport':'control'})
            continue
        try:
            u=urlsplit('//'+addr);port=u.port
            host=u.hostname or ('0.0.0.0' if u.netloc.startswith(':') else None)
            if host and port and 1<=port<=65535:result.append({'path':'$.'+name,'address':host,'ranges':[(port,port)],'network':'tcp','transport':'control'})
        except ValueError:continue
    return result


def check_config(v,config):
    if not isinstance(config,dict):return
    def emit(code,path,msg,severity='ERROR',source='transport/internet/system_listener.go'):
        v.issue(code,path,msg,'AUTHORING_POLICY',severity,source)
    footprints=listener_footprints(config)
    if len(footprints)>1024:
        emit('BIND_INVENTORY_LIMIT','$','Более1024 bind-объектов; попарная проверка сознательно не выполнялась.','WARNING');return
    for i,a in enumerate(footprints):
        for b in footprints[i+1:]:
            if a['path']==b['path'] or a['network']!=b['network'] or not _overlap(a['address'],b['address']):continue
            overlap=a['network']=='unix' or any(max(x,u)<=min(y,w) for x,y in a['ranges'] for u,w in b['ranges'])
            if overlap:
                xhttp=a['transport']=='xhttp' or b['transport']=='xhttp'
                emit('XHTTP_LISTENER_OVERLAP' if xhttp else 'LISTENER_OVERLAP',b['path'],
                     'Пересечение с '+a['path']+'. SO_REUSEPORT может разрешить запуск, но распределять соединения между разными handlers/session maps; это не HTTP-aware frontend.',
                     'ERROR' if xhttp else 'WARNING')
    # All endpoints, including the anonymous default outbound, must resolve dialerProxy.
    outs=[e for e in config.get('outbounds') or [] if isinstance(e,dict)]
    tags={e.get('tag') for e in outs if isinstance(e.get('tag'),str) and e.get('tag')}
    owners={}
    api=config.get('api');metrics=config.get('metrics')
    if isinstance(api,dict) and api.get('tag') and not api.get('listen'):owners.setdefault(api['tag'],[]).append('api')
    if isinstance(metrics,dict) and (metrics.get('tag') or metrics.get('listen')):owners.setdefault(metrics.get('tag') or 'Metrics',[]).append('metrics')
    for i,e in enumerate(config.get('inbounds') or []):
        if not isinstance(e,dict) or e.get('protocol')!='vless':continue
        o=e.get('settings') or {}
        if not isinstance(o,dict):continue
        us=o.get('clients') if o.get('clients') is not None else o.get('users',[])
        for u in us if isinstance(us,list) else []:
            if not isinstance(u,dict) or not isinstance(u.get('reverse'),dict):continue
            tag=u['reverse'].get('tag')
            if isinstance(tag,str) and tag:owners.setdefault(tag,[]).append('vless-reverse')
    for tag,names in owners.items():
        if len(set(names))>1:emit('VIRTUAL_OWNER_COLLISION','$','Несколько разных служебных механизмов назначают один outbound tag; значение скрыто.',source='app/commander/commander.go')
        if 'vless-reverse' in names and tag in tags:emit('REVERSE_OUTBOUND_COLLISION','$','Reverse и обычный outbound используют один tag; не подменяйте служебный handler вручную.',source='proxy/vless/inbound/inbound.go')
    def streams(s,depth=0):
        if not isinstance(s,dict) or depth>24:return
        yield s
        from validate import settings
        down=settings(s).get('downloadSettings')
        if isinstance(down,dict):yield from streams(down,depth+1)
    for i,e in enumerate(outs):
        if e.get('tag'):continue # named endpoints are checked by the base graph
        for s in streams(e.get('streamSettings',{})):
            so=s.get('sockopt') or {}
            if not isinstance(so,dict):continue
            tag=so.get('dialerProxy')
            if isinstance(tag,str) and tag and tag not in tags and tag not in owners:
                emit('DIALER_TAG',f'$.outbounds[{i}]','Анонимный outbound ссылается на отсутствующий dialerProxy; отсутствие tag не отменяет проверку.',source='transport/internet/dialer.go')


def check_direct_pair(v,client,server):
    """Only call when the user explicitly declares no frontend/NAT/rewriting."""
    cs=client.get('streamSettings') or {};ss=server.get('streamSettings') or {}
    if not isinstance(cs,dict) or not isinstance(ss,dict):raise ValueError('stream object')
    def emit(code,msg,warning=False):
        v.issue(code,'$.peer.direct',msg,'COVERAGE' if warning else 'AUTHORING_POLICY','WARNING' if warning else 'ERROR','transport/internet/system_listener.go')
    if transport(cs)=='xdrive' or carrier_changes_socket(cs) or carrier_changes_socket(ss):
        emit('PEER_DIRECT_CARRIER_UNVERIFIED','Storage/carrier меняет физическую связь; direct port/IP-check не доказывает её.',True);return
    so=cs.get('sockopt') or {}
    if isinstance(so,dict) and (so.get('dialerProxy') or str(so.get('addressPortStrategy','')).lower() not in ('','none')):
        emit('PEER_DIRECT_REDIRECT_UNVERIFIED','dialerProxy/SRV/TXT меняет путь; direct-проверка endpoint не охватывает его.',True);return
    sec=lambda s:(s.get('security') or 'none').lower()
    if sec(cs)!=sec(ss):emit('PEER_DIRECT_SECURITY','Для явно прямой пары security различается; TLS termination не был объявлен.')
    from validate import settings
    opts=settings(ss);sock=ss.get('sockopt') or {}
    if opts.get('acceptProxyProtocol') is True or isinstance(sock,dict) and sock.get('acceptProxyProtocol') is True:
        if runtime_finalmask(cs):
            emit('PEER_PROXY_PREAMBLE_UNVERIFIED','Listener требует PROXY preamble; содержимое пользовательской mask/wrapper-последовательности не проверено.',True)
        else:
            emit('PEER_PROXY_PROTOCOL_REQUIRED','Listener требует PROXY preamble; обычный прямой клиент его не добавляет. Нужен согласованный frontend/обёртка.')
    cnet=physical_networks(cs);snet=physical_networks(ss,True)
    if cnet and snet and not cnet.intersection(snet):emit('PEER_DIRECT_NETWORK','Физическая TCP/UDP сеть клиента не принимается выбранным listener.')
    address,port=endpoint_target(client)
    listen=server.get('listen') or '0.0.0.0'
    if not isinstance(address,str) or not address or address.startswith('env:'):
        emit('PEER_DIRECT_ADDRESS_UNVERIFIED','Клиентский адрес отсутствует или зависит от окружения; разрешение имён не выполнялось.',True)
    if isinstance(listen,str) and listen.startswith(('/', '@')):
        emit('PEER_DIRECT_UNIX_UNVERIFIED','Unix endpoint требует отдельного сопоставления пути и ролей, не сравнения TCP port.',True);return
    try:ranges=port_ranges(server.get('port'))
    except (TypeError,ValueError):ranges=None
    if type(port) is not int or not 1<=port<=65535:emit('PEER_DIRECT_PORT','Нужен действующий клиентский port1..65535.')
    elif ranges is None:emit('PEER_DIRECT_PORT_UNVERIFIED','Серверный port не разрешён статически.',True)
    elif not any(a<=port<=b for a,b in ranges):emit('PEER_DIRECT_PORT','Клиентский port не входит в список портов выбранного listener.')
    cip,sip=_ip(address),_ip(listen)
    if cip is None:
        emit('PEER_DIRECT_DNS_UNVERIFIED','DNS-имя не разрешалось: адрес listener должен быть подтверждён отдельно.',True)
    elif sip is not None:
        if cip.version==sip.version:
            if not sip.is_unspecified and cip!=sip:emit('PEER_DIRECT_ADDRESS','Прямая пара указывает на другой конкретный IP, чем выбранный listener.')
        elif sip.version==6 and sip.is_unspecified and not (isinstance(sock,dict) and sock.get('v6only')):
            emit('PEER_DIRECT_DUALSTACK_UNVERIFIED','Приём IPv4 через [::] зависит от ОС и IPV6_V6ONLY; не подтверждён.',True)
        else:emit('PEER_DIRECT_ADDRESS','Семейства IP явно прямой пары несовместимы.')
    elif listen!='localhost' or not cip.is_loopback:
        emit('PEER_DIRECT_ADDRESS_UNVERIFIED','Серверный bind-address не установлен статически.',True)
