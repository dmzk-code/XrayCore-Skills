#!/usr/bin/env python3
"""Explicit, bounded native regression lab for r5. Loopback only, new directory.
Verifies SHA256 before executing a trusted binary; no external services/accounts.
Generated private configs/logs MUST NOT be distributed as production templates.
"""
from __future__ import annotations
import argparse,copy,json,re,time
from pathlib import Path
from build_lab import create_lab,write_json
from lab_trust import verify_binary
from lint_config import SHA
from run_lab import Child,capture,echo_servers,tcp_probe,udp_probe,wait_tcp_probe,save_report
from validate import Validator,check_pair
from compose_config import merge_named


def protocol(c,s,kind,legacy=False):
    ce,se=c['outbounds'][0],s['inbounds'][0];key='id' if kind=='vmess' else 'password'
    old=ce['settings'];credential=old['id'];user={key:credential}
    target={'address':old['address'],'port':old['port'],**user}
    if kind=='vmess':target['security']='auto'
    ce['protocol']=se['protocol']=kind
    if not legacy:ce['settings']=target
    elif kind=='trojan':ce['settings']={'servers':[target]}
    else:ce['settings']={'vnext':[{'address':old['address'],'port':old['port'],'users':[user]}]}
    se['settings']={'users':[user]}


def active_account(c):
    o=c['outbounds'][0]['settings']
    if 'address' in o:return o
    if 'servers' in o:return o['servers'][0]
    return o['vnext'][0]['users'][0]


def mutations(name,c,s,encryption_pairs):
    cs=c['outbounds'][0]['streamSettings'];ss=s['inbounds'][0]['streamSettings']
    x,y=cs.get('xhttpSettings',{}),ss.get('xhttpSettings',{})
    bad=None;code=None
    if name=='xhttp-header-case':
        x.update(sessionIDPlacement='header',sessionIDKey='x-session',seqPlacement='header',seqKey='x-seq')
        y.update(sessionIDPlacement='header',sessionIDKey='X-Session',seqPlacement='header',seqKey='X-Seq')
    elif name=='xhttp-auto-body':y.update(uplinkDataPlacement='body')
    elif name=='xhttp-unused-path-keys':x.update(sessionIDKey='unused-a');y.update(sessionIDKey='unused-b')
    elif name=='xhttp-streamone-inactive':
        x.update(sessionIDPlacement='header',seqPlacement='cookie');y.update(sessionIDPlacement='query',seqPlacement='header')
    elif name=='xhttp-padding-cookie-query':
        x.update(xPaddingObfsMode=True,xPaddingPlacement='cookie');y.update(xPaddingObfsMode=True,xPaddingPlacement='query')
    elif name=='xhttp-default-padding':
        bad=copy.deepcopy(c);bad['outbounds'][0]['streamSettings']['xhttpSettings']['xPaddingBytes']='1-20';code='PEER_PADDING_RANGE'
    elif name=='xhttp-effective-host':
        x['host']='';y['host']=cs['tlsSettings']['serverName']
        bad=copy.deepcopy(c);bad['outbounds'][0]['streamSettings']['xhttpSettings']['host']='different.invalid';code='PEER_HTTP_HOST'
    elif name=='xhttp-host-port-case':
        x['host']='LOCALHOST:443';y['host']='localhost'
    elif name=='masque-default-template':
        cs['masqueSettings'].pop('path',None);ss['masqueSettings']['path']='/.well-known/masque/ip/{target}/{ipproto}/'
    elif name=='masque-query-order':
        cs['masqueSettings']['path']='/r5?b=2&a=1';ss['masqueSettings']['path']='/r5?a=1&b=2'
        bad=copy.deepcopy(c);bad['outbounds'][0]['streamSettings']['masqueSettings']['path']='/r5?a=1&b=9';code='PEER_MASQUE_URI'
    elif name=='masque-dual-listener':
        cs['tlsSettings']['alpn']=['h2','h3'];ss['tlsSettings']['alpn']=['h2','h3']
    elif name.startswith(('vmess','trojan')):
        kind=name.split('-')[0];protocol(c,s,kind,name.endswith('legacy'))
        bad=copy.deepcopy(c);active_account(bad)['id' if kind=='vmess' else 'password']='OTHER-LAB-CREDENTIAL';code='PEER_AUTH'
    elif name.startswith('encryption-'):
        keytype=0 if 'x25519' in name else 1
        secret,public=encryption_pairs[keytype]
        s['inbounds'][0]['settings']['decryption']=secret;c['outbounds'][0]['settings']['encryption']=public
        # Full valid credentials from a separately generated pair; no malformed keys.
        bad=copy.deepcopy(c);bad['outbounds'][0]['settings']['encryption']=encryption_pairs[keytype+2][1]
        code='PEER_VLESS_ENCRYPTION_KEY' if keytype==0 else 'PEER_VLESS_ENCRYPTION_UNVERIFIED'
    return bad,code


def run(binary:Path,out:Path,digest:str):
    observed=verify_binary(binary,digest);binary=binary.resolve();out=out.absolute()
    if out.exists() or out.is_symlink():raise ValueError('NEW directory required')
    out.mkdir(parents=True,mode=0o700)
    version=capture([str(binary),'version'],out,out/'version.log',8)
    if version['status']!='PASS' or not re.search(r'\b26\.9\.30\b',(out/'version.log').read_text()):raise ValueError('wrong binary')
    bases=['raw-none','raw-tls','xhttp-packet-h1','xhttp-one-h2','masque-h2','mkcp-tls']
    create_lab(out/'lab',bases)
    enc=[]
    for n in (0,1):
        rr=capture([str(binary),'vlessenc'],out,out/f'keys-{n}.private.log',10)
        if rr['status']!='PASS':raise ValueError('vlessenc failed')
        text=(out/f'keys-{n}.private.log').read_text()
        ss=re.findall(r'"decryption"\s*:\s*"([^"]+)"',text);cc=re.findall(r'"encryption"\s*:\s*"([^"]+)"',text)
        if len(ss)!=2 or len(cc)!=2:raise ValueError('unexpected vlessenc format')
        enc.extend(zip(ss,cc))
    report={'revision':'r5','core_commit':SHA,'binary_sha256':observed,'scope':'fresh loopback regression checks; no WAN or external provider','wire':[],'composition':[],'native':[],'status':'RUNNING'}
    cases=[('xhttp-header-case','xhttp-packet-h1'),('xhttp-auto-body','xhttp-packet-h1'),('xhttp-unused-path-keys','xhttp-packet-h1'),('xhttp-streamone-inactive','xhttp-one-h2'),('xhttp-padding-cookie-query','xhttp-packet-h1'),('xhttp-default-padding','xhttp-packet-h1'),('xhttp-effective-host','xhttp-one-h2'),('xhttp-host-port-case','xhttp-packet-h1'),('masque-default-template','masque-h2'),('masque-query-order','masque-h2'),('masque-dual-listener','masque-h2')]
    cases +=[(p+'-'+style,'raw-tls') for p in ('vmess','trojan') for style in ('simple','legacy')]
    cases +=[('encryption-'+k+'-'+transport,base) for k in ('x25519','mlkem768') for transport,base in [('raw','raw-none'),('xhttp','xhttp-one-h2'),('mkcp','mkcp-tls')]]
    for name,base in cases:
        d=out/'lab'/base;c=json.loads((d/'client.json').read_text());s=json.loads((d/'server.json').read_text());top=json.loads((d/'topology.json').read_text())
        bad,expected_code=mutations(name,c,s,enc);logdir=out/name;logdir.mkdir(mode=0o700)
        record={'name':name,'base':base,'status':'RUNNING','core_tests':[],'static_good_errors':[]};children=[]
        try:
            errors=[x for obj in (c,s) for x in Validator().config(obj) if x['severity']=='ERROR']
            errors +=[x for x in check_pair(c,s,'lab-proxy','lab-in') if x['severity']=='ERROR']
            record['static_good_errors']=sorted({x['code'] for x in errors})
            if errors:raise ValueError('positive pair rejected by checker')
            for filename,obj in [('server.json',s),('good.json',c)]+([('bad.json',bad)] if bad else []):
                write_json(logdir/filename,obj)
                rr=capture([str(binary),'run','-test','-config',str(logdir/filename)],d,logdir/(filename+'.test.log'),15)
                record['core_tests'].append({'file_role':filename,'exit_code':rr['exit_code'],'status':rr['status']})
                if rr['status']!='PASS':raise ValueError('generated config not accepted')
            def start(label,file=None):
                file=file or label
                child=Child([str(binary),'run','-config',str(logdir/(file+'.json'))],d,logdir/(label+'.runtime.log'));children.append(child);return child
            start('server');good=start('good')
            with echo_servers() as (tp,up):
                target_host=top.get('probe_destination','127.0.0.1')
                wait_tcp_probe(top['client_socks'],tp,children,seconds=12,target_host=target_host)
                tcp_probe(top['client_socks'],tp,32768,target_host=target_host);udp_probe(top['client_socks'],up,target_host=target_host)
                record.update(tcp='PASS',udp='PASS')
                if bad:
                    found={x['code'] for x in check_pair(bad,s,'lab-proxy','lab-in')}
                    record['negative_static_codes']=sorted(found)
                    accepted_codes={expected_code}
                    if expected_code=='PEER_VLESS_ENCRYPTION_KEY':accepted_codes.add('PEER_VLESS_ENCRYPTION_UNVERIFIED')
                    if not accepted_codes.intersection(found):raise ValueError('negative static signal missing')
                    good.stop();children.remove(good);wrong=start('bad');time.sleep(.2)
                    rejected=False
                    try:tcp_probe(top['client_socks'],tp,512,timeout=2,target_host=target_host)
                    except (OSError,ConnectionError):rejected=True
                    rejected=rejected and wrong.process.poll() is None
                    record['negative_auth_or_wire']='PASS' if rejected else 'FAIL'
                    wrong.stop();children.remove(wrong)
                    start('control','good');wait_tcp_probe(top['client_socks'],tp,children,seconds=12,target_host=target_host);tcp_probe(top['client_socks'],tp,2048,target_host=target_host)
                    record['positive_control']='PASS'
                    if not rejected:raise ValueError('negative connected')
            record['status']='PASS'
        except (OSError,ValueError,ConnectionError,KeyError,TypeError) as e:
            record.update(status='FAIL',reason=type(e).__name__+'; inspect private local logs')
        finally:
            for child in reversed(children):child.stop()
        report['wire'].append(record)
    # Native -dump comparison verifies meaningful merged fields, not default/null
    # struct serialization. Do not execute external files or root env values.
    merge_cases=[
      ('prepend',[('a.json',{'outbounds':[{'tag':'a','protocol':'freedom'}]}),('b.json',{'outbounds':[{'tag':'b','protocol':'blackhole'}]})]),
      ('tail-parent',[('a.json',{'outbounds':[{'tag':'a','protocol':'freedom'}]}),('retail/b.json',{'outbounds':[{'tag':'b','protocol':'blackhole'}]})]),
      ('replace-whole',[('a.json',{'outbounds':[{'tag':'a','protocol':'freedom','settings':{'redirect':'127.0.0.1:9'}}]}),('b.json',{'outbounds':[{'tag':'a','protocol':'blackhole'}]})]),
      ('replace-empty-dns',[('a.json',{'dns':{'tag':'old','servers':['1.1.1.1']}}),('b.json',{'dns':{}})]),
      ('null-does-not-clear',[('a.json',{'dns':{'tag':'old'}}),('b.json',{'dns':None})]),
      ('env-map',[('a.json',{'env':{'R5_TEST_ONLY':'A','R5_OTHER':'B'}}),('b.json',{'env':{'R5_TEST_ONLY':'C'}})]),
      ('untagged',[('a.json',{'outbounds':[{'protocol':'freedom'}]}),('b.json',{'outbounds':[{'protocol':'blackhole'}]})]),
      ('deferred-duplicate',[('a.json',{}),('b.json',{'outbounds':[{'tag':'z','protocol':'freedom'},{'tag':'z','protocol':'blackhole'}]})]),
      ('tail-duplicate',[('a.json',{}),('tail.json',{'outbounds':[{'tag':'z','protocol':'freedom'},{'tag':'z','protocol':'blackhole'}]})]),
    ]
    for name,fragments in merge_cases:
        d=out/('merge-'+name);d.mkdir();files=[]
        for filename,obj in fragments:
            path=d/filename;path.parent.mkdir(parents=True,exist_ok=True);write_json(path,obj);files.append(path)
        expected,_=merge_named([(str(path),obj) for path,(_,obj) in zip(files,fragments)])
        argv=[str(binary),'run','-dump']
        for path in files:argv+=['-c',str(path)]
        rr=capture(argv,d,d/'dump.private.log',10);status='FAIL'
        try:
            actual=json.loads((d/'dump.private.log').read_text())
            def project(x):
                return {'outbounds':[{k:e[k] for k in ('tag','protocol','settings') if e.get(k) not in (None,'')} for e in (x.get('outbounds') or [])],
                        'dns_tag':(x.get('dns') or {}).get('tag',''),'dns_servers':(x.get('dns') or {}).get('servers',[]),'env':x.get('env') or {}}
            status='PASS' if rr['status']=='PASS' and project(expected)==project(actual) else 'FAIL'
        except (ValueError,TypeError):pass
        report['composition'].append({'name':name,'status':status,'exit_code':rr['exit_code']})
    native_cases=[('trojan-flow','trojan','flow','xtls-rprx-vision',False),('trojan-empty-password','trojan','password','',False),('vmess-security-fallback','vmess','security','none',True),('vmess-empty-id','vmess','id','',False),('vmess-port-overflow','vmess','port',65536,False),('trojan-level-overflow','trojan','level',256,False)]
    for name,p,k,value,accepted in native_cases:
        d=out/'lab/raw-tls';c=json.loads((d/'client.json').read_text());s=json.loads((d/'server.json').read_text());protocol(c,s,p)
        c['outbounds'][0]['settings'][k]=value;file=out/(name+'.json');write_json(file,c)
        rr=capture([str(binary),'run','-test','-config',str(file)],d,out/(name+'.test.log'),15)
        got='ACCEPT' if rr['exit_code']==0 else 'REJECT' if rr['exit_code']==23 else 'EXECUTION_FAILURE'
        report['native'].append({'name':name,'expected':'ACCEPT' if accepted else 'REJECT','observed':got,'exit_code':rr['exit_code'],'status':'PASS' if got==('ACCEPT' if accepted else 'REJECT') else 'FAIL'})
    parser_cases=[
        ('jsonc-comments','{# test\n"outbounds":[/* test */{"protocol":"freedom","tag":"direct"}]// test\n}',True),
        ('jsonc-trailing-comma','{"outbounds":[{"protocol":"freedom"}],}',False),
        ('jsonc-single-quotes',"{'outbounds':[]}",False),
        ('root-env-after-parse',json.dumps({'env':{'R5_PARSE_PORT_UNSET':'12345'},'inbounds':[{'protocol':'socks','listen':'127.0.0.1','port':'env:R5_PARSE_PORT_UNSET'}]}),False),
    ]
    for name,text,accepted in parser_cases:
        file=out/(name+'.jsonc')
        with file.open('x',encoding='utf-8') as f:f.write(text)
        file.chmod(0o600)
        rr=capture([str(binary),'run','-test','-config',str(file)],out,out/(name+'.test.log'),15)
        got='ACCEPT' if rr['exit_code']==0 else 'REJECT' if rr['exit_code']==23 else 'EXECUTION_FAILURE'
        report['native'].append({'name':name,'expected':'ACCEPT' if accepted else 'REJECT','observed':got,'exit_code':rr['exit_code'],'status':'PASS' if got==('ACCEPT' if accepted else 'REJECT') else 'FAIL'})
    report['status']='PASS' if all(r['status']=='PASS' for key in ('wire','composition','native') for r in report[key]) else 'FAIL'
    save_report(out/'report.json',report)
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--xray',required=True,type=Path);p.add_argument('--sha256',required=True);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
    if not a.execute:p.error('explicit --execute required')
    try:r=run(a.xray,a.out,a.sha256)
    except (OSError,ValueError,KeyError,TypeError):print('FAIL_PRECONDITION; no credentials printed');return 2
    print(r['status']+' — '+str(a.out/'report.json'));return 0 if r['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
