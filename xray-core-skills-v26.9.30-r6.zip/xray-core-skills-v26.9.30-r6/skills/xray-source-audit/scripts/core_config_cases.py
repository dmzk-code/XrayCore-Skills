#!/usr/bin/env python3
"""Fixed positive/negative config-build regressions against a trusted pinned Xray.
No listener launch: version + run -test only. Uses a verified, locally generated lab.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,re,sys
from pathlib import Path
from run_lab import capture,validate_manifest,save_report
from lint_config import SHA,loads

# id, scenario, config filename, mutation path, value, expected build result
CASES=[
('removed-http','raw-tls','client.json',['outbounds',0,'streamSettings','network'],'http','REJECT_CORE'),
('removed-quic','raw-tls','client.json',['outbounds',0,'streamSettings','network'],'quic','REJECT_CORE'),
('tls-allow-insecure','raw-tls','client.json',['outbounds',0,'streamSettings','tlsSettings','allowInsecure'],True,'REJECT_CORE'),
('tls-invalid-pin','raw-tls','client.json',['outbounds',0,'streamSettings','tlsSettings','pinnedPeerCertSha256'],'abc','REJECT_CORE'),
('xhttp-mode','xhttp-packet-h1','client.json',['outbounds',0,'streamSettings','xhttpSettings','mode'],'invalid','REJECT_CORE'),
('xhttp-forbidden-host','xhttp-packet-h1','client.json',['outbounds',0,'streamSettings','xhttpSettings','headers'],{'Host':'localhost'},'REJECT_CORE'),
('xhttp-get-stream','xhttp-stream-h2','client.json',['outbounds',0,'streamSettings','xhttpSettings','uplinkHTTPMethod'],'GET','REJECT_CORE'),
('xhttp-xmux-conflict','xhttp-packet-h1','client.json',['outbounds',0,'streamSettings','xhttpSettings','xmux'],{'maxConcurrency':2,'maxConnections':2},'REJECT_CORE'),
('kcp-invalid-mtu','mkcp-tls','client.json',['outbounds',0,'streamSettings','kcpSettings','mtu'],20,'REJECT_CORE'),
('hysteria-version','hysteria2','client.json',['outbounds',0,'streamSettings','hysteriaSettings','version'],1,'REJECT_CORE'),
('hysteria-protocol-version','hysteria2','client.json',['outbounds',0,'settings','version'],1,'REJECT_CORE'),
('masque-mux','masque-h2','client.json',['outbounds',0,'mux'],{'enabled':True},'REJECT_CORE'),
('masque-remote-dns-domain','masque-h2','client.json',['outbounds',0,'settings','remoteDNS'],['example.invalid'],'REJECT_CORE'),
('masque-double-v4','masque-h2','server.json',['inbounds',0,'settings','address'],['10.1.0.1/24','10.2.0.1/24'],'REJECT_CORE'),
('httpupgrade-host','httpupgrade-tls','client.json',['outbounds',0,'streamSettings','httpupgradeSettings','headers'],{'Host':'localhost'},'REJECT_CORE'),
('unknown-transport','raw-tls','client.json',['outbounds',0,'streamSettings','network'],'nonexistent','REJECT_CORE'),
('unknown-security','raw-tls','client.json',['outbounds',0,'streamSettings','security'],'nonexistent','REJECT_CORE'),
('legacy-proxy-settings','raw-tls','client.json',['outbounds',0,'proxySettings'],{'tag':'dummy'},'REJECT_CORE'),
('legacy-reverse','raw-tls','client.json',['reverse'],{},'REJECT_CORE'),
('unknown-json-key-accepted','raw-tls','client.json',['outbounds',0,'streamSettings','fieldNotPresentInXray'],'must-not-be-certified-functional','ACCEPT_CORE'),
('kcp-seed-accepted-not-effect-proof','mkcp-tls','client.json',['outbounds',0,'streamSettings','kcpSettings','seed'],'unit-lab-only','ACCEPT_CORE'),
('websocket-legacy-host','websocket-tls','client.json',['outbounds',0,'streamSettings','wsSettings','headers'],{'Host':'localhost'},'ACCEPT_CORE'),
('xhttp-extra-shadows-outer-header','xhttp-packet-h1','client.json',['outbounds',0,'streamSettings','xhttpSettings','extra'],{},'ACCEPT_CORE'),
('freedom-ipsblocked-accepted-not-effect-proof','raw-tls','server.json',['outbounds',0,'settings','ipsBlocked'],['127.0.0.1'],'ACCEPT_CORE'),
]

def mutate(o,path,value):
    target=o
    for k in path[:-1]:
        if isinstance(target,dict):target=target.setdefault(k,{})
        else:target=target[k]
    target[path[-1]]=copy.deepcopy(value)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('lab',type=Path);p.add_argument('--xray',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--allow-core-test',action='store_true');a=p.parse_args()
    if not a.allow_core_test:p.error('explicit --allow-core-test required')
    if a.out.exists() or a.out.is_symlink():p.error('--out must not exist')
    report={'status':'NOT_RUN','core_commit':SHA,'scope':'fixed run -test cases; ACCEPT_CORE does not prove field application','cases':[]}
    try:
        lab=a.lab.resolve(strict=True);validate_manifest(lab);binary=a.xray.resolve(strict=True)
        digest=hashlib.sha256(binary.read_bytes()).hexdigest()
        if digest.lower()!=a.sha256.lower():raise ValueError('binary hash mismatch')
        out=a.out.absolute();out.mkdir(parents=True,mode=0o700)
        r=capture([str(binary),'version'],out,out/'version.log',10);version=(out/'version.log').read_text()
        if r['status']!='PASS' or not re.search(r'\b26\.9\.30\b',version):raise ValueError('version mismatch')
        report['binary']={'sha256':digest,'version_output':version[:256]}
        for name,scenario,filename,path,value,expected in CASES:
            obj=loads((lab/scenario/filename).read_text());mutate(obj,path,value)
            if name=='xhttp-extra-shadows-outer-header':obj['outbounds'][0]['streamSettings']['xhttpSettings']['headers']={'Host':'localhost'}
            f=out/(name+'.json');f.write_text(json.dumps(obj));f.chmod(0o600)
            r=capture([str(binary),'run','-test','-config',str(f)],out,out/(name+'.log'),20)
            observed='ACCEPT_CORE' if r['exit_code']==0 else ('REJECT_CORE' if r['exit_code']==23 else 'FAIL_EXECUTION')
            # Xray run -test uses exit23 for config failures; do not accept crash/timeout as expected rejection.
            report['cases'].append({'name':name,'expected':expected,'observed':observed,'status':'PASS' if observed==expected else 'FAIL','exit_code':r['exit_code']})
        report['status']='PASS' if all(r['status']=='PASS' for r in report['cases']) else 'FAIL'
        save_report(out/'report.json',report);print(report['status']+' — '+str(out/'report.json'));return 0 if report['status']=='PASS' else 1
    except (OSError,ValueError,KeyError) as e:
        print('CORE_CASES_ERROR: '+type(e).__name__,file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
