#!/usr/bin/env python3
"""Create a NEW isolated loopback Xray laboratory. Never edits production files.
All secrets/certificates are generated locally. Python>=3.10 + OpenSSL CLI.
Generated pairs are test fixtures, not claims of verified core compatibility.
"""
from __future__ import annotations
import argparse
import base64
import copy
import hashlib
import json
import os
import secrets
import shutil
import socket
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any
from validate import Validator,check_pair
from lint_config import SHA

SCENARIOS = {
 'raw-none':('raw','none','VLESS RAW, только loopback; без защиты'),
 'raw-tls':('raw','tls','VLESS RAW TLS с pin'),
 'raw-vision-tls':('raw','tls','VLESS Vision RAW TLS1.3'),
 'raw-reality':('raw','reality','VLESS Vision RAW REALITY с локальным TLS target'),
 'raw-fragment-tls':('raw','tls','RAW TLS с клиентской fragmentation ClientHello'),
 'xhttp-packet-h1':('xhttp','none','XHTTP packet-up HTTP/1.1 loopback'),
 'xhttp-stream-h2':('xhttp','tls','XHTTP stream-up HTTP/2'),
 'xhttp-one-h2':('xhttp','tls','XHTTP stream-one HTTP/2'),
 'xhttp-packet-h3':('xhttp','tls','XHTTP packet-up HTTP/3 UDP'),
 'xhttp-header-h2':('xhttp','tls','XHTTP packet-up payload в header, небольшие POST'),
 'xhttp-split-nginx':('xhttp','none','Два HTTP frontend плеча к одному XHTTP listener; loopback'),
 'mkcp-tls':('mkcp','tls','VLESS mKCP TLS поверх UDP'),
 'grpc-tls':('grpc','tls','VLESS gRPC Tun с TLS'),
 'grpc-multi-tls':('grpc','tls','VLESS gRPC TunMulti с TLS'),
 'websocket-tls':('websocket','tls','VLESS WebSocket с TLS'),
 'websocket-ed-tls':('websocket','tls','WebSocket early data, ed=2048'),
 'httpupgrade-tls':('httpupgrade','tls','VLESS HTTPUpgrade с TLS'),
 'hysteria2':('hysteria','tls','Нативный Hysteria2, два блока version=2'),
 'masque-h2':('masque','tls','Нативный MASQUE CONNECT-IP HTTP/2'),
 'masque-h3':('masque','tls','Нативный MASQUE CONNECT-IP HTTP/3'),
 'xdrive-local':('xdrive','none','XDRIVE в общей локальной тестовой папке; не cloud benchmark'),
 'chain-raw-tls':('raw','tls','Два RAW TLS узла, второй через dialerProxy первого'),
}


def write_json(path: Path,value: Any) -> None:
    with path.open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    path.chmod(0o600)


def command(args: list[str],timeout: float=20) -> bytes:
    p=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,check=False)
    if p.returncode:raise ValueError('OpenSSL operation failed; no secret output printed')
    return p.stdout


def certificate(directory: Path,openssl: str) -> tuple[str,str,str]:
    cert=directory/'lab-cert.pem';key=directory/'lab-key.pem'
    command([openssl,'req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-keyout',str(key),'-out',str(cert),'-days','2','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'])
    key.chmod(0o600);cert.chmod(0o600)
    der=command([openssl,'x509','-in',str(cert),'-outform','DER'])
    return str(cert),str(key),hashlib.sha256(der).hexdigest()


def reality_keys(directory: Path,openssl: str) -> tuple[str,str]:
    p=directory/'reality-private.pem'
    command([openssl,'genpkey','-algorithm','X25519','-out',str(p)]);p.chmod(0o600)
    private=command([openssl,'pkey','-in',str(p),'-outform','DER'])
    public=command([openssl,'pkey','-in',str(p),'-pubout','-outform','DER'])
    # Fixed RFC8410 DER shapes, assert instead of silently slicing an unknown format.
    if len(private)!=48 or private[:16].hex()!='302e020100300506032b656e04220420' or len(public)!=44 or public[:12].hex()!='302a300506032b656e032100':
        raise ValueError('Unexpected OpenSSL X25519 DER encoding')
    enc=lambda b:base64.urlsafe_b64encode(b).decode().rstrip('=')
    return enc(private[-32:]),enc(public[-32:])


def unused_ports(count: int) -> list[int]:
    result=[]
    # Both UDP and TCP are checked, reservations released only after all are collected.
    held=[]
    try:
        for _ in range(count):
            for attempt in range(50):
                t=socket.socket();u=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
                try:
                    t.bind(('127.0.0.1',0));port=t.getsockname()[1];u.bind(('127.0.0.1',port))
                    held.extend([t,u]);result.append(port);break
                except OSError:t.close();u.close()
            else:raise ValueError('No free loopback port')
    finally:
        for s in held:s.close()
    return result


def make_pair(name: str,root: str,ports: list[int],cred: dict[str,str]) -> dict[str,Any]:
    """Pure renderer shared by templates and runtime materializer; no I/O."""
    if name not in SCENARIOS:raise ValueError('Unknown scenario')
    net,sec,_=SCENARIOS[name]
    sport,cport,upport,downport,targetport,relayport=ports
    cs={'network':{'mkcp':'kcp','websocket':'ws'}.get(net,net),'security':sec}
    bs=copy.deepcopy(cs)
    if sec=='tls':
        alpn=['h3'] if name in ('xhttp-packet-h3','masque-h3','hysteria2') else (['h2'] if net in ('grpc','xhttp','masque') else ['http/1.1'])
        cs['tlsSettings']={'serverName':'localhost','alpn':alpn,'pinnedPeerCertSha256':cred['pin']}
        # Empty fingerprint selects Chrome uTLS where the transport uses GetFingerprint; these fixtures do not assert strict client TLS-version enforcement.
        bs['tlsSettings']={'alpn':alpn,'certificates':[{'certificateFile':cred['cert'],'keyFile':cred['key']}]}
        if name=='raw-vision-tls':
            cs['tlsSettings']['minVersion']='1.3';bs['tlsSettings']['minVersion']='1.3'
    elif sec=='reality':
        cs['realitySettings']={'serverName':'localhost','fingerprint':'chrome','password':cred['public'],'shortId':cred['shortid']}
        bs['realitySettings']={'target':f'127.0.0.1:{targetport}','serverNames':['localhost'],'privateKey':cred['private'],'shortIds':[cred['shortid']]}
    if net=='xhttp':
        mode='stream-up' if name=='xhttp-stream-h2' else ('stream-one' if name=='xhttp-one-h2' else 'packet-up')
        x={'host':'localhost','path':'/xray-lab/','mode':mode}
        if name=='xhttp-header-h2':x.update({'uplinkDataPlacement':'header','scMaxEachPostBytes':1024,'uplinkChunkSize':1400,'serverMaxHeaderBytes':16384})
        cs['xhttpSettings']=copy.deepcopy(x);bs['xhttpSettings']=copy.deepcopy(x)
        if name=='xhttp-split-nginx':
            down=copy.deepcopy(cs);down.update({'address':'127.0.0.1','port':downport})
            cs['xhttpSettings']['downloadSettings']=down
    elif net=='grpc':
        cs['grpcSettings']={'serviceName':'xraylab','multiMode':name=='grpc-multi-tls'}
        bs['grpcSettings']={'serviceName':'xraylab'}
    elif net in ('websocket','httpupgrade'):
        key='wsSettings' if net=='websocket' else 'httpupgradeSettings'
        cs[key]={'host':'localhost','path':'/xray-lab'+('?ed=2048' if name=='websocket-ed-tls' else '')}
        bs[key]={'host':'localhost','path':'/xray-lab'}
    elif net=='mkcp':cs['kcpSettings']={};bs['kcpSettings']={}
    elif net=='hysteria':
        cs['hysteriaSettings']={'version':2,'auth':cred['auth']}
        bs['hysteriaSettings']={'version':2}
    elif net=='masque':
        cs['masqueSettings']={'host':'localhost','path':'/xray-lab/','user':'lab-user','pass':cred['auth']}
        bs['masqueSettings']={'path':'/xray-lab/'}
    elif net=='xdrive':
        for s in (cs,bs):s['xdriveSettings']={'service':'local','remoteFolder':str(Path(root)/'storage'),'pollIntervalMs':50,'maxPollIntervalMs':100,'sessionTtlSeconds':60}
    if name=='raw-fragment-tls':cs['finalmask']={'tcp':[{'type':'fragment','settings':{'packets':'tlshello','length':'100-200','delay':'1-2'}}]}
    proto=net if net in ('hysteria','masque') else 'vless'
    if proto=='vless':
        user={'id':cred['uuid']}
        if name in ('raw-vision-tls','raw-reality'):user['flow']='xtls-rprx-vision'
        inbound={'protocol':'vless','settings':{'users':[user],'decryption':'none'}}
        outsettings={'address':'127.0.0.1','port':upport if name=='xhttp-split-nginx' else sport,'id':cred['uuid'],'encryption':'none'}
        if user.get('flow'):outsettings['flow']=user['flow']
    elif proto=='hysteria':
        inbound={'protocol':'hysteria','settings':{'version':2,'users':[{'auth':cred['auth'],'email':'lab-user'}]}}
        outsettings={'version':2,'address':'127.0.0.1','port':sport}
    else:
        inbound={'protocol':'masque','settings':{'users':[{'email':'lab-user','pass':cred['auth']}],'address':['10.252.0.1/24'],'mtu':1280}}
        outsettings={'address':'127.0.0.1','port':sport}
    inbound.update({'tag':'lab-in','listen':'127.0.0.1','port':sport,'streamSettings':bs})
    outbound={'tag':'lab-proxy','protocol':proto,'settings':outsettings,'streamSettings':cs}
    server={'log':{'loglevel':'warning'},'inbounds':[inbound],'outbounds':[{'tag':'direct','protocol':'freedom','settings':{'finalRules':[{'action':'allow','network':'tcp,udp','ip':['127.0.0.1'],'port':'1024-65535'},{'action':'block','blockDelay':0}]}}]}
    if proto=='masque':server['outbounds'][0]['settings']['redirect']='127.0.0.1:0'
    client={'log':{'loglevel':'warning'},'inbounds':[{'tag':'lab-socks','listen':'127.0.0.1','port':cport,'protocol':'socks','settings':{'auth':'noauth','udp':True,'ip':'127.0.0.1'}}],'outbounds':[outbound]}
    extra={}
    if name=='chain-raw-tls':
        relay=copy.deepcopy(server);relay['inbounds'][0]['port']=relayport
        hop=copy.deepcopy(outbound);hop['tag']='hop-one';hop['settings']['port']=relayport
        outbound['streamSettings']['sockopt']={'dialerProxy':'hop-one'}
        client['outbounds'].append(hop);extra['relay.json']=relay
    topology={'kind':name,'client_socks':cport,'server_port':sport,'up_port':upport,'down_port':downport,'target_port':targetport,'relay_port':relayport,'session_owner':'server.json:lab-in','listeners_bind':'127.0.0.1','physical_underlay':'storage' if net=='xdrive' else ('udp' if net in ('mkcp','hysteria') or name in ('xhttp-packet-h3','masque-h3') else 'tcp'),'requires_nginx':name=='xhttp-split-nginx','requires_tls_target':sec=='reality','protocol':proto,'transport':net,'probe_destination':'198.18.0.1' if proto=='masque' else '127.0.0.1','core_runtime_status':'NOT_RUN','environment':'same-host-isolated-lab'}
    return {'server.json':server,'client.json':client,**extra,'topology.json':topology}


def nginx_text(root: str,ports: list[int]) -> str:
    sport,_,up,down,_,_=ports
    # No TLS in this local routing test: two public-looking legs must share one origin listener.
    return f'''worker_processes 1;
pid "{root}/nginx.pid";
error_log "{root}/nginx-error.log" warn;
events {{ worker_connections 128; }}
http {{
  access_log off;
  server {{
    listen 127.0.0.1:{up};
    listen 127.0.0.1:{down};
    server_name localhost;
    client_max_body_size 2m;
    location /xray-lab/ {{
      proxy_pass http://127.0.0.1:{sport};
      proxy_http_version 1.1;
      proxy_set_header Host localhost;
      proxy_set_header Connection "";
      proxy_request_buffering off;
      proxy_buffering off;
      proxy_cache off;
      proxy_read_timeout 60s;
      proxy_send_timeout 60s;
    }}
    location / {{ return 404; }}
  }}
}}
'''


def create_lab(directory: Path,names: list[str],openssl: str|None=None) -> dict:
    if not names or len(names)!=len(set(names)) or any(n not in SCENARIOS for n in names):raise ValueError('Invalid/duplicate scenarios')
    directory=directory.absolute()
    if directory.exists() or directory.is_symlink():raise ValueError('Destination must not exist')
    if any(x in str(directory) for x in ('\n','\r','"','\\')):raise ValueError('Unsupported path characters')
    openssl=openssl or shutil.which('openssl')
    if not openssl:raise ValueError('OpenSSL CLI required')
    directory.mkdir(mode=0o700,parents=True,exist_ok=False)
    result={'schema_version':1,'builder':'xray-skills-r2','root':str(directory.resolve()),'core_tag':'v26.9.30','core_commit':SHA,'core_runtime_status':'NOT_RUN','scenarios':[]}
    for name in names:
        d=directory/name;d.mkdir(mode=0o700)
        cert,key,pin=certificate(d,openssl)
        private,public=reality_keys(d,openssl) if SCENARIOS[name][1]=='reality' else ('','')
        cred={'uuid':str(uuid.uuid4()),'auth':secrets.token_urlsafe(24),'pin':pin,'cert':cert,'key':key,'private':private,'public':public,'shortid':secrets.token_hex(8)}
        ports=unused_ports(6);objects=make_pair(name,str(d),ports,cred)
        if name=='xdrive-local':(d/'storage').mkdir(mode=0o700)
        for file,obj in objects.items():write_json(d/file,obj)
        if name=='xhttp-split-nginx':
            with (d/'nginx.conf').open('x',encoding='utf-8') as f:f.write(nginx_text(str(d),ports))
            (d/'nginx.conf').chmod(0o600)
        # Credentials in wrong-auth client are fresh, not a serialization of any real user.
        negative=copy.deepcopy(objects['client.json']);primary=negative['outbounds'][0]
        if primary['protocol']=='vless':primary['settings']['id']=str(uuid.uuid4())
        elif primary['protocol']=='hysteria':primary['streamSettings']['hysteriaSettings']['auth']=secrets.token_urlsafe(24)
        else:primary['streamSettings']['masqueSettings']['pass']=secrets.token_urlsafe(24)
        write_json(d/'negative-auth.json',negative)
        issues=[]
        for filename,obj in objects.items():
            if filename!='topology.json':issues.extend(Validator().config(obj))
        issues.extend(check_pair(objects['client.json'],objects['server.json'],'lab-proxy','lab-in'))
        write_json(d/'static-validation.json',{'status':'FAIL' if any(i['severity']=='ERROR' for i in issues) else 'PASS_STATIC_ONLY','core_test_run':False,'issues':issues})
        if any(i['severity']=='ERROR' for i in issues):raise ValueError('Generated fixture failed static validation; no runnable manifest issued')
        files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}
        result['scenarios'].append({'name':name,'files_sha256':files,'topology':objects['topology.json']})
    write_json(directory/'lab-manifest.json',result)
    return result


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path);ap.add_argument('--scenario',action='append',choices=list(SCENARIOS));ap.add_argument('--all',action='store_true');ap.add_argument('--list',action='store_true');a=ap.parse_args()
    if a.list:
        for name,(_,_,desc) in SCENARIOS.items():print(name+' — '+desc)
        return 0
    if not a.out:ap.error('--out is required')
    if a.all and a.scenario:ap.error('Choose --all OR --scenario')
    names=list(SCENARIOS) if a.all else (a.scenario or ['raw-tls'])
    try:
        manifest=create_lab(a.out,names)
        print(f'Созданы {len(manifest["scenarios"])} лабораторных схем. Runtime NOT_RUN. Manifest: {a.out / "lab-manifest.json"}')
        return 0
    except (OSError,ValueError,subprocess.TimeoutExpired):
        print('LAB_BUILD_FAILED: проверьте новую папку, доступность OpenSSL и файловые права. Секреты не выводятся.',file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
