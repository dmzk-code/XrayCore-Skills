#!/usr/bin/env python3
"""Bounded native and peer regression checks. Explicit trusted binary and --execute.
Local generated configs only; no external API, account, deployment or firewall.
Not an execution sandbox. New output directory; no overwrite of old evidence.
"""
from __future__ import annotations
import argparse,base64,copy,json,secrets,sys,time,re
from pathlib import Path
from build_lab import create_lab,write_json
from lab_trust import verify_binary
from lint_config import SHA
from run_lab import Child,capture,echo_servers,tcp_probe,udp_probe,wait_tcp_probe,save_report
from validate import Validator,check_pair
from peer_checks import canonical_id


def run(binary: Path,out: Path,digest: str) -> dict:
    observed=verify_binary(binary,digest);binary=binary.resolve();out=out.absolute()
    if out.exists() or out.is_symlink():raise ValueError('new output directory required')
    out.mkdir(mode=0o700,parents=True)
    create_lab(out/'lab',['raw-tls','raw-reality','grpc-tls','xhttp-header-h2'])
    version=capture([str(binary),'version'],out,out/'version.log',8)
    text=(out/'version.log').read_text(errors='replace')
    if version['status']!='PASS' or not re.search(r'\b26\.9\.30\b',text):raise ValueError('binary version mismatch')
    report={'revision':'r4','core_commit':SHA,'binary_sha256':observed,'scope':'r4 native JSON and loopback peer regressions','native':[],'wire':[],'status':'RUNNING'}
    base=json.loads((out/'lab/raw-tls/server.json').read_text())
    def patch(path,value):
        c=copy.deepcopy(base);where=c
        for key in path[:-1]:
            if isinstance(where,dict) and key not in where:where[key]={}
            where=where[key]
        where[path[-1]]=value;return c
    cases=[
      ('listen-bool',['inbounds',0,'listen'],True,False),
      ('port-bool',['inbounds',0,'port'],False,False),
      ('port-array',['inbounds',0,'port'],[8443],False),
      ('loglevel-integer',['log','loglevel'],42,False),
      ('dnsLog-string',['log','dnsLog'],'true',False),
      ('policy-stats-string',['policy','system','statsInboundUplink'],'true',False),
      ('policy-uint-overflow',['policy','levels','0','handshake'],2**32,False),
      ('sniff-invalid-protocol',['inbounds',0,'sniffing'],{'enabled':True,'destOverride':['h2']},False),
      ('api-no-tag',['api'],{'listen':'127.0.0.1:10085','services':[]},False),
      ('api-unknown-service-ignored',['api'],{'tag':'api','services':['StatService']},True),
      ('api-direct-valid',['api'],{'tag':'api','listen':'127.0.0.1:10085','services':['StatsService']},True),
      ('metrics-no-endpoint',['metrics'],{},False),
      ('metrics-direct-valid',['metrics'],{'listen':'127.0.0.1:10086'},True),
      ('stats-empty-object',['stats'],{},True),
      ('policy-null-level',['policy'],{'levels':{'0':None}},True),
      ('policy-no-buffer-overflow',['policy'],{'levels':{'0':{'bufferSize':1024}}},True),
      ('geodata-http-url',['geodata'],{'assets':[{'url':'http://example.invalid/test','file':'example.dat'}]},False),
      ('geodata-empty-assets',['geodata'],{'assets':[]},True),
      ('version-type',['version'],{'min':26},False),
      ('fakeDns-array',['fakeDns'],[{'ipPool':'198.18.0.0/15','poolSize':32768}],True),
    ]
    configs=out/'native';configs.mkdir()
    for name,path,value,accepted in cases:
        c=patch(path,value);file=configs/(name+'.json');write_json(file,c)
        r=capture([str(binary),'run','-test','-config',str(file)],configs,configs/(name+'.log'),15)
        got='ACCEPT' if r['exit_code']==0 else ('REJECT' if r['exit_code']==23 else 'FAIL_EXECUTION');report['native'].append({'name':name,'expected':'ACCEPT' if accepted else 'REJECT','observed':got,'exit_code':r['exit_code'],'status':'PASS' if got==('ACCEPT' if accepted else 'REJECT') else 'FAIL','static_codes':sorted({x['code'] for x in Validator().config(c)})})
    # Compare a documented deterministic identifier with the actual pinned core.
    import subprocess
    p=subprocess.run([str(binary),'uuid','-i','Alice'],capture_output=True,text=True,timeout=5)
    report['uuid_mapping']={'status':'PASS' if p.returncode==0 and p.stdout.strip()==canonical_id('Alice') else 'FAIL','input':'public test string Alice','expected_uuid':canonical_id('Alice')}
    scenarios=[('raw-reality','reality-key'),('raw-reality','reality-shortid'),('raw-reality','reality-sni'),('raw-tls','sudoku-password'),('grpc-tls','grpc-method'),('xhttp-header-h2','xhttp-payload-key'),('raw-tls','tls-version'),('raw-tls','tls-version-utls')]
    for base_name,name in scenarios:
        d=out/'lab'/base_name;c=json.loads((d/'client.json').read_text());s=json.loads((d/'server.json').read_text());t=json.loads((d/'topology.json').read_text())
        cs=c['outbounds'][0]['streamSettings'];ss=s['inbounds'][0]['streamSettings']
        if name=='sudoku-password':
            for st in (cs,ss):st['finalmask']={'tcp':[{'type':'sudoku','settings':{'password':'PUBLIC-TEST-PASSWORD'}}]}
        if name=='grpc-method':
            cs['grpcSettings']['serviceName']='/r4/T';ss['grpcSettings']['serviceName']='/r4/T|M'
        if name=='tls-version':cs['tlsSettings']['fingerprint']='unsafe'
        logdir=out/name;logdir.mkdir()
        for filename,obj in [('good.json',c),('server.json',s)]:write_json(logdir/filename,obj)
        bad=copy.deepcopy(c);bcs=bad['outbounds'][0]['streamSettings']
        if name=='reality-key':bcs['realitySettings']['password']=base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip('=')
        elif name=='reality-shortid':bcs['realitySettings']['shortId']='ff'
        elif name=='reality-sni':bcs['realitySettings']['serverName']='wrong.invalid'
        elif name=='sudoku-password':bcs['finalmask']['tcp'][0]['settings']['password']='DIFFERENT-TEST-PASSWORD'
        elif name=='grpc-method':bcs['grpcSettings']['serviceName']='/r4/Other'
        elif name=='xhttp-payload-key':bcs['xhttpSettings']['uplinkDataKey']='DifferentData'
        else:bcs['tlsSettings']['minVersion']='1.3';ss['tlsSettings']['maxVersion']='1.2';(logdir/'server.json').write_text(json.dumps(s))
        write_json(logdir/'bad.json',bad)
        static=check_pair(bad,s,'lab-proxy','lab-in');record={'name':name,'static_codes':sorted({x['code'] for x in static}),'status':'RUNNING'};children=[]
        try:
            def start(label,file):
                child=Child([str(binary),'run','-config',str(logdir/file)],d,logdir/(label+'.log'));children.append(child);return child
            if t['requires_tls_target']:
                import shutil
                openssl=shutil.which('openssl')
                child=Child([openssl,'s_server','-accept',f'127.0.0.1:{t["target_port"]}','-cert',str(d/'lab-cert.pem'),'-key',str(d/'lab-key.pem'),'-tls1_3','-alpn','h2','-www','-quiet'],d,logdir/'target.log');children.append(child)
            server=start('server','server.json');good=start('good','good.json')
            with echo_servers() as (tp,up):
                wait_tcp_probe(t['client_socks'],tp,children,seconds=15)
                tcp_probe(t['client_socks'],tp,2048);udp_probe(t['client_socks'],up)
                record['positive']='PASS';good.stop();children.remove(good)
                wrong=start('bad','bad.json');time.sleep(.3)
                rejected=False
                try:tcp_probe(t['client_socks'],tp,512,timeout=2)
                except (OSError,ConnectionError):rejected=True
                expected_rejection=name!='tls-version-utls'
                record['expected_probe']='REJECT' if expected_rejection else 'ACCEPT_WITH_UNAPPLIED_POLICY'
                record['observed_probe']='REJECT' if rejected else 'ACCEPT'
                record['negative']='PASS' if rejected==expected_rejection and wrong.process.poll() is None else 'FAIL'
                wrong.stop();children.remove(wrong)
                good=start('positive-control','good.json');wait_tcp_probe(t['client_socks'],tp,children,seconds=15)
                record['positive_control']='PASS'
                record['status']='PASS' if record['negative']=='PASS' and (any(x['severity']=='ERROR' for x in static) or name=='tls-version-utls' and 'UTLS_FIELDS_NOT_COPIED' in record['static_codes']) else 'FAIL'
        except (OSError,ValueError,TimeoutError,RuntimeError,ConnectionError) as e:record.update(status='FAIL',reason=type(e).__name__)
        finally:
            for child in reversed(children):child.stop()
        report['wire'].append(record)
    report['status']='PASS' if all(x['status']=='PASS' for x in report['native']+report['wire']+[report['uuid_mapping']]) else 'FAIL'
    save_report(out/'report.json',report);return report


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--xray',type=Path,required=True);ap.add_argument('--sha256',required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--execute',action='store_true');a=ap.parse_args()
    if not a.execute:ap.error('--execute is required')
    try:r=run(a.xray,a.out,a.sha256);print(r['status']);return 0 if r['status']=='PASS' else 1
    except (OSError,ValueError) as e:print('FAIL_PRECONDITION: '+type(e).__name__,file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
