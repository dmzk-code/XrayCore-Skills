#!/usr/bin/env python3
"""Read-only static authoring checks for Xray v26.9.30. NOT a core/runtime test.
Python >=3.10, standard library. No network, no subprocess, no configuration writes.
Coverage is deliberately explicit: transport fields + selected full-config invariants.
Unknown extension/protocol schemas are NOT silently certified by this validator.
"""
from __future__ import annotations
import argparse
import base64
import copy
import ipaddress
import json
import math
import re
import sys
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit
import lint_config as old

ROOT_KEYS = set('env log routing dns inbounds outbounds policy api metrics stats reverse fakeDns observatory burstObservatory version geodata transport'.split())
ROUTE_KEYS = set('type ruleTag outboundTag balancerTag domain domains ip port network sourceIP source sourcePort user vlessRoute inboundTag protocol attrs localIP localPort process localOS webhook'.split())
DNS_KEYS = set('servers hosts clientIp tag queryStrategy disableCache serveStale serveExpiredTTL disableFallback disableFallbackIfMatch enableParallelQuery useSystemHosts'.split())
NS_KEYS = set('address clientIp port skipFallback domains expectedIPs expectIPs queryStrategy tag timeoutMs disableCache serveStale serveExpiredTTL finalQuery unexpectedIPs'.split())
VLESS_OUT = set('address port level email id flow seed encryption reverse testpre testseed vnext'.split())
VLESS_IN = set('users clients decryption fallbacks flow testseed'.split())
MASKS = json.loads((Path(__file__).resolve().parents[2]/'xray-security-sockopt-finalmask/references/mask-fields.json').read_text(encoding='utf-8'))['types']
QUIC_KEYS = set('congestion debug bbrProfile brutalUp brutalDown brutalDisableLossCompensation initStreamReceiveWindow maxStreamReceiveWindow initConnectionReceiveWindow maxConnectionReceiveWindow maxIdleTimeout keepAlivePeriod disablePathMTUDiscovery disableChromeParrot disableGSO maxIncomingStreams disableStatelessReset'.split())
DOMAIN_STRATEGIES = {'','asis','useip','useipv4','useipv6','useipv4v6','useipv6v4','forceip','forceipv4','forceipv6','forceipv4v6','forceipv6v4'}
EXPR_ARITY = {'concat':None,'slice':3,'xor16':2,'xor32':2,'be16':1,'be32':1,'le16':1,'le32':1,'le64':1,'pad':3,'truncate':2,'add':2,'sub':2,'and':2,'or':2,'shl':2,'shr':2}


import semantic_checks as sem
import schema_checks
import peer_checks
import http_peer_checks
import protocol_checks
import proxy_edge_checks
import topology_checks


def network(s: Any) -> str:
    if not isinstance(s,dict):return ''
    v=s.get('method') if s.get('method') is not None else (s.get('network') if s.get('network') is not None else 'raw')
    return old.ALIASES.get(v.lower(),'') if isinstance(v,str) else ''


def settings(s: dict) -> dict:
    n=network(s); k=old.KEYS.get(n,'')
    o=s.get(k) if s.get(k) is not None else s.get({'raw':'tcpSettings','xhttp':'splithttpSettings'}.get(n,''),{})
    if not isinstance(o,dict):return {}
    if n=='xhttp' and 'extra' in o and (o['extra'] is None or isinstance(o['extra'],dict)):
        return {**(o['extra'] or {}),**{k:o.get(k,'') for k in ('host','path','mode')}}
    return o


def list_strings(v: Any) -> list[str]:
    if isinstance(v,str):return v.split(',')
    if isinstance(v,list) and all(isinstance(x,str) for x in v):return v
    return []


def vless_account(e: dict) -> tuple[dict,Any]:
    o=e.get('settings',{})
    if not isinstance(o,dict):return {},None
    if o.get('address') is not None:return o,o.get('address')
    v=o.get('vnext')
    if isinstance(v,list) and len(v)==1 and isinstance(v[0],dict):
        us=v[0].get('users')
        if isinstance(us,list) and len(us)==1 and isinstance(us[0],dict):return us[0],v[0].get('address')
    return {},None


def keybytes(value: str) -> bytes:
    if not re.fullmatch(r'[A-Za-z0-9_-]+',value):raise ValueError('invalid base64url')
    return base64.urlsafe_b64decode(value+'='*(-len(value)%4))


def safe_shape(value: Any,depth: int=0,budget: list[int]|None=None) -> None:
    if budget is None:budget=[100000]
    budget[0]-=1
    if depth>48 or budget[0]<0:raise ValueError('JSON exceeds structural safety limit')
    if isinstance(value,dict):
        for k,v in value.items():
            if not isinstance(k,str):raise ValueError('JSON keys must be strings')
            safe_shape(v,depth+1,budget)
    elif isinstance(value,list):
        for v in value:safe_shape(v,depth+1,budget)
    elif type(value) is float and not math.isfinite(value):
        raise ValueError('Nonfinite JSON number')
    elif not (value is None or type(value) in (str,int,float,bool)):
        raise ValueError('Non-JSON value')


class Validator(old.Linter):
    def issue(self,code: str,p: str,msg: str,kind: str='AUTHORING_POLICY',severity: str='ERROR',file: str='infra/conf/xray.go') -> None:
        self.emit(code,p,msg,kind,severity,file)

    def unknown(self,o: dict,keys: set[str],p: str) -> None:
        for k in sorted(set(o)-keys):
            self.issue('UNKNOWN_FIELD',p+'.<unknown-field>','Поле вне проверенной схемы этого блока; это не доказательство ошибки JSON-parser ядра.')

    def number(self,o: dict,k: str,p: str,lo: int=0,hi: int=2**32-1) -> None:
        if k in o and (not old.integer(o[k]) or not lo<=o[k]<=hi):
            self.issue('NUMBER',p+'.'+k,f'Требуется целое число в диапазоне {lo}..{hi}.')

    def rng(self,o: dict,k: str,p: str,minimum: int|None=None) -> tuple[int,int]:
        try:
            a,b=old.range32(o.get(k,0))
            if minimum is not None and a<minimum:raise ValueError()
            return a,b
        except (ValueError,TypeError):
            self.issue('RANGE',p+'.'+k,'Некорректный безопасный целочисленный диапазон.');return 0,0

    def stream(self,o: Any,p: str='$',depth: int=0) -> None:
        # Parent checks known transport fields and aliases. Guard against untyped structures.
        if depth>24:self.issue('DEPTH',p,'Слишком глубокая вложенность.');return
        if not isinstance(o,dict):self.issue('OBJECT',p,'Требуется объект streamSettings.');return
        super().stream(o,p,depth)
        for k in ('sockopt','finalmask','tlsSettings','realitySettings'):
            if k in o and not isinstance(o[k],dict):self.issue('OBJECT',p+'.'+k,'Требуется объект.');continue
        so=o.get('sockopt')
        if isinstance(so,dict):
            self.enum(so,'domainStrategy',DOMAIN_STRATEGIES,p+'.sockopt',True)
            self.enum(so,'addressPortStrategy',{'','none','srvportonly','srvaddressonly','srvportandaddress','txtportonly','txtaddressonly','txtportandaddress'},p+'.sockopt',True)
            for k in ('mark','tcpKeepAliveInterval','tcpKeepAliveIdle','tcpWindowClamp','tcpMaxSeg','tcpUserTimeout'):
                self.number(so,k,p+'.sockopt',-2**31,2**31-1)
            if 'tcpFastOpen' in so and not (type(so['tcpFastOpen']) is bool or old.integer(so['tcpFastOpen'])):self.issue('TFO_TYPE',p+'.sockopt.tcpFastOpen','Используйте bool или целое, не дробное число.')
            for k in ('dialerProxy','domainStrategy','interface','tcpCongestion'):
                if k in so and not isinstance(so[k],str):self.issue('TYPE',p+'.sockopt.'+k,'Требуется строка.')
            if 'trustedXForwardedFor' in so:
                if not old.strings(so['trustedXForwardedFor']):self.issue('XFF_TYPE',p+'.sockopt.trustedXForwardedFor','Требуется массив строк.')
                elif any(v in ('0.0.0.0/0','::/0','*') for v in so['trustedXForwardedFor']):self.issue('XFF_TRUST_ALL',p+'.sockopt','Не доверять XFF от любого peer.','AUTHORING_POLICY','WARNING')
            h=so.get('happyEyeballs')
            if h is not None:
                if not isinstance(h,dict):self.issue('OBJECT',p+'.sockopt.happyEyeballs','Требуется объект.')
                else:
                    self.unknown(h,{'prioritizeIPv6','tryDelayMs','interleave','maxConcurrentTry'},p+'.sockopt.happyEyeballs')
                    for k in ('tryDelayMs','interleave','maxConcurrentTry'):self.number(h,k,p+'.sockopt.happyEyeballs')
                    if h.get('maxConcurrentTry')==0:self.issue('HAPPY_ZERO',p+'.sockopt.happyEyeballs','maxConcurrentTry=0 отключает TcpRaceDial; это не «безлимит».','AUTHORING_POLICY','WARNING')
            c=so.get('customSockopt')
            if c is not None:
                if not isinstance(c,list):self.issue('ARRAY',p+'.sockopt.customSockopt','Требуется массив.')
                else:
                    for i,a in enumerate(c):
                        q=f'{p}.sockopt.customSockopt[{i}]'
                        if isinstance(a,dict):self.types(a,{k:'string' for k in ('system','network','level','opt','value','type')},q)
                        else:self.issue('OBJECT',q,'Требуется объект.')
        if isinstance(o.get('finalmask'),dict):self.masks(o['finalmask'],p+'.finalmask')
        t=o.get('tlsSettings')
        if isinstance(t,dict):
            for k in ('serverName','fingerprint','minVersion','maxVersion','echConfigList','echServerKeys','verifyPeerCertByName'):
                if k in t and not isinstance(t[k],str):self.issue('TYPE',p+'.tlsSettings.'+k,'Требуется строка.')
            self.enum(t,'minVersion',{'','1.0','1.1','1.2','1.3'},p+'.tlsSettings')
            self.enum(t,'maxVersion',{'','1.0','1.1','1.2','1.3'},p+'.tlsSettings')
            for k in ('alpn','curvePreferences'):
                if k in t and not (isinstance(t[k],str) or old.strings(t[k])):self.issue('STRING_LIST',p+'.tlsSettings.'+k,'Требуется StringList: строка либо массив строк.')
            certs=t.get('certificates',[])
            if not isinstance(certs,list):self.issue('ARRAY',p+'.tlsSettings.certificates','Требуется массив.')
            else:
                for i,c in enumerate(certs):
                    q=f'{p}.tlsSettings.certificates[{i}]'
                    if isinstance(c,dict):
                        self.types(c,{'certificateFile':'string','certificate':'array[string]','keyFile':'string','key':'array[string]','usage':'string','ocspStapling':'int64','oneTimeLoading':'boolean','buildChain':'boolean'},q)
                        if not c.get('certificateFile') and not c.get('certificate'):self.issue('TLS_CERT_REQUIRED',q,'Не задан сертификат.','SOURCE_BUILD',file='infra/conf/transport_security.go')
                    else:self.issue('OBJECT',q,'Требуется объект сертификата.')
        rr=o.get('realitySettings')
        if isinstance(rr,dict):
            for k in ('serverNames','shortIds'):
                if k in rr and not old.strings(rr[k]):self.issue('ARRAY_STRING',p+'.realitySettings.'+k,'Требуется массив строк.')

    def encryption(self,value: Any,server: bool,p: str) -> None:
        if value=='none':return
        if not isinstance(value,str):self.issue('VLESS_ENCRYPTION',p,'Требуется none либо корректная строка VLESS Encryption.','SOURCE_BUILD',file='infra/conf/vless.go');return
        a=value.split('.')
        good=len(a)>=4 and a[0]=='mlkem768x25519plus' and a[1] in ('native','xorpub','random')
        if good:
            if server:good=bool(re.fullmatch(r'\d+(?:-\d+)?s?',a[2]))
            else:good=a[2] in ('1rtt','0rtt')
        try:
            for part in a[3:]:
                if len(part)>=20 and len(keybytes(part)) not in ((32,64) if server else (32,1184)):good=False
        except ValueError:good=False
        if not good:self.issue('VLESS_ENCRYPTION',p,'Некорректная строка; значения ключей скрыты. Конструктор encryption.Init проверяет дополнительные условия.','SOURCE_BUILD',file='infra/conf/vless.go')
        else:self.issue('ENCRYPTION_INIT_REQUIRED',p,'Формат принят статически; обязательны core init и handshake с парным ключом.','SOURCE_RUNTIME','WARNING','proxy/vless/encryption/client.go')

    def endpoint(self,e: Any,p: str,side: str) -> None:
        if not isinstance(e,dict):self.issue('OBJECT',p,'Требуется объект endpoint.');return
        allowed={'protocol','tag','settings','streamSettings'} | ({'listen','port','sniffing'} if side=='inbounds' else {'sendThrough','proxySettings','mux','targetStrategy'})
        self.unknown(e,allowed,p)
        protocol=e.get('protocol','');s=e.get('streamSettings',{});o=e.get('settings',{})
        if not isinstance(protocol,str):self.issue('PROTOCOL',p,'protocol должен быть строкой.');return
        protocol=protocol.lower()
        if not isinstance(o,dict):self.issue('OBJECT',p+'.settings','Требуется объект settings.');return
        if not isinstance(s,dict):s={}
        n=network(s);sec=s.get('security','none');sec=sec.lower() if isinstance(sec,str) else ''
        if side=='inbounds' and isinstance(e.get('listen'),str) and e['listen'].startswith(('/', '@')) and e.get('port') not in (None,0):self.issue('UNIX_PORT',p+'.port','Unix listener требует port отсутствующий/0; не переносить TCP port.')
        if 'tag' in e and not isinstance(e['tag'],str):self.issue('TAG_TYPE',p+'.tag','Требуется строка.')
        if side=='inbounds':
            listen=e.get('listen','')
            if protocol!='tun' and not (isinstance(listen,str) and listen.startswith(('/', '@'))) and 'port' not in e:self.issue('LISTEN_PORT',p,'IP-listener требует port.','SOURCE_BUILD')
            if isinstance(listen,str) and listen in ('','0.0.0.0','::') and protocol in ('socks','mixed','http'):
                self.issue('OPEN_LOCAL_PROXY',p,'Проверьте auth/firewall: локальный proxy слушает публичные интерфейсы.','AUTHORING_POLICY','WARNING')
        if side=='outbounds' and n=='grpc' and not topology_checks.runtime_finalmask(s):self.issue('GRPC_RECONNECT_OBSERVED',p+'.streamSettings','Без непустого массива TCP/UDP masks getGrpcClient захватывает context первого запроса. Пустой finalmask или только quicParams не устраняет ветку с дефектом переподключения.','SOURCE_RUNTIME','WARNING','transport/internet/grpc/dial.go')
        if n=='masque' and protocol!='masque':self.issue('MASQUE_NATIVE',p,'MASQUE transport разрешён только с masque protocol.','SOURCE_BUILD')
        if protocol in ('masque','hysteria') and n!=protocol:self.issue('NATIVE_TRANSPORT',p,'Нативному протоколу нужен одноимённый транспорт.','AUTHORING_POLICY')
        if 'proxySettings' in e and e['proxySettings'] is not None:self.issue('PROXYSETTINGS_REMOVED',p+'.proxySettings','Используйте streamSettings.sockopt.dialerProxy.','SOURCE_BUILD')
        m=e.get('mux')
        if m is not None:
            if not isinstance(m,dict):self.issue('OBJECT',p+'.mux','Требуется объект.')
            else:
                self.types(m,{'enabled':'boolean','concurrency':'int32','xudpConcurrency':'int32','xudpProxyUDP443':'string'},p+'.mux')
                for k in ('concurrency','xudpConcurrency'):self.number(m,k,p+'.mux',-32768,32767)
                self.enum(m,'xudpProxyUDP443',{'','reject','allow','skip'},p+'.mux')
                if protocol=='masque' and m.get('enabled') is True:self.issue('MASQUE_MUX',p+'.mux','MASQUE outbound не поддерживает mux.','SOURCE_BUILD')
                if n in ('xhttp','grpc','hysteria','masque') and m.get('enabled') is True:self.issue('NESTED_MUX',p+'.mux','Дополнительный Mux поверх встроенного multiplexing требует обоснования и теста.','AUTHORING_POLICY','WARNING')
        if 'targetStrategy' in e:self.enum(e,'targetStrategy',DOMAIN_STRATEGIES,p,True)
        if side=='outbounds' and sec=='tls' and peer_checks.uses_utls(s,n):
            tls=s.get('tlsSettings',{})
            if any(k in tls for k in ('minVersion','maxVersion','cipherSuites','curvePreferences','enableSessionResumption')):
                self.issue('UTLS_FIELDS_NOT_COPIED',p+'.tlsSettings','uTLS copyConfig не переносит заданные TLS version/cipher/curve/session параметры; не считать их действующей клиентской policy.','SOURCE_RUNTIME','WARNING','transport/internet/tls/tls.go')
        if protocol in ('freedom','direct'):
            so=s.get('sockopt',{});so=so if isinstance(so,dict) else {}
            if str(so.get('addressPortStrategy','')).lower() not in ('','none'):self.issue('FREEDOM_APS',p,'freedom запрещает addressPortStrategy.','SOURCE_BUILD')
            if e.get('targetStrategy') or o.get('domainStrategy'):self.issue('FREEDOM_STRATEGY_MIGRATION',p,'Ненулевой targetStrategy, иначе freedom.domainStrategy, переносится в sockopt и может перекрыть его.','SOURCE_BUILD','WARNING')
            if 'ipsBlocked' in o:self.issue('FREEDOM_IPSBLOCKED_IGNORED',p+'.settings.ipsBlocked','Старый ipsBlocked вызывает warning, но Build не переносит список; используйте finalRules.','SOURCE_BUILD','WARNING','infra/conf/freedom.go')
            if o.get('noise') is not None:self.issue('FREEDOM_NOISE_REMOVED',p+'.settings.noise','noise object удалён; noises[] или соответствующая Finalmask — разные уровни.','SOURCE_BUILD',file='infra/conf/freedom.go')
            rules=o.get('finalRules',[])
            if not isinstance(rules,list):self.issue('ARRAY',p+'.settings.finalRules','Требуется массив правил.')
            else:
                if rules and so.get('dialerProxy'):self.issue('FREEDOM_FINALRULES_IGNORED',p+'.settings.finalRules','finalRules не применяются, когда freedom не конечный outbound из-за dialerProxy.','SOURCE_RUNTIME','WARNING','proxy/freedom/freedom.go')
                for j,r in enumerate(rules):
                    q=p+f'.settings.finalRules[{j}]'
                    if not isinstance(r,dict):self.issue('OBJECT',q,'Требуется объект правила.');continue
                    self.unknown(r,{'action','network','port','ip','blockDelay'},q)
                    if not isinstance(r.get('action'),str) or r['action'].lower() not in ('allow','block'):self.issue('FREEDOM_RULE_ACTION',q+'.action','Требуется allow или block.','SOURCE_BUILD',file='infra/conf/freedom.go')
                    if 'network' in r and any(x.lower() not in ('tcp','udp','unix') for x in list_strings(r['network'])):self.issue('FREEDOM_RULE_NETWORK',q+'.network','Используйте известные network values; unknown не считается полезным правилом.')
                    if 'blockDelay' in r:self.rng(r,'blockDelay',q,0)
                    if r.get('action','').lower()=='allow' and not r.get('ip') and not r.get('port') and not r.get('network'):self.issue('FREEDOM_ALLOW_ALL',q,'Безусловный allow снимает default private-target block; требуется явное обоснование.','AUTHORING_POLICY','WARNING')
        if protocol=='vless':
            self.unknown(o,VLESS_IN if side=='inbounds' else VLESS_OUT,p+'.settings')
            if side=='inbounds':
                self.encryption(o.get('decryption'),True,p+'.settings.decryption')
                if o.get('decryption')!='none' and o.get('fallbacks') is not None:self.issue('VLESS_ENCRYPTION_FALLBACK',p+'.settings','Ненулевое encryption несовместимо даже с явно пустым fallbacks.','SOURCE_BUILD',file='infra/conf/vless.go')
                users=o.get('clients',o.get('users',[]))
                if 'clients' in o and 'users' in o:self.issue('CLIENTS_SHADOW',p+'.settings','clients заменяет users.','SOURCE_BUILD','WARNING','infra/conf/vless.go')
                if not isinstance(users,list):self.issue('ARRAY',p+'.settings.users','Требуется массив.');return
                for i,u in enumerate(users):
                    q=f'{p}.settings.users[{i}]'
                    if not isinstance(u,dict):self.issue('OBJECT',q,'Требуется объект пользователя.');continue
                    if u.get('encryption'):self.issue('VLESS_IN_ENCRYPTION',q+'.encryption','encryption нельзя указывать у inbound user.','SOURCE_BUILD',file='infra/conf/vless.go')
                    flow=u.get('flow') or o.get('flow','')
                    if flow not in ('','xtls-rprx-vision'):self.issue('VLESS_FLOW',q+'.flow','Недопустимый inbound flow.','SOURCE_BUILD',file='infra/conf/vless.go')
                    if not isinstance(u.get('id'),str) or not u['id']:self.issue('VLESS_ID',q+'.id','Нужна непустая строка id; допустимость нестандартного id проверить core.')
                    if isinstance(u.get('reverse'),dict) and u['reverse'].get('sniffing') is not None:self.issue('REVERSE_SIDE',q+'.reverse','Inbound reverse не принимает sniffing.','SOURCE_BUILD',file='infra/conf/vless.go')
                self.enum(o,'flow',{'','xtls-rprx-vision'},p+'.settings')
            else:
                acc,address=vless_account(e)
                if not acc:self.issue('VLESS_ONE',p+'.settings','Нужен simplified address/id либо ровно один vnext с одним user.','SOURCE_BUILD',file='infra/conf/vless.go')
                if o.get('address') is not None and 'vnext' in o:self.issue('VLESS_SHADOW',p+'.settings','Simplified address заменяет vnext целиком.','SOURCE_BUILD','WARNING','infra/conf/vless.go')
                self.encryption(acc.get('encryption'),False,p+'.settings.encryption')
                flow=acc.get('flow','')
                if flow not in ('','xtls-rprx-vision','xtls-rprx-vision-udp443'):self.issue('VLESS_FLOW',p+'.settings.flow','Недопустимый outbound flow.','SOURCE_BUILD',file='infra/conf/vless.go')
                encrypted=bool(acc.get('encryption') and acc.get('encryption')!='none')
                if flow and not encrypted and not (n=='raw' and sec in ('tls','reality')) and not (n=='mkcp' and sec=='tls'):
                    self.issue('VISION_WRAPPER',p,'Без VLESS Encryption транспорт должен вернуть прямой TLS/REALITY wrapper; HTTP обёртки этого не дают.','SOURCE_RUNTIME',file='proxy/vless/outbound/outbound.go')
                if flow and m and isinstance(m,dict) and m.get('enabled') and m.get('concurrency',0)>=0:self.issue('VISION_TCP_MUX',p+'.mux','Обычный TCP Mux несовместим с серверным Vision; отдельно проверяйте XUDP.','SOURCE_RUNTIME',file='proxy/vless/inbound/inbound.go')
                if 'seed' in o:self.issue('VLESS_SEED_IGNORED',p+'.settings.seed','Копирование simplified seed в account закомментировано.','SOURCE_BUILD','WARNING','infra/conf/vless.go')
                if o.get('testpre') or o.get('testseed'):self.issue('VLESS_TEST_KNOBS',p+'.settings','Экспериментальные test* не включать без измерений.','AUTHORING_POLICY','WARNING')
                if not encrypted and sec not in ('tls','reality'):self.public_cleartext(address,p)
                rv=acc.get('reverse')
                if rv is not None:
                    if not isinstance(rv,dict) or not rv.get('tag'):self.issue('REVERSE_TAG',p+'.settings.reverse','Reverse требует tag.','SOURCE_BUILD',file='infra/conf/vless.go')
                    if o.get('address') is None:self.issue('REVERSE_SIMPLIFIED',p+'.settings','Reverse требует simplified outbound.','SOURCE_BUILD',file='infra/conf/vless.go')
        elif protocol=='masque':
            if side=='outbounds':
                self.unknown(o,{'address','port','remoteDNS'},p+'.settings')
                if not o.get('address') or not o.get('port'):self.issue('MASQUE_ENDPOINT',p+'.settings','Нужны address и port.','SOURCE_BUILD',file='infra/conf/masque.go')
                if 'remoteDNS' in o and not old.strings(o['remoteDNS']):self.issue('MASQUE_DNS_TYPE',p+'.settings.remoteDNS','Нужен массив IP-строк.')
                for a in list_strings(o.get('remoteDNS',[])):
                    try:ipaddress.ip_address(a)
                    except ValueError:self.issue('MASQUE_DNS_IP',p+'.settings.remoteDNS','remoteDNS должен содержать IP literals.','SOURCE_BUILD',file='infra/conf/masque.go')
            else:
                self.unknown(o,{'address','mtu','users','clients'},p+'.settings')
                add=o.get('address',[])
                if not old.strings(add) or not add:self.issue('MASQUE_ADDRESS',p+'.settings.address','Требуется хотя бы один IP prefix.','SOURCE_BUILD',file='infra/conf/masque.go')
                else:
                    families=[]
                    for a in add:
                        try:families.append(ipaddress.ip_interface(a).version)
                        except ValueError:self.issue('MASQUE_PREFIX',p+'.settings.address','Некорректный prefix.','SOURCE_BUILD',file='infra/conf/masque.go')
                    if len(families)!=len(set(families)):self.issue('MASQUE_PREFIX_COUNT',p+'.settings.address','Не более одного prefix на семейство.','SOURCE_BUILD',file='infra/conf/masque.go')
                if o.get('mtu'):self.number(o,'mtu',p+'.settings',1280,65535)
                seen=set()
                us=o.get('clients',o.get('users',[]))
                if not isinstance(us,list):self.issue('ARRAY',p+'.settings.users','Требуется массив.')
                else:
                    for u in us:
                        if not isinstance(u,dict):self.issue('OBJECT',p+'.settings.users','Требуется объект.');continue
                        email=u.get('email');password=u.get('pass')
                        if not isinstance(email,str) or not email or ':' in email or not password:self.issue('MASQUE_USER',p+'.settings.users','Нужны email без двоеточия и непустой pass.','SOURCE_BUILD',file='infra/conf/masque.go')
                        elif email.lower() in seen:self.issue('MASQUE_DUPLICATE',p+'.settings.users','Повтор email без учёта регистра.','SOURCE_BUILD',file='infra/conf/masque.go')
                        else:seen.add(email.lower())
        elif protocol=='hysteria':
            if o.get('version')!=2:self.issue('HYSTERIA_PROTOCOL_VERSION',p+'.settings.version','Нативный settings.version тоже должен равняться2.','SOURCE_BUILD',file='infra/conf/hysteria.go')
        elif protocol not in ('socks','mixed','http','freedom','direct','blackhole','block','loopback','dns','dokodemo-door','tunnel','tun','wireguard','vmess','trojan','shadowsocks'):
            self.issue('PROTOCOL_UNKNOWN',p+'.protocol','Протокол отсутствует в стандартных loaders целевого commit.','SOURCE_BUILD')
        elif protocol in ('shadowsocks','wireguard','tun'):
            self.issue('PROTOCOL_SCHEMA_CORE_REQUIRED',p+'.settings','Полная схема этого протокола не реализована в Python linter; обязательна проверка точным ядром.','COVERAGE','WARNING')
        proxy_edge_checks.check_endpoint(self,e,p,side)
        sniff=e.get('sniffing')
        if isinstance(sniff,dict):
            self.unknown(sniff,{'enabled','destOverride','domainsExcluded','ipsExcluded','metadataOnly','routeOnly'},p+'.sniffing')
            if any(x.lower() not in ('http','tls','https','ssl','quic','fakedns','fakedns+others') for x in list_strings(sniff.get('destOverride',[]))):self.issue('SNIFF_PROTOCOL',p+'.sniffing.destOverride','Неизвестный sniff protocol.','SOURCE_BUILD')

    def public_cleartext(self,address: Any,p: str) -> None:
        if not isinstance(address,str):return
        try:
            ip=ipaddress.ip_address(address)
            if ip.is_global:self.issue('PUBLIC_CLEARTEXT',p,'VLESS без TLS/REALITY/VLESS Encryption к публичному IP запрещён.','SOURCE_BUILD')
        except ValueError:
            if address not in ('localhost',) and not address.endswith('.localhost'):
                self.issue('PUBLIC_DOMAIN_CORE_CHECK',p,'Core проверяет домен по своему private geodata matcher; Python не подменяет его ipaddress.','COVERAGE','WARNING')

    def masks(self,o: dict,p: str) -> None:
        self.unknown(o,{'tcp','udp','quicParams'},p)
        for net in ('tcp','udp'):
            arr=o.get(net,[])
            if not isinstance(arr,list):self.issue('ARRAY',p+'.'+net,'Требуется массив масок.');continue
            if len(arr)>16:self.issue('MASK_STACK_LIMIT',p+'.'+net,'Более16 масок: ограничение безопасной генерации, не лимит ядра.');continue
            for i,m in enumerate(arr):
                q=f'{p}.{net}[{i}]'
                if not isinstance(m,dict):self.issue('OBJECT',q,'Требуется объект маски.');continue
                self.unknown(m,{'type','settings'},q)
                typ=m.get('type');s=m.get('settings',{})
                if not isinstance(typ,str) or typ not in MASKS or net not in MASKS[typ]:self.issue('MASK_NETWORK',q,'Тип не зарегистрирован для этого TCP/UDP слоя.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go');continue
                if not isinstance(s,dict):self.issue('OBJECT',q+'.settings','Требуется объект.');continue
                q+='.settings';self.unknown(s,set(MASKS[typ][net]),q)
                if typ=='fragment':
                    lengths=s.get('lengths') or [s.get('length',0)]
                    if not isinstance(lengths,list):self.issue('ARRAY',q+'.lengths','Требуется массив диапазонов.')
                    else:
                        for r in lengths:self.rng({'r':r},'r',q,1)
                    if s.get('packets') not in (None,'','tlshello'):
                        self.rng({'packets':s['packets']},'packets',q,1)
                elif typ=='salamander':
                    a,b=self.rng(s,'packetSize',q)
                    if b>0 and (a<=0 or b>2048):self.issue('GECKO_SIZE',q+'.packetSize','Положительный диапазон должен находиться в1..2048.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                elif typ=='mkcp-legacy':self.enum(s,'header',{'','dns','dtls','srtp','utp','wechat','wireguard'},q,True)
                elif typ=='xdns':
                    self.number(s,'extraPoll',q,0,3)
                    for arrkey,allowed in [('domains',{'name','lenLimit','labelLimit','types','edns0'}),('resolvers',{'type','settings'})]:
                        arr2=s.get(arrkey,[])
                        if not isinstance(arr2,list):self.issue('ARRAY',q+'.'+arrkey,'Требуется массив.');continue
                        for a in arr2:
                            if not isinstance(a,dict):self.issue('OBJECT',q+'.'+arrkey,'Требуется объект.');continue
                            self.unknown(a,allowed,q+'.'+arrkey)
                            if arrkey=='resolvers':
                                self.enum(a,'type',{'tcp','udp'},q+'.resolvers')
                                if not isinstance(a.get('settings'),dict) or not a['settings'].get('addr'):self.issue('XDNS_RESOLVER',q+'.resolvers','Нужен settings.addr.')
                elif typ=='udphop':
                    mode=s.get('mode','');modes=mode.lower().split(',') if isinstance(mode,str) else []
                    if not modes or any(a not in ('intervallocal','intervalremote','perconnremote') for a in modes):self.issue('UDPHOP_MODE',q+'.mode','Некорректный CSV mode.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                    if s.get('interval') not in (None,0,'0',''):self.rng(s,'interval',q,5)
                    for a in list_strings(s.get('remoteIPs',[])):
                        try:ipaddress.ip_network(a,strict=False)
                        except ValueError:self.issue('UDPHOP_IP',q+'.remoteIPs','Ожидается IP/CIDR.')
                elif typ=='xicmp':
                    for a in list_strings(s.get('ips',[])):
                        try:ipaddress.ip_address(a)
                        except ValueError:self.issue('XICMP_IP',q+'.ips','Ожидается IP literal.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                elif typ=='realm':
                    try:
                        u=urlsplit(s.get('url',''))
                        if u.scheme not in ('realm','realm+http') or not u.hostname or '@' not in u.netloc or not u.netloc.rsplit('@',1)[0] or not u.path.removeprefix('/'):raise ValueError()
                    except (ValueError,TypeError):self.issue('REALM_URL',q+'.url','Нужен realm/realm+http URL с host, token и id; URL не выводится.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                    if not old.strings(s.get('stunServers')) or not s.get('stunServers'):self.issue('REALM_STUN',q+'.stunServers','Нужен непустой массив STUN endpoints.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                    if isinstance(s.get('portMapping'),dict):
                        self.unknown(s['portMapping'],{'enabled','timeout','lifetime'},q+'.portMapping')
                    if isinstance(s.get('tlsConfig'),dict):self.tls(s['tlsConfig'],q+'.tlsConfig')
                elif typ=='xmc':
                    if not s.get('password') or not isinstance(s.get('profiles'),list) or not s['profiles']:self.issue('XMC_PROFILE',q,'Нужны password и подписанные профили.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                    else:
                        for a in s['profiles']:
                            if not isinstance(a,dict):self.issue('OBJECT',q+'.profiles','Требуется объект.');continue
                            self.unknown(a,{'username','uuid','texturesValue','texturesSignature'},q+'.profiles')
                            try:
                                uuid.UUID(a.get('uuid',''))
                                if not re.fullmatch(r'[A-Za-z0-9_]{3,16}',a.get('username','')) or not a.get('texturesValue') or not a.get('texturesSignature'):raise ValueError()
                            except (ValueError,TypeError,AttributeError):self.issue('XMC_PROFILE',q+'.profiles','Некорректные обязательные поля профиля; значения скрыты.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                elif typ=='header-custom':
                    seqs=[]
                    for k in (('clients','servers','errors') if net=='tcp' else ('client','server')):
                        a=s.get(k,[])
                        if not isinstance(a,list):self.issue('ARRAY',q+'.'+k,'Требуется массив.');continue
                        if net=='udp':seqs.append(a)
                        else:
                            for seq in a:
                                if not isinstance(seq,list):self.issue('ARRAY',q+'.'+k,'Требуется массив последовательностей.');continue
                                seqs.append(seq)
                    for seq in seqs:
                        for item in seq:self.custom_item(item,q,net)
                elif typ=='noise':
                    a=s.get('noise',[])
                    if not isinstance(a,list):self.issue('ARRAY',q+'.noise','Требуется массив.')
                    else:
                        for item in a:
                            if not isinstance(item,dict):self.issue('OBJECT',q+'.noise','Требуется объект.');continue
                            self.unknown(item,{'rand','randRange','type','packet','delay'},q+'.noise')
                            if item.get('packet') is not None and self.rng(item,'rand',q)[1]>0:self.issue('NOISE_KIND',q+'.noise','Нельзя задавать одновременно packet и положительный rand.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
                if typ in ('sudoku','xmc','xdns','realm','xicmp'):
                    self.issue('MASK_RUNTIME_REQUIRED',q,'Статический разбор не проверяет внешнюю среду, wire behaviour и все runtime ветки этой маски.','COVERAGE','WARNING')
        qp=o.get('quicParams')
        if qp is not None:
            if not isinstance(qp,dict):self.issue('OBJECT',p+'.quicParams','Требуется объект.');return
            self.unknown(qp,QUIC_KEYS,p+'.quicParams')
            self.enum(qp,'congestion',{'','brutal','bbr','reno','force-brutal'},p+'.quicParams',True)
            self.enum(qp,'bbrProfile',{'','conservative','standard','aggressive'},p+'.quicParams',True)
            for k in ('initStreamReceiveWindow','maxStreamReceiveWindow','initConnectionReceiveWindow','maxConnectionReceiveWindow'):
                self.number(qp,k,p+'.quicParams',0,2**64-1)
                if old.integer(qp.get(k)) and 0<qp[k]<16384:self.issue('QUIC_WINDOW',p+'.quicParams.'+k,'Ненулевое окно должно быть>=16384.','SOURCE_BUILD',file='infra/conf/transport_internet.go')
            for k,lo,hi in [('maxIdleTimeout',4,120),('keepAlivePeriod',2,60),('maxIncomingStreams',8,2**63-1)]:
                if k in qp and qp[k]!=0:self.number(qp,k,p+'.quicParams',lo,hi)
            for a,b in [('initStreamReceiveWindow','maxStreamReceiveWindow'),('initConnectionReceiveWindow','maxConnectionReceiveWindow')]:
                if old.integer(qp.get(a)) and old.integer(qp.get(b)) and 0<qp[b]<qp[a]:self.issue('QUIC_WINDOW_ORDER',p+'.quicParams','Initial window больше max; не полагаться на нормализацию зависимости.')
            if qp.get('congestion')=='force-brutal' and not qp.get('brutalUp'):self.issue('BRUTAL_UP',p+'.quicParams','force-brutal требует brutalUp.','SOURCE_BUILD',file='infra/conf/transport_internet.go')
            if qp.get('debug'):self.issue('QUIC_DEBUG',p+'.quicParams.debug','Debug меняет environment процесса; не включать штатно.','AUTHORING_POLICY','WARNING')

    def custom_item(self,item: Any,p: str,net: str) -> None:
        if not isinstance(item,dict):self.issue('OBJECT',p,'Требуется объект item.');return
        self.unknown(item,{'rand','randRange','capture','type','reuse','transform','packet'}|({'delay'} if net=='tcp' else set()),p)
        kinds=sum([item.get('packet') is not None, old.integer(item.get('rand')) and item['rand']>0, bool(item.get('reuse')),item.get('transform') is not None])
        if kinds>1 or (kinds==0 and item.get('capture')):self.issue('CUSTOM_KIND',p,'Не более одного источника; capture требует ровно один.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
        for k in ('capture','reuse'):
            if k in item and (not isinstance(item[k],str) or (item[k] and not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',item[k]))):self.issue('CUSTOM_VAR',p+'.'+k,'Некорректное имя переменной.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
        if 'transform' in item:self.expr(item['transform'],p+'.transform',0)
        if 'randRange' in item:
            a,b=self.rng(item,'randRange',p)
            if a<0 or b>255:self.issue('CUSTOM_RAND_RANGE',p+'.randRange','Диапазон байтов0..255.')

    def expr(self,o: Any,p: str,depth: int) -> None:
        if depth>20:self.issue('DEPTH',p,'Слишком глубокое выражение.');return
        if not isinstance(o,dict):self.issue('OBJECT',p,'Требуется объект выражения.');return
        self.unknown(o,{'op','args'},p)
        op=o.get('op');args=o.get('args')
        if not isinstance(op,str) or op not in EXPR_ARITY:self.issue('EXPR_OP',p+'.op','Операция отсутствует в runtime evaluator.','SOURCE_RUNTIME',file='transport/internet/finalmask/header/custom/evaluator.go');return
        if not isinstance(args,list) or not args:self.issue('EXPR_ARGS',p+'.args','Нужен непустой массив args.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go');return
        if EXPR_ARITY[op] is not None and len(args)!=EXPR_ARITY[op]:self.issue('EXPR_ARITY',p,'Неверное число аргументов.','SOURCE_RUNTIME',file='transport/internet/finalmask/header/custom/evaluator.go')
        for a in args:
            if not isinstance(a,dict):self.issue('OBJECT',p+'.args','Требуется объект аргумента.');continue
            self.unknown(a,{'type','bytes','u64','reuse','metadata','transform'},p+'.args')
            if sum(k in a and a[k] is not None for k in ('bytes','u64','reuse','metadata','transform'))!=1:self.issue('EXPR_ARG_KIND',p+'.args','Аргумент задаёт ровно одно значение.','SOURCE_BUILD',file='infra/conf/transport_finalmask.go')
            self.number(a,'u64',p+'.args',0,2**64-1)
            if 'transform' in a:self.expr(a['transform'],p+'.args.transform',depth+1)

    def routing_dns(self,o: dict) -> None:
        dns=o.get('dns')
        if dns is not None:
            if not isinstance(dns,dict):self.issue('OBJECT','$.dns','Требуется объект.')
            else:
                self.unknown(dns,DNS_KEYS,'$.dns')
                self.enum(dns,'queryStrategy',sem.DNS_STRATEGIES,'$.dns',True)
                servers=dns.get('servers',[])
                if not isinstance(servers,list):self.issue('ARRAY','$.dns.servers','Требуется массив.')
                else:
                    for i,ns in enumerate(servers):
                        p=f'$.dns.servers[{i}]'
                        if isinstance(ns,str):continue
                        if not isinstance(ns,dict):self.issue('OBJECT',p,'Нужны строка либо объект DNS server.');continue
                        self.unknown(ns,NS_KEYS,p)
                        if not ns.get('address'):self.issue('DNS_ADDRESS',p,'Обязателен address.','SOURCE_BUILD',file='infra/conf/dns.go')
                        self.enum(ns,'queryStrategy',sem.DNS_STRATEGIES,p,True)
                        if ns.get('expectedIPs') and ns.get('expectIPs'):self.issue('DNS_ALIAS',p,'expectedIPs имеет приоритет над expectIPs.','SOURCE_BUILD','WARNING','infra/conf/dns.go')
                        self.number(ns,'port',p,0,65535)
                        self.number(ns,'timeoutMs',p,0,2**64-1)
                if dns.get('serveStale') and dns.get('disableCache'):self.issue('DNS_STALE_NOCACHE','$.dns','Stale-cache не помогает при отключённом cache.','AUTHORING_POLICY','WARNING')
        for key,allowed in [('observatory',{'subjectSelector','probeURL','probeInterval','enableConcurrency'}),('burstObservatory',{'subjectSelector','pingConfig'})]:
            ob=o.get(key)
            if ob is None:continue
            if not isinstance(ob,dict):self.issue('OBJECT','$.'+key,'Требуется объект.');continue
            self.unknown(ob,allowed,'$.'+key)
            if 'subjectSelector' in ob and not old.strings(ob['subjectSelector']):self.issue('ARRAY_STRING','$.'+key+'.subjectSelector','Требуется массив строк.')
            if key=='burstObservatory' and not isinstance(ob.get('pingConfig'),dict):self.issue('BURST_PING_REQUIRED','$.'+key+'.pingConfig','BurstObservatory требует pingConfig.','SOURCE_BUILD',file='infra/conf/observatory.go')
        r=o.get('routing')
        if r is None:return
        if not isinstance(r,dict):self.issue('OBJECT','$.routing','Требуется объект.');return
        self.unknown(r,{'rules','domainStrategy','balancers'},'$.routing')
        self.enum(r,'domainStrategy',{'','asis','ipifnonmatch','ipondemand'},'$.routing',True)
        rules=r.get('rules',[])
        if not isinstance(rules,list):self.issue('ARRAY','$.routing.rules','Требуется массив.');return
        for i,a in enumerate(rules):
            p=f'$.routing.rules[{i}]'
            if not isinstance(a,dict):self.issue('OBJECT',p,'Требуется объект rule.');continue
            self.unknown(a,ROUTE_KEYS,p)
            if not a.get('outboundTag') and not a.get('balancerTag'):self.issue('ROUTE_TARGET',p,'Обязателен outboundTag либо balancerTag.','SOURCE_BUILD',file='infra/conf/router.go')
            if a.get('outboundTag') and a.get('balancerTag'):self.issue('ROUTE_SHADOW',p,'outboundTag имеет приоритет над balancerTag.','SOURCE_BUILD','WARNING','infra/conf/router.go')
            for x,y in [('domains','domain'),('sourceIP','source')]:
                if x in a and y in a:self.issue('ROUTE_ALIAS',p,x+' имеет приоритет над '+y+'.','SOURCE_BUILD','WARNING','infra/conf/router.go')
        balancers=r.get('balancers',[])
        if not isinstance(balancers,list):self.issue('ARRAY','$.routing.balancers','Требуется массив.');return
        for i,a in enumerate(balancers):
            p=f'$.routing.balancers[{i}]'
            if not isinstance(a,dict):self.issue('OBJECT',p,'Требуется объект.');continue
            self.unknown(a,{'tag','selector','strategy','fallbackTag'},p)
            if not a.get('tag') or not list_strings(a.get('selector')):self.issue('BALANCER_REQUIRED',p,'Нужны tag и непустой selector.','SOURCE_BUILD',file='infra/conf/router.go')
            st=a.get('strategy',{})
            if not isinstance(st,dict):self.issue('OBJECT',p+'.strategy','Требуется объект.');continue
            self.enum(st,'type',{'','random','leastload','leastping','roundrobin'},p+'.strategy',True)
            if str(st.get('type','')).lower() in ('leastload','leastping') and not o.get('observatory') and not o.get('burstObservatory'):self.issue('BALANCER_OBSERVER',p,'Нет источника результатов наблюдения; нужна согласованная observatory схема.','AUTHORING_POLICY','WARNING')

    def graph(self,o: dict) -> None:
        outs={};ins={}
        for side,index in [('inbounds',ins),('outbounds',outs)]:
            for i,e in enumerate(o.get(side,[]) if isinstance(o.get(side,[]),list) else []):
                if not isinstance(e,dict):continue
                tag=e.get('tag')
                if not isinstance(tag,str) or not tag:continue
                if tag in index:self.issue('DUPLICATE_TAG',f'$.{side}[{i}].tag','Повтор tag в одном namespace.')
                index[tag]=e
        virtual=set()
        api=o.get('api',{})
        if isinstance(api,dict) and isinstance(api.get('tag'),str) and not api.get('listen'):virtual.add(api['tag'])
        metrics=o.get('metrics')
        if isinstance(metrics,dict) and (metrics.get('tag') or metrics.get('listen')):virtual.add(metrics.get('tag') or 'Metrics')
        for t in virtual:
            if t in outs:self.issue('VIRTUAL_TAG_COLLISION','$.outbounds','API/Metrics создаёт handler с tag существующего outbound и может заменить его.','AUTHORING_POLICY')
        for e in ins.values():
            s=e.get('settings',{})
            if not isinstance(s,dict):continue
            for u in s.get('clients',s.get('users',[])) if isinstance(s.get('clients',s.get('users',[])),list) else []:
                if isinstance(u,dict) and isinstance(u.get('reverse'),dict) and isinstance(u['reverse'].get('tag'),str):virtual.add(u['reverse']['tag'])
        r=o.get('routing',{});r=r if isinstance(r,dict) else {}
        bs=r.get('balancers',[]);bs=bs if isinstance(bs,list) else []
        btags=[b.get('tag') for b in bs if isinstance(b,dict) and isinstance(b.get('tag'),str)]
        if len(btags)!=len(set(btags)):self.issue('BALANCER_DUPLICATE','$.routing.balancers','Повтор balancer tag.')
        for a in r.get('rules',[]) if isinstance(r.get('rules',[]),list) else []:
            if not isinstance(a,dict):continue
            for k,allowed in [('outboundTag',set(outs)|virtual),('balancerTag',set(btags))]:
                if isinstance(a.get(k),str) and a[k] not in allowed:self.issue('UNKNOWN_TAG','$.routing.rules.'+k,'Ссылка на отсутствующий tag; значение скрыто.')
        for b in bs:
            if not isinstance(b,dict):continue
            if b.get('fallbackTag') and b['fallbackTag'] not in outs and b['fallbackTag'] not in virtual:self.issue('FALLBACK_TAG','$.routing.balancers','Не найден fallbackTag.')
            sels=list_strings(b.get('selector',[]))
            if sels and not any(tag.startswith(tuple(sels)) for tag in outs):self.issue('EMPTY_SELECTION','$.routing.balancers','Ни один outbound tag не совпадает с selector prefixes.')
        edges={t:set() for t in outs}
        def streams(s: Any,depth: int=0):
            if not isinstance(s,dict) or depth>24:return
            yield s
            tls=s.get('tlsSettings',{})
            if isinstance(tls,dict) and isinstance(tls.get('echSockopt'),dict):yield {'sockopt':tls['echSockopt']}
            down=settings(s).get('downloadSettings')
            if isinstance(down,dict):
                down=copy.deepcopy(down)
                sock=s.get('sockopt')
                if isinstance(sock,dict) and sock.get('penetrate'):down['sockopt']=copy.deepcopy(sock)
                yield from streams(down,depth+1)
        for t,e in outs.items():
            for s in streams(e.get('streamSettings',{})):
                so=s.get('sockopt',{})
                if not isinstance(so,dict):continue
                dp=so.get('dialerProxy')
                if not isinstance(dp,str) or not dp:continue
                if dp not in outs and dp not in virtual:self.issue('DIALER_TAG','$.outbounds.streamSettings.sockopt.dialerProxy','Не найден outbound для dialerProxy.')
                elif dp in outs:edges[t].add(dp)
        visiting=set();visited=set()
        def visit(t: str) -> bool:
            if t in visiting:return True
            if t in visited:return False
            visiting.add(t)
            if any(visit(n) for n in edges[t]):return True
            visiting.remove(t);visited.add(t);return False
        if any(visit(t) for t in edges):self.issue('DIALER_CYCLE','$.outbounds','Обнаружен цикл dialerProxy; запуск не выполнялся.')
        if any(e.get('protocol')=='loopback' for e in outs.values()):self.issue('LOOPBACK_GRAPH_REVIEW','$.outbounds','Граф повторной dispatch-маршрутизации зависит от правил; статический DFS проверяет только dialerProxy.','COVERAGE','WARNING')

    def config(self,o: Any,as_stream: bool=False) -> list[dict[str,str]]:
        try:
            safe_shape(o)
            schema_checks.check(self,o,as_stream)
            o=sem.normalize_config(o,as_stream)
            if as_stream:
                self.stream(o)
                sem.check(self,{'outbounds':[{'streamSettings':o}]})
                return self.issues
            if not isinstance(o,dict):self.issue('ROOT_OBJECT','$','Требуется JSON object.');return self.issues
            self.unknown(o,ROOT_KEYS,'$')
            if o.get('reverse') is not None:self.issue('LEGACY_REVERSE_REMOVED','$.reverse','Legacy reverse удалён; используйте VLESS Reverse.','SOURCE_BUILD')
            if o.get('transport'):self.issue('GLOBAL_TRANSPORT_REMOVED','$.transport','Глобальный transport удалён.','SOURCE_BUILD')
            for side in ('inbounds','outbounds'):
                es=o.get(side,[])
                if not isinstance(es,list):self.issue('ARRAY','$.'+side,'Требуется массив.');continue
                for i,e in enumerate(es):
                    p=f'$.{side}[{i}]';self.endpoint(e,p,side)
                    if isinstance(e,dict) and 'streamSettings' in e:self.stream(e['streamSettings'],p+'.streamSettings')
            self.routing_dns(o);self.graph(o);sem.check(self,o);topology_checks.check_config(self,o)
        except (TypeError,ValueError,KeyError,AttributeError,RecursionError,OverflowError):
            # Fail closed for malformed shapes; never convert an internal diagnostic failure into PASS.
            self.issue('STRUCTURE_UNSUPPORTED','$','Некорректная либо слишком сложная структура; проверка прекращена. Значения скрыты.')
        return self.issues


def canonical_id(value: Any) -> str:
    return peer_checks.canonical_id(value)


def check_pair(client: dict,server: dict,outbound_tag: str|None=None,inbound_tag: str|None=None,*,direct: bool=False) -> list[dict[str,str]]:
    v=Validator()
    try:
        safe_shape(client);safe_shape(server)
        client=sem.normalize_config(client);server=sem.normalize_config(server)
    except (ValueError,TypeError,RecursionError):
        v.issue('PEER_STRUCTURE','$','Некорректная структура пары.');return v.issues
    if not isinstance(client,dict) or not isinstance(server,dict):v.issue('PEER_OBJECT','$','Нужны два полных объекта.');return v.issues
    try:
        co=[e for e in client.get('outbounds',[]) if isinstance(e,dict) and (e.get('tag')==outbound_tag if outbound_tag else e.get('protocol') in ('vless','hysteria','masque','trojan','vmess','socks','mixed','http'))]
        se=[e for e in server.get('inbounds',[]) if isinstance(e,dict) and (e.get('tag')==inbound_tag if inbound_tag else e.get('protocol') in ('vless','hysteria','masque','trojan','vmess','socks','mixed','http'))]
        if len(co)!=1 or len(se)!=1:v.issue('PEER_AMBIGUOUS','$','Выберите ровно одну сторону через --outbound-tag / --inbound-tag.');return v.issues
        c,b=co[0],se[0];cs=c.get('streamSettings',{});bs=b.get('streamSettings',{})
        if not isinstance(cs,dict) or not isinstance(bs,dict):raise ValueError()
        cn,bn=network(cs),network(bs);ct,bt=settings(cs),settings(bs)
        if c.get('protocol')!=b.get('protocol') and not proxy_edge_checks.compatible(c.get('protocol'),b.get('protocol')):v.issue('PEER_PROTOCOL','$','Протоколы сторон различаются; внешний преобразователь этим checker не моделируется.')
        if cn!=bn:v.issue('PEER_TRANSPORT','$','Разные транспорты; topology/proxy mapping необходимо проверять отдельно.')
        if cs.get('security','none')!=bs.get('security','none'):v.issue('PEER_TERMINATION','$','Различная security допустима при явно заданном TLS termination; прямую пару это не доказывает.','COVERAGE','WARNING')
        if cn in ('websocket','httpupgrade'):
            def pathval(s):
                p=s.get('path') or ''
                p=p.split('?',1)[0]
                return p if p.startswith('/') else '/'+p
            if pathval(ct)!=pathval(bt):v.issue('PEER_PATH','$','Эффективные path различаются; без rewrite это не согласованная пара.')
        if cn==bn:http_peer_checks.check(v,c,b,cs,bs,ct,bt,cn)

        if c.get('protocol')=='vless':
            ca,_=vless_account(c);o=b.get('settings',{});us=o.get('clients',o.get('users',[]));matches=[u for u in us if isinstance(u,dict) and canonical_id(u.get('id',''))==canonical_id(ca.get('id',''))]
            if not matches:v.issue('PEER_AUTH','$','Клиентский id не найден на сервере; значения credentials скрыты.')
            else:
                sf=matches[0].get('flow') or o.get('flow','');cf=ca.get('flow','').removesuffix('-udp443')
                if cf!=sf:v.issue('PEER_FLOW','$','Различные flow; TCP и XUDP требуют раздельной проверки.')
            ce=ca.get('encryption');de=o.get('decryption')
            if (ce=='none')!=(de=='none'):v.issue('PEER_ENCRYPTION','$','Только одна сторона включает VLESS Encryption.')
            elif ce!='none':protocol_checks.encryption_pair(v,ce,de)
        elif c.get('protocol')=='hysteria':
            us=b.get('settings',{}).get('clients',b.get('settings',{}).get('users',[]))
            if not any(isinstance(u,dict) and u.get('auth')==ct.get('auth') for u in us):v.issue('PEER_AUTH','$','Hysteria auth не найден на сервере.')
        elif c.get('protocol')=='masque':
            us=b.get('settings',{}).get('clients',b.get('settings',{}).get('users',[]))
            if not any(isinstance(u,dict) and u.get('email')==ct.get('user') and u.get('pass')==ct.get('pass') for u in us):v.issue('PEER_AUTH','$','MASQUE user/pass не совпадает с серверной записью.')
        if c.get('protocol') in ('vmess','trojan'):protocol_checks.check_pair(v,c,b)
        proxy_edge_checks.check_pair(v,c,b)
        if direct:topology_checks.check_direct_pair(v,c,b)
        if cn==bn:peer_checks.check(v,c,b,cs,bs,ct,bt,cn)
    except (TypeError,ValueError,AttributeError,KeyError,RecursionError):v.issue('PEER_STRUCTURE','$','Неподдержанная структура пары; проверка не завершена.')
    return v.issues


def read(path: Path) -> Any:
    if path.stat().st_size>16*1024*1024:raise ValueError('Input exceeds16MiB')
    return old.loads(path.read_text(encoding='utf-8-sig'))


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('file',type=Path);ap.add_argument('--stream',action='store_true')
    ap.add_argument('--peer',type=Path);ap.add_argument('--outbound-tag');ap.add_argument('--inbound-tag')
    ap.add_argument('--direct-peer',action='store_true',help='Assert no NAT, frontend or port rewrite between selected peers')
    ap.add_argument('--json',action='store_true');a=ap.parse_args()
    if a.direct_peer and (not a.peer or a.stream):ap.error('--direct-peer requires --peer and full configs')
    try:
        obj=read(a.file);v=Validator();issues=v.config(obj,a.stream)
        if a.peer:
            peer=read(a.peer);pv=Validator();pi=pv.config(peer)
            issues+= [{**x,'path':'PEER:'+x['path']} for x in pi]
            issues+=check_pair(obj,peer,a.outbound_tag,a.inbound_tag,direct=a.direct_peer)
        n=sum(x['severity']=='ERROR' for x in issues)
        out={'schema_version':1,'core_tag':'v26.9.30','core_commit':old.SHA,'scope':'L0 authoring checks; NOT a complete core schema','core_test_run':False,'network_test_run':False,'status':'FAIL' if n else 'PASS_STATIC_ONLY','issues':issues,'peer_topology':'DIRECT_DECLARED' if a.direct_peer else ('UNDECLARED' if a.peer else 'NOT_REQUESTED')}
        if a.json:print(json.dumps(out,ensure_ascii=False,indent=2))
        else:
            print(out['status']+' — core/runtime NOT_RUN')
            for x in issues:print(f"{x['severity']} {x['code']} {x['path']}: {x['message']}")
            print(f'{n} ошибок; {len(issues)-n} предупреждений.')
        return 1 if n else 0
    except (OSError,ValueError,RecursionError):
        print('INPUT_ERROR: файл не прочитан либо JSON некорректен; содержимое не выводится.',file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
