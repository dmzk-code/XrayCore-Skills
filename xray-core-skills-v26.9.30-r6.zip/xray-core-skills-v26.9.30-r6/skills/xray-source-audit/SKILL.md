---
name: xray-source-audit
description: "Проверка знаний Xray-core по исходникам и точной версии: JSON→Build→runtime, commit/blob provenance, статический полный конфиг/пара, лаборатория и различение PASS/NOT_RUN."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# Проверка исходников и инструменты
Сначала [общий контракт](../xray-config-orchestrator/references/contract.md). Проверенные файлы и диапазоны — [provenance](references/provenance.json), JSON transport inventory — [fields](references/transport-fields.json). Не считать факт загрузки неизвестного поля доказательством применения.

## Правило исследования
Проследить доступность через JSON tag, Unmarshal/alias, Build/default/validation, protobuf transfer, зарегистрированный Dial/Listen, runtime usage на обеих сторонах, зависимость и тест. Каждое наблюдение снабдить commit/path/symbol, отделить фактическую ветку от inference и от авторской политики.

## Инструменты
`source_probe.py <checkout>` сверяет pinned blobs, commit, dirty/untracked tree и возвращает REVIEW_REQUIRED при расхождении. Checkout не переключать и не менять; брать отдельную копию нужного релиза. Regex tags — только inventory.

`validate.py config.json --peer server.json --json` — основной расширенный L0 checker, включая граф tags/dialerProxy, VLESS/native protocols, DNS/routing, masks и peer. `lint_config.py` оставлен как backward-compatible transport-only интерфейс.

`build_lab.py --out <new-dir> --all` создаёт22 тестовые схемы. `run_lab.py <lab> --xray <trusted-path> --sha256 <trusted-hash> --allow-lab-execution --report <new-file>` запускает ядро только по явному разрешению. Это не sandbox для неизвестного executable. Не вызывать runtime для пользовательского production конфига без отдельного разрешения.

Ошибки входного JSON и type mismatch не должны давать PASS. Неизвестные schemas/protocol options помечать COVERAGE, не уверенно валидировать по чужой версии. Полное описание: [testing](../xray-runtime-validation/references/testing.md).

## Индекс согласованной библиотеки r6
[Карта знаний и границ доказательства](../xray-config-orchestrator/references/knowledge-map.md). Версию поля проверять по pinned источнику, внешнюю среду — отдельным bounded тестом.

В r4 доступны `run_r4_regressions.py` (native+peer) и `run_control_lab.py` (API/Metrics/counters). Оба требуют `--execute --xray PATH --sha256 HASH --out NEW_DIR`. X25519 backend optional; без него ключи не объявляются проверенными.

## Сборка нескольких исходных конфигов
Используй `scripts/compose_config.py` и [правила Config.Override](../xray-config-orchestrator/references/composition.md), а не recursive merge. Отчёт не содержит значений credentials; запись merged требует явного нового файла.
