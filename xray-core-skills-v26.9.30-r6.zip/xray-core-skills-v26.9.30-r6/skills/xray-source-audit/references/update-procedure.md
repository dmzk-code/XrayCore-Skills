# Порядок обновления скиллов

1. Определить опубликованный релиз и канал stable/pre-release по official releases; записать полный commit и фактическую версию бинарника. Не подменять production release без требования пользователя.
2. Получить отдельный чистый checkout нужного commit. source_probe на старой версии должен отличитьMATCH отREVIEW_REQUIRED; несовпадение — сигнал анализа, не команда git reset.
3. Сравнить JSON tags, builders, runtime Dial/Listen, security/protocol wrappers, Finalmask loaders, новые/удалённые типы, aliases/defaults, go.mod и тесты. Добавление поля в proto без JSON Build→consumer не даёт пользовательскую поддержку.
4. Обновить карточки fields/runtime-peer, compatibility и машинные inventories. Для каждого изменённого правила — позитивная и негативная регрессия, category SOURCE_BUILD/RUNTIME/INFERENCE/POLICY. Новые неподтверждённые сочетания пометитьUNKNOWN, а не copied PASS.
5. Обновить renderer сценариев, при необходимости новые peer/frontend схемы. Перегенерировать **все** assets из make_pair и исключить реальные ключи.
6. Запустить собственные tests, actual core config cases, TCP/UDP/auth/restart и ограниченную нагрузку; известные ошибки старого релиза проверить повторно. Actual FAIL сохранить. Долгие resource/mobile/CDN тесты проводить отдельно.
7. Обновить VERSION.lock, provenance с blob hashes и реальным объёмом прочитанного, runtime evidence, CHANGELOG и SHA256SUMS. Blob hash подтверждает точный файл, но не факт исполнения каждой его ветки.
8. Через install.py --replace установить весь согласованный набор, сохранить backup для rollback. Активацию проверить в новой сессии конкретного агента явным именем skill; не предполагать её по наличию файла.

Нельзя считать актуализацией одну замену v26.9.30 на новую строку. Код знаний и тесты должны изменяться вместе.
