# MASQUE / CONNECT-IP: поведение и ловушки

- MASQUE здесь имеет и transport, и proxy/protocol реализацию. Собирать согласованную native пару, а не произвольный VLESS stream поверх CONNECT-IP без доказательства совместимости.
- TLS обязательно проверяется runtime. Клиент выбирает H2, если ALPN содержит h2 и НЕ содержит h3; иначе H3. Это отличается от XHTTP, где проверяется длина ALPN списка.
- Сервер запускает H2 при наличии h2; H3 при наличии h3 ИЛИ отсутствии h2. Поэтому [h2,h3] открывает TCP+UDP listeners на порту, а клиент при этом выбирает H3, не последовательный fallback.
- Серверный listen не принимает domain address в прочитанном Listener; использовать локальный IP.
- Проверка path на сервере — точное совпадение пути и query map. Звёздочка после замены URI template не является универсальным произвольным glob-matching маршрутов.
- user/pass преобразуются в клиентский Authorization. Серверный transport передаёт request в protocol handler; аутентификацию задавать в settings.users, не рассчитывать на transport user/pass как на ACL listener.
- Client protocol settings: address, port, remoteDNS (только IP literal). Server: users/clients, address (CIDR), mtu. Требуется address; максимум один IPv4 и один IPv6 prefix; mtu=0 либо 1280–65535.
- Server users: непустые email и pass; email без ':'; дубликаты email проверяются без учёта регистра. clients при наличии заменяет users.
- CONNECT-IP требует фактического назначения адреса и полезного packet size не меньше 1280. Успешный TLS/HTTP handshake ещё не означает готовый tunnel.
- H3 congestion пусто/bbr/brutal в прочитанном dialer/hub используют BBR, а force-brutal отдельную ветку. Не переносить Hysteria переговоры bandwidth по одному названию brutal.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [infra/conf/masque.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/masque.go)
- [transport/internet/masque/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/dialer.go)
- [transport/internet/masque/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/hub.go)
