# MASQUE: protocol-only coupling, CONNECT-IP и ALPN

## Жёсткая связь
MASQUE transport допускается только с protocol=masque на inbound и outbound. MASQUE outbound с enabled Mux отвергается. Это не универсальная транспортная обёртка для VLESS. Native client settings содержит address/port/remoteDNS, auth лежит в masqueSettings.user/pass либо допустимом Authorization header.

## H2 и H3
Client usesHTTP2: ALPN содержитh2 и не содержитh3. Иначе выбирается H3. Это другой алгоритм, чем XHTTP. Server открывает TCP H2 при наличииh2; H3 открывается при h3 либо отсутствииh2. Поэтому MASQUE server [h2,h3] действительно может слушать оба внешних протокола, а клиент с этим списком выбираетH3 и не обещает автоматический fallback.

H2 требовательно проверяет negotiated protocol=h2, реализует extended CONNECT. H3 включает datagrams. Generic HTTP reverse proxy нельзя объявлять совместимым без CONNECT-IP. TLS config нужен на обеих сторонах.

## IP назначения / адреса
Client отправляет CONNECT-IP request, требует packet size не ниже1280, запрашивает IPv4/IPv6 assignment и ждёт хотя бы один пригодный address. Успешный TLS handshake без выдачи адреса — ещё не туннель. remoteDNS допускает только IP literals и принадлежит native settings.

Server settings.address требует минимум один prefix, не более одного на семейство. users.email непустой и без ':', pass непустой, email уникален case-insensitive. Клиентский user соответствует серверному email. settings.clients nonnil заменяет users.

## Path и headers
MASQUE path поддерживает только заданные target/ipproto шаблоны, преобразуемые builder. Runtime pathMatcher сравнивает точный path и map query values; произвольные query изменения могут дать404. Host/capsule-protocol запрещены в headers; Authorization конфликтует с user/pass. У User-Agent есть короткие aliases, отсутствие UA имеет собственную ветку.

Сценарии masque-h2 / masque-h3 отличаются транспортным ALPN, но не моделью auth. Для UDP полезного трафика тестировать SOCKS UDP echo отдельно от внешнего UDP H3.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [infra/conf/masque.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/masque.go)
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)
- [transport/internet/masque/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/dialer.go)
- [transport/internet/masque/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/hub.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `masque-h2`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `masque-h3`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
