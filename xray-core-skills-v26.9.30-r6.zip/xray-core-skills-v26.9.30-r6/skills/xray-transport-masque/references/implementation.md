# ALPN и CONNECT-IP

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Client H2 выбирается, когда ALPN содержит h2 и не содержит h3; иначе H3. Сервер может поднять TCP H2 и UDP H3 в зависимости от ALPN, в отличие от XHTTP. TLS обязателен. Masque transport допускается только native masque protocol; enabled Mux отвергается.

MasqueSettings.host/path/headers/user/pass — HTTP CONNECT-IP уровень; server protocol.users — авторизация. Нельзя подставлять VLESS UUID. server path+query сопоставляются точно, path поддерживает target/ipproto переменные с нормализацией. User-Agent aliases реализованы клиентом. Пакет должен помещаться в negotiated IP tunnel; для localhost-теста использовать тестовую внутреннюю нелокальную IP цель и отдельный endpoint redirect, не принять gVisor martian-policy за транспортную ошибку.

## Исходники
- [transport/internet/masque/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/dialer.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
