# MASQUE / CONNECT-IP: сложные схемы

Рецепты — процедуры для агента, не уже испытанные production deployments.

### H2-only за TCP-доступом
Задать TLS ALPN [h2] на обеих сторонах. Проверить extended CONNECT и CONNECT-IP, а не обычный HTTP proxy. Сверить user/pass клиента и email/pass server users, выдачу IP адресов и remoteDNS. Обычный reverse proxy может не поддержать данный туннель.

### H2 + H3 listener
Выделить TCP и UDP port mapping явно; сертификаты и маршруты должны обслуживать оба. Проверить отсутствие UDP bind conflict с другим QUIC сервисом. План H3→H2 fallback реализовать отдельными outbound/маршрутами, не выдавая один ALPN список за failover.

## Обязательный отрицательный тест
Проверить неверные auth/host/path или peer-поля, обрыв канала, reconnect после рестарта backend и одновременные соединения. Наблюдаемая ошибка должна соответствовать неисправному уровню; не лечить любой отказ выключением проверки сертификата.
