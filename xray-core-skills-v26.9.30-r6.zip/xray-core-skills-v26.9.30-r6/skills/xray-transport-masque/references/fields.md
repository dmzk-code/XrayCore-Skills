# MASQUE / CONNECT-IP: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри masqueSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `host` | `string` | Authority; проверяется как валидный host в https URL. Не задавать через headers.Host. |
| `path` | `string` | Пусто → DefaultPath из masque/config.go. Поддерживает только переменные target/ipproto и перечисленные query-expansion формы. |
| `user` | `string` | Клиентское Basic username; запрещён двоеточие. При user или pass создаётся Authorization. |
| `pass` | `string` | Клиентский Basic password; не определяет самостоятельно список пользователей на сервере. |
| `headers` | `map[string]string` | Валидные HTTP имена/значения; host и capsule-protocol запрещены; Authorization конфликтует с user/pass. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.
