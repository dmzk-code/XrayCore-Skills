# Frontend: что сохранять

| Схема | Требования |
|---|---|
| RAW/REALITY | L4 passthrough; обычный HTTP proxy_pass не сохраняет TLS handshake |
| XHTTP H1 packet-up | preserve host/path/query, body/header/cookie metadata; cache off; request/response buffering off; суммарные header/body limits |
| XHTTP H2 stream-up/one | front supports streaming request and response; проверить backend HTTP mode, не заменять HTTP на gRPC по одному Content-Type |
| WS | HTTP/1.1 Upgrade/Connection передаются явно; настроить read timeout; backend path должен совпадать |
| HTTPUpgrade | передать одиночный Connection: upgrade, не список токенов; после 101 нет WS framing |
| gRPC | H2/gRPC frontend, согласованный serviceName и custom stream names; использовать grpc_pass только для соответствующего gRPC backend |
| MASQUE | CONNECT-IP и H2 extended CONNECT / H3 datagrams требуют конкретной поддержки; обычный reverse-proxy пример не доказывает её |
| Hysteria/H3 | UDP должен проходить до нужного QUIC endpoint; HTTP TLS termination не автоматически проксирует native Hysteria |
| XDRIVE | storage API path/auth/quotas; обычный сайт перед Xray listener не заменяет storage |

TLS external и plaintext loopback backend — допустимая топология, но не называть её end-to-end TLS. Для недоверенного межсерверного backend требуется отдельная защищённая линия. REALITY нельзя «закончить» на обычном HTTP frontend и ожидать прежний handshake.

Безопасный XFF: доверять только IP настоящих frontend и перезаписывать клиентские forwarded headers на внешней границе. `acceptProxyProtocol` не является разрешением доверять любому клиенту; отправитель PROXY обязан быть ограничен listener/firewall/сетью. При неточном whitelist сохранить реальный remoteAddr, не подменять произвольным XFF.

Path Nginx: proxy_pass без URI сохраняет исходный request URI; с URI и trailing slash возможна замена prefix. Для split fixtures используется один backend и отсутствие подмены URI. Согласовать exact/normalized path и sessionID location. H1 path/query поведение отличается от gRPC service path; не делать общий rewrite на все транспорты.

Frontend-таймауты не заменяют heartbeat транспортов. При тесте обрыва одного плеча ожидать ограниченное завершение/переподключение, а не бесконечное зависание. H2/H3 ALPN клиента не доказывает версию HTTP frontend→backend.

CDN лимиты, разрешённые порты, WebSocket/gRPC/CONNECT поддержка и антибот-фильтры проверяются по текущим официальным документам провайдера и реальным запросом. В этом пакете нет утверждения, что любой CDN поддерживает все варианты XHTTP.


## Первичные источники pinned commit
- [transport/internet/websocket/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/websocket/hub.go)
- [transport/internet/httpupgrade/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/httpupgrade/hub.go)
- [transport/internet/grpc/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/hub.go)
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
- [transport/internet/masque/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/hub.go)
