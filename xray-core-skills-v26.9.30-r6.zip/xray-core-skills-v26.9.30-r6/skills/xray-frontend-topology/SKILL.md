---
name: xray-frontend-topology
description: "Nginx/L4 passthrough, TLS termination, XHTTP split upload/download, WS/gRPC/HTTPUpgrade frontend и session affinity; создание согласованных frontend/backend конфигураций."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# Frontend и topology
Прочитай [контракт](../xray-config-orchestrator/references/contract.md) и [правила frontend](references/frontend.md). Нельзя считать frontend прозрачным: выпиши преобразования Host/path/ALPN/PROXY/XFF, streaming, cache и ограничения.

Используй пример XHTTP split с одним backend listener из общего assets/scenarios. Внешние два порта не должны стать двумя независимыми Xray session-owner. Для TLS-клиента укажи точку termination и доверенный сертификат каждого плеча.

Проверь nginx -t в отдельном prefix, затем proxying с реальным ядром. Правильный синтаксис Nginx не доказывает CONNECT-IP/CDN/streaming совместимость. Не применять конфиг к рабочему Nginx автоматически.

## Индекс согласованной библиотеки r6
[Карта знаний и границ доказательства](../xray-config-orchestrator/references/knowledge-map.md). Версию поля проверять по pinned источнику, внешнюю среду — отдельным bounded тестом.
