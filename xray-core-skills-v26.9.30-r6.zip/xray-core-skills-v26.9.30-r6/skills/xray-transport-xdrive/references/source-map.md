# Источники и границы: xdrive

Core `b26a91de4f3294e26a0ad0a970b81a386a41f789`; r2.


## Основание на закреплённом commit
- [transport/internet/xdrive/xdrive.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/xdrive.go)
- [transport/internet/xdrive/params.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/params.go)
- [transport/internet/xdrive/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/client.go)
- [transport/internet/xdrive/template.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/template.go)

Полные диапазоны и Git blob SHA: [provenance](../../xray-source-audit/references/provenance.json).
Не загружать все исходники заново для стандартного рецепта. Сначала использовать fields.md и runtime-peer.md.
Повторное исследование обязательно для другого commit, нестандартной обёртки, новой зависимости, неподтверждённой ветки либо расхождения теста с описанием. Статус прочитанного файла не равен покрытию всех вызываемых зависимостей.
