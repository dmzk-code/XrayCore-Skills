# XDRIVE: хранилища, шаблон API, OAuth, очереди и границы защиты

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

## Модель передачи и криптография
Транспорт передаёт байты потоков через объекты общего хранилища. Client пишет announcement `sessions/<UnixNano>-<sessionID>` и c2s, server читает announcement и пишет s2c. Listen/Dial не означают обычный входящий TCP listener с remote endpoint. Обе стороны должны видеть одно и то же namespace и иметь необходимые операции чтения/записи/удаления/list. Несколько независимых server процессов в одной папке могут конкурировать за announcements: process-local claim не является распределённой блокировкой.

`streamSettings.security:"tls"` у XDRIVE настраивает HTTP-доступ к провайдеру, **не шифрует end-to-end содержимое `.seg` в хранилище**. В WAL байты поступают прямо в storage.Put. Для защиты от оператора/читателя хранилища использовать проверенную протокольную encryption, например согласованную VLESS Encryption; одного `https://` API недостаточно. Local storage также не шифрует файлы.

## Все настройки транспорта
| Поле | Default / ограничения | Значение |
|---|---|---|
| `service` | Нет default; точные строки `local`, `Google Drive`, `template` | Выбор реализации. |
| `remoteFolder` | Непустой для local и Google Drive при создании storage | Путь локального каталога / Google folder ID / переменная шаблона. |
| `secrets` | Array strings; Google требует ровно 3 непустые строки | Google: clientID, clientSecret, refreshToken; template: secret0, secret1… |
| `segmentBytes` | 0 → 524288; максимум16777216, больше молча clamp | Предельный размер одного WAL-сегмента, байты. |
| `flushIntervalMs` | 0 → 20ms | Tick writer; растущий buffer может удерживаться до 8 coalesced ticks, не гарантированный flush каждые20ms. |
| `pollIntervalMs` | 0 → 50ms | Минимальная пауза reader/listener. |
| `maxPollIntervalMs` | 0 → 500ms; ниже min повышается до min | Верхняя пауза экспоненциального backoff polling. |
| `sessionTtlSeconds` | 0 → 300s | Устаревание announcement и уборка заброшенных sessions; часы сторон должны быть согласованы. |
| `concurrency` | 0 → 8; максимум64, больше clamp | Параллельные upload/fetch WAL, не глобальный лимит API. |
| `eagerWindowMs` | 0 → 2000ms | После активности polling остаётся быстрым. |
| `holeTimeoutMs` | 0 → 30000ms | Пропуск ожидаемого seq при наличии более поздних завершается ошибкой после срока. |
| `template` | Нужен для service=template | Объект API, разобран ниже; не относится к native Google Drive. |

Поле объявлено как uint32: отрицательное JSON-число не следует подставлять вместо «выключить». Для отключения polling нет специального zero-disable: нули включают defaults.

## Полный template
Корень: `flatten:bool` (false), `concurrency:int` (<=0 →32; >256 →256), `auth:object`, `put/get/delete/list:object`, `retry:object`.
Четыре операции обязательны: в каждой должен быть непустой `url`. `list.namesRegex` обязателен, валиден как Go regexp, должен иметь хотя бы одну capture group. Используется **первая** группа; неверное имя объекта ломает WAL даже при HTTP200.

Поля операции: `method:string` (пустой → GET), `url:string`, `headers:map[string]string`, `body:string`, `namesRegex:string`. **body применяется только к put**, а namesRegex только к list. Не рассчитывать, что get.body/delete.body/list.body будут отправлены. Put.body при наличии получает `{data}` как standard base64; Get всегда возвращает необработанные response bytes и автоматически не декодирует JSON/base64. Endpoint должен вернуть исходные байты сегмента.

Подстановки — буквальная `strings.ReplaceAll`, без JSON/XML/form/URL escaping:
`{folder}`, `{secret0}`, `{secret1}`…; `{name}` для put/get/delete; `{prefix}` для list; `{data}` только put.body; `{token}` после получения OAuth token. Это не полноценный шаблонизатор: неизвестные placeholders не обязаны дать ошибку, рекурсивные подстановки зависят от map iteration; не делать secrets зависимыми от других placeholders. Ключи headers не подставляются.

При flatten=true `/` заменяется на `~`; listing ожидает полные flat names, фильтрует по flatPrefix+`~`, возвращает прямой child и удаляет дубли. При false regex должен выдавать непосредственные имена детей, не весь путь. Pagination для template не реализована: list endpoint должен отдавать весь нужный набор за запрос либо реализовывать агрегацию снаружи. Delete prefix должен удалять дерево/namespace, иначе уборка оставит файлы.

## Полный auth
`type`: `""/none`, `static`, `basic`, `oauth2`. `header` — **единственное число**, map string→string. `username/password` используются basic; `tokenUrl`, `form:map[string]string`, `tokenPath`, `expiryPath` — oauth2. Не использовать `headers` вместо `header` внутри auth.

Static: подставленные auth.header. Basic: standard base64(username+":"+password) в Authorization. OAuth2: POST к tokenUrl; auth.form значения подставляются, но form строится соединением `key=value` через `&` **без url.Values.Encode** (в отличие от native Google). Символы `&`, `+`, `=` и `%` требуют корректной подготовки значений/endpoint. TokenUrl сам не проходит subst в этой ветке.

Требуется HTTP200; response читается с пределом1MiB. tokenPath пустой → access_token; token должен быть непустой строкой. Lifetime default3600s; expiryPath берётся только при положительном числовом значении; если lifetime>60, отнимается60s. Доступ к cache token синхронизирован. HTTP401 сбрасывает token и повторяет операцию. Endpoint-specific refresh grants задаются form; отдельной встроенной логики discovery/OIDC нет.

`op.headers` накладываются после auth.header и могут перезаписать Authorization. Не создавать случайно противоречащие формы авторизации. Ответы с ошибками могут включаться в upstream log: использовать отдельные тестовые credentials и не публиковать такой log без redaction.

## retry и статусы
`retry.status` — array HTTP codes; `retry.rateReason` — путь к непустой строке в JSON при HTTP403. Если строка по пути непустая, это условие retry, а не сравнение с конкретным именем rate-limit. Без retry.status обычные 429/5xx в template автоматически не добавляются в retry-list. Сетевые ошибки и OAuth401 повторяются независимо. До8попыток; начальный backoff200ms, удвоение до8s; случайная пауза в нижней половине интервала; context отменяет ожидание. HTTP client timeout60s на один запрос, не на все8попыток вместе.

Put успешен на2xx. Get2xx возвращает body,404→notFound. Delete2xx/404успешен. List404→пустойсписок,2xx→regex parsing. Повторы Put должны быть безопасны при повторении одного object name: template backend должен поддерживать idempotent replace; не считать все POST провайдеров идемпотентными.

## Native Google Drive
Folder ID обязателен. Exactly3 непустых secrets. OAuth refresh form кодируется штатным url.Values.Encode; expires_in обрезается на60s если>60, нулевой expiry не заменяется автоматически3600s. 401→invalidate; 403retry только при rateLimitExceeded/userRateLimitExceeded/sharingRateLimitExceeded или RESOURCE_EXHAUSTED; также429/500/502/503/504. До8 попыток, API client60s, global storage inflight32. Listing pageSize1000 с nextPageToken до конца, supportsAllDrives/includeItemsFromAllDrives.

Имена flatten через `~`. <=12000bytes сохраняются как base64 description metadata, больше — multipart media. При Get сначала media; пустое тело заставляет читать description. Это не шифрование и не маскировка содержимого от провайдера. List может передавать Inline bytes reader без отдельного GET. Кэш name→ID инвалидируется после404/delete. Удаление ищет prefix children. Квоты сервиса не определяются настройкой WAL concurrency.

## Shared storage: приоритет первого объекта
Ключ sharedStorage = service + remoteFolder + secrets + SecurityType + destination.NetAddr. В него **не входят template, TLS certificate/SNI/fingerprint и sockopt**. При совпавшем ключе возвращается ранее созданный storage: отличающиеся template/TLS/sockopt во втором stream могут не примениться. Не создавать в одном процессе такие конфликтующие определения; статический валидатор r3 сообщает collision. Изменение JSON не гарантирует новую реализацию при live reload без сброса процесса.

## WAL, память и отказ
Сегменты имеют seq, `.seg`/`.end`/`.err`; reader выдаёт их по порядку, загружая contiguous batch до concurrency. Hole timeout стартует, когда более поздние segments уже есть; это не общий idle timeout. Первая ошибка upload фиксируется и пишется err marker. При закрытии writer высылает остаток, ждёт uploads, затем end marker. Reader удаляет использованные объекты через ограниченную очередь, переполненное discard-задание может быть пропущено и убрано позднее.

Concurrency ограничивает одновременно работающие upload-запросы семафором, **не число созданных goroutines/накопленных chunk bytes**: writer создаёт upload goroutines до захвата semaphore. Большой быстрый producer и медленное хранилище требуют ограничения нагрузки снаружи, а не обещания памяти `segmentBytes×concurrency`. Персистентность облачных объектов не означает возобновление произвольного TCP-соединения после рестарта.

Local Put: временный файл в том же каталоге, запись, close, rename; mkdir0700; temp names скрываются listing; Delete использует RemoveAll внутри корня. У root-папки должны быть ограниченные права; не применять к чужой пользовательской папке. Ни local, ни template не следует проверять на рабочем облачном каталоге без отдельного разрешения.

## Исходники
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/xdrive/params.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/params.go)
- [transport/internet/xdrive/xdrive.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/xdrive.go)
- [transport/internet/xdrive/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/client.go)
- [transport/internet/xdrive/storage.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/storage.go)
- [transport/internet/xdrive/local.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/local.go)
- [transport/internet/xdrive/template.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/template.go)
- [transport/internet/xdrive/drive.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/drive.go)
- [transport/internet/xdrive/wal.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/wal.go)
