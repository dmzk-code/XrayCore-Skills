# XDRIVE: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри xdriveSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `remoteFolder` | `string` | Идентификатор/путь папки backend; namespace обеих сторон должен соответствовать storage implementation. |
| `service` | `string` | Строго local, Google Drive или template; регистр важен. |
| `secrets` | `array[string]` | Google Drive требует ровно 3: ClientID, ClientSecret, RefreshToken. Не писать реальные значения в отчёт. |
| `segmentBytes` | `uint32` | Runtime 0→524288; cap 16777216. |
| `flushIntervalMs` | `uint32` | 0→20 мс. |
| `pollIntervalMs` | `uint32` | 0→50 мс. |
| `maxPollIntervalMs` | `uint32` | 0→500 мс; если ниже pollIntervalMs, поднимается до него. |
| `sessionTtlSeconds` | `uint32` | 0→300 секунд; точное JSON имя Ttl, а не TTL. |
| `concurrency` | `uint32` | 0→8; cap 64. Не равно template.concurrency. |
| `eagerWindowMs` | `uint32` | 0→2000 мс. |
| `holeTimeoutMs` | `uint32` | 0→30000 мс. |
| `template` | `object` | При service=template поле обязательно; подробная runtime схема ниже, не произвольный провайдерский JSON. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.

Подробные вложенные структуры: [storage-runtime.md](storage-runtime.md).
