# XDRIVE: namespace, объявления, storage session lifecycle

## Непривычная схема
Serve не открывает обычный TCP listener на переданном port: создаёт storage backend и accept/collect loops. Dial не использует dest как VPN socket; создаёт случайную16-byte sessionId, пишет `sessions/<UnixNano>-<session>` и открывает WAL-потоки `streams/<session>/c2s` и `s2c`. Общий JSON inbound всё равно требует корректную оболочку listen/port, если его builder не обошёл это правило.

Тест xdrive-local использует общую приватную папку на одном хосте. Для двух машин папка должна означать один реальный backend namespace, а не одинаковую строку локального path на разных дисках.

## Lifecycle
Accept loop сканирует announcements с minPollInterval, сохраняет активный eagerWindow, затем удваивает задержку до maxPollInterval. Неверные и старые announcements удаляются. Stale определяется timestamp и sessionTTL: часы сторон влияют на принятие.

active/handled maps предотвращают повторное принятие внутри одного Listener. Это **не распределённый lock** между двумя серверными процессами, подключёнными к одному namespace. Масштабирование несколькими читателями требует отдельного решения, иначе оба могут принять одну сессию.

Collect loop период sessionTTL/2, удаляет неактивные stream prefixes после наблюдаемого idleTTL, чистит handled. Close отменяет listener context и закрывает storage. Не ставить слишком короткий TTL для backend с большими задержками, иначе сборка мусора конфликтует с доставкой.

## Криптография и storage
TLS backend защищает HTTP-плечо к storage, но не означает, что загруженные объекты доступны только пользователям VPN. Для cloud use обязательно выбрать end-to-end protocol protection и доступ к storage по минимальным правам. Локальная none-конфигурация — лишь тест без внешнего exposure.

## Template
Схема всех внешних параметров и cap values в fields/behavior. subst — обычный strings.ReplaceAll, не URL/JSON escaping. Отдельно ограничить размер/list pagination/retry у реального backend. Недоступные credentials, квоты и отказ storage должны давать ошибку backend, а не автоматически считаться непригодностью всего core.

Сценарий xdrive-local проверяет передачу через storage без облачных расходов. Его результат не переносится на Google Drive или произвольный HTTP template.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [transport/internet/xdrive/xdrive.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/xdrive.go)
- [transport/internet/xdrive/params.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/params.go)
- [transport/internet/xdrive/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/client.go)
- [transport/internet/xdrive/template.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/template.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `xdrive-local`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
