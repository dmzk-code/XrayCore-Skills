# XDRIVE: поведение и ловушки

- Это storage-based транспорт. Параметры polling/segments/TTL и квоты storage важнее привычной настройки TCP listener. Не обещать latency/throughput обычного RAW.
- Для service=Google Drive порядок secrets строгий; наличие трёх элементов не доказывает их действительность или доступность folder.
- Ноль у runtime params включает fallback. Значение concurrency=100 не даёт 100 worker: ограничивается 64. segmentBytes выше 16 MiB ограничивается, а не вызывает Build error.
- Template верхние поля: flatten, concurrency, auth, put, get, delete, list, retry. Операция: method,url,headers,body,namesRegex. Runtime требует URL всех четырёх операций и namesRegex в list с хотя бы одной capture group.
- Template auth: type,header,username,password,tokenUrl,form,tokenPath,expiryPath. Типы '',none,static,oauth2,basic; остальные вызывают runtime error. Header здесь в единственном числе.
- Template retry: status (array int), rateReason (string). Template concurrency: <=0 берётся provider default, >256 ограничивается 256. Это другой лимит, не xdriveSettings.concurrency=64.
- Подстановки template: folder, secret0/secret1/...; oauth2 добавляет token. Полный набор operation-specific переменных и escaping проверять в template.go перед конкретным backend рецептом. subst делает строковую замену, а не гарантированное URL/JSON escaping.
- HTTPS backend использует TLS даже без security=tls: newServiceClient создаёт стандартный TLS config по URL. Явные tlsSettings управляют этим плечом. TLS к storage НЕ доказывает end-to-end шифрование содержимого объектов; проверить защиту внутреннего protocol payload отдельно.
- Service client H2 выбирает только при ALPN ровно [h2] либо наличии REALITY runtime config. Но обычный StreamConfig.Build запрещает REALITY для network=xdrive. Наличие REALITY ветки в helper НЕ делает такое JSON сочетание допустимым.
- streamSettings.address/port может переопределять адрес TCP подключения к backend, сохраняя host логического URL. Не заполнять address произвольным VPN endpoint из шаблона: это изменяет storage connectivity.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/xdrive/params.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/params.go)
- [transport/internet/xdrive/template.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/template.go)
- [transport/internet/xdrive/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/client.go)
