# Cloud и template теперь описаны по consumers

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Полный справочник операций, auth, retries, substitutions, cache key, TTL и очередей: [storage-runtime](storage-runtime.md). service:Google Drive имеет родной provider handler, service:template — другой универсальный HTTP contract. Параметр service с иным написанием не выбирает дополнительного provider автоматически.

Локальные mock-тесты r3 проходят none/static/basic/oauth2 и инъекцию429 с retry. Это проверка реализованной HTTP-машины состояний, не квот/прав реального Google Drive. XDRIVE не слушает обычный TCP порт для хранения: endpoints и полеport проходят общий inbound Build, а передача идёт через storage. Публичность и шифрование объектов storage анализировать отдельно отHTTPS к API.

## Исходники
- [transport/internet/xdrive/xdrive.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/xdrive.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
