---
name: xray-legacy-migration
description: "Миграция старых Xray конфигураций на v26.9.30: removed transports, aliases, TLS pinning, mKCP masks, proxySettings, legacy reverse, VLESS layout и сохранение rollback."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# Миграция без молчаливой потери логики
Прочитать [контракт](../xray-config-orchestrator/references/contract.md), [приоритеты](../xray-config-orchestrator/references/effective-config.md), [совместимость](../xray-config-orchestrator/references/compatibility.md). Сохранить оригинал и diff; не перезаписывать credential/uuid/tag без необходимости.

Удалённые HTTP/h2/h3 transport и старый QUIC заменить осмысленным XHTTP режимом и парой, не одной сменой network. Non-removal deprecated WS/gRPC/HTTPUpgrade не удалять автоматически.

allowInsecure=true не переносить: организовать реальное доверие CA/leaf pin и обновление обеих сторон. `rawSettings` заменяет `tcpSettings`, `xhttpSettings` заменяет `splithttpSettings`; смешение aliases предупреждать. mKCP header/seed текущим Build не применяются: проверить Finalmask mkcp-legacy вместо притворного сохранения старого эффекта.

Outbound.proxySettings удалён → sockopt.dialerProxy с проверкой графа. Legacy root reverse удалён → VLESS Reverse с различием forward/reverse account и client/server fields. Global transport удалён → локальные streamSettings. Для freedom targetStrategy/старый settings.domainStrategy мигрируют в sockopt.domainStrategy и могут затереть уже заданную стратегию: устранить конфликт явно.

После изменения выполнять validate.py и доступные уровни core/peer tests. Не обещать backward compatibility несовпадающим third-party клиентам без собственной пары; сохранять резервный endpoint и rollback, но не менять работающий сервер в ходе анализа.

Обязательно учитывать [Freedom finalRules и private-target защиту](../xray-protocol-composition/references/freedom.md); successful accepted не гарантирует выход к локальному адресу.

## Индекс согласованной библиотеки r6
[Карта знаний и границ доказательства](../xray-config-orchestrator/references/knowledge-map.md). Версию поля проверять по pinned источнику, внешнюю среду — отдельным bounded тестом.
