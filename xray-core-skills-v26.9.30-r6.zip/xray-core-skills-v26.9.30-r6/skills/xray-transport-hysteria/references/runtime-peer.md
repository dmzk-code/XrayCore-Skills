# Hysteria2: auth, UDP manager, QUIC, masquerade

## Два разных способа использования
Нативный protocol=hysteria передаёт validator через context; server HTTP auth проверяет его users. При использовании только транспорта с другим stream-протоколом необходим transport auth. Если validator отсутствует и hysteriaSettings.auth пуст, Listen отвергает конфигурацию. Нативный UDP session manager запускается при наличии validator, а не просто при network=hysteria.

Auth handler принимает определённые Method/Host/Path, объявленные константами протокола. После успешного auth соединение запоминает пользователя. Произвольное перемещение этих значений в настройки XHTTP не влияет на native Hysteria.

## QUIC
Обязателен TLS config, внешний сокет UDP. Настройки congestion/окна теперь читаются из finalmask.quicParams. Server defaults окна stream8388608, connection20971520, idle30s, incoming streams1024. При congestion пусто/brutal BBR используется, если local brutalUp или peer объявленная скорость0; иначе Brutal получает min(localUp,peerDown). force-brutal не проводит такое согласование.

Клиент включает ChromeParrot по умолчанию; отключение меняет QUIC профиль. Проверка версий зависимостей важна: client датированная ветка OmitMaxDatagramFrameSize начинает действовать после2026-09-01UTC. Это поведение кода, не самостоятельное поле JSON. Поддержка Hysteria другого клиента проверяется соединением, не совпадением названия.

## Masquerade по runtime
`type` после lower-case: пусто/404 → NotFound; file → http.FileServer(dir); proxy → reverse proxy; string → headers/content/statusCode (0→200). Другой type ошибка. Для proxy URL http/https, пустая схема или unix используют разные backend dialers; unix отключает Proxy и задаёт прямой Unix dial.

rewriteHost=false сохраняет исходный Host; xForwarded=true вызывает SetXForwarded. insecure относится к TLS backend masquerade и отключает его проверку; в стандартных схемах false. Это не возвращает удалённый tlsSettings.allowInsecure и не делает выключение проверки безопасным.

Сценарий hysteria2 использует native users, TLS pin и defaults без искусственного завышения скорости. Неверный auth обязан не передавать полезный payload, даже если masquerade возвращает200.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [infra/conf/hysteria.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/hysteria.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/hysteria/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/hysteria/dialer.go)
- [transport/internet/hysteria/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/hysteria/hub.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `hysteria2`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
