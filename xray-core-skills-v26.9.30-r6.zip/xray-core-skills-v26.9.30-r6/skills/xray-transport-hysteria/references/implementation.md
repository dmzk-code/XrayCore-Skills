# Native protocol, masquerade и повторное соединение

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Нативная Hysteria2 имеет version2 одновременно в protocol и transport. Transport-only auth и native validator — разные режимы: native UDP dispatcher создаётся при наличии validator. У server с нетривиальным внутренним protocol должна быть auth в transport; пустой не означает разрешить всех.

Masquerade type404/пусто, file(dir), proxy(url,rewriteHost,xForwarded,insecure), string(content,headers,statusCode default200). Proxy поддерживает http/https и Unix socket путь; insecure относится к masquerade upstream, не клиентской проверке сертификата. client auth всегда по transport.auth; bytes/sec bandwidth интерпретацию смотреть QUIC reference. QUIC pool cache и idle30s влияют на обнаружение умершего сервера; факт initial-success не доказывает мгновенный reconnect.

## Исходники
- [transport/internet/hysteria/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/hysteria/dialer.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
