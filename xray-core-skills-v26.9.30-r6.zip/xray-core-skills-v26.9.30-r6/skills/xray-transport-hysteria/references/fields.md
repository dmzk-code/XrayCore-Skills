# Hysteria 2 transport: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри hysteriaSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `version` | `int32` | Обязательное эффективное значение 2; 0/пропуск поля внутри объекта вызывает Build error. |
| `auth` | `string` | Клиентская транспортная аутентификация; серверный users[].auth относится к protocol settings. |
| `udpIdleTimeout` | `int64` | 0→60 секунд; ненулевое значение 2–600. |
| `masquerade` | `object` | type, dir, url, rewriteHost, xForwarded, insecure, content, headers, statusCode; runtime проверяется в hub/masquerade. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.
