# Hysteria 2 transport: поведение и ловушки

- `network=hysteria` и `protocol=hysteria` — разные слои. Для native Hysteria2 пары сверить оба version=2 и auth: client hysteriaSettings.auth против server settings.users[].auth.
- Для client protocol settings: version, address, port. Для server protocol settings: version, users/clients с auth, level, email. Непустое по наличию clients заменяет users.
- Не помещать congestion, brutalUp, brutalDown, receive windows или параметры hopping в hysteriaSettings только потому, что они известны из другого клиента. В этом ядре QUIC-параметры лежат в streamSettings.finalmask.quicParams; конкретную структуру читать по pinned source.
- REALITY исключён StreamConfig. QUIC/H3 использует собственный handshake; нельзя приписывать ему обычный TCP uTLS fingerprint только по наличию tlsSettings.
- Клиентский runtime default: stream receive windows 8388608, connection receive windows 20971520, max idle 30 секунд, когда соответствующий параметр 0. Эти значения не означают, что каждое соединение немедленно выделяет весь объём RAM.
- У keepAlivePeriod в прочитанном Hysteria dialer нет активного default=10s: код такого default закомментирован. Не выдавать комментарий за выполняемое поведение.
- В dialer есть временная ветка OmitMaxDatagramFrameSize после 2026-09-01 UTC. Поэтому при проверке совместимости сохранять не только версию, но и дату/условия запуска.
- Congestion: reno оставляет стандартную ветку; bbr явный; пусто/brutal используют переговоры скоростей. Это отличается от XHTTP H3 и MASQUE; общей таблицы enum недостаточно для вывода о поведении.
- Внешний UDP, UDP внутри туннеля и UDP idle session — разные уровни. Измерять UDP echo/DNS отдельно от TCP download.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [infra/conf/hysteria.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/hysteria.go)
- [transport/internet/hysteria/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/hysteria/dialer.go)
