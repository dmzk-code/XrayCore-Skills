---
name: xray-security-sockopt-finalmask
description: "Общие слои Xray: TLS/REALITY, certificate pinning, ECH, sockopt по ОС, все зарегистрированные Finalmask и QUIC параметры. Используют транспортные скиллы."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# TLS / REALITY / sockopt / Finalmask
Прочитай [контракт](../xray-config-orchestrator/references/contract.md), [security](references/security.md), [sockopt](references/sockopt.md), [Finalmask](references/finalmask.md), [QUIC](references/quic.md), [платформы](references/platforms.md).

Проверь порядок обёрток и фактический consumer. Security выбирается полем security, не наличием блока. REALITY и TLS не включаются одновременно; ECH и certificate pinning проверяются отдельно от protocol Encryption. Вырезать секреты из отчётов.

Для Finalmask проверяй допустимый TCP/UDP type, вложенные поля, порядок и владельцев HandleDial/HandleListen; не менять порядок на второй стороне автоматически. Явно учитывать bytes overhead и MTU. Маски не являются универсальным шифрованием/аутентификацией.

Для socket options сопоставь GOOS, тип физического socket и права. Не предлагать Linux sysctl для Windows/Android. Для QUIC используй таблицу конкретного транспорта: общий Build enum не равен общей runtime поддержке.

Запусти validate.py, затем core config test и сетевую пару. При нестандартном сочетании сначала source evidence и bounded lab, потом рекомендации production.

## Обязательные consumers по использованным полям
[Маски](references/mask-runtime.md), [Realm/NAT](references/realm-runtime.md), [XMC](references/xmc-runtime.md), [платформенные sockets](references/socket-runtime.md), [DialSystem и chaining](references/dial-chain-runtime.md), [ECH](references/ech-runtime.md). Не заменять эти готовые результаты общим указанием «изучить код».

### TLS consumers — уточнение r4
До обещания min/max TLS-version или curve/cipher policy прочитать [различие Go TLS и uTLS copyConfig](../xray-config-orchestrator/references/peer-validation.md#tls-copyconfig-результат-отрицательного-теста). Пустой fingerprint не означает отсутствие uTLS.
