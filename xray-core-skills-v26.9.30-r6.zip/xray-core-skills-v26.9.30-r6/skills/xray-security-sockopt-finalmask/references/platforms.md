# Платформенные границы и socket options

Общий JSON Build не гарантирует применение options на любой ОС. Поля: mark, tcpFastOpen, tproxy, acceptProxyProtocol, domainStrategy, dialerProxy, tcpKeepAliveInterval, tcpKeepAliveIdle, tcpCongestion, tcpWindowClamp, tcpMaxSeg, penetrate, tcpUserTimeout, v6only, interface, tcpMptcp, customSockopt, addressPortStrategy, happyEyeballs, trustedXForwardedFor.

customSockopt: system, network, level, opt, value, type; числовой OS constant не переносить между Linux/Darwin/Windows. happyEyeballs: prioritizeIPv6=false, interleave=1, tryDelayMs=0, maxConcurrentTry=4 по JSON defaults. Явное0 и пропуск — не универсально эквивалентны.

Linux/Android: mark/tproxy/interface могут требовать capabilities, подходящего kernel и policy routing. Не включать tproxy без правил и предотвращения self-loop. Android приложение не равно root-shell; VpnService/TUN lifecycle и доступность option требуют устройства. Unix sockets отличаются от IP listeners, права на каталог и cleanup проверяются отдельно.

Darwin/Windows: Linux numeric constants и sysctl не применять. Не предполагать наличие Linux congestion-control module или одинаковую семантику интерфейсной привязки. Внешний TCP у RAW/WS/gRPC и внешний UDP у Hysteria/KCP имеют разные setsockopt пути.

`tcpFastOpen`: missing→не вызывать setsockopt; true→256; false→-1; integer→числовая настройка после преобразования. Это не гарантия, что peer/маршрут поддерживает TFO. tcpMptcp тоже требует kernel/peer support. `penetrate` в XHTTP копирует основной SocketSettings в downloadSettings и может отменить ожидаемый независимый dialerProxy.

Матрица проверки имеет отдельные строки GOOS/GOARCH/kernel/capabilities. Встроенные Linux loopback тесты не являются подтверждением на macOS/Windows/Android. Непроверенную платформенную опцию не добавлять в production preset ради формального «полного» списка.


## Первичные источники pinned commit
- [infra/conf/transport_sockopt.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_sockopt.go)
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
