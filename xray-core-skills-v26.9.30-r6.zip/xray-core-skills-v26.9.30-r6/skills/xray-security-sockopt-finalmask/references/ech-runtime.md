# ECH: включение, DNS bootstrap, cache и ошибка handshake

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

`tlsSettings.echServerKeys` — standard-base64 encoded ECHKeySetList. Builder декодирует base64; consumer читает последовательность uint16-length-prefixed private key + config. Это не REALITY privateKey и не PEM certificate. `echConfigList` клиента — standard-base64 ECHConfigList либо источник DNS. Server/client значения имеют разные форматы и не копируются друг в друга.

Форма DNS: `https://resolver/dns-query`, `h2c://resolver/dns-query`, `udp://resolver:53`, либо `имя+https://resolver/dns-query`. При отсутствии имени слева используется TLS ServerName, который должен быть domain. Голый base64 не инициирует DNS. Поддержка схем здесь отличается от `dns.servers` factory: не подставлять автоматически `quic+local://` или `https+local://`.

Запрашивается HTTPS record type65 с ECH parameter. DoH POST проверяет HTTP200; таймаут HTTP-client30s. UDP default53, timeout5s, receive buffer512. Это не observatory, где status игнорируется. `echSockopt` передаётся в internet.DialSystem именно для ECH DNS; не наследовать transport.sockopt неявно и не направлять lookup в туннель, для подключения которого ещё нужен ECH.

Cache key включает resolver, domain, **pointer sockopt**, не только значения. До истечения DNS TTL используется cache. После expiry в течение4h может возвращаться прежний config с background refresh; после4h/cold-start запрос ожидает обновления. Это собственный ECH cache, не dns.serveStale.

При неудаче клиентского получения ECH consumer устанавливает заведомо неправильный config, чтобы handshake **не откатился молча в обычный TLS**. Ошибка ApplyECH может быть только записана GetTLSConfig в журнал, поэтому успешный parsing ещё не доказывает рабочий ECH. Проверять TLS handshake, ECHAccepted и negative test неподходящего ECH key. Fingerprint влияет на выбранную GoTLS/uTLS ветку; поддержка конкретного ClientHello — отдельная часть совместимости клиента, не произвольное поле `ech:true`.

Нельзя публиковать echServerKeys и masterKeyLog в диагностике. При смене ECH ключей учитывать DNS TTL и четырёхчасовой stale cache, согласовать период перекрытия старого и нового ключей.

## Исходники
- [infra/conf/transport_security.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_security.go)
- [transport/internet/tls/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tls/config.go)
- [transport/internet/tls/ech.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tls/ech.go)
