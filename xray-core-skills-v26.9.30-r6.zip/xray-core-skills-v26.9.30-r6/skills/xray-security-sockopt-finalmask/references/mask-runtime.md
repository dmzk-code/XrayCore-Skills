# Finalmask: роли, единицы, wire-совместимость и ограничения реализации

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

## Карта применения
Этот справочник дополняет полный реестр полей в `finalmask.md` и `mask-fields.json`. Маска относится к **физическому внешнему socket**: VLESS UDP внутри RAW/TCP использует TCP-маски, а не UDP-маски. JSON-массив применяется через reversed runtime-массив. Сохраняй порядок согласованных преобразований сторон; не инвертируй JSON второй стороны автоматически.

| Маска | Где применяется | Что обязательно согласовать |
|---|---|---|
| header-custom TCP | Первое Write клиента / первое Read сервера | Последовательности clients/servers, длины, literals, capture/reuse и порядок обмена |
| header-custom UDP prefix | Каждый datagram | client/server header definitions; размеры headers+payload |
| header-custom UDP standalone | Отдельный обмен перед данными клиента | Равные определения обмена и достижимый ответ; это не firewall аутентификации |
| fragment TCP | Write выбранной стороны | Второй стороне специальный decoder не нужен; приложение всё равно должно принимать получившийся поток |
| noise UDP | Перед настоящим datagram при первом обращении/после простоя | Второй стороне маска не обязательна; её протокол должен безопасно отвергать шум |
| mkcp-legacy UDP | Header либо original/AES legacy wrapper | Выбранный вариант, header, value, порядок преобразований |
| salamander UDP | Каждый datagram, 8-byte salt + XOR | Password; обычный и Gecko — разные framing-варианты |
| sudoku TCP/UDP | Кодирование потока/пакета | Password, нормализованный ASCII режим, упорядоченные таблицы; padding может отличаться |
| xdns UDP | DNS carrier, клиент через resolvers; сервер на своём UDP listener | Общие domains/types/размеры; resolver-клиенты не требуются серверу |
| xicmp UDP | Собственные ICMP sockets | Достижимость ICMP; client ips — destinations, server ips — source allowlist |
| realm UDP | Координация + STUN/NAT | URL/token/session id/сервер координации и достижимость peer; см. realm-runtime.md |
| udphop UDP | Только клиент, владеет Dial | Общий серверный сеанс за всеми выбранными адресами/портами, а не независимые серверы |
| xmc TCP | Minecraft-подобный внешний handshake | Password, подписанные профили и hostname; не заменяет шифрование внутреннего протокола |

`udphop` имеет HandleDial и обязан быть последней UDP-маской JSON. На сервере его Wrap возвращает `udphop: client only`. XICMP имеет HandleDial и HandleListen, также требует внешней позиции. XDNS **не имеет** этих marker-интерфейсов в config.go: нельзя автоматически отнести его к тому же классу владельцев. Список владельцев — свойство реализации, не имени типа.

## fragment: packets — не номера TCP/IP-пакетов
`packets` ограничивает счётчик вызовов Write этой обёртки. Пустое значение означает общий режим сегментации, `tlshello` — только первый Write с полным TLS record типа22. Если первый Write не содержит полный подходящий record, специальное разделение не выполняется. Это не гарантированное разделение каждого TLS ClientHello в произвольном стеке.

`length`/`lengths[]` — bytes; `delay`/`delays[]` — milliseconds; `maxSplit` — число фрагментов, положительный предел отдаёт остаток последним фрагментом, 0 не задаёт предела. Непустые массивы заменяют одиночные поля; после окончания массива повторяется его последний элемент. Генератор требует положительных lengths и неотрицательных delays, даже когда Build проверяет только часть ограничений.

Для TLSHello **одна нулевая запись delays** объединяет новые TLS records в один Write нижележащего socket. Поэтому `delay:0` не означает «вызвать отдельную TCP-отправку на каждый TLS record». Реальную пакетизацию определяет также ОС. Server wrapper запрещает splice-through; клиентский разрешает снятие обёртки для fast path.

## noise: reset — период простоя, а не независимый таймер
`reset` измеряется в **секундах**, item.delay — в **миллисекундах**. Время следующего допуска обновляется после КАЖДОГО payload WriteTo. Шум отправляется впервые и, при reset.max>0, после достаточно длинного простоя конкретного addr. При постоянном трафике периодического шума может не быть. При reset=0 повторный шум этому addr не включается.

`type:exp`: `<b HEX>` literal bytes; `<r N-M>` случайные bytes; `<rc N-M>` только ASCII-буквы A–Z/a–z; `<rd N-M>` цифры; `<t>` Unix seconds uint32 big-endian (4 bytes); `<c>` увеличиваемый uint32 big-endian (4 bytes); `<n>` random nonce (8 bytes). Это не формат произвольного скрипта.

WriteTo держит общий mutex, включая отправку шума и Sleep: чрезмерные delays блокируют другие записи этого wrapper. Ошибки отправки noise не превращаются автоматически в ошибку отправки payload. Таблица peer-адресов не имеет показанного eviction в conn.go. Включать шум только с ограниченными размерами/адресным fan-out; не считать его защитой целостности или шифрованием.

## Salamander и Gecko
Password проверяется runtime: **минимум 4 UTF-8 bytes**, не 4 Unicode-символа. Обычный вариант добавляет 8 bytes salt, получает BLAKE2b-256(password+salt) и XOR-ит payload повторяемым ключом; отдельного MAC нет. Шифрование/аутентификация основного протокола остаются обязательными.

Если `packetSize` имеет положительную верхнюю границу, builder выбирает **Gecko**: From>0, To<=2048. Значение0 выбирает обычный Salamander; это не запрос Gecko с default. Внутренние defaults Gecko512–1200 относятся к прямому созданию GeckoConfig, а не к такому JSON0.

Gecko фрагментирует пакеты с установленным старшим битом первого byte (ожидаемый QUIC long header); короткие заголовки отправляет после обычной обфускации. Это **не универсальный фрагментатор mKCP/любого UDP**. Диапазон packetSize управляет padding фрагментов, но не гарантирует верхний предел любого передаваемого datagram: если базовый fragment уже больше max, padding становится0. Reassembly TTL8s, до4096 записей глобально и8 на source, дубликаты/несогласованные fragments отбрасываются. Получатель должен использовать Gecko, не обычный Salamander.

## Sudoku: defaults и размеры
ASCII после trim/lower: пусто/entropy/prefer_entropy → prefer_entropy; ascii/prefer_ascii → prefer_ascii; иное ошибка runtime. В prefer_ascii пользовательские таблицы **игнорируются**. В entropy непустой customTables[] выигрывает над customTable; legacy snake_case используется builder только при пустом/нулевом camelCase.

Custom pattern: ровно8 символов после lower/удаления пробелов, ровно2`x`,2`p`,4`v`. Дубликаты убираются с сохранением порядка. Пароль определяет перестановку кодовых таблиц; это appearance transform, не защищённое шифрование.

paddingMin/Max — **проценты вероятности**, не bytes. Оба ограничиваются100, max поднимается до min; пропуск0. Classic codec даёт4 hint bytes на byte входа; на один byte возможны ещё5 padding positions плюс один завершающий padding byte. При100% верхняя оценка classic **9*N+1**, а не N+paddingMin. TCP uplink использует classic, TCP downlink packed; клиент/сервер сами выбирают направления. UDP использует classic с tableIndex=0 заново для каждого datagram. Нельзя рассчитывать MTU по размеру исходного пакета без expansion. Разные последовательности таблиц на peers портят декодирование.

## header-custom: обмен, области переменных и блокировки
Для TCP клиент первый раз исполняет handshake внутри Write; его Read ждёт окончания handshake. Сервер — внутри Read; его Write ждёт. Порядок: clients[i], затем servers[j], затем оставшиеся server-sequences. Имена `clients` и `servers` на сервере **не переставляются**. errors[i] — ответ сервера при несовпавшей client sequence i. Item delay перед отправкой, последовательные zero-delay bytes объединяются.

При чтении rand означает «принять столько bytes», а не проверку принадлежности randRange. capture сохраняет реально полученные bytes; reuse/transform сравнивают вычисленный результат. Неизвестные переменные дают ошибку. State store имеет5s TTL; TCP store создаётся в объекте соединения, не является общей базой между произвольными клиентами.

UDP prefix добавляет header каждому datagram. Его ожидаемая длина вычисляется заранее и должна оставаться постоянной; общий budget4096bytes. В UDP match создаётся evalContext без адресных metadata, хотя sender их получает. Выражение с local/remote metadata, которое получатель обязан вычислить заново, не становится рабочим от одного успешного Build. Передавай динамическое значение в поле фиксированной длины с capture, а не требуй одинаковой локальной топологии/NAT на обоих peers.

UDP standalone отделяет handshake от payload; клиент ждёт подходящий ответ, отдельного retransmission/timeout в показанном ожидании нет. Server пропускает неподходящий под handshake datagram дальше, поэтому этот режим **не авторизационный барьер**. Применять bounded connection timeout. Не запускать такой тест без ограничителя времени.

## XDNS: полный смысл nested domains/resolvers
`domains[].name` — обслуживаемый DNS suffix, использовать ASCII без конечной точки. `lenLimit`0→255, допустим<=255; `labelLimit`0→63, допустим<=63. Общая длина вместе с suffix и base32 labels должна вместить минимум17 bytes служебного payload. `types` обязателен и содержит только1(A),5(CNAME),16(TXT),28(AAAA). `edns0`0 либо512..4096. `resolvers[]` — `{type:"udp"|"tcp",settings:{addr:"host:port"}}`.

Клиент требует domains и resolvers. Сервер требует domains; resolvers/extraPoll не используются его NewServer. Клиентский carrier выбирает resolver и query type/domain, а не просто посылает UDP на endpoint из VLESS address. Для локального стенда resolver может быть собственным XDNS listener; публичная схема требует маршрута DNS к authoritative/forwarder под контролем владельца.

`extraPoll`0..3 — дополнительные пустые запросы. Idle poll начинает500ms, удваивается до10s; успешная активность возвращает короткий интервал. send queue16; при переполнении WriteTo может вернуть длину, хотя пакет не поставлен в очередь. Payload1..4096; большие внутренние пакеты режутся с overhead12/15 bytes и пределом255 частей. Сервер читает DNS-query до512bytes, отвечает до4096 с EDNS clamp, держит до255 request records и задерживает ответ до1s. SetDeadline для carrier возвращает unsupported. Тюнинг throughput должен учитывать QPS и carrier-очереди, а не только mKCP MTU.

## XICMP: стороны принципиально различаются
Клиент `dgram:true` использует ICMP datagram sockets udp4/udp6, false — raw ip4:icmp/ip6:ipv6-icmp. В текущем конструкторе требуются успешные sockets **обоих семейств**, даже для единственного IPv4 target. dgram не гарантирует работу без прав на каждой ОС. Клиент ips — список IP назначений, случайно выбираемый на каждую отправку; без него нужен literal endpoint-IP.

Сервер всегда создаёт raw sockets IPv4/IPv6, `dgram` не выбирает ему другой режим. Сервер ips — **allowlist удалённых адресов клиентов**, а не адреса, на которых нужно слушать. Внешние listen/port основного transport не превращают ICMP в UDP port. Этот carrier создаёт sockets самостоятельно, поэтому обычные sockopt нельзя автоматически считать применёнными к нему.

Client payload budget4080bytes (16bytes overhead в4096), server response4088. Таблица return-address живёт60s с очисткой30s. Linux дополнительно читает destination control message. Параметры root/capabilities, ICMP ACL, IPv6 и NAT описываются как условия окружения; скилл не меняет их самовольно.

## UDPHop: действующая схема, а не случайные адреса
`mode` может содержать intervalLocal, intervalRemote, perConnRemote через запятую (регистр не важен, пробелы builder не trim). `interval`0→30seconds, minimum5. intervalLocal меняет source socket и некоторое время принимает старый; intervalRemote меняет destination IP/port; perConnRemote делает только первоначальный выбор. Пустые remoteIPs/remotePorts сохраняют исходное значение.

Все назначения должны вести к **одному совместимому живому transport session**. Случайные независимые Hysteria/QUIC-серверы не разделяют connection state. Выбор CIDR не исключает reserved/broadcast автоматически; авторинг должен задавать контролируемый узкий пул. Packet buffer4096. Last JSON position обязательна; в server finalmask не копировать.

## Исходники
- [transport/internet/finalmask/realm/portmap.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/realm/portmap.go)
- [transport/internet/finalmask/realm/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/realm/client.go)
- [transport/internet/finalmask/sudoku/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/sudoku/config.go)
- [transport/internet/finalmask/sudoku/codec.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/sudoku/codec.go)
- [transport/internet/finalmask/sudoku/conn_udp.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/sudoku/conn_udp.go)
- [transport/internet/finalmask/fragment/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/fragment/config.go)
- [transport/internet/finalmask/fragment/conn.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/fragment/conn.go)
- [transport/internet/finalmask/salamander/conn.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/salamander/conn.go)
- [transport/internet/finalmask/salamander/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/salamander/config.go)
- [transport/internet/finalmask/salamander/salamander.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/salamander/salamander.go)
- [transport/internet/finalmask/noise/conn.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/noise/conn.go)
- [transport/internet/finalmask/header/custom/tcp.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/header/custom/tcp.go)
- [transport/internet/finalmask/udphop/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/udphop/config.go)
- [transport/internet/finalmask/udphop/conn.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/udphop/conn.go)
- [transport/internet/finalmask/xicmp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xicmp/config.go)
- [transport/internet/finalmask/xicmp/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xicmp/client.go)
- [transport/internet/finalmask/xicmp/server.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xicmp/server.go)
- [transport/internet/finalmask/xdns/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xdns/config.go)
- [transport/internet/finalmask/xdns/domain.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xdns/domain.go)
- [transport/internet/finalmask/xdns/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xdns/client.go)
- [transport/internet/finalmask/xdns/server.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xdns/server.go)
- [transport/internet/finalmask/sudoku/table.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/sudoku/table.go)
- [transport/internet/finalmask/header/custom/udp.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/header/custom/udp.go)
- [transport/internet/finalmask/xicmp/server_oob.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xicmp/server_oob.go)
