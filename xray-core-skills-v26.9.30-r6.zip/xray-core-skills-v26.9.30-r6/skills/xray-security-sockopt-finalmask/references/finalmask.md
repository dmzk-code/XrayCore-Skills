# Finalmask: конфигурация, композиция, ограничения

Точный путь: `streamSettings.finalmask.tcp[]` / `.udp[]`; элемент `{type, settings}`. QUIC общие параметры — `streamSettings.finalmask.quicParams`, не hysteriaSettings. 11 уникальных типов, 13 TCP/UDP регистраций. Реестр допустимых ключей рядом: mask-fields.json. Изложенные Build-правила подтверждены исходником; отсутствие сетевого теста не скрыто.

## Порядок обёрток
NewFinalMask переворачивает оба массива, затем Dial/Listen применяют обёртки. Не переворачивать массивы на сервере «для симметрии» автоматически: семантика Read/Write и направления разные. Тип с HandleDial/HandleListen может находиться только на runtime index=0; после reverse это последняя соответствующая JSON-маска. Нельзя поставить два таких владельца подряд, рассчитывая на автоматическое chaining. Точные marker-роли каждого типа описаны в [runtime-справочнике](mask-runtime.md).

headerManager для UDP имеет буфер UDPSize=4096; суммарный размер headers+payload не должен переполнять его. Увеличение MTU другого слоя не увеличивает автоматически этот буфер. UnwrapTcpMask снимает только слои, у которых Splice() разрешает; наличие маски может менять достижимость fast path.

## RAW header и Finalmask — разные уровни
rawSettings.header обрабатывается после TLS/REALITY; Finalmask TCP применяется к внешнему TCP до security. Эти поля нельзя механически заменить друг другом. UDP-маска без UDP-внешнего плеча не начинает работать только потому, что приложение передаёт UDP через TCP-туннель.

## Типы и все поля их внешнего settings
| Тип / уровень | Поля | Build/default/согласование |
|---|---|---|
| header-custom TCP | clients, servers, errors | Массивы последовательностей TCPItem; client/server handshake должен иметь согласованные длины и значения |
| header-custom UDP | mode, client, server | mode пустой/prefix → prefix Config; standalone → отдельный Config; другое ошибка |
| fragment TCP | packets, length, delay, lengths, delays, maxSplit | lengths при непустом массиве заменяет length; delays заменяет delay; последняя min length не 0; packets=tlshello специальный диапазон, пустой — отдельный режим |
| mkcp-legacy UDP | header, value | пустые оба → original; пустой header+value → AES128GCM password; header dns/dtls/srtp/utp/wechat/wireguard; dns empty value → www.baidu.com |
| noise UDP | reset, noise | NoiseItem описан ниже; bytes и rand не одновременно |
| salamander UDP | password, packetSize | positive packetSize.To включает Gecko; From>0 и To<=2048; иначе обычный Salamander; не считать wire-compatible с Gecko автоматически |
| sudoku TCP/UDP | password, ascii, customTable/custom_table, customTables/custom_tables, paddingMin/padding_min, paddingMax/padding_max | camelCase nonempty/nonzero выигрывает; иначе legacy fallback; правила alphabets/padding зависят также от runtime таблицы |
| xdns UDP | domains, resolvers, extraPoll | domains поля ниже; extraPoll 0..3; вызывается NewDomain; это не обычный dns.servers |
| xicmp UDP | dgram, ips | ips — IP literals; raw/DGRAM socket права зависят от ОС; имя маски не даёт CAP_NET_RAW |
| realm UDP | url, stunServers, tlsConfig, ipMode, portMapping | realm/realm+http, hostname и token и path id обязательны; default 443/80; stunServers непустой host:port список; tlsConfig обычный TLS builder |
| udphop UDP | mode, interval, remoteIPs, remotePorts | mode comma-separated intervalLocal/intervalRemote/perConnRemote, case-insensitive без trim; interval default30, min5; IP/CIDR; remotePorts PortList |
| xmc TCP | hostname, profiles, password | profiles непустой, password непустой; профиль username 3..16 [A-Za-z0-9_], uuid, texturesValue, texturesSignature. Реальная подпись профиля и доступность endpoints — внешняя проверка |

## header-custom вложенные структуры
TCPItem: `delay` (Int32Range), `rand` (int32), `randRange` (Int32Range pointer, default0..255), `capture`, `type`, `reuse`, `transform`, `packet`. UDPItem — тот же набор без delay. Имена capture/reuse `[A-Za-z_][A-Za-z0-9_]*`. Из packet/rand>0/reuse/transform не больше одного; при capture должен быть ровно один источник. Отрицательный rand не считать способом выделить отрицательный буфер: отвергать политикой авторинга.

packet type: пусто/array → JSON byte representation, str → raw text, hex → hex decode, base64 → standard base64. Это не base64url для REALITY. Не менять кодировку при переносе шаблона.

transform `{op,args}`: op и args обязательны; каждый аргумент содержит ровно одно из bytes/u64/reuse/metadata/transform; optional type определяет bytes decoding. Поддержка op проверяется runtime, не Build. Подтверждённый evaluator: concat, slice, xor16, xor32, be16, be32, le16, le32, le64, pad, truncate, add, sub, and, or, shl, shr. `be64`, hash и произвольный язык выражений не поддержаны этой switch-веткой. slice требует3 аргумента; pack1; pad3. Arithmetic проверяет overflow/underflow; shift<64. Реальное значение metadata и область capture зависит от sender/receiver контекста.

## NoiseItem / expression
NoiseItem: rand (Int32Range), randRange (default0..255), type, packet, delay. Маска имеет reset range и noise[]. `type:exp` требует packet-строку из `<b HEX>`, `<r SIZE>`, `<rc SIZE>`, `<rd SIZE>`, `<t>`, `<c>`, `<n>`; size/range упорядочен, 0..65535; t/c/n без аргументов. Непустой посторонний текст и пустое выражение дают ошибку. Не смешивать expression с обычными bytes/рандомной длиной. Генерация шума не является шифрованием или гарантией обхода.

## XDNS / Realm / XMC внешние зависимости
XDNS domain: name, lenLimit(default255), labelLimit(default63), types (int32→uint16 cast), edns0(int32→uint16). Авторинг проверяет числовые пределы до cast; resolvers `{type:tcp|udp,settings:{addr}}`. Требуются реальные домены/маршрут/authoritative инфраструктура, не случайный публичный resolver. extraPoll увеличивает нагрузку, не всегда пропускную способность.

Realm URL содержит секретный token: не логировать URL целиком. Realm требует STUN/coordination server и совместимого NAT. portMapping содержит `enabled` (bool), `timeout` (int64), `lifetime` (int64) по realm/config.proto. timeout и lifetime — секунды; 0 выбирает соответственно10 и600, отрицательные значения запрещены. Renewal через половину аренды. Полный путь и обработка ошибок: [Realm runtime](realm-runtime.md). Фактическая поддержка NAT mapping остаётся свойством роутера.

XMC profiles должны быть согласованными подписанными профилями; не подделывать texturesSignature. XICMP и UDPHop могут нуждаться в системных разрешениях/маршрутах/firewall mapping. Синтаксическая валидация не доказывает прохождение ICMP или port hopping.


## Первичные источники pinned commit
- [infra/conf/transport_finalmask.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_finalmask.go)
- [transport/internet/finalmask/finalmask.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/finalmask.go)
- [transport/internet/finalmask/header/custom/evaluator.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/header/custom/evaluator.go)


## Тип результата выражений и metadata
xor16/xor32 и арифметика возвращают u64, **не bytes**. Чтобы использовать их как packet, обернуть в be16/be32/le16/le32/le64. concat принимает bytes. slice/pad/truncate при вычислении длины требуют literal u64 для length, а не любой вычисляемый u64-expression: evaluator вычисления значения и measureExpr имеют разные ограничения.

Metadata доступны при заполненных TCPAddr/UDPAddr: local_port, remote_port, local_ip4_u32, remote_ip4_u32; aliases src_port_u16/src_ip4_u32 относятся к remote, dst_port_u16/dst_ip4_u32 — к local. IPv4 keys отсутствуют при чистомIPv6. Context с nil/UnixAddr их не получает. measureExprArg для direct metadata выдаёт not implemented; использовать metadata через byte-width pack, когда это действительно поддерживает вызывающая ветка.

В capture сохраняются byte значения и длины; неизвестный reuse вызывает ошибку. Runtime-принятие выражения не означает допустимость самостоятельного integer в поле packet. Проверять ошибки как Build, так и transform evaluation после появления адресов соединения.


## Основание на закреплённом commit
- [transport/internet/finalmask/header/custom/evaluator.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/header/custom/evaluator.go)
- [transport/internet/finalmask/realm/config.proto](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/realm/config.proto)
## Реализация каждого семейства
[Все маски: роли, ограничения и единицы](mask-runtime.md) · [Realm](realm-runtime.md) · [XMC](xmc-runtime.md).
