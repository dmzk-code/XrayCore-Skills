# XMC: поля, согласование профилей и фактический handshake

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Внешние поля ровно hostname, password, profiles[]. Профиль: username, uuid, texturesValue, texturesSignature. Builder требует непустой password/список, username3..16 ASCII `[A-Za-z0-9_]`, UUID и обе texture-строки; получает RSA key из password. Не существует JSON-настроек protocolVersion, cipher, serverStatus, paddingSchedule или arbitrary Minecraft plugin.

`hostname` используется **клиентом** в handshake serverAddress. При пустом значении берётся host нижележащего RemoteAddr; port тоже извлекается из RemoteAddr, начальный fallback25565. hostname — не DNS перенаправление и не серверный allowlist в показанной ветке. Server wrapper его не получает.

Клиент выбирает один профиль криптографическим random из списка. Сервер ищет соответствие username+UUID; затем клиент сравнивает полученный login profile со своим. На обеих сторонах нужен один и тот же согласованный набор texture-полей для выбранного профиля. Подлинность данных внешнего издателя нельзя подменять совпадением строк: использовать реально предоставленный подписанный профиль и не заявлять криптопроверку подписи только на основании такого сравнения.

Фиксированный протокольный номер775; серверный status-response описывает26.1.2. После login: RSA PKCS#1v1.5 exchange, 16-byte shared secret, verify-token4bytes плюс password; сервер сравнивает пароль constant-time. Полученный профиль должен совпасть, затем startup padding schedule и packetStream. Это не обычный RAW без framing. Неверный пароль/профиль/ключ завершают handshake.

Read и Write инициируют handshake под lock, Close останавливает packetStream и закрывает socket. Настройки дедлайнов проходят отдельный connectionDeadlines helper. Для production всё равно применять защищённый внутренний протокол: appearance layer и наличие устаревшего RSA/AES framing не дают доказательства уровня безопасности современного TLS/REALITY.

Никаких запросов к внешнему profile API в приведённом handshake нет: профили заранее подаются в конфигурации. Их получение/обновление — отдельная операция, не скрытая функция transport. Не выдумывать сервисные токены ради заполнения шаблона.

## Исходники
- [infra/conf/transport_finalmask.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_finalmask.go)
- [transport/internet/finalmask/xmc/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xmc/config.go)
- [transport/internet/finalmask/xmc/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xmc/client.go)
- [transport/internet/finalmask/xmc/server.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/xmc/server.go)
