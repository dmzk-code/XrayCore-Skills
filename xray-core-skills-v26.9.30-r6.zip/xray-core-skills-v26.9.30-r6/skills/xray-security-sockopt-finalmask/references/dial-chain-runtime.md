# DialSystem: порядок DNS, SRV/TXT, Happy Eyeballs и chaining

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

При sockopt=nil DialSystem сразу вызывает системный dialer. С sockopt сначала выполняется addressPortStrategy, затем доменное разрешение DomainStrategy, затем dialerProxy, иначе обычный socket. Ошибка SRV/TXT override игнорируется внешней веткой, и остаётся исходное назначение. Это **не fail-closed service discovery**.

SRV использует системный DefaultResolver и ожидает имя `_service._proto.domain`; берётся первый возвращённый record. TXT тоже системный resolver, первая подходящая запись host:port. Эти операции не используют встроенный DNSClient просто от наличия блока dns. Применение к literalIP ничего не меняет. Freedom запрещает addressPortStrategy своим builder.

Для UseIP/UseIPv4… при ошибке lookup может продолжиться системное разрешение исходного имени; ForceIP/ForceIPv4… возвращает ошибку. Указанный source-IP ограничивает семейство и отключает отдельный fallback-family pass. UseIPv4v6/UseIPv6v4 — предпочтение и fallback, не обязательно одновременная гонка.

Happy Eyeballs запускает TcpRaceDial только при **всех** условиях: DomainStrategy действительно разрешает domain, минимум2 IP, физический TCP, `tryDelayMs>0`, `maxConcurrentTry>0`, dialerProxy пуст. Иначе выбирается один random resolved IP. Следовательно defaults tryDelayMs0 и maxConcurrentTry4 **не включают** гонку. Значение maxConcurrentTry0 её отключает, а не означает unlimited. UDP/QUIC и соединения через dialerProxy не используют эту ветку. `prioritizeIPv6` и `interleave` влияют только когда race реально выбрана.

`dialerProxy` ищет outbound по точному tag; отсутствующий manager/handler — runtime error. Перенаправление создаёт pipe-connection и новый outbound context; raw UDP vs TCP выбирает разные connection adapters. Не путать с routing.outboundTag: chaining несёт транспортное соединение через другой выход, routing выбирает обработчик пользовательского назначения. Циклы запрещены политикой генерации до запуска.

`sockopt.penetrate` не является универсальным режимом TCP: в XHTTP оно заменяет socket settings download-плеча внешними настройками. Не включать, если download должен использовать независимый dialerProxy/DNS/interface. Роли source gateway и сокета промежуточного hop проверяются отдельно.

## Исходники
- [transport/internet/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/dialer.go)
- [transport/internet/system_dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/system_dialer.go)
- [infra/conf/transport_sockopt.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_sockopt.go)
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
