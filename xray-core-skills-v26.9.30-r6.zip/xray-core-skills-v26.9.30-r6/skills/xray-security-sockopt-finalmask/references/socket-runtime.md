# Socket options: общий dialer и различия ОС

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

## Что реально происходит при dial
DefaultSystemDialer для TCP устанавливает общий timeout 16 секунд, KeepAliveConfig Enable=true, Idle=45 секунд, Interval=45 секунд, Count=-1. Положительные tcpKeepAliveIdle/Interval заменяют соответствующие значения. Отрицательное любое значение отключает keepalive; противоположные ненулевые знаки дают ошибку. Не смешивать отрицательное отключение с положительным интервалом. UDP использует ListenPacket с wildcard семейства destination и исходящими socket options.

Критический нюанс: ошибки `applyOutboundSocketOptions` логируются внутри Control callback, но не пробрасываются из этой внутренней функции как ошибка DialContext. TCP/UDP соединение иногда продолжит работать без нужной option. `run -test` не проверяет setsockopt. Отсутствие ошибки подключения не доказывает применение SO_MARK, Interface, TFO или congestion. Альтернативный SystemDialer adapter вообще вызывает только Dial(network,address), без реализации этих sockopt данным адаптером.

## Проверенная карта платформ
| Параметр | Linux/Android runtime | Darwin runtime | Windows runtime |
|---|---|---|---|
| `mark` | SO_MARK для in/out, если не 0 | В рассмотренных callbacks не применяется | В callbacks не применяется |
| `interface` | BindToDevice в outbound; inbound callback его не читает | BOUND_IF по имени и семейству в in/out | IP_UNICAST_IF/IPV6_UNICAST_IF в outbound; inbound callback не читает |
| `tcpFastOpen` | FASTOPEN_CONNECT outbound, FASTOPEN backlog inbound | TCP_FASTOPEN CLIENT/SERVER bits | TCP_FASTOPEN 0/1 |
| `tcpCongestion` | TCP_CONGESTION для TCP in/out | Нет специального применения этого поля | Нет специального применения |
| `tcpWindowClamp` | TCP_WINDOW_CLAMP при >0 | Нет специального применения | Нет специального применения |
| `tcpUserTimeout` | TCP_USER_TIMEOUT при >0; **миллисекунды**, в отличие от keepalive | Нет специального применения | Нет специального применения |
| `tcpMaxSeg` | TCP_MAXSEG при >0; байты | Нет специального применения | Нет специального применения |
| `tproxy` | IP_TRANSPARENT когда TProxy mode включён; требует прав/маршрутизации | Не Linux IP_TRANSPARENT; original destination может извлекаться через /dev/pf | Нет Linux transparent socket implementation в callback |
| `v6only` | Inbound IPV6_V6ONLY, если true | Inbound IPV6_V6ONLY | Inbound IPV6_V6ONLY |
| `customSockopt` | int/str | int/str | Только int; str возвращает ошибку |
| `tcpMptcp` | Общий net.Dialer.SetMultipathTCP; фактическая поддержка ОС | Тот же API не доказывает поддержку ядром ОС | Тот же API не доказывает поддержку ядром ОС |

`tcpKeepAlive*` outbound также задаются общим Go dialer; нельзя заключать, что отсутствие соответствующей инструкции в Linux callback означает отсутствие keepalive. В Darwin callback у двух полей Idle/Interval видна перекрёстная передача значений: это наблюдение по коду, а не доказанный эффект после всех операций Go dialer. Для inbound и разных чисел требуются фактические getsockopt/packet timing; не выдумывать одинаковое поведение всех ОС.

## customSockopt — полный контракт
Поля `system`, `network`, `level`, `opt`, `value`, `type` — строки. system пустой → любая ОС, иначе точное равенство runtime.GOOS. network сравнивается HasPrefix с tcp4/tcp6/udp4/udp6: `tcp` означает оба семейства TCP, пусто означает любое. Регистр автоматически не приводится.

level пустой → 6 (TCP); opt обязателен. level/opt и value для type=int читаются десятичным Atoi. Ошибки Atoi в ядре местами игнорируются и превращаются в 0: генератор обязан проверять десятичную строку заранее. `0x…` здесь не означает корректный шестнадцатеричный OS constant. type — ровно int либо str; str Windows не поддерживает. Передача Linux opt-number на Darwin/Windows недопустима без платформенной карты. Настройки применяются последовательно; более поздний customSockopt может перекрыть ранее заданную опцию.

## Параметры, не являющиеся setsockopt
`domainStrategy`, `addressPortStrategy`, `dialerProxy`, `happyEyeballs`, `penetrate`, `trustedXForwardedFor`, `acceptProxyProtocol` относятся к разрешению, графу dial, наследованию и обработке соединений. Они не включают firewall сами. `acceptProxyProtocol` в RAW/WS/HTTPUpgrade объединяется логическим OR с аналогом в transport settings; ставить false в одном месте недостаточно, если в другом true.

Для неизвестной платформы не переносить Linux таблицу. В отчёте конфигурации всегда указать: ОС, внешний TCP/UDP, направление in/out, socket owner, доступные capabilities. Проверка исходников ОС и фактическая проверка на устройстве — разные свидетельства.

## Исходники
- [infra/conf/transport_sockopt.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_sockopt.go)
- [transport/internet/system_dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/system_dialer.go)
- [transport/internet/sockopt_linux.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/sockopt_linux.go)
- [transport/internet/sockopt_darwin.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/sockopt_darwin.go)
- [transport/internet/sockopt_windows.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/sockopt_windows.go)
- [transport/internet/tcp/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tcp/hub.go)
