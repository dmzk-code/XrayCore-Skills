# Realm: параметры, STUN, port mapping и жизненный цикл

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

`streamSettings.finalmask.udp[].type="realm"`; settings: `url`, `stunServers`, `tlsConfig`, `ipMode`, `portMapping`.

| Поле | Значение и фактическая роль |
|---|---|
| `url` | `realm://TOKEN@HOST/ID` для HTTPS координации либо `realm+http://…` для HTTP. TOKEN и ID URL-decoded; оба непустые. Порт default 443/80. Не печатать URL целиком в отчёте. |
| `stunServers` | Непустой массив host:port. Получение внешних адресов, не data relay и не DNS upstream. |
| `tlsConfig` | Обычный TLSConfig для соединения с coordinator. Это отдельный уровень от шифрования переносимых UDP-данных. |
| `ipMode` | После lower-case: dual/v4/v6; пустое и неизвестное значение в client switch приводят к Dual. Авторинг допускает только пусто/dual/v4/v6. |
| `portMapping.enabled` | false/отсутствие → не запрашивать UPnP/NAT-PMP mapping; true → попытка mapping локального UDP порта. |
| `portMapping.timeout` | int64, **секунды**. 0 → 10 секунд. Отрицательное возвращает ErrInvalidPortMapConfig. Discovery и первое mapping имеют отдельные timeout, суммарно до 2×timeout. |
| `portMapping.lifetime` | int64, **секунды**. 0 → 600 секунд. Отрицательное ошибочно. Обновление аренды через Lifetime/2; очистка mapping best-effort при Close. |

Client вызывает NewPortMapper, но неудача optional port mapping логируется и не отменяет немедленно дальнейший STUN/punch путь. Поэтому ошибки gateway не следует автоматически считать причиной отказа всего Realm: нужно смотреть, получены ли locals и peer.

Последовательность клиента: создать UDP socket → optional gateway mapping → разрешить STUN servers с учётом семейства → BindingRequest/сбор locals → coordinator Connect(ID, Addresses, PunchMetadata) → кандидаты peer → authenticated punch hello/ack → фиксированный peer для WriteTo. Назначение, переданное последующему WriteTo, заменяется выбранным peer. Никакой гарантии прохождения symmetric NAT из самого факта валидного JSON нет.

Если mapping создан, адрес gateway включается в locals. Mapper отклоняет unspecified/loopback external address; нельзя использовать локальный mock, возвращающий 127.0.0.1, как подтверждение настоящего mapping.

`realmConnClient.Close()` в этой версии отменяет контекст и ждёт mapping goroutine, но сам не вызывает Close исходного PacketConn. Это существенная граница lifecycle для долгоживущего embedding: не обещать освобождение всех sockets одной этой функцией и не подменять анализ утверждением «finalmask автоматически всё закрывает».

Для deployment должны совпадать coordinator, ID/права token и допустимое семейство; клиентские и серверные физические адреса не обязаны совпадать. Реальный coordinator/STUN/NAT тест требует изолированной инфраструктуры и разрешения на mapping; общий skill не открывает порты роутера автоматически.

## Исходники
- [infra/conf/transport_finalmask.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_finalmask.go)
- [transport/internet/finalmask/realm/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/realm/client.go)
- [transport/internet/finalmask/realm/portmap.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/finalmask/realm/portmap.go)
