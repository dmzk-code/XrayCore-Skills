# Security по коду snapshot
Источник: [transport_security.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_security.go), [StreamConfig](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_internet.go). Внутренние TLS/REALITY consumers проверить для конкретной схемы.

## TLSConfig: полный набор top-level JSON полей
`allowInsecure`, `certificates`, `serverName`, `alpn`, `enableSessionResumption`, `disableSystemRoot`, `minVersion`, `maxVersion`, `cipherSuites`, `fingerprint`, `rejectUnknownSni`, `curvePreferences`, `masterKeyLog`, `pinnedPeerCertSha256`, `verifyPeerCertByName`, `echServerKeys`, `echConfigList`, `echSockopt`.

Bool: allowInsecure, enableSessionResumption, disableSystemRoot, rejectUnknownSni. StringList: alpn, curvePreferences. certificates — массив объектов. echSockopt — SocketConfig. Остальные поля строки. StringList допускает список либо comma-separated string, но для генерации предпочтителен массив. `echForceQuery` не входит в данный struct.

allowInsecure=true вызывает removed-feature error; false не включает отключение проверки. pinnedPeerCertSha256 — строка comma-separated SHA256 hex, допускает разделители ':', каждый непустой hash 32 bytes. Это не Base64 и не массив устаревших pinned-chain полей. verifyPeerCertByName — строка comma-separated имён; правила runtime приведены ниже; это не универсальная логика AND между pin и именами.

fingerprint приводится к lower; неизвестное значение ошибка; unsafe допускается builder TLS, но не рекомендовано как настройка по умолчанию. Список поддерживаемых fingerprint получать из tls runtime текущей зависимости, не копировать список другого поколения.

Если ALPN содержит специальное fromMitm значение, разрешён только один элемент. fromMitm требует соответствующего контекста, не применять к произвольному outbound. minVersion/maxVersion/cipherSuites/curvePreferences попадают в Go TLS config, но uTLS copyConfig их не копирует. В GetFingerprint пустое имя выбирает Chrome; отсутствие fingerprint не означает Go TLS. Для RAW/gRPC/WebSocket/HTTPUpgrade/XHTTP H1–H2 не считать эти поля применённой policy uTLS-клиента; см. [реальный consumer и два контрольных handshake](../../xray-config-orchestrator/references/peer-validation.md). echServerKeys декодируется standard Base64, echConfigList и echSockopt — отдельные поля. Не обещать поддержку ECH любой CDN/сборкой.

### Certificates
Поля объекта: certificateFile:string, certificate:[]string, keyFile:string, key:[]string, usage:string, ocspStapling:uint64, oneTimeLoading:bool, buildChain:bool. Файл имеет приоритет над inline строками. Без обеих file paths forced oneTimeLoading=true. usage encipherment/verify/issue; неизвестное значение в Build становится encipherment. Lint вправе считать опечатку ошибкой проекта, но не утверждать, что core её отклонит. Не включать masterKeyLog в production: это чувствительные данные для диагностики.

## REALITYConfig: поля и ветвление
Общие/серверные: masterKeyLog, show, target, dest, type, xver, serverNames, privateKey, minClientVer, maxClientVer, maxTimeDiff, shortIds, mldsa65Seed, limitFallbackUpload, limitFallbackDownload.
Клиентские: fingerprint, serverName, password, publicKey, shortId, mldsa65Verify, spiderX.

target при наличии заменяет dest. Ветка server/client выбирается builder по наличию dest после alias, а не по тому, находится объект в inbounds или outbounds! Не добавлять target в клиент «для полноты».

Сервер: target/dest допускает порт или endpoint с автоопределением tcp/unix; xver только0/1/2, PROXY receiver должен быть согласован. Требуются непустые serverNames, privateKey, shortIds. privateKey — base64url без padding,32 bytes. shortIds — массив hex строк длиной <=16 символов; hex обязан корректно декодироваться. Пустой элемент синтаксически возможен, это не основание рекомендовать ослабленную схему авторизации.

minClientVer/maxClientVer: до3 числовых компонентов, каждый<256. Закомментированная строка default minClientVer=26.3.27 не является действующим default. maxTimeDiff и fallback rate fields не тождественны socket timeout. Для их единиц и воздействия проверить reality runtime.

MLDSA seed: base64url32 bytes, не равен privateKey. Клиентский mldsa65Verify: base64url1952 bytes. Требования поддержки peer обязательны.

Клиент: fingerprint unsafe/hellogolang запрещены; значение должно существовать в GetFingerprint. serverNames и shortIds массивы запрещены — использовать serverName и shortId. password непустой заменяет publicKey; это публичная часть REALITY, не произвольный пользовательский пароль. После декодирования32 bytes. shortId hex <=16 символов. spiderX default '/', должен начинаться с '/'; параметры p/c/t/i/r парсятся как специальные диапазоны и удаляются из URL.

LimitFallback содержит AfterBytes,BytesPerSec,BurstBytesPerSec uint64 без явных JSON tags; для канонических имён и runtime единиц сверить документацию/consumer. Не придумывать вложенные поля.

## Границы совместимости
В этом StreamConfig REALITY разрешён только для internal tcp/splithttp/grpc. RAW TLS не означает HTTPS endpoint. TLS termination на frontend отделять от security=none между frontend и backend; такое внутреннее плечо защищать сетью/Unix permissions или отдельным TLS.


## Фактический TLS runtime
GetTLSConfig устанавливает VerifyPeerCertificate callback. При непустом pin или verifyPeerCertByName Go InsecureSkipVerify включает **собственную проверку callback**, а не бесконтрольный accept. Это внутренний механизм, не доступный обратно через allowInsecure=true.

1. Pin сначала ищется по leaf certificate. Совпадение leaf немедленно возвращает успех, не добавляя проверку имени/chain/срока в этой callback ветке.
2. Если совпал CA из остальной присланной цепочки, он образует отдельный RootCA pool; далее проверяются цепочка и verifyPeerCertByName, либо ServerName.
3. При verifyPeerCertByName пробуются имена по очереди: достаточно одного успешно проверенного имени. Это OR по именам, а не AND.
4. Pin задан, но ни leaf ни пригодный CA не найден → ошибка. Pin CA без ServerName и без успешного name override также не проходит.
5. Без обеих опций штатная проверка Go TLS остаётся включённой; финальный callback не заменяет её.

Leaf fingerprint относится к сертификату DER, не SPKI. При обновлении сертификата leaf pin меняется; для плавной ротации возможен список старого/нового pin с ограниченным переходным периодом. Такой pin не равен стандартной PKI-проверке по имени.

## ALPN / TLS versions / curves
Без NextProtos runtime ставит [h2,http/1.1]. WithNextProto заполняет только пустой список; transport-specific logic может переопределять или выбирать ветку раньше. Явные min/maxVersion разбираются по1.0/1.1/1.2/1.3; неизвестные строки не устанавливают ограничение, поэтому linter должен отмечать опечатки.

ParseCurveName: curvep256, curvep384, curvep521, x25519, x25519mlkem768, secp256r1mlkem768, secp384r1mlkem1024, case-insensitive; неизвестные имена логируются и пропускаются. CipherSuites разбирается как список через ':' из известных Go suites; неизвестные элементы игнорируются. Это не настройка всех TLS1.3 cipher suites через данный список.

## Сертификаты и hot reload
BuildCertificates пропускает неправильные X509 key pairs с warning, поэтому Config Build не гарантирует наличие пригодного сертификата в listener. Проверять реальный handshake. Certificate-only verify/issue не следует трактовать как обычную server leaf+private key.

Без oneTimeLoading запускается ticker обновления: default3600s, либо ocspStapling seconds. Перечитывание происходит только при обоих file paths certificate+key; inline сертификаты получают oneTimeLoading=true в builder. Ошибка чтения может завершить соответствующий ticker. Новые serverNames и certificate SAN не считать автоматически проверенными без handshake.

masterKeyLog path создаётся runtime с mode0644, если значение не пусто и не none. Не включать в production; секреты логов требуют отдельного доступа/удаления. ApplyECH error логируется: отсутствие ошибки Config Build не доказывает ECH negotiation; записывать ECHAccepted и источник ECH config без секретных ключей.


## Основание на закреплённом commit
- [transport/internet/tls/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tls/config.go)
- [infra/conf/transport_security.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_security.go)