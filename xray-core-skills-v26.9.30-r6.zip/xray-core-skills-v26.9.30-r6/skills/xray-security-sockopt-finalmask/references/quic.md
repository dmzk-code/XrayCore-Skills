# QUIC общие поля и транспортные отличия

Путь `streamSettings.finalmask.quicParams`.

| Поля | Тип / Build / unit |
|---|---|
| congestion | string: пусто, reno, bbr, brutal, force-brutal; последнее требует nonzero brutalUp |
| bbrProfile | empty → standard; conservative/standard/aggressive |
| brutalUp / brutalDown | строки Bandwidth; unit b/bps,k/kbps,m/mbps,g/gbps,t/tbps с множителем1024 и /8 → bytes/s; непустая nonzero скорость >=65536 bytes/s |
| brutalDisableLossCompensation | bool |
| initStreamReceiveWindow / maxStreamReceiveWindow | uint64 bytes; nonzero >=16384 |
| initConnectionReceiveWindow / maxConnectionReceiveWindow | uint64 bytes; nonzero >=16384 |
| maxIdleTimeout | seconds: 0 либо4..120 |
| keepAlivePeriod | seconds: 0 либо2..60 |
| maxIncomingStreams | int64: 0 либо>=8 на Build, хотя runtime client может сам поставить -1 |
| disablePathMTUDiscovery / disableChromeParrot / disableGSO / disableStatelessReset | bool; scope зависит от dialer/listener |
| debug | bool; Build выставляет process env HYSTERIA_BBR_DEBUG/HYSTERIA_BRUTAL_DEBUG; не per-connection безопасный флаг |

Диапазоны Build не проверяют все отношения: initial window <= max window — дополнительная авторская проверка; зависимость quic-go может добавить свои ограничения. Отрицательная или переполняющаяся bandwidth строка не должна доходить до uint64 cast.

| Transport | congestion='' / brutal | Keepalive/default | Примечание |
|---|---|---|---|
| XHTTP H3 | empty→BBR; brutal отсутствует в клиентском switch и ведёт к panic | QUIC default из net constants, либо XMUX hKeepAlivePeriod при отсутствии explicit QUIC override | force-brutal читает brutalUp; нельзя переносить Hysteria negotiation |
| Hysteria2 | переговоры скоростей; без подходящих rates fallback BBR | ранее предлагаемый default10s закомментирован; не считать активным | stream windows default8388608, conn20971520, idle30s |
| MASQUE H3 | empty/brutal→BBR | idle30s, client keepalive net.QuicgoH3KeepAlivePeriod | H2-ветка не использует QUIC настройки |

TCP sockopt.tcpCongestion не выбирает QUIC congestion. TLS fingerprint не доказывает использование TCP uTLS на H3. Windows/Linux/macOS Path MTU ветки отличаются от остальных GOOS; проверять фактическую сборку. Server/client параметры могут иметь разные defaults и роль.


## Первичные источники pinned commit
- [infra/conf/transport_internet.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_internet.go)
- [infra/conf/transport_finalmask.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_finalmask.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
- [transport/internet/hysteria/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/hysteria/dialer.go)
- [transport/internet/masque/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/masque/dialer.go)
