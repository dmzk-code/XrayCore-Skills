# SocketConfig
Источник: [transport_sockopt.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_sockopt.go). Все runtime/OS-specific единицы и эффекты проверять в transport/internet/system_* и socket_* файлах фактической сборки.

Полный набор: mark, tcpFastOpen, tproxy, acceptProxyProtocol, domainStrategy, dialerProxy, tcpKeepAliveInterval, tcpKeepAliveIdle, tcpCongestion, tcpWindowClamp, tcpMaxSeg, penetrate, tcpUserTimeout, v6only, interface, tcpMptcp, customSockopt, addressPortStrategy, happyEyeballs, trustedXForwardedFor.

Числа int32: mark, tcpKeepAliveInterval/Idle, tcpWindowClamp, tcpMaxSeg, tcpUserTimeout. Bool: acceptProxyProtocol, penetrate, v6only, tcpMptcp. Строки: tproxy,domainStrategy,dialerProxy,tcpCongestion,interface,addressPortStrategy. trustedXForwardedFor — []string.

tcpFastOpen: отсутствие означает не вызывать setsockopt, false → внутреннее -1 (disable), true →256, numeric преобразуется int32 с верхним clamp. Генератор должен выдавать bool либо целое, не использовать дробное усечение.

tproxy lower: tproxy/redirect; всё остальное, включая опечатку, становится Off. domainStrategy lower: AsIs,UseIP,UseIPv4,UseIPv6,UseIPv4v6,UseIPv6v4,ForceIP,ForceIPv4,ForceIPv6,ForceIPv4v6,ForceIPv6v4; прочие ошибка. Не путать это поле с DNS/routing domainStrategy другого scope.

addressPortStrategy lower: none, srvPortOnly, srvAddressOnly, srvPortAndAddress, txtPortOnly, txtAddressOnly, txtPortAndAddress; прочие ошибка. Фактическую поддержку и DNS semantics проверить по dialer.

happyEyeballs: prioritizeIPv6:bool=false, tryDelayMs:uint64=0, interleave:uint32=1, maxConcurrentTry:uint32=4. Custom UnmarshalJSON сохраняет defaults для опущенных полей частичного объекта.

customSockopt: массив объектов system,network,level,opt,value,type — все строки. Builder переносит их без гарантии применения ОС. Не угадывать номера socket options, права или смысл TCP/UDP совпадения.

acceptProxyProtocol / trustedXForwardedFor: сверить конкретный listener и доверенные источники. Backend нельзя оставлять публичным только потому, что указан allowlist forwarded headers. penetrate для XHTTP download копирует base socket settings; учесть при независимых dialerProxy.
