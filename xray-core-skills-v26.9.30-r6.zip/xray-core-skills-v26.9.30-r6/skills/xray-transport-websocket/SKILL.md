---
name: xray-transport-websocket
description: "WebSocket: создание и аудит конфигураций Xray-core v26.9.30; поля, приоритеты, client/server, runtime нюансы, несовместимости, примеры и тесты."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# WebSocket

## Перед генерацией
Прочитай [единый контракт](../xray-config-orchestrator/references/contract.md), [совместимость](../xray-config-orchestrator/references/compatibility.md), [поля](references/fields.md), [поведение](references/behavior.md), [runtime и peer-map](references/runtime-peer.md). Если контракт уже загружен, не перечитывай его. Не запускай orchestrator рекурсивно.

## Процедура
1. Выбери pinned core/версию клиента и различи protocol, transport, security. Из файлов извлеки endpoint, authentication, frontend и необходимые TCP/UDP возможности.
2. Возьми минимальную согласованную пару из `../xray-config-orchestrator/assets/scenarios/`; [каталог](../xray-config-orchestrator/references/scenarios.md). Не оставляй лабораторные секреты/loopback addresses в production.
3. Для каждого нестандартного поля укажи полный JSON path, сторону, единицы, effective default и причину изменения. Сверь aliases, null/zero и условия применения по [порядку полей](../xray-config-orchestrator/references/effective-config.md).
4. Согласуй обе стороны и frontend, не копируя вслепую все параметры. При split/chaining проверь session-owner и graph; при Vision/Encryption прочитай [protocol guide](../xray-protocol-composition/references/vless.md).
5. Для TLS/REALITY/Finalmask/sockopt подключи `../xray-security-sockopt-finalmask/SKILL.md`; для DNS/failover — `../xray-dns-routing-balancing/SKILL.md`. Не изобретать параметры других ядер.
6. Выполни `../xray-source-audit/scripts/validate.py client.json --peer server.json`, затем отдельные уровни [тестирования](../xray-runtime-validation/references/testing.md). Линтер не является ядром; NOT_RUN нельзя заменять PASS.

## Выдать
Полные конфиги сторон, peer-map, причины расширенных параметров, честный журнал тестов и rollback. [Рецепты](references/recipes.md) и [карта источников](references/source-map.md) — дополнение, не замена готовым файлам.

Перед выбором production-рецепта прочитать [измеренные ограничения r2](../xray-runtime-validation/references/known-issues.md). Успех первой передачи не означает успешное восстановление после отказа.

## Уточнения реализации r3
Прочитай [implementation](references/implementation.md). В общих слоях загружай [индекс знаний](../xray-config-orchestrator/references/knowledge-map.md) только по используемым полям. Для Finalmask читай также runtime-справочник, а не только список типов.

### TLS consumers — уточнение r4
До обещания min/max TLS-version или curve/cipher policy прочитать [различие Go TLS и uTLS copyConfig](../xray-config-orchestrator/references/peer-validation.md#tls-copyconfig-результат-отрицательного-теста). Пустой fingerprint не означает отсутствие uTLS.

## Эффективная HTTP-семантика r5
Перед сверкой сторон прочитай [активные поля, Host, padding и MASQUE URI](../xray-config-orchestrator/references/http-wire-semantics.md). Не сравнивай aliases/defaults буквально.

## Границы общей схемы r6
При локальном SOCKS/mixed/HTTP входе или relay прочитать [proxy edges](../xray-protocol-composition/references/local-proxy-edges.md); для bind/прямой пары — [topology](../xray-config-orchestrator/references/topology-and-listeners.md). Транспортный PASS не подтверждает авторизацию другого протокольного края.
