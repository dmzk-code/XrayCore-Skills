# HTTP и ранние данные

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Host приоритет host > TLS serverName > endpoint; legacy headers.Host переносится при пустом host с предупреждением. ?ed=N извлекается из path и удаляется из request query, early bytes передаются Sec-WebSocket-Protocol rawURLbase64. При first Write больше лимита ed применяется обычная отправка, не частичная обрезка полезных данных.

Сервер проверяет path на равенство, не префикс, и Host при непустом host. handshake server4s/client8s, MaxHeaderBytes8192. HeartbeatPeriod в секундах задаёт frames, не системный TCP keepalive. Не включать слишком частые heartbeat на мобильных без измерения батареи.

## Исходники
- [transport/internet/websocket/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/websocket/dialer.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
