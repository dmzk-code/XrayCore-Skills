# WebSocket: поведение и ловушки

- `ws`/`websocket` → websocket; транспорт есть, но отмечен non-removal deprecated. REALITY + WS запрещён StreamConfig.
- TLS клиент принудительно использует HTTP/1.1/WebsocketHandshake. Одно изменение alpn на h2 не превращает этот транспорт в WebSocket over H2.
- Early data задаётся в path как `?ed=N`, а не отдельным произвольным JSON полем. Парсер Atoi игнорирует ошибку и кастует в uint32; требовать корректное неотрицательное число, не допускать отрицательные/нечисловые значения.
- При Ed>0 соединение отложено до первого Write. Если первый payload больше Ed, клиент отправляет его обычным способом вместо частичного early-data embedding.
- В WebSocket early data передаются base64url в Sec-WebSocket-Protocol. Эта семантика отличается от HTTPUpgrade, несмотря на одинаковый ed в URL.
- HandshakeTimeout обычного websocket dialer равен 8 секундам в прочитанном коде. Он не управляется придуманным полем wsSettings.handshakeTimeout.
- Browser Dialer — отдельная ветка; не считать её идентичной native socket/TLS пути. Для нового рецепта читать этот код и проверять его предпосылки.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/websocket/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/websocket/dialer.go)
