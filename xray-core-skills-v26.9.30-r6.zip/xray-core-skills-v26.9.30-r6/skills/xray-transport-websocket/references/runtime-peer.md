# WebSocket: upgrade, early data, heartbeat, peer

## HTTP Upgrade и TLS
Client использует Gorilla WebSocket, read/write buffers4096, handshake timeout8s. Server upgrade timeout4s; HTTP ReadHeaderTimeout4s и MaxHeaderBytes8192. Эти значения не имеют произвольных JSON override кроме описанных полей транспорта. TLS/uTLS client имеет специальную WebsocketHandshakeContext ветку; REALITY с WS отвергается общим builder.

Server проверяет Host при заданном host и сравнивает normalized path с request.URL.Path **точно**. Это отличается от prefix-проверки XHTTP. CheckOrigin возвращает true: нельзя считать Origin встроенным ACL. Доступ ограничивает внутренний protocol auth и firewall.

## Early data
`?ed=N` удаляется из query при Build. При Ed>0 connection откладывает dial до первой Write. Если первая запись длиннее Ed, она не режется до лимита для ранних данных, а идёт обычным payload после upgrade. Иначе данные передаются в Sec-WebSocket-Protocol в raw URL-base64. Server декодирует и эхо-подтверждает subprotocol, затем подставляет extraReader перед обычным потоком.

LocalAddr/RemoteAddr до deferred dial возвращают nil (защита от nil embedded conn); нельзя считать это доказательством отсутствия будущего соединения. BrowserDialer — отдельный backend; не обещать применимость всех socket/fingerprint настроек без этой ветки.

## PROXY и XFF
wsSettings.acceptProxyProtocol OR sockopt.acceptProxyProtocol. XFF влияет на remote address лишь через ApplyTrustedXForwardedFor и доверенные peers; серверная Host-проверка не является доверением к XFF. Не включать одновременно PROXY при отправителе обычного HTTP без соответствующего префикса.

## Сценарии
websocket-tls и websocket-ed-tls. Проверить handshake, двусторонний payload, early-data threshold, idle heartbeat и закрытие. UA/headers не переносятся автоматически на h2/h3 transport.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [transport/internet/websocket/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/websocket/dialer.go)
- [transport/internet/websocket/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/websocket/hub.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `websocket-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `websocket-ed-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
