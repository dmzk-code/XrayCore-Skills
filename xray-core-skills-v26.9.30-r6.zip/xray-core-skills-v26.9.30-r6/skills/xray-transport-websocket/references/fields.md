# WebSocket: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри wsSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `host` | `string` | Отдельный Host; приоритет на клиенте host → TLS serverName → destination address. |
| `path` | `string` | Пустой нормализуется runtime; query ed извлекается Build и удаляется из фактического path. |
| `headers` | `map[string]string` | Host в map устарел: переносится в host, если тот пуст, затем удаляется. |
| `acceptProxyProtocol` | `boolean` | Серверная настройка; только за доверенным отправителем PROXY. |
| `heartbeatPeriod` | `uint32` | Передаётся в NewConnection; проверить единицу/поведение в connection.go, не выдавать за TCP keepalive. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.
