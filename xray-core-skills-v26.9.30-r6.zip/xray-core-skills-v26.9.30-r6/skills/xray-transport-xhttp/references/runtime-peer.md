# XHTTP: серверная машина состояний, лимиты и два плеча

## Одна сессия — один requestHandler
`ListenXH` создаёт новый requestHandler со своей sessions sync.Map. Даже два inbounds одного процесса не разделяют эту map. Upload и download должны попадать в один listener либо в явно реализованное внешнее решение общего состояния (не встроенное обещание Xray). В комплекте xhttp-split-nginx два разных frontend порта ведут в один и тот же backend listener.

Сессия с sessionId, но без полностью открытого GET, удаляется через30 секунд. После открытия GET срок связан с его жизнью; при завершении handler удаляет запись. Это не настройка произвольного sessionTTL в xhttpSettings.

## Выбор режима и HTTP версии
Клиент auto без REALITY → packet-up. С REALITY → stream-one, а при downloadSettings → stream-up. REALITY использует H2. Без security клиент использует H1. TLS с единственным ALPN h3 → H3; единственным http/1.1 → H1; остальные варианты → H2. Не считать список [h3,h2] механизмом fallback.

Listener выбирает H3 только если эффективный TLS ALPN ровно[h3]; иначе TCP/Unix ветка. H1/h2c поддерживаются обычным серверным HTTP handler. Нельзя считать один XHTTP listener одновременно TCP H2 и UDP H3 только по двум элементам ALPN: для внешней конвертации нужен frontend, который всё равно сохраняет одного session-owner.

## Серверные критерии, которые не видны в JSON Build
Host проверяется при непустом host; path проверяется по префиксу normalized path. OPTIONS возвращает200. Padding проверяется отдельно: неверная длина/представление даёт400. Пустая sessionId разрешена при server mode пусто/auto/stream-one/stream-up; packet-up запретит.

GET с непустым seq считается uplink; GET без seq — download. Другие методы рассматриваются как uplink. Uplink с sessionId, но без seq — stream-up и требует server auto/stream-up. С seq — packet-up и требует auto/packet-up. Server stream-up может принять stream-one; одинаковое буквальное mode на сторонах не является единственной допустимой схемой.

## Payload / размеры
Placement auto читает header chunks, cookie chunks и body, затем объединяет; это не автопереключение по наиболее удобной стороне. Cookie keys имеют suffix `_N`, header keys `-N`, кодировка raw URL-base64. Keys/placements согласовать на обоих концах. Внешний HTTP proxy может удалить/ограничить эти данные.

Суммарный payload ограничен серверным scMaxEachPostBytes.To; большие запросы получают413. При unknown ContentLength чтение ограничено limit+1. Запас header budget учитывает base64 расширение, padding и метаданные. serverMaxHeaderBytes применяется TCP HTTP server; не обещать тот же лимит в H3 server, где это поле не задаётся этой веткой.

GET/downlink и stream-up выставляют X-Accel-Buffering:no, Cache-Control:no-store; downlink Content-Type:text/event-stream зависит от noSSEHeader. Эти заголовки не отменяют принудительные настройки CDN. Нельзя включать кэширование ответов или retries, дублирующие части сессии.

## XMUX / downloadSettings
extra заменяет расширенные внешние настройки; host/path/mode берутся снаружи. Указать maxConnections и maxConcurrency одновременно положительными запрещено. Пустой XmuxConfig получает набор default целиком; partial object не означает merge с этим default.

DownloadSettings — StreamConfig со своим address/port/network=xhttp/security/sockopt, не второй outboundTag. Consumer разыменовывает destination и приводит config к XHTTP. stream-one+downloadSettings запрещено. penetrate копирует внешний sockopt в download stream и может затереть его настройки.

## Проверяемые сценарии
packet-h1, stream-h2, one-h2, packet-h3, header-h2, split-nginx. Включение H3, split frontend и смена placement — отдельные регрессии. Отдельно проверять восстановление после обрыва download GET, полного POST, ошибки413 и рестарта origin.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/splithttp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/config.go)
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
- [transport/internet/splithttp/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/hub.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `xhttp-packet-h1`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load FAIL.
- `xhttp-stream-h2`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `xhttp-one-h2`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `xhttp-packet-h3`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `xhttp-header-h2`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `xhttp-split-nginx`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
