# Клиент, partial defaults и повторное использование

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Полный dialer прослежен, включая packet uploader, отдельный HTTP client download, H1 transport, HTTP2/3 pools. В H1 download-запросе DisableKeepAlives не равен запрету всех переиспользований uplink. XMUX pool — не outbound.mux. Явный partial xmux не сливается с default3connections/600–900requests/1800–3000seconds. extra:null заменяет advanced-настройки, как extra:{}; host/path/mode остаются внешними.

При расчёте лимита HTTP headers считать суммарную base64URL длину, все numbered chunks, padding и metadata, а не один uplinkChunkSize. GET payload в header/cookie требует packet-up; одинаковая схема метаданных на peers обязательна. R3 расширенные сценарии отдельно покрывают GET header/cookie, все metadata placements, tokenish-padding и H3 stream-up/one.

## Исходники
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
