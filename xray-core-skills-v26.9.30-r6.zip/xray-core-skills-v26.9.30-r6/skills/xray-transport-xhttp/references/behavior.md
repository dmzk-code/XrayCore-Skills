# XHTTP / SplitHTTP: поведение и ловушки

- Внутреннее имя `splithttp`; `xhttpSettings` заменяет `splithttpSettings`, если заданы оба. Использовать только один вариант.
- `extra` — не deep merge. Если extra присутствует, все расширенные параметры держать внутри него; снаружи оставить только host/path/mode. Даже пустой extra меняет эффективный набор.
- Выбор HTTP клиента: REALITY → H2; нет TLS/REALITY → H1.1; TLS с ровно одним ALPN `h3` → H3; ровно `http/1.1` → H1.1; другие TLS-варианты → H2. ALPN `[h2,h3]` не включает автоматический H3 fallback.
- Режим auto в текущем dialer: обычно packet-up; с REALITY stream-one; с REALITY и downloadSettings stream-up. Это НЕ один универсальный режим для всех схем.
- downloadSettings компилируется как StreamConfig, но dialer разыменовывает Destination и приводит ProtocolSettings к XHTTP Config. Задать явные address/port/network=xhttp; отсутствие адреса или другой transport считать runtime-риском, даже если Build не возражает.
- `sockopt.penetrate=true` у основного плеча переносит его socket settings на download-плечо. Не обещать независимые dialerProxy/маршруты без проверки этой ветки.
- XMUX поля: `maxConcurrency`, `maxConnections`, `cMaxReuseTimes`, `hMaxRequestTimes`, `hMaxReusableSecs` — range; `hKeepAlivePeriod` — int64, секунды. Ненулевые maxConnections.To и maxConcurrency.To одновременно запрещены.
- Полностью нулевой XMUX включает Build defaults: maxConnections=3, hMaxRequestTimes=600–900, hMaxReusableSecs=1800–3000. Частично заполненный объект не получает весь этот набор автоматически.
- При xPaddingObfsMode=false клиентская ветка использует query-in-Referer и x_padding. Записанный xPaddingHeader сам по себе не меняет wire format.
- HTTP cookies/headers с данными кодируются base64url и разбиваются на части. Учитывать увеличение размера и суммарный лимит фронтенда, а не только размер одного chunk.
- Потенциально опасное расхождение кода: общий builder принимает congestion=brutal, но switch H3-клиента XHTTP не содержит этого case и попадает в panic. Для XHTTP/H3 не генерировать brutal; использовать проверенную поддерживаемую ветку. Это статический вывод, не воспроизведённый здесь crash-тест.
- Запретить scMaxEachPostBytes с активной неположительной From. Нулевой диапазон и ненулевой диапазон с From=0 — не одно и то же.
- Два плеча upload/download должны попадать в один согласованный контекст сессии сервера. Произвольное распределение запросов по независимым Xray без sticky routing не считать рабочим.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/splithttp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/config.go)
- [transport/internet/splithttp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/dialer.go)
