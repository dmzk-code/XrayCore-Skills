# XHTTP / SplitHTTP: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри xhttpSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `host` | `string` | HTTP Host; клиентский приоритет host → TLS/REALITY serverName → destination address. |
| `path` | `string` | Путь и необязательная query. Нормализация добавляет начальный / и, при path placement, конечный /. |
| `mode` | `string` | Пусто → auto. Допустимы auto, packet-up, stream-up, stream-one; регистр важен. |
| `headers` | `map[string]string` | Host в любом регистре запрещён; host задаётся отдельно. |
| `xPaddingBytes` | `range` | Нельзя выключать ненулевым диапазоном с границей <=0; нулевой диапазон включает runtime default. |
| `xPaddingObfsMode` | `boolean` | По умолчанию false; управляет использованием настраиваемой схемы padding. |
| `xPaddingKey` | `string` | Build default x_padding; при выключенном xPaddingObfsMode клиент использует стандартную ветку. |
| `xPaddingHeader` | `string` | Build default X-Padding, но без obfs runtime использует Referer, а не это поле. |
| `xPaddingPlacement` | `string` | Пусто → queryInHeader; cookie, header, query, queryInHeader. |
| `xPaddingMethod` | `string` | Пусто → repeat-x; repeat-x или tokenish. |
| `uplinkHTTPMethod` | `string` | Пусто → POST; преобразуется к верхнему регистру. GET только с явно заданным packet-up. |
| `sessionIDPlacement` | `string` | Пусто → path; path, cookie, header, query. |
| `sessionIDKey` | `string` | Для cookie/query default x_session; для header X-Session; path не нуждается в ключе. |
| `sessionIDTable` | `string` | Пользовательский ASCII-алфавит или predefined table; требуется достаточное пространство идентификаторов. |
| `sessionIDLength` | `range` | При custom table From >0; сумма количества возможных строк должна быть >= 2<<30. |
| `seqPlacement` | `string` | Пусто → path; path, cookie, header, query. |
| `seqKey` | `string` | Для cookie/query default x_seq; для header X-Seq. |
| `uplinkDataPlacement` | `string` | Пусто → auto; auto/body/header/cookie. header/cookie только с явно заданным packet-up. |
| `uplinkDataKey` | `string` | Для cookie default x_data; для auto/header X-Data; body не использует этот ключ для данных. |
| `uplinkChunkSize` | `range` | Runtime: cookie 2048–3072, header 3000–4000; иначе scMaxEachPostBytes. Нижняя заданная граница <64 поднимается до 64. |
| `noGRPCHeader` | `boolean` | Отключает добавление application/grpc для потокового request body; не превращает XHTTP в другой транспорт. |
| `noSSEHeader` | `boolean` | Серверная настройка заголовка ответа; проверить ветку обработчика перед изменением. |
| `scMaxEachPostBytes` | `range` | Runtime default 1000000. Неположительная нижняя граница в активном packet-up может привести к panic. |
| `scMinPostsIntervalMs` | `range` | Runtime default 30 мс; нулевой To не означает выключение задержки. |
| `scMaxBufferedPosts` | `int64` | Runtime default 30 при 0; буферизация серверных upload-пакетов. |
| `scStreamUpServerSecs` | `range` | Runtime default 20–80 секунд; не трактовать как TCP timeout. |
| `serverMaxHeaderBytes` | `int32` | Отрицательное значение запрещено; runtime default 8192 при <=0. |
| `xmux` | `object` | Пул HTTP соединений; не равен outbound.mux. Поля и особое поведение нулевого объекта ниже. |
| `downloadSettings` | `StreamConfig` | Отдельное download-плечо; запрещено при stream-one. Нужны address, port и XHTTP network для runtime. |
| `extra` | `object` | ЗАМЕНЯЕТ весь внешний XHTTPConfig, кроме host/path/mode. Остальные внешние значения теряются. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.

Подробные вложенные структуры: [runtime-peer.md](runtime-peer.md).
