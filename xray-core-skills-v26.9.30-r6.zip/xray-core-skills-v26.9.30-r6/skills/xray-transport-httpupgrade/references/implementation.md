# HTTPUpgrade не WebSocket framing

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

После HTTP/1.1 upgrade переносится raw stream, не WebSocket frames. Server принимает Connection:"upgrade" и Upgrade:"websocket" как точные lower-case сравнения всего значения; комбинированный Connection:"keep-alive, Upgrade" не равен ожидаемому. Path сравнивается целиком. headers.Host запрещён, использовать host.

?ed=N здесь не тот же WS Sec-WebSocket-Protocol payload: положительное Ed откладывает чтение101 до первого Read и позволяет раннюю запись. Не переносить произвольно клиентскую WS-реализацию. Server read header deadline4s, ограничение входного handshake reader12288bytes.

## Исходники
- [transport/internet/httpupgrade/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/httpupgrade/dialer.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
