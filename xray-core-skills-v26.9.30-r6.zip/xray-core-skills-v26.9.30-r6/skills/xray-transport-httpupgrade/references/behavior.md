# HTTPUpgrade: поведение и ловушки

- Транспорт присутствует, но получает non-removal deprecated warning. REALITY запрещён общим Build.
- Не равен WebSocket: handshake похож на Upgrade:websocket, после него используется другой поток данных. Не обещать совместимость с произвольным WebSocket клиентом/сервером.
- TLS dialer использует HTTP/1.1 и WebsocketHandshake; ALPN h2 сам по себе не добавляет H2 поддержку.
- Клиент принудительно ставит Connection:Upgrade, Upgrade:websocket. Если Sec-WebSocket-Key не задан, генерирует 16 случайных байт; при отсутствии Sec-WebSocket-Version ставит 13.
- `ed` здесь меняет ожидание ответа: Ed=0 проверяет handshake сразу, Ed>0 откладывает чтение ответа до первого Read. Это не тот же механизм, что WS base64 payload в Sec-WebSocket-Protocol, и число не следует трактовать как идентичный WS лимит.
- В проверке ответа нужен статус `101 Switching Protocols`, значение Upgrade после lower-case ровно websocket, Connection ровно upgrade. Список токенов вроде keep-alive, Upgrade не проходит эту конкретную проверку.
- Парсер ed имеет такой же небезопасный для ошибочного ввода cast Atoi→uint32: валидировать значение до генерации.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/httpupgrade/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/httpupgrade/dialer.go)
