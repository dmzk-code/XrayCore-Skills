# HTTPUpgrade: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри httpupgradeSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `host` | `string` | Отдельный HTTP Host; клиентский fallback TLS serverName → destination address. |
| `path` | `string` | Query ed разбирается Build и удаляется; путь нормализуется transport config. |
| `headers` | `map[string]string` | Host в любом регистре запрещён; заголовки handshake могут дополняться/заменяться runtime. |
| `acceptProxyProtocol` | `boolean` | Серверная настройка за доверенным PROXY-отправителем. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.
