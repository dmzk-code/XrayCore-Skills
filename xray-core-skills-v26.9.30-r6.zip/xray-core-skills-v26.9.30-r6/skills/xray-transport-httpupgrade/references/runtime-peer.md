# HTTPUpgrade: похож на WS handshake, но не WS framing

## Транспортные различия
После HTTP upgrade идёт обычный byte stream, не WebSocket framing. Нельзя смешивать WS клиент с HTTPUpgrade сервером потому, что оба ответили101.

Client формирует GET, Host из host→TLS serverName→address, Connection:Upgrade, Upgrade:websocket. При отсутствии добавляет случайный Sec-WebSocket-Key и version13. Header helper сохраняет заданный регистр ключей. Сторона ответа требует статус101 Switching Protocols и значения upgrade/websocket после lower-case.

Server read deadline4s, чтение заголовков ограничено12288 bytes, затем deadline сбрасывается. Host — опциональная проверка, path — точное совпадение normalized path. Connection должен быть ровно upgrade после lower-case: список `keep-alive, Upgrade` не равен этому значению в текущей реализации. Server формирует Sec-WebSocket-Accept, когда пришёл key.

## Early data и посредник
Ed!=0 на клиенте откладывает чтение upgrade ответа; Ed==0 читает ответ до возврата соединения. Это не та же схема, что WS subprotocol early data, и не означает перенос JSON настроек WS.

Server выполняет отдельный HTTP parse перед addConn. PROXY settings объединяются OR с sockopt, TLS обычным listener. Нестандартные header/early-data схемы требуют теста конкретного frontend; обычный101 не проверяет сохранность уже прочитанных байтов. Нагрузочный/пакетный тест включает первую запись и запись после handshake.

## Сценарий
httpupgrade-tls. Не добавлять REALITY: JSON gate её запрещает. Не ставить H2/H3 ALPN для HTTP/1.1 upgrade в стандартной паре.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [transport/internet/httpupgrade/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/httpupgrade/dialer.go)
- [transport/internet/httpupgrade/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/httpupgrade/hub.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `httpupgrade-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
