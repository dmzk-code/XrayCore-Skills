---
name: xray-protocol-composition
description: "VLESS flow/Vision, ML-KEM Encryption, native Hysteria/MASQUE, SOCKS/mixed/HTTP, auth и совместимость protocol/transport/security; при создании клиент-серверных пар и сложных цепочек."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# Протокол поверх транспорта
Прочитай общий [контракт](../xray-config-orchestrator/references/contract.md), [совместимость](../xray-config-orchestrator/references/compatibility.md), [VLESS](references/vless.md) и [native protocol](references/native.md).

Раздели settings (protocol) и streamSettings (transport/security). Определи фактический return type транспорта: именно его видит Vision. Собери auth пары, encryption/decryption и flow каждой стороны. Не переносить flow в rawSettings/realitySettings и не путать TLS, REALITY и VLESS Encryption.

При изменении протокола не терять user level/email, fallback и reverse. Не включать testpre/testseed и новую crypto-композицию как автоматическую оптимизацию. Выполни validate.py и peer-check; зафиксируй L1–L3. Для Encryption используй ключи, сгенерированные доверенным pinned core, а не произвольные base64 строки нужной длины.

Обязательно учитывать [Freedom finalRules и private-target защиту](references/freedom.md); successful accepted не гарантирует выход к локальному адресу.

## Индекс согласованной библиотеки r6
[Карта знаний и границ доказательства](../xray-config-orchestrator/references/knowledge-map.md). Версию поля проверять по pinned источнику, внешнюю среду — отдельным bounded тестом.

## VMess/Trojan и VLESS keys
Используй [полный перечень protocol settings, aliases и ограничения сверки ключей](references/vmess-trojan.md). Не путать deprecated с removed; legacy endpoint-массивы не служат балансировщиком.

## SOCKS/mixed/HTTP
[Все поля и runtime-правила этих proxy edges](references/local-proxy-edges.md). accounts:[] не равно запрету доступа; auth должен быть точным. HTTP headers могут менять фактические credentials. У HTTP outbound нет UDP; у SOCKS UDP ассоциация использует динамический порт и живой TCP control.
