# Native Hysteria и MASQUE

## Hysteria 2
Client protocol settings: `version:2`, `address`, `port`. Server: `version:2`, `users`/`clients`; user: `auth`, `email`, `level`. Client transport: `network:hysteria`, `hysteriaSettings.version:2`, `auth`. Native client transport.auth сопоставляется server protocol.users[].auth. Server transport.masquerade управляет ответом на неавторизованный HTTP, не подменяет protocol users.

При инкапсуляции VLESS поверх Hysteria не выдавать native Hysteria auth/config за эквивалент. Не вставлять чужие `up`, `down`, `obfs`, `hopInterval` в transport settings: соответствующие функции находятся в finalmask/quicParams и отличаются схемой.

## MASQUE CONNECT-IP
Client protocol settings: `address`, `port`, `remoteDNS` (массив IP literals). Transport: `host`, `path`, `user`, `pass`, `headers`. user/pass генерируют HTTP Basic Authorization; одноимённый server transport-блок не создаёт ACL.

Server protocol settings: users/clients с обязательными `email`, `pass`, optional `level`; `address`: массив максимум из одного IPv4 CIDR и одного IPv6 CIDR, не пустой; `mtu`: 0 либо 1280–65535. Email уникален без регистра и не содержит ':'. Транспорт допустим для native masque inbound; не использовать VLESS inbound с network=masque.

Успех TLS не достаточен: нужны CONNECT-IP response, назначенные адреса и поддерживаемый packet size. H2 и H3 имеют различный внешний протокол и MTU overhead; для H3 проверить UDP по всей цепочке. remoteDNS относится к native protocol, не к tlsSettings/sockopt.

## Остальные proxy protocols
VMess/Trojan/Shadowsocks могут иметь собственные ограничения. Пакет не копирует API Mihomo/sing-box. Для Trojan public/no-TLS builder имеет отдельный guard. WireGuard — proxy protocol в этой регистрации, не `streamSettings.network=wireguard`; TUN — inbound, не новый transport. Не создавать дополнительные транспортные скиллы из названий протоколов.


## Первичные источники pinned commit
- [infra/conf/hysteria.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/hysteria.go)
- [infra/conf/masque.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/masque.go)
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
