# SOCKS, mixed и HTTP: протокольные края и цепочки

Закреплённая версия: Xray-core v26.9.30. Это `inbounds[].protocol` / `outbounds[].protocol`, а не `streamSettings.network`. HTTP proxy CONNECT не равен XHTTP, HTTPUpgrade или WebSocket. Сначала определить роль протокола, затем транспорт каждой связи. В исходном loader `mixed` — входной alias SOCKS; `outbounds[].protocol="mixed"` не зарегистрирован.

## Поля входных настроек

| Путь в `settings` | Тип | Отсутствие / применение |
|---|---|---|
| SOCKS/mixed `auth` | string | Пустое значение и `noauth` выбирают NO_AUTH; только точное `password` включает password-auth SOCKS. Неизвестное значение тоже выбирает NO_AUTH. |
| SOCKS/mixed/HTTP `users` | массив `{user, pass}` | Основной список. В map сохраняется последний password повторённого username. |
| SOCKS/mixed/HTTP `accounts` | такой же массив | Любое non-null значение заменяет `users` целиком; `[]` очищает действующий список, `null` не переопределяет его. |
| SOCKS/mixed `udp` | bool | По умолчанию false; разрешает UDP ASSOCIATE, не превращает основной listener в фиксированный UDP-port. |
| SOCKS/mixed `ip` | Address, обычно IP string | При UDP ASSOCIATE применяется к IP ответа **и локальному bind нового UDP socket**. Без него используется local IP TCP-соединения. Нужен локально доступный адрес, не просто внешний NAT-address. |
| SOCKS/mixed/HTTP `userLevel` | uint32 | По умолчанию 0; уровень политики входных сессий. |
| HTTP `allowTransparent` | bool | По умолчанию false; передаётся в HTTP handler. Не является включателем системных TUN/TPROXY, DNS interception или маршрутов ОС. |

`auth` и `udp` не являются полями HTTPServerConfig. Имена role-specific полей проверяются по registry, а не общей догадке о proxy.

## HTTP-ветка SOCKS/mixed — важная граница безопасности

SOCKS handler направляет первый байт, отличный от 4/5, в HTTP server. Это действует для обоих имён `socks` и `mixed`. HTTP server требует Basic authentication только при **непустой** accounts map; SOCKS передаёт ему accounts только при `auth == "password"`.

Следствия, подтверждённые source и локальными соединениями:

- `auth:"password", accounts:[]`: SOCKS password handshake не имеет подходящей записи, **но HTTP CONNECT на том же listener остаётся без авторизации**. Это не deny-all.
- `auth:"Password"` либо другая опечатка: Build выбирает NO_AUTH; заполненный `accounts` это не исправляет.
- `users:[...], accounts:[]`: пустой alias скрывает основной список. `accounts:null` при том же `users` сохраняет защиту.
- HTTP inbound без accounts тоже не требует Basic authentication. TLS перед ним шифрует канал, но сам по себе не добавляет проверку пользователя.

Правило скилла: для password-защищённого SOCKS/mixed задавать **точное** `auth:"password"` и непустую действующую accounts map. Для HTTP задавать непустую accounts map. Проверять не только SOCKS, но и HTTP CONNECT: без пароля — отказ, с неверным — отказ, с верным — полезный трафик. Public listener без нужной проверки личности запрещён политикой генерации; локальная noauth лаборатория не образец для публичной эксплуатации.

Шаблон защищённых SOCKS/mixed настроек (секрет обязательно заменить):

```json
{"auth":"password","accounts":[{"user":"REPLACE_USER","pass":"REPLACE_WITH_UNIQUE_SECRET"}],"udp":false,"userLevel":0}
```

Это только фрагмент `settings`, не готовая конфигурация. По умолчанию локальный вход привязывать к `127.0.0.1`; при удалённом доступе отдельно согласовать транспортную защиту и ACL. Пароль SOCKS5/Basic в незашифрованном соединении не считать защищённым от наблюдения.

## Поля выходных настроек

| Поле | Тип и роль |
|---|---|
| `address` | Address; non-null включает simplified форму и полностью заменяет `servers`. |
| `port` | uint16; в авторинге обязателен 1..65535, даже когда permissive Build допускает нулевое значение. |
| `level`, `email` | uint32 и string; metadata выбранного remote user, а не дополнительные auth-поля. |
| `user`, `pass` | string; simplified форма создаёт user/account только при непустом `user`. Один `pass` не включает authentication. |
| `servers` | Legacy массив **ровно одного** `{address, port, users}`. `users` содержит не более одной записи `{user, pass, level, email}`. Балансировка — отдельные outbounds и balancer, не несколько servers. |
| HTTP `headers` | map string:string; дополнительные заголовки CONNECT, включая Go `text/template` с полями `.Source` и `.Target`. В SOCKS такого поля нет. |

Политика authoring требует непустые user/pass у объявленной password-записи. Для SOCKS5 учитывать **байты UTF-8**, не число символов: каждое поле должно помещаться в 1..255 bytes. Go JSON Build может принять более длинное значение; это не подтверждает его пригодность в handshake. HTTP Basic username не должен содержать `:` — это разделитель user/pass.

Упрощённая и legacy формы не дополняются. Не переносить `user/pass` в `streamSettings`; не помещать `users` непосредственно в simplified объект в надежде на объединение. Неверные типы и неизвестные role-specific поля не считать успешными настройками.

## HTTP headers и действующий пароль

`setUpHTTPTunnel` сначала устанавливает Basic `Proxy-Authorization` из выбранной учётной записи, **затем** применяет `headers`. Поэтому одноимённый пользовательский header перекрывает user/pass. В peer-check сравнивается фактическое значение постоянного Basic header; исходные credentials в диагностику не выводятся. Шаблонный header получает `PEER_PROXY_AUTH_UNVERIFIED`: checker не исполняет Go-шаблоны в несуществующем runtime-контексте.

Два ключа, различающихся только регистром, после `Header.Set` могут конфликтовать; порядок обхода Go map нельзя использовать для выбора победителя. CR/LF/NUL и некорректные имена header отвергаются авторингом. Заголовок `Host` нельзя считать заменой `Request.Host`/CONNECT destination по аналогии с transport host.

## TCP, UDP и длительность association

HTTP outbound явно отклоняет UDP. Для цепочки через него требуется другой UDP-outbound или осознанный блок UDP; отсутствие UDP не записывать как успешный тест. SOCKS outbound способен работать с SOCKS UDP ASSOCIATE; сервер должен разрешать `udp`.

SOCKS сервер создаёт UDP listener на port **0** (динамический порт), возвращает выбранный порт клиенту и связывает association с TCP control-соединением и inactivity policy. Закрытие control TCP завершает association. Открытие в firewall только UDP-порта основного TCP listener недостаточно. Через NAT/контейнеры/remote TLS frontend отдельно проверять достижимость возвращённого UDP endpoint и ограничение источника; один TCP CONNECT этого не доказывает.

Входной `socks` принимает SOCKS4/4a/5; SOCKS4 отклоняется при password-auth. SOCKS5 BIND не поддерживается. Особые Tor resolve-команды в прочитанной ветке обрабатываются как CONNECT, а не как полноценный резолвер Tor.

## Сопоставление протоколов

HTTP client → HTTP server допустим; HTTP client → SOCKS/mixed server допустим через HTTP-ветку. SOCKS client → SOCKS/mixed допустим; SOCKS client → HTTP server без отдельного преобразователя — несовместим. Когда сервер не требует авторизации, peer-check выдаёт предупреждение `PEER_PROXY_NO_AUTH`, а не доказательство совпадения парольной пары.

Для простого соединения без NAT/frontend использовать `validate.py client.json --peer server.json --direct-peer`. В сетях с преобразователем включать карту физических плеч, не обходить ошибку случайной сменой имени protocol. Для общих правил: [топология](../../xray-config-orchestrator/references/topology-and-listeners.md).

## Доказательства

[Измерения r6](../../xray-runtime-validation/references/r6-regressions.json): восемь auth-случаев с реальным CONNECT/payload и восемь proxy-пар с неправильным паролем и положительным контролем. В отчёте PASS опасного fixture означает **воспроизведение ожидаемого риска**, не разрешение его использовать. Не проверены remote NAT, внешние аккаунты или другие реализации SOCKS/HTTP.

## Закреплённые первичные источники
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)
- [infra/conf/socks.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/socks.go)
- [infra/conf/http.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/http.go)
- [proxy/socks/server.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/socks/server.go)
- [proxy/socks/protocol.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/socks/protocol.go)
- [proxy/http/server.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/http/server.go)
- [proxy/http/client.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/http/client.go)
