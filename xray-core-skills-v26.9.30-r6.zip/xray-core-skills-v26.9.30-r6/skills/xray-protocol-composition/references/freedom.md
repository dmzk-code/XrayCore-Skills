# Freedom: конечные правила выхода и private-address защита

Правильный путь: `outbounds[].settings.finalRules` у `protocol:freedom`. Это **не** routing.rules и не streamSettings. Правила проверяются по порядку; первое совпадение выбирает action. Поля: action (`allow`/`block`, регистр нормализуется), network (NetworkList), port (PortList), ip (StringList с правилами geodata), blockDelay (Int32Range, секунды). Отсутствующий критерий не ограничивает совпадение.

В этой версии default block private-IP применяется при inbound names vless/vmess/trojan/hysteria/wireguard и shadowsocks*; vless-reverse имеет default block-all. MASQUE в просмотренной switch не перечислен, поэтому нельзя переносить это правило на все протоколы без проверки. Явные finalRules проверяются **раньше** default rule. При freedom.sockopt.dialerProxy конечная фильтрация отключается: finalRules с предупреждением игнорируются и этот freedom уже не конечный выход.

Блокировка не обязательно мгновенный reset: default blackhole удерживает поток 30–90 секунд. Поэтому успешный входной handshake и accepted в access-log могут соседствовать с отсутствием полезных байтов. Не лечить это сменой транспорта, отключением TLS или случайным увеличением буферов.

## Лабораторный allow, не production default
Все локальные тестовые server/relay разрешают только TCP/UDP к 127.0.0.1, ports1024–65535, затем блокируют остальное с blockDelay0. Это позволяет проверить echo и второй локальный узел, **не** открывает публичный сервер и не отключает защиту всех private networks. Лаборатория слушает только127.0.0.1 и имеет отдельные credentials. Не переносить эти разрешения в production.

## Миграция и дополнительные поля
`ipsBlocked` принят структурой и выдаёт warning об удалении, но просмотренный Build **не** переносит значения в finalRules. Не полагаться на сохранение блокировки старым полем. `noise:{}` вызывает removed error; `noises:[]` имеет отдельную старую семантику: type rand/str/hex/base64, packet, delay, applyTo ip/ipv4/ipv6. Это не взаимозаменяемый формат Finalmask.noise.

Freedom `fragment` имеет packets,length,interval,maxSplit; required length и interval. Здесь `interval`, а у Finalmask fragment — `delay`, и положение слоя различается. targetStrategy имеет приоритет над старым domainStrategy внутри settings; общий outbound builder мигрирует эффективную стратегию в sockopt. proxyProtocol передаётся только при значении1 или2. redirect — host:port; пустой host меняет только port. userLevel — policy level.

Проверено реальным ядром: до узкого allow RAW+TLS принимал VLESS, но blackhole блокировал loopback echo; после добавления allow TCP/UDP, negative auth и restart прошли. Это наблюдение по локальной схеме, не доказательство всех веток DNS rebinding.

## Источники
- [Builder](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/freedom.go)
- [Runtime default/final rules](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/freedom/freedom.go)
