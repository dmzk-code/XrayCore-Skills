# VLESS: полные места размещения и ограничения

## Server settings
`users` / `clients`: массив пользователей; `decryption`: обязательно `none` либо корректная ML-KEM-строка; `fallbacks`: массив; `flow`: default для user.flow; `testseed`: массив uint32 экспериментального назначения. User: `id`, `flow`, `level`, `email`, `reverse`, `testseed`; user.encryption на inbound запрещён. Пустой user.flow наследует settings.flow; короткий testseed (<4) наследует общий. Inbound reverse требует tag, не допускает sniffing.

Fallback: `name`, `alpn`, `path`, `type`, `dest`, `xver`; path пустой либо начинается `/`; dest — port, host:port или Unix socket; xver=0/1/2. Non-none decryption несовместимо даже с заданным пустым массивом fallbacks (non-nil). `serve-ws-none` имеет специальную ветку, не является внешним hostname.

## Client settings
Simplified: `address`, `port`, `id`, `encryption`, `flow`, `email`, `level`, `reverse`, `testpre`, `testseed`, `seed`. `seed` присутствует в struct, но присваивание account.Seed в прочитанном Build закомментировано: не обещать эффект. Legacy vnext: ровно один сервер, ровно один user. Simplified address имеет приоритет. Reverse в этом поколении использовать только simplified: `{tag, sniffing}`. tag обязателен; reverse user на server не имеет права обычного forward proxy.

Outbound.flow допускает `xtls-rprx-vision-udp443`, inbound нет. Отключённый TCP Mux не тождественен запрету XUDP. Не добавлять общий mux к каждому транспорту с собственным pooling.

## ML-KEM-768 + X25519
Server prefix: `mlkem768x25519plus.{native|xorpub|random}.{seconds-or-range}[s].…`; client: `mlkem768x25519plus.{native|xorpub|random}.{1rtt|0rtt}.…`. Ключевые сегменты server декодируются в 32 или 64 bytes, client — 32 или 1184 bytes. Короткие сегменты (<20 символов) builder относит к padding. Это описание парсера, не спецификация безопасной криптографии: не собирать ключи вручную и не считать любую строку соответствующей длины корректной парой.

Различать Build и Init/Handshake: принятие prefix и длины ещё не доказывает правильность числа/порядка ключей и peer pairing. 0rtt — явный выбор модели повторного использования; не включать молча. Локально выполнить `xray help vlessenc`/доступную справку точной сборки, сохранить результат генерации в приватных файлах. Если helper отсутствует у пользовательского бинарника, не изобретать его CLI. Пакет не записывает production ключи в примеры.

Runtime.New создаёт ClientInstance при non-none encryption, затем Process выполняет encryption.Handshake перед VLESS. Vision поддерживает CommonConn особой веткой, а при XorConn/non-RAW/additional-security отключает splice penetration. Не путать возможность обработки с ускорением. Inbound Vision TLS требует TLS1.3. Без flow на клиенте TCP к account с обязательным Vision будет отклонён.

`testpre > 0` запускает экспериментальные preconnect workers; это ресурсная нагрузка и особый lifecycle, не бесплатное уменьшение latency. В стандартных рецептах оставлено выключенным.


## Первичные источники pinned commit
- [infra/conf/vless.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/vless.go)
- [proxy/vless/outbound/outbound.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vless/outbound/outbound.go)
- [proxy/vless/inbound/inbound.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vless/inbound/inbound.go)
