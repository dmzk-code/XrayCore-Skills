# VMess и Trojan: протокол отдельно от транспорта

Зафиксированы [VMess Build](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/vmess.go), [VMess Account](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vmess/account.go), [Trojan Build](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/trojan.go) и [нормализация UUID](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/common/uuid/uuid.go). Наличие транспорта RAW/XHTTP/gRPC не определяет схему `settings` протокола. Не переносить flow/VLESS encryption в Trojan/VMess.

## VMess
Inbound принимает `users` либо legacy `clients`; `clients` при non-null имеет приоритет, даже если это пустой массив. `default.level` — byte. User содержит `id`, `level`, `email`, `security`, `experiments`. ID может быть каноническим UUID либо короткой UTF-8 строкой до30bytes; ядро детерминированно переводит короткое значение в UUID. Сравнивать нормализованные ID, а не только текст.

Outbound имеет simplified `address`, `port`, `id`, `level`, `email`, `security`, `experiments` либо `vnext` ровно с одним endpoint и одним user. Non-null simplified address заменяет **весь** vnext. Резервирование делать отдельными outbounds с balancer, не несколькими vnext members. `address` и `port` endpoint — не адрес сервиса назначения внутри прокси.

`security` регистронезависимо распознаёт `aes-128-gcm`, `chacha20-poly1305`, `auto`; пустое или иное значение, в том числе `none`/`zero`, превращается в AUTO. Не считать опечатку отказом парсера или выключением шифрования. Эффективная security из Account используется клиентом; сравнивать её на inbound как обязательный общий пароль неправильно.

`experiments` — строка с **регистрозависимым поиском подстрок** `AuthenticatedLength` и `NoTerminationSignal`; это не JSON-массив, не единое transport-level переключение. Включать только с явно проверяемой целью. `alterId` отсутствует в этом VMessAccount, старые примеры не подтверждают его действие.

## Trojan
Outbound simplified-поля: `address`, `port`, `password`, `level`, `email`, `flow`; альтернативно `servers` ровно с одним таким endpoint. Simplified address имеет приоритет. Address обязателен, port не0, password непустой. Level ограничен byte (0..255), в отличие от simplified VMess level uint32. Непустой flow вызывает ошибку удалённой возможности.

Inbound — `users`/`clients` с password, level, email, flow и необязательные fallbacks. Приоритет clients тот же. Builder inbound не вводит такой же явный запрет пустого password, как outbound; безопасный авторинг всё равно требует непустой секрет. Сравнение credentials — точное, регистр пароля значим, email не заменяет password. Несогласованный пароль не считается допустимым оттого, что TLS прошёл.

Fallback: `name`, `alpn`, `path`, `type`, `dest`, `xver`. Path пустой или с `/`; xver только0/1/2. Числовой dest означает локальный TCP-порт, адрес+порт — TCP, абсолютный путь или @ — Unix; специальный `serve-ws-none` имеет отдельную serve-ветку. Точный frontend/fallback сценарий проверять отдельно от положительного Trojan handshake. Fallback не создаёт публичную аутентификацию для произвольного сервиса.

Оба протокола в данном commit печатают предупреждения deprecated/non-removal: это **не удаление реализации**. При миграции действующего проекта не менять протокол молча. В новом проекте обосновать выбор и выполнить полноценную проверку нужных TCP/UDP сценариев. Успешный тест RAW не сертифицирует все сочетания транспортов.

## Что делает пакет
Структурно проверяет все перечисленные поля и числовые типы, aliases, single-endpoint ограничения, неверный flow, пустой пароль и ID. Peer-check понимает simplified/legacy форму и проверяет действующие credentials на выбранном inbound. Отчёт не выводит значения credentials. Нативные регрессии отдельно испытывают четыре пары (VMess/Trojan × simplified/legacy) с положительным TCP/UDP, неверными credentials и повторным положительным контролем.

## VLESS Encryption: граница статического доказательства
Две строки с префиксом `mlkem768x25519plus` ещё не являются согласованной парой. Для простого формата с одним32-byte X25519 ключом пакет при наличии optional cryptography выводит public из private и сравнивает bytes. Для ML-KEM seed/public, цепочек ключей, padding или отсутствующего backend выдаёт **PEER_VLESS_ENCRYPTION_UNVERIFIED**, а не притворное подтверждение.

Ключи генерировать доверенным `xray vlessenc` закреплённой версии. Не принимать декоративную случайную строку за ML-KEM public key. В r5 есть отдельные native тесты реально сгенерированных X25519 и ML-KEM768 пар на RAW, XHTTP и mKCP; неверный public key проверяется отдельно. Они доказывают только эти параметры/режимы и эту сборку, не все комбинации VLESS Encryption.

## Поля закреплённых объектов

### VMessUser

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `id` | `string` |
| `security` | `string` |
| `experiments` | `string` |
| `level` | `uint32` |
| `email` | `string` |

### VMessDefault

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `level` | `uint8` |

### VMessInbound

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `users` | `array[VMessUser]` |
| `clients` | `array[VMessUser]` |
| `default` | `VMessDefault?` |

### VMessTarget

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `address` | `Address?` |
| `port` | `uint16` |
| `users` | `array[VMessUser]` |

### VMessOutbound

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `address` | `Address?` |
| `port` | `uint16` |
| `id` | `string` |
| `security` | `string` |
| `experiments` | `string` |
| `level` | `uint32` |
| `email` | `string` |
| `vnext` | `array[VMessTarget]` |

### TrojanUser

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `password` | `string` |
| `level` | `uint8` |
| `email` | `string` |
| `flow` | `string` |

### TrojanTarget

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `address` | `Address?` |
| `port` | `uint16` |
| `password` | `string` |
| `level` | `uint8` |
| `email` | `string` |
| `flow` | `string` |

### TrojanOutbound

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `address` | `Address?` |
| `port` | `uint16` |
| `password` | `string` |
| `level` | `uint8` |
| `email` | `string` |
| `flow` | `string` |
| `servers` | `array[TrojanTarget]` |

### TrojanFallback

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `name` | `string` |
| `alpn` | `string` |
| `path` | `string` |
| `type` | `string` |
| `dest` | `RawMessage` |
| `xver` | `uint64` |

### TrojanInbound

| Поле | Тип JSON/целочисленная граница |
|---|---|
| `users` | `array[TrojanUser]` |
| `clients` | `array[TrojanUser]` |
| `fallbacks` | `array[TrojanFallback]` |
