# Ресурсный бюджет и высокая нагрузка

Не существует доказанного «самого быстрого» JSON для всех сетей. Сначала зафиксировать RTT, loss, bandwidth, simultaneous sessions, message sizes, CPU architecture и лимиты FD/RAM. Измерения публиковать с workload и продолжительностью, а не с одним удачным speedtest.

Модель RAM: baseline + активные соединения × реально наблюдаемый overhead + buffers/queues + HTTP/QUIC pools + DNS/route caches. Объявленные окна QUIC — предел flow control, не обещание немедленного выделения всей памяти. Для XDRIVE отдельно requests/second ≈ active sessions × polling frequency плюс list/get/put/delete; квоты provider важнее настройки 64 workers.

Перед увеличением concurrency/окон/keepalive измерить baseline. Затем менять один параметр, сравнивать p50/p95 latency, throughput, errors, RSS и FD после cooldown. Нагрузочный driver в пакете имеет ограничение потоков/длительности, тестирует только указанный loopback SOCKS/echo и не является DDoS-инструментом.

mKCP: uplink/downlink capacity участвуют в целочисленных формулах windows. Увеличение не создаёт отсутствующую полосу; unsigned overflow и MTU overhead вредны. Finalmask увеличивает размер пакетов; учитывать IP+UDP+QUIC/KCP+mask overhead. Не ставить максимальные окна по всем слоям одновременно.

Hysteria brutal скорости задавать по измеренному каналу; завышение может дать потери/нагрузку. XHTTP packet-up header/cookie payload расширяется при base64 и создаёт больше HTTP запросов, чем stream-up. Единичный chunk меньше лимита header не гарантирует, что суммарный заголовок влезает.

Нельзя установить OS TCP congestion control настройкой на любом транспорте: UDP/QUIC использует другой controller. cpu/FD/conntrack/SYN backlog и sysctl менять только отдельным согласованным rollout с rollback; скилл не применяет произвольные «тюнинг-команды».


## Первичные источники pinned commit
- [transport/internet/kcp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/config.go)
- [transport/internet/xdrive/params.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/xdrive/params.go)
- [transport/internet/hysteria/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/hysteria/dialer.go)
- [transport/internet/splithttp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/splithttp/config.go)
