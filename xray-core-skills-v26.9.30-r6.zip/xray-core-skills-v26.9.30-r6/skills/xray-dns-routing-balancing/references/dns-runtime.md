# DNS: полный путь выбора сервера, фильтрации и fallback

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

## Четыре разных уровня
`dns.queryStrategy` ограничивает семейства ответов встроенного DNS; `routing.domainStrategy` решает, когда маршрутизатор инициирует DNS для сопоставления правил; `outbounds[].targetStrategy` относится к разрешению пользовательской цели; `streamSettings.sockopt.domainStrategy` — к соединению с адресом назначения системного dialer. Одинаковое слово «DNS» не делает эти настройки взаимозаменяемыми. Адрес сервера туннеля и адрес пользовательского сайта должны иметь независимый путь bootstrap.

## Все общие поля и фактическое поведение
| JSON-путь относительно `dns` | Пропуск / значение | Применение |
|---|---|---|
| `servers` | При отсутствии/пустом списке создаётся localhost resolver | Каждый элемент — строка address либо объект NameServer. Не считать пустой список запретом DNS. |
| `hosts` | Нет статических записей | Статическое сопоставление до обращения к upstream. Ответ IP имеет TTL 10 секунд. Domain value заменяет имя запроса. |
| `clientIp` | ECS не задан этим блоком | Только IP literal; конкретный сервер может переопределить. Это не IP для привязки исходящего socket. |
| `tag` | Генерируется случайный tag | Inbound-tag собственных DNS-запросов, чтобы отделить их маршрутизацию от пользовательского трафика. |
| `queryStrategy` | UseIP | UseIP: IPv4+IPv6; UseIPv4/UseIP4 и UseIPv6/UseIP6: одно семейство; UseSystem/UseSys дополнительно проверяет доступные системные маршруты. Неизвестная строка в builder превращается в UseIP. |
| `disableCache` | false | Передаётся каждому upstream, если не переопределено на сервере. |
| `serveStale` | false | Разрешение отдачи устаревших записей; сроки и обновление раскрыты в cache/resolver reference. Не отменяет отсутствие записи при cold start. |
| `serveExpiredTTL` | 0 | Общая настройка, передаваемая cache каждого resolver; server pointer может явно переопределить нулём. |
| `disableFallback` | false | Исключает добавление неприоритетных клиентов, но НЕ гарантирует отсутствие обращения к первому серверу, если итоговый список пуст. |
| `disableFallbackIfMatch` | false | Исключает fallback только при наличии domain-match. |
| `enableParallelQuery` | false | Запрашивает выбранных клиентов параллельно, но возвращает по приоритетным группам, не просто первый ответ любого сервера. |
| `useSystemHosts` | false | Читает hosts при Build и добавляет записи после явного `hosts`; ошибка чтения фатальна для Build. На Windows путь из SystemRoot, иначе /etc/hosts. |

`queryStrategy` принимает написания из `resolveQueryStrategy`: `useip`, `use_ip`, `use-ip`; варианты `useip4/useipv4/use_ip4/use_ipv4/use_ip_v4/use-ip4/use-ipv4/use-ip-v4`; аналогично v6; `usesys/usesystem/use_sys/use_system/use-sys/use-system`. Регистр незначим, произвольные пробелы не удаляются. Для генерации использовать канонические UseIP, UseIPv4, UseIPv6, UseSystem.

## Все поля объекта сервера
| Поле | Значение / default / роль |
|---|---|
| `address` | Обязательно; IP/имя или одна из реально зарегистрированных схем ниже. |
| `port` | uint16; для URL-based resolver порт берётся из URL его обработчиком; для обычного UDP — поле port, 0 обрабатывается resolver как стандартный порт. Не задавать два противоречащих порта. |
| `clientIp` | IP literal; непустой валидный IP заменяет общий ECS. |
| `skipFallback` | false; исключает только из fallback-списка, а не из domain-matched списка. |
| `domains` | StringList; приоритетные правила, порядок связан с порядком регистрации matcher. |
| `expectedIPs`, `expectIPs` | Основное имя expectedIPs; если оно пусто, применяется alias expectIPs. Без `*` оставляет только совпавшие IP, пустой результат считается неуспехом. |
| `unexpectedIPs` | Без `*` удаляет совпавшие IP; пустой результат считается неуспехом. |
| `queryStrategy` | UseIP наследует ограничение глобального DNS, а не включает заново отключённое семейство. Конфликт глобального IPv4-only с IPv6-only сервера приводит к ошибке создания client. |
| `tag` | Непустой заменяет общий DNS tag. |
| `timeoutMs` | 0 → 4000 мс; отдельный Context timeout каждого запроса. |
| `disableCache`, `serveStale`, `serveExpiredTTL` | Pointer override: отсутствует/null → наследование; явно false/0 → переопределение. |
| `finalQuery` | false; останавливает ДОБАВЛЕНИЕ дальнейших серверов в список. Это не запрет уже запущенных запросов parallelQuery. |

В `expectedIPs` наличие `*` переключает строгую фильтрацию в предпочтение: если подходящие IP есть, возвращаются они; иначе исходный список остаётся. В `unexpectedIPs` `*` предпочитает несовпавшие IP, но при отсутствии альтернативы сохраняет исходный список. Эти режимы не являются fail-closed фильтром адресов.

## Зарегистрированные resolver-формы
| address | Маршрут |
|---|---|
| `localhost` | Системный DNS; Xray routing для этой операции не используется. |
| IP либо обычный address + port | Classic UDP через dispatcher. |
| `tcp://…` | DNS-over-TCP через dispatcher. |
| `tcp+local://…` | Прямой системный TCP, вне routing dispatcher. |
| `https://…` | DoH через dispatcher. |
| `h2c://…` | Незашифрованный HTTP/2 DoH через dispatcher; только доверенный локальный участок. |
| `https+local://…`, `h2c+local://…` | Прямой DoH без dispatcher. |
| `quic+local://…` | Прямой DNS-over-QUIC. `quic://` не является зарегистрированным remote-эквивалентом в этом factory. |
| `fakedns` | FakeDNSEngine; нужен согласованный корневой fakeDns и восстановление имён на входе. |

Неизвестная URL-схема НЕ обязана дать немедленный Build error: factory может дойти до classic UDP ветки. Авторинг должен отвергать неизвестную схему, а не полагаться на успешный `run -test`.

## Точный порядок fallback
Сначала добавляются совпавшие domain-клиенты, каждый один раз. Если встретился finalQuery, список возвращается немедленно. Затем, если не запрещено fallback-политикой, добавляются ещё не использованные клиенты без skipFallback до первого finalQuery. Если список всё-таки пуст, выбирается ПЕРВЫЙ сконфигурированный client. Поэтому `disableFallback:true` с неподходящими domains не является гарантией «никого не спрашивать».

В последовательном режиме возвращается первый непустой ответ. В параллельном режиме запросы стартуют сразу ко всем выбранным клиентам. Соседние клиенты с одинаковым PolicyID образуют группу; можно вернуть успех внутри текущей группы, но более поздняя группа ждёт полного неуспеха предшествующей. PolicyID строится по ECS, skipFallback, queryStrategy, tag, domains, expected/expect/unexpected; address, timeout/cache/stale/finalQuery не входят в этот ключ. Перестановка серверов влияет на группировку.

## Разрешение и безопасность
`MayUseSystemResolver()` возвращает true при наличии хотя бы одного localhost client. Перенаправление системного DNS обратно в такой Xray может образовать петлю. Даже при наличии независимого DoH одного localhost достаточно для некоторых доменов. `UseSystem` и `localhost` — разные понятия: первое ограничивает семейства по маршрутам, второе выбирает системный resolver.

Сначала проверять cold-cache bootstrap, затем cache, затем отсутствие upstream/IPv6. Не выдавать CDN/transport timeout за доказанную DNS-ошибку. Локальные лабораторные тесты DNS не являются проверкой утечек на интерфейсах конкретного устройства.

## Исходники
- [infra/conf/dns.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/dns.go)
- [app/dns/dns.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/dns/dns.go)
- [app/dns/nameserver.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/dns/nameserver.go)
