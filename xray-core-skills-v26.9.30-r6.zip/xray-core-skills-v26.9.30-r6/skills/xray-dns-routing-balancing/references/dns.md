# DNS: карта полей и цикл bootstrap

Корневые поля: `servers`, `hosts`, `clientIp`, `tag`, `queryStrategy`, `disableCache`, `serveStale`, `serveExpiredTTL`, `disableFallback`, `disableFallbackIfMatch`, `enableParallelQuery`, `useSystemHosts`.

Server может быть строкой или объектом: `address`, `port`, `clientIp`, `skipFallback`, `domains`, `expectedIPs`, `expectIPs`, `unexpectedIPs`, `queryStrategy`, `tag`, `timeoutMs`, `disableCache`, `serveStale`, `serveExpiredTTL`, `finalQuery`. address обязателен, clientIp — IP literal. Server cache/stale параметры являются указателями и позволяют переопределять глобальное значение явно false/0.

`expectedIPs` при пустом списке берёт `expectIPs`; `*` из expectedIPs включает actPrior, из unexpectedIPs — actUnprior, а не обычный IP matcher. Не копировать правила IP из другого ядра без разбора. `hosts` поддерживает адрес/массив адресов и domain redirection; если в массиве присутствует domain, builder возвращает ProxiedDomain, а не смешанную балансировку IP+domain. Новые схемы не должны смешивать эти типы.

`skipFallback` исключает сервер из fallback-кандидатов, а не отключает его целевые запросы. `disableFallbackIfMatch`, `finalQuery`, parallel query и stale изменяют политику разрешения; не подменять их понятием «никогда не утекать». Реальный leak-test требует packet capture/контроля путей на целевой системе. На свежем устройстве без DNS-cache endpoint должен разрешаться независимо от ещё не поднятого outbound.

Составь четыре отдельных шага: endpoint DNS → transport connect; application domain routing; target resolution выбранным outbound; DNS-сервис для клиентского устройства. Встроенный DNS не перенастраивает системный resolver сам. SOCKS5 ATYP=domain и локальное разрешение дают разные трассы.

Не выдавать fallback DNS за failover прокси. Для сети без IPv6 UseIPv6/ForceIPv6 требуют отдельной проверки, а не универсальной оптимизации. DNS timeoutMs в миллисекундах, TTL/keepalive других слоёв могут быть в секундах.


## Первичные источники pinned commit
- [infra/conf/dns.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/dns.go)
- [infra/conf/transport_sockopt.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_sockopt.go)
- [infra/conf/router.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/router.go)
