# Балансировка: реальные алгоритмы и все вложенные настройки

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

## Объект balancer
`routing.balancers[]`: непустой уникальный `tag`; непустой `selector` (StringList селекторов outbound tags); `strategy:{type,settings}`; необязательный `fallbackTag`. Пустой strategy.type → random, регистр имени нормализуется. Доступны random, roundRobin, leastPing, leastLoad. `fallbackTag` — существующий outbound, не balancer и не «автоматически самый быстрый».

Стратегия выбирает outbound **для нового соединения**; не объединяет пропускную способность нескольких серверов для одного TCP stream и не переносит уже установленный stream при отказе. `dialerProxy` строит последовательную цепочку и не является балансировкой. Публичный default outbound при ошибке balancer может нарушить fail-closed: явное безопасное fallback и конечное routing-правило должны быть частью топологии.

## random и roundRobin
Обе стратегии имеют пустую структуру `settings`; произвольные `healthCheck`, `weights`, `concurrency` внутри не подключают такие функции. Random равномерно выбирает кандидата; roundRobin циклически выбирает из текущего списка с синхронизированным index.

Неочевидное условие: подключение observatory и отбрасывание dead-кандидатов здесь включается **при непустом fallbackTag**. Неизвестный наблюдателю кандидат считается alive. При ошибке GetObservation остаётся исходный список. Без fallbackTag эти стратегии не становятся health-aware только от присутствия блока observatory.

## leastPing
Требует feature Observatory; берёт alive-кандидата с минимальным `Delay`, полученным из report. При равном Delay первый в порядке report сохраняется. Нет подходящего/понятного report → пустой tag, затем fallbackTag или ошибка с дальнейшим default handling. Гарантировать абсолютный выбор быстрейшего сервера без актуальных probes нельзя.

## Полный leastLoad.settings
| Поле | Тип | Build и runtime |
|---|---|---|
| `costs` | array `{match:string,regexp:bool,value:number}` | Первая совпавшая запись задаёт cost; details ниже. |
| `baselines` | array duration strings | Build убирает <=0, но не сортирует; задавать возрастающие значения. Сравнение с **RTT deviation × sqrt(cost)**, строго меньше baseline. |
| `expected` | int32 | Отрицательное → 0. При отсутствии baselines локальный минимум выбора — 1. Если expected больше числа доступных, возвращаются все доступные. |
| `maxRTT` | duration | Отрицательное → 0; 0 отключает фильтр. `Delay >= maxRTT.Milliseconds()` исключается. |
| `tolerance` | number | Преобразование float32 и clamp 0..1. Фильтр доли ошибок включается только при >0; **0 отключает фильтр**, а не требует ноль ошибок. |

Это **не** CPU load, число активных соединений или канал, измеренный в Мбит/с. Из report берутся alive, delay и при наличии HealthPing — average, deviation, all/fail. Ранжирование: weighted deviation; затем average; меньше failures; больше samples; tag. При обычном observatory без HealthPing используется delay вместо статистической deviation. Выбор среди итоговых qualified nodes — случайный.

С baselines и expected>0 набираются узлы по возрастающим baseline, но expected является минимальным желаемым числом даже при нарушении последнего baseline. С expected=0 и baselines допустим пустой результат и fallback. Без baselines expected=0 выбирает один лучший по ранжированию. maxRTT и alive фильтруются до выбора, поэтому expected не возвращает уже исключённые dead узлы.

## Полный costs и auto-weight
`match` без regexp ищется как подстрока, с regexp — Go regexp. Пустое совпадение не считается подходящим. Первая подходящая запись с value>0 задаёт этот cost. Иначе из совпавшей строки извлекается первое число по `\d+(\.\d+)?`; если его нет, default cost=1. Затем значение кэшируется по outbound tag. Невалидный regexp логируется и не совпадает. Не передавать отрицательные/NaN/Infinity cost: авторинг требует конечный value>0 или явный осмысленный auto-weight. Число 0 в auto-match возможно и меняет weighted score, это не надёжная семантика «отключённый узел».

## Fallback и override
Сначала SelectOutbounds, потом override target (если задан через API), иначе strategy.PickOutbound. Если выбор пустой — fallbackTag, при его отсутствии ошибка. API override не доказывает здоровье target. После снятия override повторно проверять нормальную стратегию. Логи и API-теги не должны содержать секреты.

Обязательные тесты схемы: холодный report, все alive, один dead, все dead, неизвестный кандидату report, изменённый набор tags, недоступная probe-цель при рабочем туннеле. Полезная нагрузка и переключение проверяются отдельно; запись SOURCE_RUNTIME означает прочитанную реализацию, а не что все эти тесты автоматически пройдены.

## Исходники
- [infra/conf/router.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/router.go)
- [infra/conf/router_strategy.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/router_strategy.go)
- [app/router/balancing.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/router/balancing.go)
- [app/router/strategy_random.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/router/strategy_random.go)
- [app/router/strategy_leastping.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/router/strategy_leastping.go)
- [app/router/strategy_leastload.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/router/strategy_leastload.go)
- [app/router/weight.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/router/weight.go)
