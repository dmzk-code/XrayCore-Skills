# Routing и outbound graph

Корень: `rules`, `domainStrategy`, `balancers`. domainStrategy: AsIs, IPIfNonMatch, IPOnDemand; незнакомое значение builder превращает в AsIs — линтер строже. Не использовать sockopt UseIPv4 здесь.

Rule поля: `ruleTag`, `outboundTag`, `balancerTag`, `domain`/`domains`, `ip`, `port`, `network`, `sourceIP`/`source`, `sourcePort`, `user`, `vlessRoute`, `inboundTag`, `protocol`, `attrs`, `localIP`, `localPort`, `process`, `localOS`, `webhook` (url, deduplication, headers). `domains` заменяет `domain`; `sourceIP` выигрывает у source; `outboundTag` выигрывает у balancerTag. Генератор запрещает двусмысленное задание обоих target-полей. Старые `type:field` и domainMatcher не следует называть действующими настройками по одному старому примеру: в прочитанном RouterConfig их нет.

Balancer: `tag`, непустой `selector`, `strategy:{type,settings}`, `fallbackTag`. Типы random (default), leastPing, leastLoad, roundRobin; builder lower-case. Префиксные selectors должны выбирать только нужные proxy tags, не direct/block. leastPing/leastLoad требуют корректно подключённых наблюдений и совместимых strategy settings; не объявлять параметр по имени достаточной healthcheck-системой.

Проверить наличие target tags, дубли inbound/outbound/balancer tags, пустые selectors, конфликт default outbound и deny-rules, порядок правил. Совпадения нескольких условий, применение sniffing и метаданных требуют runtime контекста; process/localOS доступны не во всех типах ingress.

`streamSettings.sockopt.dialerProxy` связывает исходящий endpoint с другим outbound; `proxySettings` в этой версии удалён (даже пустой объект). Проверять прямые и транзитивные циклы. `loopback` повторно вводит запрос в routing с inboundTag; петля может быть условной и не видна по одним dialerProxy. Для такого конфига обязателен ручной граф правил и тест с ограниченным timeout.

Sniffing: enabled, destOverride, domainsExcluded, ipsExcluded, metadataOnly, routeOnly. routeOnly не должен незаметно менять фактическую цель соединения. Обновление DNS/routing не гарантирует переключение уже установленных потоков. Balancer выбирает новые соединения; старые прерываются или продолжаются по своему lifecycle.

Mux: enabled, concurrency, xudpConcurrency, xudpProxyUDP443; последнее default=reject, варианты reject/allow/skip. Не путать XHTTP XMUX, gRPC pooling и общий Mux.Cool. Vision/TCP и XUDP проверяются раздельно. `concurrency<0` — специальное отключение, а не нормальный отрицательный worker count.


## Первичные источники pinned commit
- [infra/conf/router.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/router.go)
- [infra/conf/xray.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/xray.go)
- [proxy/vless/inbound/inbound.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vless/inbound/inbound.go)


## Observatory JSON (проверенный builder)
observatory: subjectSelector (array string), probeURL (string), probeInterval (duration string), enableConcurrency (bool). burstObservatory: subjectSelector и **обязательный** pingConfig, иначе Build error. Это разные механизмы; неизвестные поля из другого клиента не переносить.

Перед leastPing/leastLoad выбрать наблюдатель, selector prefixes которого покрывают тот же набор outbound tags. Проба должна идти тем же транспортом, но её HTTP endpoint может отдельно блокироваться; отсутствие результата не является логическим доказательством отказа передачи пользовательских данных. Fallback должен быть явно задан и исключать рекурсию; fail-open к direct не добавлять без требования пользователя.


## Основание на закреплённом commit
- [infra/conf/observatory.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/observatory.go)