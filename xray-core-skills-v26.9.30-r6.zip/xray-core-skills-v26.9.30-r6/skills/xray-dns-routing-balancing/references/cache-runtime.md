# DNS cache: TTL, serveStale, singleflight и память

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

| Поле | Реализация и практический смысл |
|---|---|
| disableCache=false | Cache отдельно у resolver; A/AAAA хранятся раздельно. Свежий TTL>0 отдаётся без upstream. |
| disableCache=true | Ответ публикуется ожидающим запросам, но не сохраняется в cache. Это не отключение DNS. |
| serveStale=false | Истёкший ответ не используется как немедленный результат. |
| serveStale=true | Существующий истёкший record может немедленно вернуться; параллельно запускается refresh с отдельным8s timeout без наследования cancellation исходного запроса. |
| serveExpiredTTL | **Максимальный возраст просрочки в секундах**, а НЕ TTL в выдаваемом DNS-ответе. Возвращаемый stale ответ имеет TTL1. |
| serveExpiredTTL=0 + serveStale=true | Нет ограничения возраста stale; периодическая очистка этим controller не запускается. Возможен рост cache по числу имён. |
| finite serveExpiredTTL | Очистка каждые300s; deadline записи сравнивается с текущим временем минус разрешённый stale-период. |

Глобальные значения наследуются, server pointer false/0 переопределяет. stale работает только после первого успешного сохранения; cold-cache outage он не лечит. Для политики безопасности с меняющимися IP назначения осознанно ограничивай срок устаревших ответов.

Внутри serveExpiredTTL приводится к отрицательному int32; авторинг ограничивает его диапазоном0..2147483647, а не использует весь uint32. Это защитное ограничение генератора, не точная ошибка JSON-parser.

Запросы coalesce через singleflight по FQDN+семейство4/6/46. Ожидающие одинаковый запрос используют выполнение с context инициатора. При dual-family запросе ожидание A и AAAA влияет на задержку даже при быстром первом ответе. Нельзя выводить «утечка памяти» из одного роста RSS: cache, фоновые обновления и освобождение Go heap имеют разную динамику.

При очистке больших maps реализовано shrink по high-watermark, порогу10240 и снижению65%, миграция batches4096. Это внутренние константы, **не JSON-поля**. Не придумывать dns.cacheSize/cacheMaxEntries/cleanupInterval. Для проверки нужны fresh-hit/stale-hit/cold-miss, выключенный upstream после прогрева и наблюдение количества реальных запросов, а не только `run -test`.

## Исходники
- [app/dns/cache_controller.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/dns/cache_controller.go)
- [app/dns/nameserver_cached.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/dns/nameserver_cached.go)
