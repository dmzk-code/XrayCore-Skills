# Observatory и Burst: настройки, HTTP-проверки и интерпретация результатов

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

## Обычный `observatory`
Четыре поля: `subjectSelector` (массив селекторов outbound tags), `probeURL` (строка), `probeInterval` (duration-строка), `enableConcurrency` (boolean). Пропущенный/пустой subjectSelector не запускает background probe. Пустой probeURL → `https://www.google.com/generate_204`. Интервал 0 → 10 секунд. Используется GET с таймаутом клиента 5 секунд и TLS handshake timeout 5 секунд, без перехода по redirect. Body закрывается, но не вычитывается целиком. В этой реализации **HTTP status не проверяется**. Получение 404/500 само по себе не означает Alive=false.

При `enableConcurrency:false` теги сортируются, каждый probe и ожидание probeInterval выполняются последовательно: полная длительность обхода растёт с числом узлов. При true probes параллельны, следующий обход — после завершения текущих и паузы. Не задавать отрицательный интервал: builder может принять, но отрицательный sleep создаёт слишком частый цикл.

Alive=true сохраняет измеренные миллисекунды и LastSeenTime; при неуспехе Delay становится 99999999. Это latency HTTP-запроса через конкретный outbound, не ICMP RTT и не результат замера полосы пропускания.

## Полный `burstObservatory`
Корневые поля: `subjectSelector` и **обязательный объект `pingConfig`**. Настройки ниже находятся именно в `burstObservatory.pingConfig`, а не в balancer.strategy.settings.

| Поле | Тип / единица | Пропуск и ограничения | Потребитель |
|---|---|---|---|
| `destination` | URL string | После TrimSpace пустой → `https://connectivitycheck.gstatic.com/generate_204` | Проверяется ЧЕРЕЗ выбранный outbound. |
| `connectivity` | URL string | Пустой → дополнительная проверка сети не выполняется, сеть предполагается доступной | Прямой HTTP client после неуспеха destination. |
| `interval` | duration string, например `"30s"` | 0 → 1 минута; любое ненулевое значение меньше 10s заменяется на 10s с warning | Интервал между пробами в среднем, не период полного sampling-цикла. |
| `sampling` | integer | <=0 → 10 | Размер сохраняемого набора измерений. |
| `timeout` | duration string | <=0 → 5s | Таймаут одного HTTP client. |
| `httpMethod` | string | Пустая строка → HEAD; иная обрезается по краям, **не upper-case** | Один и тот же метод используется для destination и connectivity. |

Для новых конфигураций генератор нормализует метод к `HEAD` либо `GET` и требует положительные интервалы; это AUTHORING_POLICY, а не точная копия допустимых парсером значений. Передавать строку `" "` нельзя считать надёжным способом выбора HEAD: после TrimSpace получается пустое имя, а ветка подсчёта body сравнивает именно `GET`.

## Что реально измеряется
`MeasureDelay` в pinned `burst/ping.go` не проверяет ни 204, ни класс 2xx. Любой HTTP-ответ без транспортной ошибки учитывается как успех. Комментарий «need 204» не соответствует этой ветке кода. Proxy destination не следует redirect; прямой connectivity client использует стандартную redirect-политику. Ошибка destination и успех connectivity → failed sample. Ошибка обоих → нулевой sample, который **не добавляется**; старые результаты не превращаются этим в новые успешные.

Только точное `httpMethod:"GET"` вызывает `io.Copy(io.Discard, resp.Body)` перед окончанием измерения. Тогда URL с большим ответом измеряет и передачу body, увеличивает трафик и зависит от timeout. HEAD и прочие методы измеряют получение ответа без полного body drain. `size=32000` в URL не заставляет HEAD загружать 32000 байт. Не изобретать отдельные method/status/header параметры для connectivity: их нет в этой JSON-структуре.

Планировщик использует период `interval × sampling`; probes распределяются случайно по этому периоду, плюс выполняется быстрый one-time check. Срок годности выборки — `2 × interval × sampling`. Зависшую предыдущую запланированную серию отменяют при следующей. При остановке или изменении сети наблюдение может оставаться устаревшим до его естественного обновления/истечения: отсутствие нового измерения не равно доказанному отказу транспорта.

## Практическая композиция
Селекторы observatory должны покрывать все кандидаты соответствующего balancer, но исключать сам служебный выход проверки и DNS-bootstrap, если они не являются кандидатами. Не включать оба типа observatory в один конфиг без ясного выбора потребителя: они предоставляют одинаковый feature interface, и двойное перечисление не означает объединение результатов.

Для проверки полезного трафика использовать отдельно тест TCP/UDP и ожидаемого содержимого, а не полагаться на Alive. Для CDN различать: транспортный endpoint, endpoint проверки доступности и публичный сайт назначения. Проверка одного из них не доказывает исправность двух других.

## Исходники
- [infra/conf/observatory.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/observatory.go)
- [infra/conf/router_strategy.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/router_strategy.go)
- [app/observatory/observer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/observatory/observer.go)
- [app/observatory/burst/healthping.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/observatory/burst/healthping.go)
- [app/observatory/burst/ping.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/app/observatory/burst/ping.go)
