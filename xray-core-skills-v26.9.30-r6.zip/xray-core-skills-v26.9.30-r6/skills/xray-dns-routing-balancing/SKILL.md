---
name: xray-dns-routing-balancing
description: "Xray DNS, bootstrap, routing, balancers/observatory, mux/XUDP, dialerProxy и проверки циклов. Для split routing, failover и многосерверных сложных конфигураций."
metadata:
  version: "6.0.0"
  xray-tag: "v26.9.30"
  xray-commit: "b26a91de4f3294e26a0ad0a970b81a386a41f789"
---

# DNS, routing и балансировка
Прочитай [общий контракт](../xray-config-orchestrator/references/contract.md), [DNS](references/dns.md), [routing](references/routing.md), [бюджеты](references/resources.md).

Сначала нарисуй независимый путь DNS к endpoint и management API. Различай routing.domainStrategy, DNS queryStrategy, outbound targetStrategy и sockopt.domainStrategy. Проверь tags и порядок rules, selectors как префиксы, default outbound и fail-closed требования. Не обещай перенос существующего TCP-потока при выборе другого outbound.

Выполни validate.py. Для динамических tags от API/reverse явно перечисли их в topology.json и отдельно проверь регистрацию: статическая ошибка ссылки может быть обоснованным исключением, не повод удалить рабочий динамический путь.

Проверяй probe URL через выбранный outbound, успешную загрузку/UDP и состояние после отказа. Непрошедший probe и отсутствие интернет-связности — разные диагнозы.

Обязательно учитывать [Freedom finalRules и private-target защиту](../xray-protocol-composition/references/freedom.md); successful accepted не гарантирует выход к локальному адресу.

## Реализация r3
[DNS selection/fallback](references/dns-runtime.md), [cache/TTL](references/cache-runtime.md), [обычный и burst probe](references/observatory-runtime.md), [все стратегии и costs](references/balancer-runtime.md). При запросе функциональной проверки различать probe HTTP response, реальную передачу body и маршрут DNS bootstrap.
