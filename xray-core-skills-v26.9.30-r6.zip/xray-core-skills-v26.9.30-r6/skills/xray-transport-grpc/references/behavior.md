# gRPC: поведение и ловушки

- gRPC сохранён, но StreamConfig печатает предупреждение non-removal deprecated с предложением XHTTP stream-up H2. Это не hard removal.
- `headers`, `path`, `host`, `idleTimeout`, `initial_window_size` не входят в GRPCConfig этого релиза. Использовать точные `authority`, `serviceName`, `idle_timeout`, `initial_windows_size`.
- TLS/REALITY разрешены общим Build. gRPC internals используют insecure.NewCredentials, но реальная TLS/REALITY обёртка выполняется в custom dialer: это НЕ доказательство открытого трафика.
- Клиент кеширует grpc.ClientConn по destination + memory stream config; H2 reuse не равен outbound.mux.
- Отрицательные окна/таймауты не становятся «отрицательными timeout»: Build превращает их в 0. Избегать маскирующего ошибку пользовательского ввода.
- Очень частые keepalive могут быть отвергнуты сервером/прокси. Согласовать enforcement policy после изучения hub.go и версии grpc-go из go.mod.
- User-Agent задаётся отдельной runtime процедурой, удаляющей suffix grpc-go. Не считать произвольную маскировку UA воспроизведением поведения браузера.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/grpc/dial.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/dial.go)
