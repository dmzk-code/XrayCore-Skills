# gRPC: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри grpcSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `authority` | `string` | HTTP/2 authority; в клиенте приоритет explicit → TLS serverName → destination domain, если нет REALITY. |
| `serviceName` | `string` | Имя сервиса; проверять нормализацию/имена stream в transport/internet/grpc/config.go. |
| `multiMode` | `boolean` | false → Tun stream, true → TunMulti stream; сверить сервер и frontend path. |
| `idle_timeout` | `int32` | <=0 нормализуется в 0; runtime keepalive time в секундах. |
| `health_check_timeout` | `int32` | <=0 →0; runtime keepalive timeout в секундах. |
| `permit_without_stream` | `boolean` | Разрешение keepalive без активных stream; может включить установку keepalive даже при нулевых timeout. |
| `initial_windows_size` | `int32` | <0 →0; >0 передаётся в grpc.WithInitialWindowSize; байты. |
| `user_agent` | `string` | Текущее JSON имя с подчёркиванием. Клиент поддерживает chrome/firefox/edge/golang и произвольную строку. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.
