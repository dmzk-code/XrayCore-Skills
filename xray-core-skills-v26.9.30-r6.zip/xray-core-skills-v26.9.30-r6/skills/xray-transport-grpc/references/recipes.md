# gRPC: сложные схемы

Рецепты — процедуры для агента, не уже испытанные production deployments.

### gRPC за reverse proxy
Описать внешний TLS/ALPN, имя сервиса, frontend routing и backend H2/h2c. Генерировать конфигурацию прокси по его версии и официальной документации, не заменяя grpc_pass на случайный HTTP proxy_pass. Проверить обычный Tun и MultiMode отдельно.

### gRPC + REALITY без L7 termination
Сохранить REALITY end-to-end. Не ставить обычный TLS terminating CDN перед REALITY. Проверить authority независимо от SNI. Ошибки UNAVAILABLE диагностировать по listener/protocol/serviceName/ALPN, не только таймаутам.

## Обязательный отрицательный тест
Проверить неверные auth/host/path или peer-поля, обрыв канала, reconnect после рестарта backend и одновременные соединения. Наблюдаемая ошибка должна соответствовать неисправному уровню; не лечить любой отказ выключением проверки сертификата.
