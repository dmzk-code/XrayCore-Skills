# gRPC: пути, режимы, pooled connection и server flags

## Имена RPC
serviceName без начального `/` проходит PathEscape и использует методы Tun и TunMulti. При начальном `/` участок до последнего slash задаёт service, а последний сегмент — `TunName|MultiName`. В server варианте после `|` — имя multi; в client multi варианте единственный последний сегмент также используется как multi stream name. Поэтому для custom paths сравнивать фактические service/method, а не буквальные строки serviceName.

## MultiMode не серверный переключатель регистрации
Server регистрирует **оба** RPC обработчика. Клиент multiMode выбирает TunMulti; у сервера не обязательно указывать тот же bool. Именно так составлена пара grpc-multi-tls.

## Поля по сторонам
Client использует authority, serviceName, multiMode, idle_timeout, health_check_timeout, permit_without_stream, initial_windows_size, user_agent. Server читает serviceName и positive idle/health timeout для KeepaliveParams. Поля permit_without_stream/initial_windows_size не превращаются в отдельные server options в прочитанной ветке.

Client getGrpcClient кэширует ClientConn по destination и MemoryStreamConfig; не создаёт обязательный новый TLS коннект на каждый logical stream. Shutdown исключается из переиспользования. Backoff500ms*1.5 с jitter0.2 и max19s; минимальный connect timeout5s. Это кодовые defaults, не разрешение выдумать одноимённые JSON ключи.

## TLS / bind
TLS и REALITY есть на обеих сторонах; ALPN H2 согласовать. Listener запускает bind/Serve в goroutine: успех Build/создания Listener не означает успешный bind. Проверять логи и payload, не только `run -test`.

Authority не равен IP назначения; user_agent не равен TLS fingerprint. User-agent переключатель поддерживает короткие имена, но gRPC-Go internal override не доказывает имитацию браузерного протокола. Общий transport deprecated warning не означает удаление.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [transport/internet/grpc/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/config.go)
- [transport/internet/grpc/dial.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/dial.go)
- [transport/internet/grpc/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/hub.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `grpc-tls`: TCP PASS, UDP PASS, auth PASS, restart FAIL, short-load NOT_RUN.
- `grpc-multi-tls`: TCP PASS, UDP PASS, auth PASS, restart FAIL, short-load NOT_RUN.

## Создание FinalMask и reconnect: уточнение r6
Проверка `if streamSettings.FinalMask != nil` относится к runtime-указателю, не просто к наличию JSON-объекта. `ToMemoryStreamConfig` создаёт его только при непустом tcp/udp masks массиве. Пустой finalmask, пустые массивы и объект только с quicParams оставляют non-Finalmask ветку. Оба последних случая повторно дали server-only recovery FAIL в 5-секундном bounded тесте, после рестарта клиента control PASS: [r6 evidence](../../xray-runtime-validation/references/r6-regressions.json). Предыдущие 45-секундные результаты сохранены отдельно. Не предлагать фиктивные маски как исправление; источник [memory settings](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/memory_settings.go).
