# Custom paths и исправление reconnect

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Обычный serviceName кодируется и имеет методы Tun/TunMulti. Значение с начальным / задаёт путь: префикс до последнего / — service, окончание до | — Tun, после | — TunMulti. Сервер регистрирует оба; client multiMode выбирает метод, а не обязывает сервер выставлять такой же boolean.

В v26.9.30 подтверждён дефект reconnect closure. [Подтверждение upstream](../../xray-runtime-validation/references/grpc-upstream-fix.md). Нельзя выдавать настройку idle_timeout за исправление захваченного canceled context. Продолжение использования требует явного принятия ограничения либо проверенной версии с source fix.

## Исходники
- [transport/internet/grpc/dial.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/dial.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
