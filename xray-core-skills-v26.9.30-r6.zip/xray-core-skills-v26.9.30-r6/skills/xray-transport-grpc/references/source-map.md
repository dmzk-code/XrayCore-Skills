# Источники и границы: grpc

Core `b26a91de4f3294e26a0ad0a970b81a386a41f789`; r2.


## Основание на закреплённом commit
- [transport/internet/grpc/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/config.go)
- [transport/internet/grpc/dial.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/dial.go)
- [transport/internet/grpc/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/grpc/hub.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)

Полные диапазоны и Git blob SHA: [provenance](../../xray-source-audit/references/provenance.json).
Не загружать все исходники заново для стандартного рецепта. Сначала использовать fields.md и runtime-peer.md.
Повторное исследование обязательно для другого commit, нестандартной обёртки, новой зависимости, неподтверждённой ветки либо расхождения теста с описанием. Статус прочитанного файла не равен покрытию всех вызываемых зависимостей.
