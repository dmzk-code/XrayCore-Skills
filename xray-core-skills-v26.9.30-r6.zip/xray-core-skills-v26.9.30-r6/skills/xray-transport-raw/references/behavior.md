# RAW / TCP: поведение и ловушки

- `raw` и `tcp` преобразуются во внутреннее имя `tcp`. `rawSettings` имеет приоритет над `tcpSettings`; это замена объекта, не слияние.
- В `Dial()` порядок: системное/Finalmask TCP-соединение → TLS либо REALITY → connection authenticator из `header`. HTTP-header находится внутри защищённого потока, когда включена защита.
- `header.type=http` не превращает RAW в WebSocket, XHTTP или пригодный для обычного HTTP reverse proxy протокол. Не направлять его через произвольный `proxy_pass` как обычный сайт.
- Поля `request` HTTP-authenticator: `version`, `method`, `path` (StringList), `headers` (map StringList). Поля `response`: `version`, `status`, `reason`, `headers`. Для пользовательской map заголовков непустая map заменяет набор по умолчанию. Значение заголовка null вызывает ошибку.
- HTTP request Build по умолчанию задаёт URI `/` и собственный набор заголовков; не выдавать этот набор за пользовательскую конфигурацию или гарантированную маскировку браузера.
- TLS и REALITY допустимы на уровне StreamConfig. `flow` принадлежит VLESS user, а не RAWSettings. Совместимость Vision, fallback и конкретного протокола проверить отдельно по proxy/vless.
- RAW TLS содержит специальные `fromMitm` ветви. Не переносить их в обычный клиентский рецепт: они зависят от контекста MITM, источника имени и проверки сертификата.
- Не путать inbound `listen` и порт сервиса с `streamSettings.address/port`: у обычного RAW Dial destination передаёт protocol handler, и эти stream-поля не являются универсальным override. Их специфические consumers — например XHTTP downloadSettings и XDRIVE — проверяются отдельно.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/tcp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tcp/dialer.go)
