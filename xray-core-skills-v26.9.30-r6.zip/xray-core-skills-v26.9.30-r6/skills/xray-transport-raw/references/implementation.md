# Сервер и внешний заголовок

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

Server tcp/hub.go объединяет acceptProxyProtocol из rawSettings и sockopt через OR. Нижележащий listener проходит Finalmask, затем TLS либо REALITY, затем raw header authenticator. rawSettings.header не маскирует внешний TLS ClientHello: он находится внутри security. Unix socket определяется listen, а не network="unix". Listener.Close закрывает listener; жизнью уже принятых соединений управляют их handlers.

HTTP header объект имеет type:none/http; request.version/method/path/headers и response.version/status/reason/headers. headers — map StringList. Непустая map заменяет default headers целиком; nil значение header отвергается. Request path — список вариантов, response status/reason частично дополняются200/OK. Это не reverse HTTP proxy.

## Исходники
- [transport/internet/tcp/hub.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tcp/hub.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
