# RAW: порядок слоёв и peer-контракт

## Реальный путь выполнения
DialSystem/Finalmask.DialTCP → TLS/REALITY handshake → rawSettings.header authenticator → protocol payload. Поэтому rawSettings.header HTTP находится **внутри** TLS; fragment/header-custom Finalmask — на внешнем соединении. Это разные уровни.

`rawSettings` перекрывает `tcpSettings`; network=raw/tcp выбирает один runtime tcp. Server acceptProxyProtocol объединяется с sockopt; отправитель PROXY должен находиться на доверенном предыдущем hop. Клиентский finalmask не начинает работать на сервере автоматически.

## Vision и шифрование
Обычный RAW TLS/REALITY возвращает direct wrapper, необходимый нешифрованному на уровне VLESS Vision. TLS1.3 нужен для серверной Vision ветки. VLESS Encryption добавляет CommonConn: см. общий protocol skill; наличие этого wrapper меняет достижимость, а не гарантирует splice.

## Проверять раздельно
Публичный адрес / маршруты / TCP listener → TLS trust и SNI → VLESS id/flow → target TCP/UDP. При ECH/masterKeyLog/custom curves не включать настройки «для полноты»; использовать раздел TLS runtime. Для multi-hop следующий RAW endpoint задаётся в settings.address, нижележащий hop выбирается sockopt.dialerProxy и не должен возвращаться к себе.

## Готовые схемы
raw-none, raw-tls, raw-vision-tls, raw-reality, raw-fragment-tls, chain-raw-tls. `raw-none` только локальный диагностический контроль; остальные также используют тестовые credentials. Команды генерации в общем каталоге сценариев.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [transport/internet/tcp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/tcp/dialer.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [proxy/vless/outbound/outbound.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vless/outbound/outbound.go)
- [proxy/vless/inbound/inbound.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/proxy/vless/inbound/inbound.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `raw-none`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `raw-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `raw-vision-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `raw-reality`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `raw-fragment-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
- `chain-raw-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
