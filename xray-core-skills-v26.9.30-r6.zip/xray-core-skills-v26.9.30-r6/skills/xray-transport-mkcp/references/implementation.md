# Поля ёмкости и внешний carrier

Версия: `v26.9.30`, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`.

MTU default1350, TTI50ms, uplink5/downlink20 MiB/s, cwndMultiplier1, maxSendingWindow2097152bytes. In-flight = capacity*1024*1024/MTU/(1000/TTI), minimum8; sending buffer = maxSendingWindow/MTU. Capacity не bandwidth promise. Build отвергает MTU<21, TTI вне10..1000, cwndMultiplier<1, нулевой sendingbuffer.

Legacy header/seed в kcpSettings не переносятся Build. Для legacy framing применять finalmask.udp[].type=mkcp-legacy с согласованным header/value. Sudoku classic expansion требует уменьшения MTU; это не эквивалент tlsSettings и не повод снимать TLS. TLS над KCP работает поверх надежного stream; REALITY отвергается StreamConfig builder.

## Исходники
- [transport/internet/kcp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/config.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
