# mKCP: UDP, TLS и фактические defaults

## Реализованные слои
Клиент меняет destination network на UDP, применяет UDP Finalmask/DialSystem, создаёт KCP Connection и затем при TLSConfig оборачивает её в tls.Client. Listener аналогично создаёт tls.Server. Следовательно mKCP+TLS — реализованная ветка, а не только допустимое слово в StreamConfig.

Клиент здесь не вызывает UClient: наличие fingerprint в общей TLS-конфигурации не доказывает uTLS на mKCP. REALITY отвергается общим builder.

## Состояние и размеры
Серверная сессия идентифицируется remote address, remote port и16-bit conversation. NAT rebinding меняет идентичность; «тот же UUID» протокола не означает прежнее KCP-состояние. Очередь входных пакетов клиента рассчитана на1024 элементов; при переполнении чтение сбрасывает пакет. Это не настройка kcpSettings.bufferSize.

Defaults: mtu1350, tti50, uplinkCapacity5, downlinkCapacity20, cwndMultiplier1, maxSendingWindow2097152. In-flight окна вычисляются из capacity*1024*1024/mtu/(1000/tti), с нижним пределом8. Capacity здесь не совпадает по единицам с Bandwidth.Bps QUIC.

## Миграция
header и seed есть в JSON struct, но текущий Build их не переносит. Для legacy wire behaviour использовать только разобранную Finalmask mkcp-legacy конфигурацию с согласованной другой стороной. Не переносить readBufferSize/writeBufferSize/congestion из старого поколения без доказательства существования в новом inventory.

## Практика
Сценарий mkcp-tls. Сначала проверить UDP порт и pin, затем потери/MTU/CPU. Значение maxSendingWindow должно вмещать MTU; отдельный TLS handshake может пройти, а крупные UDP datagrams — нет. Для capacity benchmark loopback недостаточен.

Вышеприведённые правила имеют статус SOURCE_BUILD/SOURCE_RUNTIME. Фактические результаты лабораторных схем приведены отдельно ниже; не переносить их на все значения полей.


## Основание на закреплённом commit
- [transport/internet/kcp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/config.go)
- [transport/internet/kcp/dialer.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/dialer.go)
- [transport/internet/kcp/listener.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/listener.go)
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)


## Фактический прогон r2
[Полный отчёт](../../xray-runtime-validation/references/runtime-evidence.json); [непройденные проверки и ограничения](../../xray-runtime-validation/references/known-issues.md).
- `mkcp-tls`: TCP PASS, UDP PASS, auth PASS, restart PASS, short-load PASS.
