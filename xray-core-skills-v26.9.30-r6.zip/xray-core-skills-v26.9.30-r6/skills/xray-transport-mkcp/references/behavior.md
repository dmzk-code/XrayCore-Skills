# mKCP: поведение и ловушки

- `kcp`/`mkcp` → внутреннее `mkcp`. Указатель у численных полей даёт различие missing/null и explicit 0: пропуск сохраняет registered default, 0 участвует в проверках.
- В этой версии старые поля congestion/readBufferSize/writeBufferSize отсутствуют в KCPConfig. Не переносить их из старых статей или настроек другого ядра.
- header/seed — пример принятых, но не применённых полей. Для legacy wire compatibility изучить `finalmask.udp` и mkcp-legacy в этой версии, а не просто копировать старый seed.
- getSendingInFlightSize = uplinkCapacity*1024*1024/mtu/(1000/tti), минимум 8; receive аналогично с downlinkCapacity. Деление целочисленное; не делать вывод о линейной зависимости latency/throughput по одному параметру.
- Огромные capacity/mtu/window могут быть формально допустимы, но приводить к переполнению uint32, фрагментации или большой памяти. Отдельно проверять разумные границы и фактический path MTU.
- REALITY отклоняется StreamConfig. TLS не запрещён общим parser для KCP; перед рецептом подтвердить его реальное применение в kcp/dialer.go и listener.go. Не делать вывод о поддержке только из отсутствия ошибки builder.
- Внешний канал — UDP; приложению может быть нужен TCP/UDP через протокол поверх него. Развести эти два значения network.

## Основание
- [infra/conf/transport_method.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/infra/conf/transport_method.go)
- [transport/internet/kcp/config.go](https://github.com/XTLS/Xray-core/blob/b26a91de4f3294e26a0ad0a970b81a386a41f789/transport/internet/kcp/config.go)
