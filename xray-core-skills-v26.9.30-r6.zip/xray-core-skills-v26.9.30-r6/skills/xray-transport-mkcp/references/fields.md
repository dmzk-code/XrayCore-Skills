# mKCP: поля

Snapshot v26.9.30, commit `b26a91de4f3294e26a0ad0a970b81a386a41f789`. Перечень основного JSON struct проверен по `infra/conf/transport_method.go`; это не заявление о полной проверке всех сочетаний runtime.

`range` означает Xray Int32Range: целое число либо строка диапазона; пустая строка → 0, отрицательные границы парсятся, From/To упорядочиваются (infra/conf/common.go; допустимость зависит от поля). `?` означает Go pointer: отсутствие может отличаться от explicit zero.

| Поле внутри kcpSettings | JSON-тип | Семантика / default / ограничения |
|---|---|---|
| `mtu` | `uint32?` | Registered default 1350; Build требует >=21. Наличие 0 отличается от отсутствия поля. |
| `tti` | `uint32?` | Registered default 50 мс; текущий Build принимает 10–1000 включительно. |
| `uplinkCapacity` | `uint32?` | Registered default 5; runtime использует множитель 1024*1024. Не путать с QUIC Bandwidth string. |
| `downlinkCapacity` | `uint32?` | Registered default 20; та же единица capacity. |
| `cwndMultiplier` | `uint32?` | Registered default 1; Build требует >=1. |
| `maxSendingWindow` | `uint32?` | Registered default 2097152; число байт; целочисленное maxSendingWindow/mtu должно быть >0. |
| `header` | `object` | JSON поле есть, но текущий KCPConfig.Build не переносит его в runtime config. Не генерировать как рабочую маску. |
| `seed` | `string?` | JSON поле есть, но текущий KCPConfig.Build его не использует. Не считать действующим шифрованием. |


Вложенные объекты/особенности описаны в behavior.md. Общие security/sockopt/finalmask поля находятся в соседнем supporting skill. Неизвестные поля нельзя считать работающими только потому, что конфигурация загрузилась.
