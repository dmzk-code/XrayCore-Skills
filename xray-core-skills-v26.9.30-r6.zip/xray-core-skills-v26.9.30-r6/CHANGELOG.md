# Изменения r6 / 6.0.0 — 7 октября 2026

## Исправлено по исходникам и проверено ядром

Добавлены SOCKS/mixed/HTTP protocol edges: семь объектов / 34 позиции полей, aliases users/accounts и simplified/legacy servers. Проверяются точный auth=password, пустые/отключённые accounts, длина SOCKS5 credentials, HTTP Basic username, реальный Proxy-Authorization после headers, дубли usernames и ограничения TCP/UDP. В loopback воспроизведена открытая HTTP-ветка SOCKS при пустых password-accounts; это отвергается новым authoring rule, не патчем ядра.

Новый topology_checks.py: явный --direct-peer без неявного предположения о NAT/frontend; пересечения физических listeners с учётом SO_REUSEPORT и владельцев XHTTP sessions; разные TCP/UDP порты не смешиваются. Проверяется анонимный outbound dialerProxy и collisions служебных tags. Custom mask/preamble и неоднозначные DNS/dualstack/carrier связи остаются UNVERIFIED вместо ложных утверждений.

gRPC warning теперь касается клиентской ветки и реального условия создания FinalMask. quicParams-only и empty object не маскируют известную reconnect-регрессию. Два bounded native cases сохранили FAIL_KNOWN и положительный контроль после перезапуска клиента.

## Проверяющая инфраструктура

clean_env удаляет dotted и uppercase-underscore core env names; два native confdir controls подтвердили изоляцию от подмешивания локальных overlay. Неизвестные имена JSON полей скрыты в null/shadow diagnostics. Новый run_r6_regressions.py выполняет hash-before-execution и разделяет parser expectations, auth observations, proxy payload, environment и known runtime failures. CI поддерживает --run-r6-regressions и не маркирует известные runtime failures как здоровую конфигурацию.

Исправлены устаревшие index.counts (оставались числа r3) и версия активного общего контракта (оставалась r2), хотя metadata скиллов уже обновлялась. Registry counts/revision и активная версия контракта теперь защищены тестами и release verifier. Все 17 SKILL metadata имеют 6.0.0.

Новые справочники: local-proxy-edges.md, topology-and-listeners.md, lab-environment.md. Общий orchestrator и все транспортные скиллы связаны с новыми общими правилами. Текущий inventory: 97 объектов, 584 позиции полей, 128 source records с точным объёмом чтения.

## Испытания и границы

564 unit tests (75 новых); новая native серия 8 parser, 8 auth, 8 proxy, 2 env; отдельно 2 известных gRPC recovery failures. Повторён r5 runner: 21 wire, 9 composition, 10 parser expectations. Точные текущие отчёты — в [VALIDATION](VALIDATION.md). Старые baseline/extended reports сохранены без переименования в новые исполнения.

Ниже история предыдущих ревизий. Утверждения о «текущем» результате внутри исторических разделов относятся к их собственной ревизии.

---

# Изменения r5 / 5.0.0 — 7 октября2026

## Исправлены ошибки существующей модели, а не только добавлены инструкции
XHTTP peer-check сравнивает только активные metadata, учитывает регистр headers, ignored path keys, auto payload, default padding и server extraction. HTTP Host использует эффективный fallback и точную серверную семантику. MASQUE сравнивает полный URI и имеет отдельную модель h2/h3 listeners. RAW справочник больше не обещает универсальный destination override через streamSettings.address.

Protocol checker теперь распознаёт VMess/Trojan simplified/legacy настройки и credentials; добавлено10 объектов/46 позиций полей. VLESS single-X25519 проверяется optional backend, непрослеженные ML-KEM/chain/padding пары не получают неявную верификацию. Native lab создаёт настоящие пары через xray vlessenc и испытывает RAW/XHTTP/mKCP.

Новый compose_config.py реализует Config.Override вместо recursive merge. Учтены full-path tail, deferred prepend, полная замена endpoint, null/empty, env по ключам и typed decode до merge. Вывод по умолчанию без secrets, запись только в новый приватный файл, местные JSON/JSONC без неявного окружения и URL. Новый runner сопоставляет9 схем с native -dump и выполняет21 wire+10 parser/build cases. Добавлен CI-флаг --run-r5-regressions.

75 новых unit/regression test methods; итоговый test count и фактический вывод приведены в [VALIDATION](VALIDATION.md). Все17 skill metadata обновлены до5.0.0, реестр90 объектов/550 полей/119 source records.17 source records в этой ревизии добавлены/повторно проверены с точным объёмом чтения.

Первый новый runtime runner имел две собственные ошибки: повторно открывал exclusive log положительного контроля под старым именем и не использовал MASQUE probe_destination из существующей topology. Они исправлены, положительные проверки не ослаблены; сохранён discovery-report. Финальная расширенная серия выполнена в новой папке. gRPC reconnect и XHTTP/H1 workload являются отдельными воспроизведёнными ограничениями ядра, не ошибками этого тестового ожидания.

Ниже неизменённая история предыдущих ревизий; текущий результат находится в VALIDATION.

---

# Изменения r4 / 4.0.0 — 7 октября 2026

## Исправленные ошибки r3
Структурный валидатор теперь проверяет envelopes и общие блоки, где раньше неверные boolean/string/list значения могли не дать ошибок. Включены log, policy, stats, API, Metrics, sniffing, Mux, FakeDNS, version/geodata. Отдельно закрыты nonfinite exponents, int32 KiB overflow и краткие UTF-8 VLESS ID.

Peer-check сверяет REALITY ключи через optional cryptography, SNI и дополненный shortId; gRPC custom method path; XHTTP payload keys и wire layer; passwords/table sets/framing/order масок. Сравнение прямой пары не объявляет unknown frontend проверенным.

Сетевое испытание выявило ошибку первоначальной модели TLS: RAW с default Chrome uTLS игнорирует клиентский minVersion при copyConfig. Источник прочитан, checker и справочники исправлены; добавлены противоположные тесты uTLS ACCEPT и Go TLS REJECT. Это не заявлено исправлением ядра или рекомендацией понижать TLS.

## Общий скилл
Новые operations.md и peer-validation.md: фактические режимы API/Metrics, виртуальные tags и конфликты, pprof, policies, статистика и асинхронное обновление counters. Все17 skills имеют версию4.0.0. Общий реестр80 объектов/504 полевых позиций и107 pinned исходных файлов/диапазонов. В этой ревизии21 source-records добавлены или повторно проверены с указанием объёма.

## Инструменты и доставка
package_integrity.py проверяет полный SHA256 manifest, отсутствующие/лишние файлы и symlinks; установщик делает это до записи целевых skills. run_lab требует digest до исполнения. lab_fixture_guard.py отвергает изменённые конфиги даже с пересчитанными hashes, если они не совпадают с canonical loopback renderer. Добавлены run_r4_regressions.py и run_control_lab.py, CI flags --run-regressions/--run-control.

Старый dummy REALITY unit fixture заменён на согласованную тестовую X25519-пару, а не обход проверки. Native rejection проверяет exit23; crash/timeout не считаются правильным отказом. Предварительные неуспешные измерения сохранены отдельно от итоговых.

Результаты актуальной серии — [VALIDATION](VALIDATION.md). Ниже сохранена история r3, а не дополнительные заявления о r4.

---

# Изменения r3 / 3.0.0 — 7 октября 2026

## Общая база
Все 17 SKILL.md обновлены согласованно. Добавлены карта знаний и проверяемый машинный индекс: 62 объекта / 423 позиции полей. Расширен журнал до 95 pinned файлов/диапазонов. Перекрёстные ссылки и версии теперь проверяются вместе с содержимым пакета.

## Закрытие пробелов r2
Добавлены готовые результаты разбора DNS selection/cache/stale/parallel policies, всех стратегий балансировки и cost weights, обычного и burst observatory со всеми вложенными pingConfig полями. В socket-runtime разобраны фактические различия Linux/macOS/Windows; в DialSystem — условия Happy Eyeballs, SRV/TXT и chaining. У Realm указаны секунды, defaults и NAT lease semantics. Маски раскрыты по направлениям, порядку, размеру, внутренней валидации, экспрессиям и runtime consumer. XDRIVE включает template/auth/retry, собственный provider, storage caching и WAL. Добавлены отдельные ECH и XMC справочники, уточнения implementation всех транспортов.

## Исполняемые инструменты
Валидатор учитывает null-vs-omitted aliases, extra:null replacement, DNS cache/family, ping/costs, ограничения масок и облачных шаблонов. Новые runners с обязательным trust SHA до выполнения: 40 расширенных сетевых вариантов и 4 DNS/cache эксперимента. CI получает --run-extended и --run-dns. Собственные тесты расширены с 200 до 314, включая CLI и блокировку выполнения несовпадающего бинарника.

## Новые фактические доказательства
Повторно выполнены 22 исходные схемы, 24 core-config cases, 40 расширенных схем и 4 DNS эксперимента. FAIL gRPC reconnect и XHTTP/H1 post-restart load сохранены. Причина gRPC дополнена merged upstream PR6877 и точным исправляющим commit; ядро в пакете не патчилось. Прежние JSON r2 оставлены неизменёнными, новые результаты хранятся отдельно с префиксом r3-.

[Отчёт и границы испытаний](VALIDATION.md).

---

## История r2

### r2 / 2.0.0

## Вместо каркаса — общий контракт и рабочие инструменты
Переписаны main инструкции всех9 transport skills и4 исходных общих skills; добавлены4 специализации (protocol composition, DNS/routing/balancing, frontend topology, runtime validation). Общий orchestrator теперь задаёт единый порядок версионности, effective config, peer-map, route graph, ресурсного бюджета, безопасности, тестов и rollout/rollback. Каждый transport подключает те же правила.

## Углублённый source разбор
Provenance расширен с21 до44 файлов; зафиксированы Go/dependency versions. Дочитаны endpoint builders, VLESS flow/encryption/reverse, transport listeners, Finalmask builders/layer order/expression evaluator, TLS certificate callback, Freedom finalRules, DNS/routing/observatory builders. Поля с alias, whole-object replacement, ignored/deprecated/removed и runtime-only checks разделены.

## Реализация
Новый full-config/peer validator; read-only source probe с dirty/untracked/blob проверкой; генератор22 схем и45 полных шаблонов; ограниченный loopback runner; 24 config cases настоящего ядра; CI entry point; offline package checker; установщик с обязательным подтверждением замены и backup. Разделены authoring policy и факт source/runtime.

## Реальные испытания изменили пакет
Получен официальный бинарник через GitHub workflow artifact, сверены hashes. Исправлены laboratory Freedom private-target allowance и MASQUE inner-IP topology; runner учитывает TIME_WAIT при preflight и отмечает реально начатый timeout как FAIL. Hysteria восстановление измерено при budget45s, а не неверно объявлено моментальным.

Сохранены непройденные gRPC restart и нестабильность H1 post-restart stress. Предупреждение gRPC внесено в validator и справочник; ошибки ядра/наблюдения не скрыты зелёным общим флагом. Подробности и реальные результаты — [VALIDATION.md](VALIDATION.md).
