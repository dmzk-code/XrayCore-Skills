#!/usr/bin/env python3
"""Install this skill set to an explicit target directory. Standard library only.
No deletion of unrelated skills. Replacements are explicit and backed up.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def safe_source(root: Path) -> list[Path]:
    if root.is_symlink() or (root/'skills').is_symlink():raise ValueError('Source root/skills symlink is unsupported')
    dirs=sorted((root/'skills').iterdir())
    if not dirs or any(d.is_symlink() or not d.is_dir() or not re.fullmatch(r'xray-[a-z0-9-]+',d.name) or not (d/'SKILL.md').is_file() for d in dirs):raise ValueError('Invalid skill directories')
    for d in dirs:
        for p in d.rglob('*'):
            if p.is_symlink():raise ValueError('Symlinks in package are unsupported')
    return dirs


def install(source: Path,target: Path,replace: bool=False) -> dict:
    dirs=safe_source(source)
    if (source/'SHA256SUMS.txt').exists():
        from package_integrity import verify_integrity
        if verify_integrity(source):raise ValueError('Package integrity verification failed')
    target=target.absolute()
    if any(p.is_symlink() for p in (target,*target.parents)):raise ValueError('Symlink in target path is unsupported')
    if target.is_symlink():raise ValueError('Target cannot be a symlink')
    if target.resolve().is_relative_to(source.resolve()):raise ValueError('Installation target must be outside the source package')
    exists=[d.name for d in dirs if (target/d.name).exists() or (target/d.name).is_symlink()]
    if exists and not replace:raise ValueError('Existing skills require --replace')
    if any((target/name).is_symlink() for name in exists):raise ValueError('Existing skill symlink is unsupported')
    target.mkdir(parents=True,exist_ok=True)
    # Staging and backup live outside skills directory so agents do not discover duplicate skills.
    stage=Path(tempfile.mkdtemp(prefix='.xray-stage-',dir=target.parent))
    backup=None;moved=[];written=[]
    try:
        for d in dirs:shutil.copytree(d,stage/d.name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        if exists:
            backup=Path(tempfile.mkdtemp(prefix='xray-skills-backup-',dir=target.parent))
            for name in exists:(target/name).rename(backup/name);moved.append(name)
        for d in dirs:(stage/d.name).rename(target/d.name);written.append(d.name)
    except BaseException:
        for name in reversed(written):shutil.rmtree(target/name)
        if backup:
            for name in reversed(moved):(backup/name).rename(target/name)
        raise
    finally:shutil.rmtree(stage,ignore_errors=True)
    return {'installed_skills':written,'target':str(target.resolve()),'backup':str(backup) if backup else None,'agent_activation_tested':False}


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--target',type=Path,required=True,help='E.g. /project/.agents/skills or /project/.claude/skills')
    ap.add_argument('--replace',action='store_true');a=ap.parse_args()
    try:
        from package_integrity import verify_integrity
        if verify_integrity(ROOT):raise ValueError('Package integrity verification failed')
        print(json.dumps(install(ROOT,a.target,a.replace),ensure_ascii=False,indent=2));return 0
    except (OSError,ValueError) as e:
        print('INSTALL_FAILED: '+str(e),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
