# Пример правила проекта

При задачах создания, изменения или диагностики Xray конфигураций сначала прочитать `xray-config-orchestrator/SKILL.md` из установленного каталога skills. Подключить только релевантные transport/protocol/security references. Не загружать сразу весь пакет.

Не переносить синтаксис Mihomo/sing-box/V2Fly в Xray без отдельного адаптера. Учитывать точный commit, aliases, ignore-vs-error, topology и peer. Прочитать runtime known-issues до production выбора. Выводить полные файлы/diff, assumptions, реально выполненные проверки и rollback. Изменения firewall/production services не входят в обычное составление конфига.

Это пример текста для ваших AGENTS.md/CLAUDE.md; установщик не перезаписывает существующие правила проекта автоматически.
