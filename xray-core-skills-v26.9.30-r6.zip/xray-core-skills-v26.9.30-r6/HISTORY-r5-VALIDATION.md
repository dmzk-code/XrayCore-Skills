# Фактическая проверка r5 — 7 октября2026

## Среда
Проверен перед исполнением бинарник Xray26.9.30/b26a91d, go1.27.1 linux/amd64; SHA256 `96efb28b8b2086275598dc46e73b5dc340da948b4e1ccc4f1719f83f67b793a7`. Linux-6.18.44-x86_64-with-glibc2.41, Python3.13.5. Доверенный бинарник не патчился. Отдельные loopback процессы, локальный Nginx, DNS upstream и storage mock; не рабочие серверы пользователя.

**Все r5-prefixed отчёты ниже — реально выполненные в этой ревизии запуски.** Поле revision внутри старого runner может обозначать его первоначальную версию r3/r4; это не попытка выдать прежний запуск за новый. [Хеши перенесённых raw reports](ci/r5-execution-manifest.json).

## Собственные тесты и структура
**489 unittest methods/cases, включая75 новых r5 регрессий.** Фактический итог и stderr/stdout: [unit-tests-r5](ci/unit-tests-r5.txt). Это тесты Python-инструментов/контрактов, а не Go-suite и не489 возможностей ядра. В состав входят авторинг, malformed inputs, pure peer logic, case/default/URI, aliases, crypto backend, composition/null/order, отсутствие исполнения до hash, приватный вывод и запрет перезаписи.

[Проверка структуры и целостности](PACKAGE-VALIDATION.json):17 SKILL.md,90 объектов/550 полевых позиций,119 исходных файлов/указанных диапазонов,45 полных шаблонов. [Установка всех17 скиллов, backup и запуск установленного CLI](ci/install-smoke-r5.json). Активация внутри UI Claude/Codex не запускалась и не приравнивается к проверке файловой установки.

## Статическая серия
[45 свежесгенерированных конфигураций и22 пары](skills/xray-runtime-validation/references/r5-static.json):0ERROR. Предупреждения о сертификатах, внешних frontend и непроверенных ветках не удалены. Peer-check не открывает произвольные key/cert paths из пользовательского JSON.

## Новый native regression runner
[Полный отчёт](skills/xray-runtime-validation/references/r5-regressions.json): **wire 21/21, composition 9/9, native parser/build 10/10**.

Для21 wire-схемы дополнительно55 готовых положительных/отрицательных JSON-файлов прошли `xray run -test`; неверные credentials специально имеют валидную структуру, отказ требуется при передаче. Каждая схема проверяет TCP32768bytes и UDP;13 из них дополнительно запускают несовместимый клиент, проверяют невозможность передачи при живом процессе и возвращают правильный клиент для положительного контроля.

| Новая схема | Статус | Проверка несовместимости/контроль |
|---|---|---|
| xhttp-header-case | PASS | не входит в этот случай / — |
| xhttp-auto-body | PASS | не входит в этот случай / — |
| xhttp-unused-path-keys | PASS | не входит в этот случай / — |
| xhttp-streamone-inactive | PASS | не входит в этот случай / — |
| xhttp-padding-cookie-query | PASS | не входит в этот случай / — |
| xhttp-default-padding | PASS | PASS / PASS |
| xhttp-effective-host | PASS | PASS / PASS |
| xhttp-host-port-case | PASS | не входит в этот случай / — |
| masque-default-template | PASS | не входит в этот случай / — |
| masque-query-order | PASS | PASS / PASS |
| masque-dual-listener | PASS | не входит в этот случай / — |
| vmess-simple | PASS | PASS / PASS |
| vmess-legacy | PASS | PASS / PASS |
| trojan-simple | PASS | PASS / PASS |
| trojan-legacy | PASS | PASS / PASS |
| encryption-x25519-raw | PASS | PASS / PASS |
| encryption-x25519-xhttp | PASS | PASS / PASS |
| encryption-x25519-mkcp | PASS | PASS / PASS |
| encryption-mlkem768-raw | PASS | PASS / PASS |
| encryption-mlkem768-xhttp | PASS | PASS / PASS |
| encryption-mlkem768-mkcp | PASS | PASS / PASS |

В VLESS Encryption шесть схем действительно используют вывод доверенного `xray vlessenc`: X25519 и ML-KEM768, по RAW/XHTTP/mKCP. Генерируется также независимая вторая пара для отрицательного теста. Простая X25519-пара проверяется Python backend, ML-KEM static остаётся UNVERIFIED; успешный native handshake не превращает этот Python-checker в ML-KEM-верификатор.

Девять composition случаев сопоставлены с native `-dump`: prepend, tail в каталоге, замена endpoint целиком, пустой/null DNS, env по ключам, untagged замена и два варианта повторных новых tags. Сравниваются значимые merged поля, а не косметическое null/default сериализованной Go-структуры. Dump не считается доказательством Build.

Десять native parser/build случаев проверяют VMess/Trojan ограничения, permissive security→AUTO, JSONC-комментарии, отказ trailing comma/single quotes и невозможность root env подставить parse-time port. REJECT засчитывается только с exit23; другой exit/crash/timeout не равны успешному отказу.

## Повторены предыдущие серии

| Серия | Фактический результат в r5 | Отчёт |
|---|---|---|
| Прежние core config cases | 24/24 совпали с ожиданием | [JSON](skills/xray-runtime-validation/references/r5-core-config-cases.json) |
| Previous regression runner |20/20 parser/build,8/8 wire,1/1 UUID mapping | [JSON](skills/xray-runtime-validation/references/r5-previous-regressions.json) |
| Транспорты/Finalmask/XDRIVE mock |40/40: config,TCP,UDP,4 parallel requests | [JSON](skills/xray-runtime-validation/references/r5-extended.json) |
| DNS/cache |4/4 | [JSON](skills/xray-runtime-validation/references/r5-dns.json) |
| API/Metrics + counters |4/4 | [JSON](skills/xray-runtime-validation/references/r5-control.json) |

Всего24+20+10=54 именованных parser/build acceptance/rejection cases.55 предварительных config-tests wire-файлов и проверки конфигов других серий — отдельные технические действия, не добавлены к этому числу. Один из8 прежних wire cases специально подтверждает успешное соединение с непереносимым uTLS minVersion, не считает его исправленным.

## Основные22 схемы и реальные FAIL

[Полный baseline](skills/xray-runtime-validation/references/r5-baseline.json): **общий FAIL**. Первоначальные config/TCP/UDP/negative auth/positive control —22/22 PASS. Restart20PASS/2FAIL. Короткая нагрузка19PASS/1FAIL/2NOT_RUN.

| Схема | TCP | UDP | Auth | Control | Restart | Load |
|---|---|---|---|---|---|---|
| raw-none | PASS | PASS | PASS | PASS | PASS | PASS |
| raw-tls | PASS | PASS | PASS | PASS | PASS | PASS |
| raw-vision-tls | PASS | PASS | PASS | PASS | PASS | PASS |
| raw-reality | PASS | PASS | PASS | PASS | PASS | PASS |
| raw-fragment-tls | PASS | PASS | PASS | PASS | PASS | PASS |
| xhttp-packet-h1 | PASS | PASS | PASS | PASS | PASS | FAIL |
| xhttp-stream-h2 | PASS | PASS | PASS | PASS | PASS | PASS |
| xhttp-one-h2 | PASS | PASS | PASS | PASS | PASS | PASS |
| xhttp-packet-h3 | PASS | PASS | PASS | PASS | PASS | PASS |
| xhttp-header-h2 | PASS | PASS | PASS | PASS | PASS | PASS |
| xhttp-split-nginx | PASS | PASS | PASS | PASS | PASS | PASS |
| mkcp-tls | PASS | PASS | PASS | PASS | PASS | PASS |
| grpc-tls | PASS | PASS | PASS | PASS | FAIL | NOT_RUN |
| grpc-multi-tls | PASS | PASS | PASS | PASS | FAIL | NOT_RUN |
| websocket-tls | PASS | PASS | PASS | PASS | PASS | PASS |
| websocket-ed-tls | PASS | PASS | PASS | PASS | PASS | PASS |
| httpupgrade-tls | PASS | PASS | PASS | PASS | PASS | PASS |
| hysteria2 | PASS | PASS | PASS | PASS | PASS | PASS |
| masque-h2 | PASS | PASS | PASS | PASS | PASS | PASS |
| masque-h3 | PASS | PASS | PASS | PASS | PASS | PASS |
| xdrive-local | PASS | PASS | PASS | PASS | PASS | PASS |
| chain-raw-tls | PASS | PASS | PASS | PASS | PASS | PASS |

Два FAIL восстановления — grpc-tls и grpc-multi-tls, budget45s. После восстановления XHTTP packet-up/H1 один из12 запросов (4workers,4096bytes,timeout5s) не прошёл. Прежние наблюдения не удалены; причина gRPC сопоставлена с upstream-изменением в known-issues, но сам тестируемый бинарник по-прежнему закреплён на исходном commit. Это не capacity benchmark, не гарантия переживания существующих соединений и не исправление ядра.

## Первые ошибки стенда и исправление
[Первый r5 discovery](skills/xray-runtime-validation/references/r5-discovery-harness.json) сохранён отдельно:6/21 wire полностью завершились, у12 попыток positive control прервался из-за повторного exclusive log имени; ещё3 MASQUE случая использовали loopback destination вместо согласованного topology.probe_destination. Исправлены уникальные имена log и выбор уже заданного адреса проверки. Отказы не переименованы в PASS: итоговый runner выполнен заново в новой папке,21/21 завершены с первоначальными требованиями к данным/auth/control. Discovery не включён в totals пройденных случаев.

## Границы
Go-suite/полная сборка ядра из исходников здесь **не выполнялись**. Внешние CDN, реальные cloud tokens/accounts, NAT/STUN разных сетей, другие ОС и длительная нагрузка не входят в исполненную локальную серию. Чтение119 файлов/диапазонов не означает119 полностью протестированных файлов или процент охвата всего репозитория.

Обнаруженные ошибки пакета закрыты конкретными изменениями и регрессиями; общая сертификация произвольной конфигурации не выдаётся. Инструкции агента требуют проверить именно создаваемую конфигурацию, её целевой бинарник и среду. В публичном архиве нет generated credentials/сертификатов и сырых runtime logs.
