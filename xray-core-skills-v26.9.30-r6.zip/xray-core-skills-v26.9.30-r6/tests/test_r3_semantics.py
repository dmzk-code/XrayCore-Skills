from __future__ import annotations
import copy,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'skills/xray-source-audit/scripts'))
from validate import Validator,network,settings,check_pair
from semantic_checks import DNS_STRATEGIES,duration,normalize_config
from test_extended import pair,cfg,mask,codes

def semcodes(o):return {x['code'] for x in Validator().config(o)}
def dns(n):return {'dns':{'queryStrategy':n,'servers':['127.0.0.1']}}
def burst(p):return {'burstObservatory':{'subjectSelector':['p'],'pingConfig':p}}
def ll(s):return {'routing':{'balancers':[{'tag':'b','selector':['p'],'strategy':{'type':'leastLoad','settings':s}}]}}
def xt(template):
    o=pair('xdrive-local')['client.json'];o['outbounds'][0]['streamSettings']['xdriveSettings']={'service':'template','remoteFolder':'/lab','secrets':['unit-only'],'template':template};return o
GOOD_TEMPLATE={'auth':{'type':'none'},'put':{'url':'http://localhost/put'},'get':{'url':'http://localhost/get'},'delete':{'url':'http://localhost/delete'},'list':{'url':'http://localhost/list','namesRegex':'<n>([^<]+)</n>'}}
class R3Rules(unittest.TestCase):
    def test_method_null_falls_through(self):self.assertEqual(network({'method':None,'network':'ws'}),'websocket')
    def test_method_precedence(self):self.assertEqual(network({'method':'raw','network':'ws'}),'raw')
    def test_network_null_default(self):self.assertEqual(network({'network':None}),'raw')
    def test_raw_null_pointer_alias(self):self.assertEqual(settings({'network':'raw','rawSettings':None,'tcpSettings':{'acceptProxyProtocol':True}}),{'acceptProxyProtocol':True})
    def test_extra_null_replaces_not_merge(self):self.assertEqual(settings({'network':'xhttp','xhttpSettings':{'host':'a','headers':{'X':'Y'},'extra':None}}),{'host':'a','path':'','mode':''})
    def test_extra_preserves_outer_mode(self):self.assertEqual(settings({'network':'xhttp','xhttpSettings':{'mode':'packet-up','extra':{'mode':'stream-one'}}})['mode'],'packet-up')
    def test_no_mutation(self):
        o=pair('xhttp-header-h2')['client.json'];o['outbounds'][0]['streamSettings']['xhttpSettings']['extra']=None;before=copy.deepcopy(o);Validator().config(o);self.assertEqual(o,before)
    def test_clients_null_uses_users(self):
        p=pair();p['server.json']['inbounds'][0]['settings']['clients']=None;self.assertFalse(any(i['code']=='PEER_AUTH' for i in check_pair(p['client.json'],p['server.json'])))
    def test_clients_empty_replaces_users(self):
        p=pair();p['server.json']['inbounds'][0]['settings']['clients']=[];self.assertTrue(any(i['code']=='PEER_AUTH' for i in check_pair(p['client.json'],p['server.json'])))
    def test_cache_zero(self):self.assertIn('STALE_UNBOUNDED',semcodes({'dns':{'serveStale':True}}))
    def test_cache_limit(self):self.assertIn('STALE_RANGE',semcodes({'dns':{'serveExpiredTTL':2**31}}))
    def test_cache_signed_max(self):self.assertNotIn('STALE_RANGE',semcodes({'dns':{'serveExpiredTTL':2**31-1}}))
    def test_cache_bool_reject(self):self.assertIn('STALE_RANGE',semcodes({'dns':{'serveExpiredTTL':True}}))
    def test_dns_family_conflict(self):self.assertIn('DNS_FAMILY_CONFLICT',semcodes({'dns':{'queryStrategy':'UseIPv4','servers':[{'address':'localhost','queryStrategy':'UseIPv6'}]}}))
    def test_dns_boolean(self):self.assertIn('NESTED_TYPE',semcodes({'dns':{'disableCache':'false'}}))
    def test_ping_unknown(self):self.assertIn('UNKNOWN_FIELD',semcodes(burst({'http_method':'GET'})))
    def test_ping_sampling(self):self.assertIn('PING_SAMPLING',semcodes(burst({'sampling':-1})))
    def test_ping_zero_default(self):self.assertNotIn('PING_SAMPLING',semcodes(burst({'sampling':0})))
    def test_ping_short_interval(self):self.assertIn('DURATION',semcodes(burst({'interval':'5s'})))
    def test_ping_lowercase_get(self):self.assertIn('PING_METHOD',semcodes(burst({'httpMethod':'get'})))
    def test_ping_status_not_assumed(self):self.assertIn('PROBE_STATUS_UNCHECKED',semcodes(burst({'httpMethod':'GET'})))
    def test_cost_invalid(self):self.assertIn('COST_VALUE',semcodes(ll({'costs':[{'value':'a'}]})))
    def test_cost_re2(self):self.assertIn('COST_REGEX_CORE',semcodes(ll({'costs':[{'match':'edge[0-9]','regexp':True,'value':1}]})))
    def test_zero_tolerance_is_not_zero_loss(self):self.assertIn('LOAD_ZERO_TOLERANCE',semcodes(ll({'tolerance':0})))
    def test_tolerance_limit(self):self.assertIn('LOAD_TOLERANCE',semcodes(ll({'tolerance':1.5})))
    def test_salamander_bytes(self):self.assertIn('SALAMANDER_PASSWORD',codes(mask('salamander',{'password':'abc'},'udp')))
    def test_salamander_utf8(self):self.assertNotIn('SALAMANDER_PASSWORD',codes(mask('salamander',{'password':'аб'},'udp')))
    def test_sudoku_badmode(self):self.assertIn('SUDOKU_ASCII',codes(mask('sudoku',{'ascii':'typo'})))
    def test_sudoku_ascii_table_ignored(self):self.assertIn('SUDOKU_TABLE_IGNORED',codes(mask('sudoku',{'ascii':'ascii','customTable':'nonsense'})))
    def test_sudoku_pattern(self):self.assertIn('SUDOKU_TABLE',codes(mask('sudoku',{'customTable':'bad'})))
    def test_sudoku_pattern_valid(self):self.assertNotIn('SUDOKU_TABLE',codes(mask('sudoku',{'customTable':'xxppvvvv'})))
    def test_padding_percentage(self):self.assertIn('SUDOKU_PADDING_POLICY',codes(mask('sudoku',{'paddingMax':101})))
    def test_udphop_inbound(self):
        o=pair('hysteria2')['server.json'];o['inbounds'][0]['streamSettings']['finalmask']={'udp':[{'type':'udphop','settings':{'mode':'perConnRemote'}}]};self.assertIn('UDPHOP_CLIENT_ONLY',codes(o))
    def test_owner_position(self):
        o=mask('udphop',{'mode':'perConnRemote'},'udp');o['outbounds'][0]['streamSettings']['finalmask']['udp'].append({'type':'salamander','settings':{'password':'aaaa'}});self.assertIn('MASK_OWNER_POSITION',codes(o))
    def test_realm_negative_lease(self):self.assertIn('REALM_DURATION',codes(mask('realm',{'url':'realm://token@localhost/id','stunServers':['localhost:3478'],'portMapping':{'lifetime':-1}},'udp')))
    def test_realm_badmode(self):self.assertIn('ENUM',codes(mask('realm',{'url':'realm://token@localhost/id','stunServers':['localhost:3478'],'ipMode':'ipv4'},'udp')))
    def test_xdns_resolver_required(self):self.assertIn('XDNS_CLIENT_RESOLVERS',codes(mask('xdns',{'domains':[{'name':'lab.test','types':[16]}]},'udp')))
    def test_xdns_type(self):self.assertIn('XDNS_TYPES',codes(mask('xdns',{'domains':[{'name':'lab.test','types':[99]}]},'udp')))
    def test_xdns_edns(self):self.assertIn('XDNS_LIMIT',codes(mask('xdns',{'domains':[{'name':'lab.test','types':[16],'edns0':256}]},'udp')))
    def test_noise_badexpr(self):self.assertIn('NOISE_EXPRESSION',codes(mask('noise',{'noise':[{'type':'exp','packet':'<shell xyz>'}]},'udp')))
    def test_noise_goodexpr(self):self.assertNotIn('NOISE_EXPRESSION',codes(mask('noise',{'noise':[{'type':'exp','packet':'<b abcd><r 2-4><rc 1><rd 1><t><c><n>'}]},'udp')))
    def test_windows_string(self):
        o=cfg();o['outbounds'][0]['streamSettings']['sockopt']={'customSockopt':[{'system':'windows','type':'str','level':'1','opt':'2','value':'a'}]};self.assertIn('SOCK_WINDOWS_STRING',codes(o))
    def test_socket_hexnotdecimal(self):
        o=cfg();o['outbounds'][0]['streamSettings']['sockopt']={'customSockopt':[{'level':'0x1','opt':'2','value':'1'}]};self.assertIn('SOCK_DECIMAL',codes(o))
    def test_template_auth_singular(self):
        t=copy.deepcopy(GOOD_TEMPLATE);t['auth']={'type':'static','headers':{'X':'Y'}};self.assertIn('UNKNOWN_FIELD',codes(xt(t)))
    def test_template_oauth_url(self):
        t=copy.deepcopy(GOOD_TEMPLATE);t['auth']={'type':'oauth2'};self.assertIn('OAUTH_URL',codes(xt(t)))
    def test_template_operation(self):
        t=copy.deepcopy(GOOD_TEMPLATE);t.pop('get');self.assertIn('TEMPLATE_OPERATION',codes(xt(t)))
    def test_template_names(self):
        t=copy.deepcopy(GOOD_TEMPLATE);t['list'].pop('namesRegex');self.assertIn('TEMPLATE_NAMES',codes(xt(t)))
    def test_template_retry(self):
        t=copy.deepcopy(GOOD_TEMPLATE);t['retry']={'status':['429']};self.assertIn('RETRY_STATUS',codes(xt(t)))
    def test_template_collision(self):
        o=xt(GOOD_TEMPLATE);b=copy.deepcopy(o['outbounds'][0]);b['tag']='second';b['streamSettings']['xdriveSettings']['template']['get']['url']='http://localhost/other';o['outbounds'].append(b);self.assertIn('XDRIVE_SHARED_COLLISION',codes(o))
    def test_template_same_cache_definition(self):
        o=xt(GOOD_TEMPLATE);b=copy.deepcopy(o['outbounds'][0]);b['tag']='second';o['outbounds'].append(b);self.assertNotIn('XDRIVE_SHARED_COLLISION',codes(o))
class DNSAliases(unittest.TestCase):pass
for n in sorted(DNS_STRATEGIES):
    def test(self,n=n):self.assertNotIn('ENUM',semcodes(dns(n)))
    setattr(DNSAliases,'test_'+(n or 'default').replace('-','dash'),test)
class DurationValues(unittest.TestCase):pass
for n,val in [('1s',1),('2m',120),('1h30m',5400),('10ms',.01),('0',0),('1.5s',1.5),('500us',.0005),('.5s',.5)]:
    def test(self,n=n,val=val):self.assertAlmostEqual(duration(n),val)
    setattr(DurationValues,'test_'+n.replace('.','dot'),test)
for n in ('-1s','nan','1d','2','1s garbage','1e20s','999999999999999999999999999h'):
    def test(self,n=n):
        with self.assertRaises(ValueError):duration(n)
    setattr(DurationValues,'test_bad_'+str(len(DurationValues.__dict__)),test)
