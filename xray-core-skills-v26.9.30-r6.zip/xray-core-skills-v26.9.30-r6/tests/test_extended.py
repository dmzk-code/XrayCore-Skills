from __future__ import annotations
import copy
import importlib.util
import json
import os
import shutil
import socket
import socketserver
import struct
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPTS=ROOT/'skills/xray-source-audit/scripts';sys.path.insert(0,str(SCRIPTS))
from validate import Validator,check_pair,canonical_id,read
from build_lab import SCENARIOS,make_pair,create_lab
from run_lab import Child,capture,read_exact,tcp_probe,udp_probe,echo_servers,validate_manifest
from source_probe import probe,blob_sha
spec=importlib.util.spec_from_file_location('skill_install',ROOT/'install.py');installer=importlib.util.module_from_spec(spec);spec.loader.exec_module(installer)
CRED={'uuid':'60375de6-847a-49cf-88ac-8c1dd05819c0','auth':'unit-test-only-not-production','pin':'a'*64,'cert':'/lab/cert.pem','key':'/lab/key.pem','private':'dwdtCnMYpX08FsFyUbJmRd9ML4frwJkqsXf7pR25LCo','public':'hSDwCYkwp1R0i33ctD73Wg2_Og0mOBr066SpjqqbTmo','shortid':'12345678'}
PORTS=[24000,24001,24002,24003,24004,24005]

def pair(name='raw-tls'):
    return make_pair(name,'/lab',PORTS,CRED)

def cfg():return pair()['client.json']
def codes(o):return {x['code'] for x in Validator().config(o)}
def mask(typ,s,net='tcp'):
    o=cfg();o['outbounds'][0]['streamSettings']['finalmask']={net:[{'type':typ,'settings':s}]};return o

def setpath(o,path,value):
    p=o
    for key in path[:-1]:p=p[key]
    p[path[-1]]=value

class PairTemplates(unittest.TestCase):pass
for name in SCENARIOS:
    def test(self,name=name):
        objects=pair(name)
        for key,o in objects.items():
            if key=='topology.json':continue
            errors=[x for x in Validator().config(o) if x['severity']=='ERROR']
            self.assertEqual(errors,[],(name,key,errors))
        errs=[x for x in check_pair(objects['client.json'],objects['server.json'],'lab-proxy','lab-in') if x['severity']=='ERROR']
        self.assertEqual(errs,[],errs)
    setattr(PairTemplates,'test_'+name.replace('-','_'),test)

class InvariantChecks(unittest.TestCase):
    def test_duplicate_keys(self):
        from lint_config import loads
        with self.assertRaises(ValueError):loads('{"a":1,"a":2}')
    def test_nonfinite(self):
        from lint_config import loads
        with self.assertRaises(ValueError):loads('{"a":NaN}')
    def test_unknown_root(self):self.assertIn('UNKNOWN_FIELD',codes({'mispelled':1}))
    def test_vless_case_preservation(self):
        self.assertNotEqual(canonical_id('Alice'),canonical_id('alice'))
        self.assertEqual(canonical_id(CRED['uuid'].upper()),canonical_id(CRED['uuid']))
    def test_native_hysteria_version(self):
        o=pair('hysteria2')['client.json'];del o['outbounds'][0]['settings']['version'];self.assertIn('HYSTERIA_PROTOCOL_VERSION',codes(o))
    def test_masque_coupling(self):
        o=pair('masque-h2')['client.json'];o['outbounds'][0]['protocol']='vless';self.assertIn('MASQUE_NATIVE',codes(o))
    def test_masque_mux(self):
        o=pair('masque-h2')['client.json'];o['outbounds'][0]['mux']={'enabled':True};self.assertIn('MASQUE_MUX',codes(o))
    def test_masque_prefix_count(self):
        o=pair('masque-h2')['server.json'];o['inbounds'][0]['settings']['address']=['10.0.0.1/24','10.1.0.1/24'];self.assertIn('MASQUE_PREFIX_COUNT',codes(o))
    def test_masque_auth_case_duplicate(self):
        o=pair('masque-h2')['server.json'];s=o['inbounds'][0]['settings'];s['users']=[{'email':'A','pass':'x'},{'email':'a','pass':'y'}];self.assertIn('MASQUE_DUPLICATE',codes(o))
    def test_remote_dns_name(self):
        o=pair('masque-h2')['client.json'];o['outbounds'][0]['settings']['remoteDNS']=['example.com'];self.assertIn('MASQUE_DNS_IP',codes(o))
    def test_remote_dns_wrong_type(self):
        o=pair('masque-h2')['client.json'];o['outbounds'][0]['settings']['remoteDNS']=1;self.assertIn('MASQUE_DNS_TYPE',codes(o))
    def test_vless_public_unprotected(self):
        o=pair('raw-none')['client.json'];o['outbounds'][0]['settings']['address']='8.8.8.8';self.assertIn('PUBLIC_CLEARTEXT',codes(o))
    def test_private_does_not_claim_geodata(self):
        o=pair('raw-none')['client.json'];o['outbounds'][0]['settings']['address']='vpn.example.com';self.assertIn('PUBLIC_DOMAIN_CORE_CHECK',codes(o))
    def test_vision_xhttp_wrapper(self):
        o=pair('xhttp-one-h2')['client.json'];o['outbounds'][0]['settings']['flow']='xtls-rprx-vision';self.assertIn('VISION_WRAPPER',codes(o))
    def test_encrypted_vision_no_blanket_transport_ban(self):
        o=pair('xhttp-one-h2')['client.json'];o['outbounds'][0]['settings'].update(flow='xtls-rprx-vision',encryption='mlkem768x25519plus.native.1rtt.'+'A'*43)
        self.assertNotIn('VISION_WRAPPER',codes(o));self.assertIn('ENCRYPTION_INIT_REQUIRED',codes(o))
    def test_encrypted_fallback_array(self):
        o=pair()['server.json'];s=o['inbounds'][0]['settings'];s.update(decryption='mlkem768x25519plus.native.300s.'+'A'*43,fallbacks=[]);self.assertIn('VLESS_ENCRYPTION_FALLBACK',codes(o))
    def test_inbound_user_encryption(self):
        o=pair()['server.json'];o['inbounds'][0]['settings']['users'][0]['encryption']='none';self.assertIn('VLESS_IN_ENCRYPTION',codes(o))
    def test_vless_seed_inert(self):
        o=cfg();o['outbounds'][0]['settings']['seed']='sample';self.assertIn('VLESS_SEED_IGNORED',codes(o))
    def test_proxysettings_removed(self):
        o=cfg();o['outbounds'][0]['proxySettings']={};self.assertIn('PROXYSETTINGS_REMOVED',codes(o))
    def test_legacy_reverse_removed(self):
        o=cfg();o['reverse']={};self.assertIn('LEGACY_REVERSE_REMOVED',codes(o))
    def test_global_transport(self):
        o=cfg();o['transport']={'tcpSettings':{}};self.assertIn('GLOBAL_TRANSPORT_REMOVED',codes(o))
    def test_tcp_mux_vision(self):
        o=pair('raw-vision-tls')['client.json'];o['outbounds'][0]['mux']={'enabled':True,'concurrency':8};self.assertIn('VISION_TCP_MUX',codes(o))
    def test_xudp_negative_tcp_concurrency(self):
        o=pair('raw-vision-tls')['client.json'];o['outbounds'][0]['mux']={'enabled':True,'concurrency':-1,'xudpConcurrency':8};self.assertNotIn('VISION_TCP_MUX',codes(o))
    def test_freedom_aps(self):
        o={'outbounds':[{'tag':'d','protocol':'freedom','streamSettings':{'sockopt':{'addressPortStrategy':'srvportonly'}}}]};self.assertIn('FREEDOM_APS',codes(o))
    def test_missing_dialer_tag(self):
        o=cfg();o['outbounds'][0]['streamSettings']['sockopt']={'dialerProxy':'missing'};self.assertIn('DIALER_TAG',codes(o))
    def test_direct_dialer_cycle(self):
        o=cfg();o['outbounds'][0]['streamSettings']['sockopt']={'dialerProxy':'lab-proxy'};self.assertIn('DIALER_CYCLE',codes(o))
    def test_indirect_cycle(self):
        o=pair('chain-raw-tls')['client.json'];o['outbounds'][1]['streamSettings']['sockopt']={'dialerProxy':'lab-proxy'};self.assertIn('DIALER_CYCLE',codes(o))
    def test_duplicate_tag(self):
        o=cfg();o['outbounds']*=2;self.assertIn('DUPLICATE_TAG',codes(o))
    def test_unknown_route(self):
        o=cfg();o['routing']={'rules':[{'outboundTag':'missing'}]};self.assertIn('UNKNOWN_TAG',codes(o))
    def test_route_both_targets(self):
        o=cfg();o['routing']={'rules':[{'outboundTag':'lab-proxy','balancerTag':'x'}]};self.assertIn('ROUTE_SHADOW',codes(o))
    def test_balancer_empty(self):
        o=cfg();o['routing']={'balancers':[{'tag':'b','selector':['none'],'strategy':{'type':'leastPing'}}]};self.assertIn('EMPTY_SELECTION',codes(o));self.assertIn('BALANCER_OBSERVER',codes(o))
    def test_burst_needs_ping(self):self.assertIn('BURST_PING_REQUIRED',codes({'burstObservatory':{'subjectSelector':['x']}}))
    def test_dns_typo(self):self.assertIn('ENUM',codes({'dns':{'queryStrategy':'UseIPv5'}}))
    def test_dns_expected_alias(self):self.assertIn('DNS_ALIAS',codes({'dns':{'servers':[{'address':'1.1.1.1','expectedIPs':['*'],'expectIPs':['1.1.1.1']}]}}))
    def test_dns_stale_nocache(self):self.assertIn('DNS_STALE_NOCACHE',codes({'dns':{'serveStale':True,'disableCache':True}}))
    def test_header_expr_unknown_op(self):self.assertIn('EXPR_OP',codes(mask('header-custom',{'clients':[[{'transform':{'op':'be64','args':[{'u64':1}]}}]]})))
    def test_header_expr_arity(self):self.assertIn('EXPR_ARITY',codes(mask('header-custom',{'clients':[[{'transform':{'op':'xor16','args':[{'u64':1}]}}]]})))
    def test_custom_two_sources(self):self.assertIn('CUSTOM_KIND',codes(mask('header-custom',{'clients':[[{'rand':4,'packet':[1,2]}]]})))
    def test_capture_without_source(self):self.assertIn('CUSTOM_KIND',codes(mask('header-custom',{'clients':[[{'capture':'x'}]]})))
    def test_bad_capture_name(self):self.assertIn('CUSTOM_VAR',codes(mask('header-custom',{'client':[{'rand':3,'capture':'bad-name'}]},'udp')))
    def test_custom_byte_range(self):self.assertIn('CUSTOM_RAND_RANGE',codes(mask('header-custom',{'clients':[[{'rand':3,'randRange':'0-256'}]]})))
    def test_udp_fragment_bad_network(self):self.assertIn('MASK_NETWORK',codes(mask('fragment',{'length':'100-200'},'udp')))
    def test_gecko_size(self):self.assertIn('GECKO_SIZE',codes(mask('salamander',{'password':'test','packetSize':'10-3000'},'udp')))
    def test_xicmp_ip(self):self.assertIn('XICMP_IP',codes(mask('xicmp',{'ips':['example.com']},'udp')))
    def test_realm_missing_stun(self):self.assertIn('REALM_STUN',codes(mask('realm',{'url':'realm://token@localhost/id'},'udp')))
    def test_realm_scheme(self):self.assertIn('REALM_URL',codes(mask('realm',{'url':'https://token@localhost/id','stunServers':['localhost:3478']},'udp')))
    def test_udphop_csv_spaces(self):self.assertIn('UDPHOP_MODE',codes(mask('udphop',{'mode':'intervalRemote, intervalLocal'},'udp')))
    def test_xdns_poll(self):self.assertIn('NUMBER',codes(mask('xdns',{'extraPoll':4},'udp')))
    def test_noise_sources(self):self.assertIn('NOISE_KIND',codes(mask('noise',{'noise':[{'rand':10,'packet':[1]}]},'udp')))
    def test_xmc_profiles(self):self.assertIn('XMC_PROFILE',codes(mask('xmc',{'hostname':'localhost'})))
    def test_quic_window(self):
        o=cfg();o['outbounds'][0]['streamSettings']['finalmask']={'quicParams':{'maxStreamReceiveWindow':100}};self.assertIn('QUIC_WINDOW',codes(o))
    def test_quic_window_order(self):
        o=cfg();o['outbounds'][0]['streamSettings']['finalmask']={'quicParams':{'initStreamReceiveWindow':100000,'maxStreamReceiveWindow':20000}};self.assertIn('QUIC_WINDOW_ORDER',codes(o))
    def test_brutal_requires_up(self):
        o=cfg();o['outbounds'][0]['streamSettings']['finalmask']={'quicParams':{'congestion':'force-brutal'}};self.assertIn('BRUTAL_UP',codes(o))
    def test_typo_nested_mask(self):self.assertIn('UNKNOWN_FIELD',codes(mask('salamander',{'passwrod':'test'},'udp')))
    def test_grpc_reconnect_runtime_warning(self):self.assertIn('GRPC_RECONNECT_OBSERVED',codes(pair('grpc-tls')['client.json']))
    def test_freedom_removed_ipsblocked(self):self.assertIn('FREEDOM_IPSBLOCKED_IGNORED',codes({'outbounds':[{'protocol':'freedom','settings':{'ipsBlocked':['127.0.0.1']}}]}))
    def test_freedom_removed_noise(self):self.assertIn('FREEDOM_NOISE_REMOVED',codes({'outbounds':[{'protocol':'freedom','settings':{'noise':{}}}]}))
    def test_freedom_action_required(self):self.assertIn('FREEDOM_RULE_ACTION',codes({'outbounds':[{'protocol':'freedom','settings':{'finalRules':[{}]}}]}))
    def test_freedom_no_blanket_allow(self):self.assertIn('FREEDOM_ALLOW_ALL',codes({'outbounds':[{'protocol':'freedom','settings':{'finalRules':[{'action':'allow'}]}}]}))
    def test_freedom_delay_nonnegative(self):self.assertIn('RANGE',codes({'outbounds':[{'protocol':'freedom','settings':{'finalRules':[{'action':'block','blockDelay':-1}]}}]}))
    def test_no_secret_values(self):
        secret='UNIT_SECRET_SHOULD_NOT_APPEAR';o=cfg();o['outbounds'][0]['settings']['encryption']=secret
        self.assertNotIn(secret,json.dumps(Validator().config(o)))

class PeerChecks(unittest.TestCase):
    def test_wrong_vless_auth(self):
        a=pair();a['client.json']['outbounds'][0]['settings']['id']='different';self.assertIn('PEER_AUTH',{x['code'] for x in check_pair(a['client.json'],a['server.json'])})
    def test_wrong_native_auth(self):
        for name in ('hysteria2','masque-h2'):
            a=pair(name);s=a['client.json']['outbounds'][0]['streamSettings'];s['hysteriaSettings' if name=='hysteria2' else 'masqueSettings']['auth' if name=='hysteria2' else 'pass']='bad'
            self.assertIn('PEER_AUTH',{x['code'] for x in check_pair(a['client.json'],a['server.json'])})
    def test_wrong_path(self):
        a=pair('websocket-tls');a['client.json']['outbounds'][0]['streamSettings']['wsSettings']['path']='/wrong';self.assertIn('PEER_PATH',{x['code'] for x in check_pair(a['client.json'],a['server.json'])})
    def test_mode_mismatch(self):
        a=pair('xhttp-packet-h1');a['server.json']['inbounds'][0]['streamSettings']['xhttpSettings']['mode']='stream-one';self.assertIn('PEER_XHTTP_MODE',{x['code'] for x in check_pair(a['client.json'],a['server.json'])})
    def test_post_limit(self):
        a=pair('xhttp-packet-h1');a['client.json']['outbounds'][0]['streamSettings']['xhttpSettings']['scMaxEachPostBytes']=2000000;self.assertIn('PEER_POST_LIMIT',{x['code'] for x in check_pair(a['client.json'],a['server.json'])})
    def test_default_metadata_key(self):
        a=pair('xhttp-packet-h1');c=a['client.json']['outbounds'][0]['streamSettings']['xhttpSettings'];s=a['server.json']['inbounds'][0]['streamSettings']['xhttpSettings'];c['sessionIDPlacement']=s['sessionIDPlacement']='header';c['sessionIDKey']='X-Session';self.assertNotIn('PEER_META',{x['code'] for x in check_pair(a['client.json'],a['server.json'])})
    def test_ambiguous_pair(self):
        a=pair();a['server.json']['inbounds']*=2;self.assertIn('PEER_AMBIGUOUS',{x['code'] for x in check_pair(a['client.json'],a['server.json'])})

class MalformedInputs(unittest.TestCase):
    def test_bad_shapes_never_raise(self):
        #144 mutations across schema positions; a diagnostic failure must fail closed.
        values=[None,True,0,1.5,[],['bad'],'bad',{'bad':'value'}]
        paths=[['inbounds'],['outbounds'],['outbounds',0],['outbounds',0,'settings'],['outbounds',0,'streamSettings'],['outbounds',0,'streamSettings','tlsSettings']]
        for path in paths:
            for v in values:
                o=cfg();setpath(o,path,v)
                result=Validator().config(o);self.assertIsInstance(result,list)
        for k in ('finalmask','sockopt','realitySettings','xhttpSettings','wsSettings','grpcSettings','kcpSettings','masqueSettings','hysteriaSettings','xdriveSettings','tlsSettings','rawSettings'):
            for val in values:
                o=cfg();o['outbounds'][0]['streamSettings'][k]=val
                self.assertIsInstance(Validator().config(o),list)
    def test_max_depth(self):
        x={};o=x
        for _ in range(80):o['extra']={};o=o['extra']
        self.assertIn('STRUCTURE_UNSUPPORTED',codes(x))
    def test_boolean_as_integer(self):
        o=cfg();o['outbounds'][0]['streamSettings']['port']=True;self.assertIn('PORT',codes(o))

class SourceProbeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.repo=Path(self.tmp.name)/'repo';self.repo.mkdir()
        def g(*args):return subprocess.run(['git','-C',str(self.repo),*args],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True).stdout.strip()
        self.g=g;g('init');g('config','user.name','Unit Test');g('config','user.email','unit@example.invalid');(self.repo/'sample.go').write_text('package test\ntype T struct { Field string `json:"field"` }\n');g('add','.');g('commit','-m','unit fixture')
        self.manifest={'commit':g('rev-parse','HEAD'),'files':[{'path':'sample.go','git_blob_sha':blob_sha((self.repo/'sample.go').read_bytes()),'coverage':'unit fixture only'}]}
    def tearDown(self):self.tmp.cleanup()
    def test_match(self):self.assertEqual(probe(self.repo,self.manifest)['status'],'MATCH')
    def test_changed(self):
        (self.repo/'sample.go').write_text('changed');self.assertEqual(probe(self.repo,self.manifest)['status'],'REVIEW_REQUIRED')
    def test_untracked(self):
        (self.repo/'new.go').write_text('x');self.assertTrue(probe(self.repo,self.manifest)['any_tree_changes_including_untracked'])
    def test_unpinned_fails(self):
        self.manifest['files'][0]['git_blob_sha']=None;self.assertEqual(probe(self.repo,self.manifest)['status'],'REVIEW_REQUIRED')
    def test_wrong_commit(self):
        self.manifest['commit']='0'*40;self.assertEqual(probe(self.repo,self.manifest)['status'],'REVIEW_REQUIRED')
    def test_traversal(self):
        self.manifest['files'][0]['path']='../outside'
        with self.assertRaises(ValueError):probe(self.repo,self.manifest)

class InstallationTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.target=Path(self.tmp.name)/'.agents/skills'
    def tearDown(self):self.tmp.cleanup()
    def test_all_installed(self):
        r=installer.install(ROOT,self.target);self.assertEqual(len(r['installed_skills']),17);self.assertFalse(r['agent_activation_tested'])
    def test_existing_no_overwrite(self):
        installer.install(ROOT,self.target);f=self.target/'xray-config-orchestrator/SKILL.md';f.write_text('OWNED')
        with self.assertRaises(ValueError):installer.install(ROOT,self.target)
        self.assertEqual(f.read_text(),'OWNED')
    def test_backup_and_unrelated(self):
        installer.install(ROOT,self.target);(self.target/'unrelated').mkdir();(self.target/'unrelated/info').write_text('KEEP');f=self.target/'xray-config-orchestrator/SKILL.md';f.write_text('OWNED')
        r=installer.install(ROOT,self.target,True)
        self.assertEqual((Path(r['backup'])/'xray-config-orchestrator/SKILL.md').read_text(),'OWNED');self.assertEqual((self.target/'unrelated/info').read_text(),'KEEP')
    def test_recursive_target(self):
        with self.assertRaises(ValueError):installer.install(ROOT,ROOT/'skills/nested')

class FixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.root=Path(cls.tmp.name)/'lab';cls.manifest=create_lab(cls.root,['raw-tls','raw-reality','xhttp-split-nginx','xdrive-local'])
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_manifest_integrity(self):self.assertEqual(validate_manifest(self.root)['core_commit'],self.manifest['core_commit'])
    def test_only_loopback(self):
        for p in self.root.glob('*/client.json'):
            o=json.loads(p.read_text());self.assertEqual(o['inbounds'][0]['listen'],'127.0.0.1')
    def test_no_overwrite(self):
        with self.assertRaises(ValueError):create_lab(self.root,['raw-tls'])
    def test_private_permissions(self):
        if os.name=='nt':self.skipTest('POSIX modes only')
        self.assertEqual((self.root/'raw-tls/lab-key.pem').stat().st_mode & 0o777,0o600)
    def test_real_pin_matches_local_certificate(self):
        d=self.root/'raw-tls';der=subprocess.check_output(['openssl','x509','-in',str(d/'lab-cert.pem'),'-outform','DER']);import hashlib
        o=json.loads((d/'client.json').read_text());self.assertEqual(o['outbounds'][0]['streamSettings']['tlsSettings']['pinnedPeerCertSha256'],hashlib.sha256(der).hexdigest())
    def test_missing_binary_is_not_success(self):
        report=Path(self.tmp.name)/'no-core-report.json'
        p=subprocess.run([sys.executable,str(SCRIPTS/'run_lab.py'),str(self.root),'--xray','/nonexistent/xray','--allow-lab-execution','--report',str(report)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        self.assertEqual(p.returncode,3);self.assertEqual(json.loads(report.read_text())['status'],'NOT_RUN')
    def test_without_opt_in(self):
        report=Path(self.tmp.name)/'no-opt-report.json';p=subprocess.run([sys.executable,str(SCRIPTS/'run_lab.py'),str(self.root),'--report',str(report)],stdout=subprocess.PIPE)
        self.assertEqual(p.returncode,3);self.assertEqual(json.loads(report.read_text())['status'],'NOT_RUN')
    def test_fixture_modification_detected(self):
        src=self.root/'raw-tls/client.json';data=src.read_bytes()
        try:
            src.write_text('{}')
            with self.assertRaises(ValueError):validate_manifest(self.root)
        finally:src.write_bytes(data)
    def test_child_log_capture_is_harness_only(self):
        d=Path(self.tmp.name);r=capture([sys.executable,'-c','print("UNIT HARNESS, NOT XRAY")'],d,d/'child.log',3)
        self.assertEqual(r['status'],'PASS');self.assertIn('NOT XRAY',(d/'child.log').read_text())

if __name__=='__main__':unittest.main()
