"""Regression tests for defects reproduced in r4; native evidence is separate."""
from __future__ import annotations
import copy,json,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'skills/xray-source-audit/scripts';sys.path.insert(0,str(S))
from validate import Validator,check_pair
from http_peer_checks import masque_uri,valid_http_host,masque_client_version,masque_server_versions,destination_address
from compose_config import merge_named,strip_comments,compose,collect_files,load_files
from test_extended import pair,codes,CRED
from peer_checks import canonical_id,uses_utls,public_from_private,http_version


def endpoints(name,mutator=None):
    p=pair(name);c,s=p['client.json'],p['server.json']
    if mutator:mutator(c['outbounds'][0]['streamSettings'],s['inbounds'][0]['streamSettings'])
    return c,s


def result(c,s):return check_pair(c,s,'lab-proxy','lab-in')
def peer_codes(c,s):return {x['code'] for x in result(c,s)}

def new_protocol(protocol,legacy=False):
    c,s=endpoints('raw-tls');ce,se=c['outbounds'][0],s['inbounds'][0]
    ce['protocol']=se['protocol']=protocol
    key='id' if protocol=='vmess' else 'password';value='Alice' if protocol=='vmess' else 'NOT-A-REAL-PASSWORD'
    opts=ce['settings'];target={'address':opts['address'],'port':opts['port'],key:value}
    if protocol=='vmess':target['security']='auto'
    if legacy:
        ce['settings']={'vnext':[{'address':target.pop('address'),'port':target.pop('port'),'users':[target]}]} if protocol=='vmess' else {'servers':[target]}
    else:ce['settings']=target
    se['settings']={'users':[{key:value}]}
    return c,s


class HTTPRegression(unittest.TestCase):
    def test_xhttp_header_case(self):
        def edit(c,s):
            c['xhttpSettings'].update(sessionIDPlacement='header',sessionIDKey='x-session')
            s['xhttpSettings'].update(sessionIDPlacement='header',sessionIDKey='X-Session')
        c,s=endpoints('xhttp-packet-h1',edit);self.assertNotIn('PEER_META',peer_codes(c,s))
    def test_xhttp_auto_payload_is_body(self):
        c,s=endpoints('xhttp-packet-h1',lambda c,s:s['xhttpSettings'].update(uplinkDataPlacement='body'))
        self.assertNotIn('PEER_DATA_PLACEMENT',peer_codes(c,s))
    def test_ignored_path_keys(self):
        c,s=endpoints('xhttp-packet-h1',lambda c,s:(c['xhttpSettings'].update(sessionIDKey='unused-a'),s['xhttpSettings'].update(sessionIDKey='unused-b')))
        self.assertNotIn('PEER_META',peer_codes(c,s))
    def test_stream_one_inactive_metadata(self):
        c,s=endpoints('xhttp-one-h2',lambda c,s:(c['xhttpSettings'].update(sessionIDPlacement='header',seqPlacement='cookie'),s['xhttpSettings'].update(sessionIDPlacement='query',seqPlacement='header')))
        self.assertNotIn('PEER_META',peer_codes(c,s))
    def test_stream_one_no_post_limit_check(self):
        c,s=endpoints('xhttp-one-h2',lambda c,s:c['xhttpSettings'].update(scMaxEachPostBytes=3000000))
        self.assertNotIn('PEER_POST_LIMIT',peer_codes(c,s))
    def test_default_padding_is_checked(self):
        c,s=endpoints('xhttp-packet-h1',lambda c,s:c['xhttpSettings'].update(xPaddingBytes='1-20'))
        self.assertIn('PEER_PADDING_RANGE',peer_codes(c,s))
    def test_zero_padding_uses_default(self):
        c,s=endpoints('xhttp-packet-h1',lambda c,s:c['xhttpSettings'].update(xPaddingBytes=0))
        self.assertNotIn('PEER_PADDING_RANGE',peer_codes(c,s))
    def test_metadata_cookie_case_matters(self):
        c,s=endpoints('xhttp-packet-h1',lambda c,s:(c['xhttpSettings'].update(sessionIDPlacement='cookie',sessionIDKey='SESSION'),s['xhttpSettings'].update(sessionIDPlacement='cookie',sessionIDKey='session')))
        self.assertIn('PEER_META',peer_codes(c,s))
    def test_padding_cookie_acceptance_independent_of_server_placement(self):
        def edit(c,s):
            c['xhttpSettings'].update(xPaddingObfsMode=True,xPaddingPlacement='cookie')
            s['xhttpSettings'].update(xPaddingObfsMode=True,xPaddingPlacement='query')
        c,s=endpoints('xhttp-packet-h1',edit)
        self.assertNotIn('PEER_PADDING_FORMAT',peer_codes(c,s))
    def test_http_host_case_and_request_port(self):
        self.assertTrue(valid_http_host('SITE.EXAMPLE:443','site.example'))
    def test_http_host_wildcard_not_supported(self):
        self.assertFalse(valid_http_host('a.example','*.example'))
    def test_server_host_must_not_include_port(self):
        self.assertFalse(valid_http_host('site.example:443','site.example:443'))
    def test_ipv6_host_literal(self):self.assertTrue(valid_http_host('[::1]:443','::1'))
    def test_sni_fallback_checked(self):
        c,s=endpoints('xhttp-stream-h2',lambda c,s:(c['xhttpSettings'].update(host=''),s['xhttpSettings'].update(host='other.invalid')))
        self.assertIn('PEER_HTTP_HOST',peer_codes(c,s))
    def test_normal_endpoint_not_overridden_by_nested_stream_address(self):
        c,s=endpoints('raw-tls');e=c['outbounds'][0];e['streamSettings']['address']='wrong.invalid'
        self.assertEqual(destination_address(e),e['settings']['address'])
    def test_masque_default_template_equal(self):
        self.assertEqual(masque_uri(''),masque_uri('/.well-known/masque/ip/{target}/{ipproto}/'))
    def test_masque_query_order_irrelevant(self):
        self.assertEqual(masque_uri('/m{?target,ipproto}'),masque_uri('/m?ipproto=*&target=*'))
    def test_masque_repeated_values_order_matters(self):
        self.assertNotEqual(masque_uri('/m?a=1&a=2'),masque_uri('/m?a=2&a=1'))
    def test_masque_query_mismatch_detected(self):
        c,s=endpoints('masque-h2',lambda c,s:(c['masqueSettings'].update(path='/m?a=1'),s['masqueSettings'].update(path='/m?a=2')))
        self.assertIn('PEER_MASQUE_URI',peer_codes(c,s))
    def test_masque_default_valid_pair(self):
        c,s=endpoints('masque-h2',lambda c,s:(c['masqueSettings'].pop('path',None),s['masqueSettings'].update(path='/.well-known/masque/ip/{target}/{ipproto}/')))
        self.assertNotIn('PEER_PATH',peer_codes(c,s));self.assertNotIn('PEER_MASQUE_URI',peer_codes(c,s))
    def test_masque_client_h3_precedence(self):self.assertEqual(masque_client_version({'tlsSettings':{'alpn':['h2','h3']}}),'h3')
    def test_masque_server_dual_listeners(self):self.assertEqual(masque_server_versions({'tlsSettings':{'alpn':['h2','h3']}}),{'h2','h3'})
    def test_masque_wrong_listener(self):
        c,s=endpoints('masque-h2',lambda c,s:c['tlsSettings'].update(alpn=['h2','h3']))
        self.assertIn('PEER_MASQUE_VERSION',peer_codes(c,s))
    def test_masque_h2_utls(self):self.assertTrue(uses_utls({'network':'masque','security':'tls','tlsSettings':{'alpn':['h2']}},'masque'))
    def test_masque_h3_not_utls(self):self.assertFalse(uses_utls({'network':'masque','security':'tls','tlsSettings':{'alpn':['h3']}},'masque'))
    def test_http_checker_does_not_mutate(self):
        c,s=endpoints('xhttp-packet-h1');expected=copy.deepcopy((c,s));check_pair(c,s);self.assertEqual((c,s),expected)


class ProtocolRegression(unittest.TestCase):
    def test_vmess_security_none_auto(self):
        c,s=new_protocol('vmess');c['outbounds'][0]['settings']['security']='none';self.assertIn('VMESS_SECURITY_AUTO',codes(c))
    def test_trojan_flow_removed(self):
        c,s=new_protocol('trojan');c['outbounds'][0]['settings']['flow']='xtls-rprx-vision';self.assertIn('TROJAN_FLOW_REMOVED',codes(c))
    def test_trojan_inbound_empty_password(self):
        c,s=new_protocol('trojan');s['inbounds'][0]['settings']['users'][0]['password']='';self.assertIn('TROJAN_PASSWORD',codes(s))
    def test_vmess_short_id_normalized(self):
        c,s=new_protocol('vmess');s['inbounds'][0]['settings']['users'][0]['id']=canonical_id('Alice');self.assertNotIn('PEER_AUTH',peer_codes(c,s))
    def test_empty_clients_overrides_users(self):
        c,s=new_protocol('trojan');s['inbounds'][0]['settings']['clients']=[];self.assertIn('PEER_AUTH',peer_codes(c,s))
    def test_null_clients_does_not_override(self):
        c,s=new_protocol('vmess');s['inbounds'][0]['settings']['clients']=None;self.assertNotIn('PEER_AUTH',peer_codes(c,s))
    def test_vless_mlkem_not_falsely_verified(self):
        c,s=endpoints('raw-tls');c['outbounds'][0]['settings']['encryption']='mlkem768x25519plus.native.0rtt.'+'A'*1579
        s['inbounds'][0]['settings']['decryption']='mlkem768x25519plus.native.600s.'+'A'*86
        self.assertIn('PEER_VLESS_ENCRYPTION_UNVERIFIED',peer_codes(c,s))
    def test_vless_simple_x25519_mismatch(self):
        if public_from_private(CRED['private']) is None:self.skipTest('optional cryptography absent')
        c,s=endpoints('raw-tls');c['outbounds'][0]['settings']['encryption']='mlkem768x25519plus.native.0rtt.'+'B'*43
        s['inbounds'][0]['settings']['decryption']='mlkem768x25519plus.native.600s.'+CRED['private']
        self.assertIn('PEER_VLESS_ENCRYPTION_KEY',peer_codes(c,s))
    def test_vless_simple_x25519_correct(self):
        c,s=endpoints('raw-tls');c['outbounds'][0]['settings']['encryption']='mlkem768x25519plus.native.0rtt.'+CRED['public']
        s['inbounds'][0]['settings']['decryption']='mlkem768x25519plus.native.600s.'+CRED['private']
        self.assertNotIn('PEER_VLESS_ENCRYPTION_KEY',peer_codes(c,s))

for proto in ('vmess','trojan'):
    for legacy in (True,False):
        def test_good(self,proto=proto,legacy=legacy):
            c,s=new_protocol(proto,legacy)
            self.assertFalse([x for x in Validator().config(c)+Validator().config(s) if x['severity']=='ERROR'])
            self.assertNotIn('PEER_AUTH',peer_codes(c,s))
        def test_bad(self,proto=proto,legacy=legacy):
            c,s=new_protocol(proto,legacy);u=s['inbounds'][0]['settings']['users'][0];u['id' if proto=='vmess' else 'password']='Other-Credential'
            self.assertIn('PEER_AUTH',peer_codes(c,s));self.assertNotIn('Other-Credential',json.dumps(result(c,s)))
        setattr(ProtocolRegression,f'test_{proto}_{legacy}_good',test_good)
        setattr(ProtocolRegression,f'test_{proto}_{legacy}_bad',test_bad)


class CompositionRegression(unittest.TestCase):
    def merge(self,*xs):return merge_named(list(xs))[0]
    def test_blocks_replace_not_deep_merge(self):
        self.assertEqual(self.merge(('a.json',{'dns':{'servers':['1.1.1.1'],'tag':'dns'}}),('b.json',{'dns':{}}))['dns'],{})
    def test_null_blocks_do_not_clear(self):
        self.assertEqual(self.merge(('a.json',{'dns':{'tag':'dns'}}),('b.json',{'dns':None}))['dns'],{'tag':'dns'})
    def test_env_keys_merge(self):
        self.assertEqual(self.merge(('a.json',{'env':{'A':'1','B':'2'}}),('b.json',{'env':{'B':'3'}}))['env'],{'A':'1','B':'3'})
    def test_new_outbounds_prepend(self):
        x=self.merge(('a.json',{'outbounds':[{'tag':'a'}]}),('b.json',{'outbounds':[{'tag':'b'},{'tag':'c'}]}));self.assertEqual([e['tag'] for e in x['outbounds']],['b','c','a'])
    def test_tail_in_parent_directory(self):
        x=self.merge(('a.json',{'outbounds':[{'tag':'a'}]}),('/retail/b.json',{'outbounds':[{'tag':'b'}]}));self.assertEqual([e['tag'] for e in x['outbounds']],['a','b'])
    def test_existing_endpoint_replaced_whole(self):
        x=self.merge(('a.json',{'outbounds':[{'tag':'a','settings':{'x':1}}]}),('b.json',{'outbounds':[{'tag':'a','protocol':'freedom'}]}));self.assertNotIn('settings',x['outbounds'][0])
    def test_inbounds_append(self):
        x=self.merge(('a.json',{'inbounds':[{'tag':'a'}]}),('b.json',{'inbounds':[{'tag':'b'}]}));self.assertEqual([e['tag'] for e in x['inbounds']],['a','b'])
    def test_empty_endpoint_array_does_not_clear(self):
        x=self.merge(('a.json',{'outbounds':[{'tag':'a'}]}),('b.json',{'outbounds':[]}));self.assertEqual(len(x['outbounds']),1)
    def test_untagged_endpoints_replace(self):
        x=self.merge(('a.json',{'inbounds':[{'protocol':'socks'}]}),('b.json',{'inbounds':[{'protocol':'http'}]}));self.assertEqual(len(x['inbounds']),1);self.assertEqual(x['inbounds'][0]['protocol'],'http')
    def test_deferred_prepend_duplicate_not_collapsed(self):
        x=self.merge(('a.json',{}),('b.json',{'outbounds':[{'tag':'z'},{'tag':'z'}]}));self.assertEqual(len(x['outbounds']),2)
    def test_tail_append_duplicate_is_replaced(self):
        x=self.merge(('a.json',{}),('tail.json',{'outbounds':[{'tag':'z','protocol':'socks'},{'tag':'z','protocol':'http'}]}));self.assertEqual(x['outbounds'],[{'tag':'z','protocol':'http'}])
    def test_no_mutation(self):
        a={'outbounds':[{'tag':'a'}]};b={'outbounds':[{'tag':'a','protocol':'socks'}]};ac,bc=copy.deepcopy((a,b));self.merge(('a',a),('b',b));self.assertEqual((a,b),(ac,bc))
    def test_comments_and_quoted_url(self):
        x=strip_comments('{#first\n"url":"https://example/#x",/* hi */"ok":true// hi\n}')
        self.assertEqual(json.loads(x),{'url':'https://example/#x','ok':True})
    def test_unclosed_comment(self):self.assertRaises(ValueError,strip_comments,'{}/*')
    def test_comments_cannot_splice_numbers(self):self.assertRaises(ValueError,json.loads,strip_comments('{"x":1/*x*/2}'))
    def test_json5_single_quotes_still_rejected(self):self.assertRaises(ValueError,json.loads,strip_comments("{'x':1}"))
    def test_jsonc_load_and_aggregate(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.jsonc';p.write_text('{// hi\n"outbounds":[{"protocol":"freedom","tag":"direct"}]}')
            obj,r=compose([str(p)]);self.assertEqual(r['status'],'STATIC_OK');self.assertEqual(r['input_count'],1)
    def test_late_env_warning(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.json';p.write_text(json.dumps({'env':{'PORT':'12345'},'inbounds':[{'protocol':'socks','port':'env:PORT'}]}))
            obj,r=compose([str(p)]);self.assertIn('ROOT_ENV_AFTER_PARSE',{x['code'] for x in r['issues']});self.assertEqual(obj['inbounds'][0]['port'],'env:PORT')
    def test_duplicate_key_refused(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.json';p.write_text('{"log":{},"log":{}}');self.assertRaises(ValueError,compose,[str(p)])
    def test_symlink_refused(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'a.json').write_text('{}');(p/'b.json').symlink_to(p/'a.json');self.assertRaises(ValueError,compose,[str(p/'b.json')])
    def test_confdir_sorted_and_explicit_first(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)
            for name in ('b.json','a.jsonc','c.JSON','ignore.yaml'):(p/name).write_text('{}')
            files=collect_files(['first.json'],str(p));self.assertEqual([Path(f).name for f in files],['first.json','a.jsonc','b.json'])
    def test_strict_json_rejects_comments(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.json';p.write_text('{}//comment');self.assertRaises(ValueError,compose,[str(p)],strict=True)
    def test_unknown_root_refused(self):self.assertRaises(ValueError,self.merge,('a',{'notAConfig':{}}))
    def test_empty_file_list(self):self.assertRaises(ValueError,merge_named,[])
    def test_string_instead_of_endpoints(self):self.assertRaises(ValueError,self.merge,('a',{'outbounds':'bad'}))
    def test_cli_does_not_leak_credentials(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.json';p.write_text('{"SECRET-THIS-MUST-NOT-LEAK":3}')
            proc=subprocess.run([sys.executable,str(S/'compose_config.py'),'-c',str(p)],text=True,capture_output=True)
            self.assertEqual(proc.returncode,2);self.assertNotIn('SECRET-THIS',proc.stdout+proc.stderr)

class ExecutionAndCompositionEdges(unittest.TestCase):
    def test_r5_binary_hash_before_output_creation(self):
        from run_r5_regressions import run
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);binary=root/'fake';binary.write_bytes(b'not executable')
            with self.assertRaises(ValueError):run(binary,root/'output','0'*64)
            self.assertFalse((root/'output').exists())
    def test_typed_fragment_error_cannot_be_hidden_by_overlay(self):
        with self.assertRaises(ValueError):merge_named([('a.json',{'dns':{'queryStrategy':42}}),('b.json',{'dns':{}})])
    def test_raw_settings_are_built_after_overlay(self):
        out,_=merge_named([('a.json',{'outbounds':[{'tag':'x','protocol':'vless','settings':{'id':42}}]}),('b.json',{'outbounds':[{'tag':'x','protocol':'freedom'}]})])
        self.assertEqual(out['outbounds'],[{'tag':'x','protocol':'freedom'}])
    def test_masque_case_insensitive_method(self):
        self.assertEqual(http_version({'method':'MASQUE','security':'tls','tlsSettings':{'alpn':['h2','h3']}}),'h3')
    def test_composer_private_new_output_only(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);src=p/'input.json';src.write_text('{"outbounds":[{"protocol":"freedom"}]}');out=p/'merged.json'
            argv=[sys.executable,str(S/'compose_config.py'),'-c',str(src),'--write-merged',str(out)]
            self.assertEqual(subprocess.run(argv,capture_output=True).returncode,0)
            self.assertEqual(out.stat().st_mode & 0o777,0o600)
            before=out.read_bytes();self.assertEqual(subprocess.run(argv,capture_output=True).returncode,2);self.assertEqual(out.read_bytes(),before)
    def test_composer_with_errors_does_not_write(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);src=p/'input.json';src.write_text('{"inbounds":[{"protocol":"socks","listen":"public.invalid","port":12345}]}');out=p/'merged.json'
            proc=subprocess.run([sys.executable,str(S/'compose_config.py'),'-c',str(src),'--write-merged',str(out)],capture_output=True)
            self.assertEqual(proc.returncode,1);self.assertFalse(out.exists())

if __name__=='__main__':unittest.main()
