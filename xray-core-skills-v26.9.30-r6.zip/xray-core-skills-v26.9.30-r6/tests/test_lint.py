"""Unit tests of the auxiliary linter only. Does NOT run Xray-core."""
import importlib.util
import json
import unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('lint_config',R/'skills/xray-source-audit/scripts/lint_config.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def stream(net='xhttp',settings=None,**extra):
    o={'network':net,**extra}
    if settings is not None:o[m.KEYS[m.ALIASES[net]]]=settings
    return o

CASES=[
('raw_minimal',stream('raw',{}),None),
('xhttp_minimal',stream(settings={'path':'/vpn/'}),None),
('xhttp_badmode',stream(settings={'mode':'invalid'}),'ENUM'),
('removed_quic',{'network':'quic'},'TRANSPORT_REMOVED'),
('removed_h2',{'network':'h2'},'TRANSPORT_REMOVED'),
('removed_h3',{'network':'h3'},'TRANSPORT_REMOVED'),
('removed_http',{'network':'http'},'TRANSPORT_REMOVED'),
('unknown_network',{'network':'imaginary'},'NETWORK_UNKNOWN'),
('alias_network',{'method':'raw','network':'xhttp'},'ALIAS_SHADOW'),
('alias_settings',{'network':'raw','rawSettings':{},'tcpSettings':{}},'ALIAS_SHADOW'),
('unknown_field',stream(settings={'imaginary':1}),'UNKNOWN_FIELD'),
('false_is_not_uint',stream('mkcp',{'mtu':False}),'TYPE'),
('padding_forbidden',stream(settings={'xPaddingBytes':'0-100'}),'XHTTP_PADDING'),
('padding_default',stream(settings={'xPaddingBytes':0}),None),
('xmux_conflict',stream(settings={'xmux':{'maxConnections':2,'maxConcurrency':2}}),'XHTTP_XMUX_CONFLICT'),
('xmux_connections',stream(settings={'xmux':{'maxConnections':'2-3'}}),None),
('xhttp_host_header',stream(settings={'headers':{'Host':'example.invalid'}}),'HOST_HEADER'),
('xhttp_extra_overwrite',stream(settings={'headers':{'X-Test':'1'},'extra':{}}),'XHTTP_EXTRA_SHADOW'),
('extra_drops_forbidden_host',stream(settings={'headers':{'Host':'example.invalid'},'extra':{}}),'XHTTP_EXTRA_SHADOW'),
('extra_host_inside',stream(settings={'extra':{'headers':{'Host':'example.invalid'}}}),'HOST_HEADER'),
('get_packetup',stream(settings={'mode':'packet-up','uplinkHTTPMethod':'get'}),None),
('get_auto_rejected',stream(settings={'mode':'auto','uplinkHTTPMethod':'GET'}),'XHTTP_GET_MODE'),
('cookie_stream_rejected',stream(settings={'mode':'stream-up','uplinkDataPlacement':'cookie'}),'XHTTP_DATA_MODE'),
('cookie_packet_allowed',stream(settings={'mode':'packet-up','uplinkDataPlacement':'cookie'}),None),
('download_stream_one',stream(settings={'mode':'stream-one','downloadSettings':{}}),'XHTTP_DOWNLOAD_MODE'),
('download_missing_dest',stream(settings={'downloadSettings':{'network':'xhttp'}}),'XHTTP_DOWNLOAD_DEST'),
('download_good',stream(settings={'downloadSettings':{'address':'example.invalid','port':443,'network':'xhttp'}}),None),
('download_wrong_network',stream(settings={'downloadSettings':{'address':'example.invalid','port':443,'network':'raw'}}),'XHTTP_DOWNLOAD_DEST'),
('h3_brutal',stream(settings={},security='tls',tlsSettings={'alpn':['h3']},finalmask={'quicParams':{'congestion':'brutal'}}),'XHTTP_H3_BRUTAL'),
('h3_bbr',stream(settings={},security='tls',tlsSettings={'alpn':['h3']},finalmask={'quicParams':{'congestion':'bbr'}}),None),
('post_zero_from',stream(settings={'scMaxEachPostBytes':'0-100'}),'XHTTP_POST_RANGE'),
('kcp_ignored',stream('mkcp',{'seed':'test-only'}),'KCP_IGNORED'),
('kcp_tti_zero',stream('mkcp',{'tti':0}),'KCP_TTI'),
('kcp_bad_mtu',stream('mkcp',{'mtu':20}),'KCP_MTU'),
('kcp_bad_window',stream('mkcp',{'maxSendingWindow':1}),'KCP_WINDOW'),
('kcp_good',stream('mkcp',{}),None),
('grpc_unknown_headers',stream('grpc',{'headers':{}}),'UNKNOWN_FIELD'),
('ws_host_warning',stream('ws',{'headers':{'Host':'example.invalid'}}),'HOST_HEADER'),
('upgrade_host_error',stream('httpupgrade',{'headers':{'HOST':'example.invalid'}}),'HOST_HEADER'),
('early_data_negative',stream('ws',{'path':'/x?ed=-1'}),'EARLY_DATA_VALUE'),
('hysteria_version',stream('hysteria',{'version':1},security='tls'),'HYSTERIA_VERSION'),
('hysteria_good',stream('hysteria',{'version':2},security='tls'),None),
('hysteria_timeout',stream('hysteria',{'version':2,'udpIdleTimeout':601},security='tls'),'HYSTERIA_TIMEOUT'),
('masque_tls_required',stream('masque',{}),'TLS_EXPECTED'),
('masque_bad_auth',stream('masque',{'user':'a','headers':{'Authorization':'test-only'}},security='tls'),'MASQUE_HEADER'),
('masque_good',stream('masque',{'user':'test','pass':'test-only'},security='tls'),None),
('xdrive_secrets',stream('xdrive',{'service':'Google Drive','secrets':['a']}),'XDRIVE_SECRETS'),
('xdrive_local',stream('xdrive',{'service':'local'}),None),
('xdrive_bad_service',stream('xdrive',{'service':'google drive'}),'XDRIVE_SERVICE'),
('xdrive_missing_operation',stream('xdrive',{'service':'template','template':{}}),'XDRIVE_OPERATION'),
('tls_insecure',stream('raw',{},security='tls',tlsSettings={'allowInsecure':True}),'TLS_INSECURE_REMOVED'),
('tls_pin_list',stream('raw',{},security='tls',tlsSettings={'pinnedPeerCertSha256':[]}), 'TLS_PIN_TYPE'),
('tls_pin_invalid',stream('raw',{},security='tls',tlsSettings={'pinnedPeerCertSha256':'00'}),'TLS_PIN_FORMAT'),
('tls_pin_valid',stream('raw',{},security='tls',tlsSettings={'pinnedPeerCertSha256':':'.join(['ab']*32)}),None),
('reality_ws',stream('ws',{},security='reality',realitySettings={}), 'REALITY_TRANSPORT'),
('reality_key_bad',stream('raw',{},security='reality',realitySettings={'password':'abc'}), 'REALITY_KEY_FORMAT'),
('reality_missing',stream('raw',{},security='reality'),'REALITY_EMPTY'),
('legacy_xtls',stream('raw',{},security='xtls'),'SECURITY_UNSUPPORTED'),
('inactive_settings',{'network':'raw','wsSettings':{}},'INACTIVE_SETTINGS'),
('inactive_security',{'network':'raw','tlsSettings':{'serverName':'example.invalid'}},'INACTIVE_SECURITY'),
('port_outside',{'network':'raw','port':65536},'PORT'),
('tproxy_typo',{'network':'raw','sockopt':{'tproxy':'tpoxy'}},'TPROXY_TYPO')]

class TestLinter(unittest.TestCase):
    def test_duplicate_json_key(self):
        with self.assertRaises(ValueError):m.loads('{"network":"raw","network":"xhttp"}')
    def test_nan_rejected(self):
        with self.assertRaises(ValueError):m.loads('{"a":NaN}')
    def test_range_sort(self):self.assertEqual(m.range32('100-10'),(10,100))
    def test_range_negative(self):self.assertEqual(m.range32('-20--10'),(-20,-10))
    def test_range_empty(self):self.assertEqual(m.range32(''),(0,0))
    def test_range_bool(self):
        with self.assertRaises(ValueError):m.range32(False)
    def test_range_overflow(self):
        with self.assertRaises(ValueError):m.range32(2**40)
    def test_full_document(self):
        result=m.Linter().config({'outbounds':[{'streamSettings':{'network':'quic'}}]})
        self.assertTrue(any(i['code']=='TRANSPORT_REMOVED' for i in result))
    def test_error_count_extra_ignored(self):
        r=m.Linter().config(stream(settings={'headers':{'Host':'a'},'extra':{}}),True)
        self.assertFalse(any(i['severity']=='ERROR' for i in r))
    def test_ws_header_warning_not_error(self):
        r=m.Linter().config(stream('ws',{'headers':{'Host':'a'}}),True)
        self.assertFalse(any(i['severity']=='ERROR' for i in r))
    def test_post_range_unused_stream_one(self):
        r=m.Linter().config(stream(settings={'mode':'stream-one','scMaxEachPostBytes':'0-100'}),True)
        self.assertNotIn('XHTTP_POST_RANGE',[i['code'] for i in r])
    def test_post_range_unused_reality_auto(self):
        r=m.Linter().config(stream(settings={'mode':'auto','scMaxEachPostBytes':'0-100'},security='reality',realitySettings={}),True)
        self.assertNotIn('XHTTP_POST_RANGE',[i['code'] for i in r])
    def test_recursion_guard(self):
        x={}
        for _ in range(30):x={'network':'xhttp','address':'example.invalid','port':443,'xhttpSettings':{'downloadSettings':x}}
        r=m.Linter().config(x,True);self.assertTrue(any(i['code']=='DEPTH' for i in r))

def make(o,expected):
    def test(self):
        r=m.Linter().config(o,True)
        if expected:self.assertIn(expected,[i['code'] for i in r],r)
        else:self.assertFalse(any(i['severity']=='ERROR' for i in r),r)
    return test
for name,obj,code in CASES:setattr(TestLinter,'test_case_'+name,make(obj,code))
if __name__=='__main__':unittest.main()
