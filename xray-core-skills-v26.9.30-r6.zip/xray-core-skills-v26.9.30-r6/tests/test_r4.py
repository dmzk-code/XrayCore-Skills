"""Regression tests for observed r3 omissions. Not Xray wire tests."""
from __future__ import annotations
import base64,copy,hashlib,json,sys,tempfile,unittest
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'skills/xray-source-audit/scripts'))
from validate import Validator,check_pair
from peer_checks import canonical_id,grpc_path,public_from_private
from lint_config import loads
from package_integrity import verify_integrity,digest,shipped
from test_extended import pair,cfg,codes,CRED,installer
from build_lab import create_lab
from run_lab import validate_manifest

def peer(name='raw-reality',edit=None):
    p=pair(name)
    if edit:edit(p['client.json'],p['server.json'])
    return {x['code'] for x in check_pair(p['client.json'],p['server.json'],'lab-proxy','lab-in')}
def streams(c,s):return c['outbounds'][0]['streamSettings'],s['inbounds'][0]['streamSettings']
def cs(c):return c['outbounds'][0]['streamSettings']
def bs(s):return s['inbounds'][0]['streamSettings']

def manifest(root):
    (root/'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.relative_to(root).as_posix()}\n' for p in sorted(root.rglob('*')) if p.is_file() and shipped(p.relative_to(root))))

class StructuralCases(unittest.TestCase):pass
CASES=[
('listen_bool',{'inbounds':[{'protocol':'socks','port':12345,'listen':True}]},'SCHEMA_TYPE'),
('port_bool',{'inbounds':[{'protocol':'socks','port':False}]},'PORT_LIST'),
('port_array',{'inbounds':[{'protocol':'socks','port':[443]}]},'PORT_LIST'),
('port_zero',{'inbounds':[{'protocol':'socks','port':0}]},'PORT_LIST'),
('port_overflow',{'inbounds':[{'protocol':'socks','port':65536}]},'PORT_LIST'),
('port_reverse',{'inbounds':[{'protocol':'socks','port':'9000-8000'}]},'PORT_LIST'),
('port_empty_item',{'inbounds':[{'protocol':'socks','port':'443,,8443'}]},'PORT_LIST'),
('port_env',{'inbounds':[{'protocol':'socks','port':'env:TEST_PORT'}]},'ENV_UNRESOLVED'),
('listen_domain',{'inbounds':[{'protocol':'socks','port':8080,'listen':'public.example'}]},'LISTEN_DOMAIN'),
('log_level_integer',{'log':{'loglevel':42}},'SCHEMA_TYPE'),
('log_dns_string',{'log':{'dnsLog':'true'}},'SCHEMA_TYPE'),
('log_access_array',{'log':{'access':[]}},'SCHEMA_TYPE'),
('log_typo',{'log':{'loglevel':'warnn'}},'LOG_LEVEL_DEFAULT'),
('root_env_integer',{'env':{'X':1}},'SCHEMA_TYPE'),
('policy_string_stats',{'policy':{'system':{'statsInboundUplink':'true'}}},'SCHEMA_TYPE'),
('policy_level_negative',{'policy':{'levels':{'-1':{}}}},'POLICY_LEVEL'),
('policy_level_overflow',{'policy':{'levels':{'4294967296':{}}}},'POLICY_LEVEL'),
('policy_level_alpha',{'policy':{'levels':{'admin':{}}}},'POLICY_LEVEL'),
('policy_overflow',{'policy':{'levels':{'0':{'bufferSize':2097152}}}},'POLICY_BUFFER_OVERFLOW'),
('policy_timeout_negative',{'policy':{'levels':{'0':{'handshake':-1}}}},'SCHEMA_TYPE'),
('policy_stats_without_component',{'policy':{'levels':{'0':{'statsUserOnline':True}}}},'STATS_REQUIRED'),
('policy_system_no_stats',{'policy':{'system':{'statsOutboundDownlink':True}}},'STATS_REQUIRED'),
('api_tag_missing',{'api':{'listen':'127.0.0.1:10085'}},'API_TAG'),
('api_services_string',{'api':{'tag':'api','services':'StatsService'}},'SCHEMA_TYPE'),
('api_service_typo',{'api':{'tag':'api','services':['StatService']}},'API_SERVICE_IGNORED'),
('api_exposed',{'api':{'tag':'api','listen':'0.0.0.0:10085'}},'CONTROL_PLANE_EXPOSED'),
('metrics_empty',{'metrics':{}},'METRICS_ENDPOINT'),
('metrics_unix',{'metrics':{'listen':'/tmp/metrics.sock'}},'METRICS_TCP_ONLY'),
('metrics_exposed',{'metrics':{'listen':'[::]:10086'}},'CONTROL_PLANE_EXPOSED'),
('sniff_enabled_string',{'inbounds':[{'protocol':'socks','port':8080,'sniffing':{'enabled':'true'}}]},'SCHEMA_TYPE'),
('sniff_unknown',{'inbounds':[{'protocol':'socks','port':8080,'sniffing':{'destOverride':['h2']}}]},'SNIFF_PROTOCOL'),
('sniff_metadata',{'inbounds':[{'protocol':'socks','port':8080,'sniffing':{'enabled':True,'metadataOnly':True,'destOverride':['tls']}}]},'SNIFF_METADATA_ONLY'),
('version_min_integer',{'version':{'min':26}},'SCHEMA_TYPE'),
('geodata_http',{'geodata':{'assets':[{'url':'http://example.com/data','file':'test.dat'}]}},'GEODATA_URL'),
('geodata_asset_string',{'geodata':{'assets':['test']}},'SCHEMA_TYPE'),
('fake_cidr',{'fakeDns':{'ipPool':'not-cidr','poolSize':32768}},'FAKEDNS_CIDR'),
('fake_array_null',{'fakeDns':[None]},'FAKEDNS_POOL'),
('fake_size_string',{'fakeDns':{'ipPool':'198.18.0.0/15','poolSize':'32768'}},'SCHEMA_TYPE'),
('unknown_protocol_direction',{'inbounds':[{'protocol':'freedom','port':8080}]},'PROTOCOL_UNREGISTERED'),
]
for name,obj,code in CASES:
    def test(self,obj=obj,code=code):self.assertIn(code,codes(copy.deepcopy(obj)))
    setattr(StructuralCases,'test_'+name,test)

class PeerRegression(unittest.TestCase):
    def test_reality_key_correct(self):self.assertNotIn('PEER_REALITY_KEY',peer())
    def test_reality_key_incorrect(self):
        if public_from_private(CRED['private']) is None:self.skipTest('optional cryptography unavailable')
        self.assertIn('PEER_REALITY_KEY',peer(edit=lambda c,s:cs(c)['realitySettings'].update(password='B'*43)))
    def test_reality_shortid_incorrect(self):self.assertIn('PEER_REALITY_SHORTID',peer(edit=lambda c,s:cs(c)['realitySettings'].update(shortId='cafe')))
    def test_reality_sni_incorrect(self):self.assertIn('PEER_REALITY_SNI',peer(edit=lambda c,s:cs(c)['realitySettings'].update(serverName='wrong.example')))
    def test_reality_padding_equivalent(self):
        self.assertNotIn('PEER_REALITY_SHORTID',peer(edit=lambda c,s:(cs(c)['realitySettings'].update(shortId='ab'),bs(s)['realitySettings'].update(shortIds=['ab00000000000000']))))
    def test_reality_public_alias_empty_password(self):self.assertNotIn('PEER_REALITY_KEY',peer(edit=lambda c,s:cs(c)['realitySettings'].update(password='',publicKey=CRED['public'])))
    def test_crypto_missing_explicit_warning(self):
        with mock.patch('peer_checks.public_from_private',return_value=None):self.assertIn('PEER_CRYPTO_UNVERIFIED',peer())
    def test_mldsa_requires_seed(self):self.assertIn('PEER_MLDSA_SEED',peer(edit=lambda c,s:cs(c)['realitySettings'].update(mldsa65Verify='test')))
    def test_id_short_maps_to_uuid(self):
        mapped=canonical_id('Alice')
        self.assertEqual(mapped,'7fd757a2-2173-5a60-8d25-615994740358')
    def test_id_pair_short_equivalent(self):
        out=peer('raw-tls',lambda c,s:(c['outbounds'][0]['settings'].update(id='Alice'),s['inbounds'][0]['settings']['users'][0].update(id=canonical_id('Alice'))))
        self.assertNotIn('PEER_AUTH',out)
    def test_utf8_30_bytes(self):self.assertEqual(len(canonical_id('я'*15)),36)
    def test_utf8_32_bytes_not_hex(self):self.assertRaises(ValueError,canonical_id,'я'*16)
    def test_id_31_bytes(self):self.assertRaises(ValueError,canonical_id,'x'*31)
    def test_grpc_normal_path(self):self.assertEqual(grpc_path('my service',False),'/my%20service/Tun')
    def test_grpc_custom_multi(self):self.assertEqual(grpc_path('/a/b/T|M',True),'/a/b/M')
    def test_grpc_path_reserved(self):self.assertEqual(grpc_path('a/b;c',False),'/a%2Fb%3Bc/Tun')
    def test_grpc_equivalent_alias(self):
        out=peer('grpc-multi-tls',lambda c,s:(cs(c)['grpcSettings'].update(serviceName='/a/M'),bs(s)['grpcSettings'].update(serviceName='/a/T|M')))
        self.assertNotIn('PEER_GRPC_METHOD',out)
    def test_grpc_wrong_method(self):self.assertIn('PEER_GRPC_METHOD',peer('grpc-tls',lambda c,s:cs(c)['grpcSettings'].update(serviceName='/wrong/T')))
    def test_xhttp_different_underlay(self):self.assertIn('PEER_XHTTP_HTTP_VERSION',peer('xhttp-stream-h2',lambda c,s:cs(c)['tlsSettings'].update(alpn=['h3'])))
    def test_xhttp_payload_key(self):self.assertIn('PEER_UPLINK_KEY',peer('xhttp-header-h2',lambda c,s:cs(c)['xhttpSettings'].update(uplinkDataKey='Other')))
    def test_xhttp_header_case_equivalent(self):self.assertNotIn('PEER_UPLINK_KEY',peer('xhttp-header-h2',lambda c,s:cs(c)['xhttpSettings'].update(uplinkDataKey='x-data')))
    def test_tls_disjoint(self):self.assertIn('PEER_TLS_VERSION',peer('raw-tls',lambda c,s:(cs(c)['tlsSettings'].update(minVersion='1.3',fingerprint='unsafe'),bs(s)['tlsSettings'].update(maxVersion='1.2'))))
    def test_utls_disjoint_is_not_false_incompatibility(self):
        out=peer('raw-tls',lambda c,s:(cs(c)['tlsSettings'].update(minVersion='1.3'),bs(s)['tlsSettings'].update(maxVersion='1.2')))
        self.assertIn('UTLS_FIELDS_NOT_COPIED',out);self.assertNotIn('PEER_TLS_VERSION',out)
    def test_certificate_not_silently_verified(self):self.assertIn('PEER_CERT_UNVERIFIED',peer('raw-tls'))
    def test_fragment_one_sided_valid(self):self.assertNotIn('PEER_MASK_ORDER',peer('raw-fragment-tls'))
    def test_sudoku_password_mismatch(self):
        def patch(c,s):
            for st,p in [(cs(c),'a'),(bs(s),'b')]:st['finalmask']={'tcp':[{'type':'sudoku','settings':{'password':p}}]}
        self.assertIn('PEER_MASK_SECRET',peer('raw-tls',patch))
    def test_masque_h2_uses_tcp_masks(self):
        self.assertIn('PEER_MASK_ORDER',peer('masque-h2',lambda c,s:cs(c).update(finalmask={'tcp':[{'type':'sudoku','settings':{'password':'test'}}]})))
    def test_masque_h3_uses_udp_masks(self):
        self.assertIn('PEER_MASK_ORDER',peer('masque-h3',lambda c,s:cs(c).update(finalmask={'udp':[{'type':'salamander','settings':{'password':'test'}}]})))
    def test_sudoku_padding_need_not_match(self):
        def patch(c,s):
            for st,n in [(cs(c),0),(bs(s),40)]:st['finalmask']={'tcp':[{'type':'sudoku','settings':{'password':'test','paddingMax':n}}]}
        self.assertNotIn('PEER_SUDOKU_TABLES',peer('raw-tls',patch))

class RootGraphAndSafety(unittest.TestCase):
    def test_no_nonfinite_exponents(self):self.assertRaises(ValueError,loads,'{"x":1e9999}')
    def test_no_nonfinite_api_object(self):self.assertTrue(any(x['severity']=='ERROR' for x in Validator().config({'log':{'x':float('inf')}})))
    def test_unknown_key_redacted(self):self.assertNotIn('SECRET_TOKEN',json.dumps(Validator().config({'SECRET_TOKEN':1})))
    def test_null_policy_level_ok(self):self.assertFalse(any(x['severity']=='ERROR' for x in Validator().config({'policy':{'levels':{'0':None}}})))
    def test_empty_stats_ok(self):self.assertFalse(any(x['severity']=='ERROR' for x in Validator().config({'stats':{}})))
    def test_uint32_vless_level_not_uint8(self):
        c=cfg();c['outbounds'][0]['settings']['level']=256;self.assertNotIn('SCHEMA_TYPE',codes(c))
    def test_duplicate_canonical_id(self):
        c=pair()['server.json'];c['inbounds'][0]['settings']['users']=[{'id':'Alice'},{'id':canonical_id('Alice')}];self.assertIn('DUPLICATE_USER_ID',codes(c))
    def test_fake_pool_auto_warning_not_false(self):
        c={'dns':{'servers':['fakedns']},'inbounds':[{'protocol':'socks','port':12345,'sniffing':{'enabled':True,'destOverride':['fakedns']}}]};self.assertNotIn('FAKEDNS_DEPENDENCY',codes(c))
    def test_api_direct_not_virtual(self):
        c=cfg();c['api']={'tag':'api','listen':'127.0.0.1:10085','services':['StatsService']};c['routing']={'rules':[{'inboundTag':['lab-socks'],'outboundTag':'api'}]};self.assertIn('UNKNOWN_TAG',codes(c))
    def test_metrics_default_virtual(self):
        c=cfg();c['metrics']={'listen':'127.0.0.1:10086'};c['routing']={'rules':[{'inboundTag':['lab-socks'],'outboundTag':'Metrics'}]};self.assertNotIn('UNKNOWN_TAG',codes(c))
    def test_virtual_collision(self):
        c=cfg();c['api']={'tag':'lab-proxy','services':[]};self.assertIn('VIRTUAL_TAG_COLLISION',codes(c))
    def test_crypto_reference_vector(self):
        expected=base64.urlsafe_b64decode(CRED['public']+'=');actual=public_from_private(CRED['private'])
        if actual is None:self.skipTest('optional crypto unavailable')
        self.assertEqual(actual,expected)
    def test_integrity_modified(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);(r/'a.txt').write_text('original');manifest(r);self.assertEqual(verify_integrity(r),[]);(r/'a.txt').write_text('changed');self.assertTrue(verify_integrity(r))
    def test_integrity_extra(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);(r/'a').write_text('a');manifest(r);(r/'b').write_text('b');self.assertIn('unlisted package file: b',verify_integrity(r))
    def test_integrity_missing(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);(r/'a').write_text('a');manifest(r);(r/'a').unlink();self.assertIn('missing manifest file: a',verify_integrity(r))
    def test_integrity_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);(r/'SHA256SUMS.txt').write_text('0'*64+'  ../outside\n');self.assertIn('unsafe checksum path',verify_integrity(r))
    def test_integrity_python_cache_ignored(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);(r/'a').write_text('a');manifest(r);(r/'__pycache__').mkdir();(r/'__pycache__/a.pyc').write_bytes(b'test');self.assertEqual(verify_integrity(r),[])
    def test_install_source_skills_parent_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);(r/'real').mkdir();(r/'skills').symlink_to(r/'real',target_is_directory=True);self.assertRaises(ValueError,installer.safe_source,r)
    def test_install_target_parent_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d);(r/'src/skills/xray-test').mkdir(parents=True);(r/'src/skills/xray-test/SKILL.md').write_text('test');(r/'real').mkdir();(r/'alias').symlink_to(r/'real',target_is_directory=True);self.assertRaises(ValueError,installer.install,r/'src',r/'alias/skills')
    def test_fixture_edited_even_rehashed(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d)/'lab';create_lab(r,['raw-tls']);validate_manifest(r)
            p=r/'raw-tls/client.json';c=json.loads(p.read_text());c['api']={'tag':'admin','listen':'0.0.0.0:10085'};p.write_text(json.dumps(c));m=json.loads((r/'lab-manifest.json').read_text());m['scenarios'][0]['files_sha256']['client.json']=digest(p);(r/'lab-manifest.json').write_text(json.dumps(m));self.assertRaises(ValueError,validate_manifest,r)
    def test_fixture_missing_manifest_entry(self):
        with tempfile.TemporaryDirectory() as d:
            r=Path(d)/'lab';create_lab(r,['raw-tls']);m=json.loads((r/'lab-manifest.json').read_text());del m['scenarios'][0]['files_sha256']['client.json'];(r/'lab-manifest.json').write_text(json.dumps(m));self.assertRaises(ValueError,validate_manifest,r)

if __name__=='__main__':unittest.main()

class R4ExecutionGuards(unittest.TestCase):
    def test_main_runner_refuses_execution_without_hash(self):
        import subprocess
        with tempfile.TemporaryDirectory() as directory:
            r=Path(directory);create_lab(r/'lab',['raw-tls']);fake=r/'not-a-binary';fake.write_bytes(b'not executable')
            proc=subprocess.run([sys.executable,str(ROOT/'skills/xray-source-audit/scripts/run_lab.py'),str(r/'lab'),'--xray',str(fake),'--allow-lab-execution','--report',str(r/'report.json')],capture_output=True,text=True,timeout=5)
            self.assertEqual(proc.returncode,2);self.assertEqual(json.loads((r/'report.json').read_text())['status'],'FAIL_PRECONDITION');self.assertFalse(list((r/'lab').glob('run-logs-*')))
    def test_r4_runner_no_execution_before_hash(self):
        import run_r4_regressions as runner
        with tempfile.TemporaryDirectory() as directory,mock.patch.object(runner,'create_lab') as build:
            r=Path(directory);p=r/'fake';p.write_bytes(b'test');self.assertRaises(ValueError,runner.run,p,r/'out','0'*64);build.assert_not_called();self.assertFalse((r/'out').exists())
    def test_actual_helper_signature(self):
        import inspect,run_r4_regressions,run_lab
        self.assertIn('seconds',inspect.signature(run_lab.wait_tcp_probe).parameters)
        self.assertNotIn('children,timeout=',Path(run_r4_regressions.__file__).read_text())
    def test_native_crash_is_not_expected_rejection(self):
        import run_r4_regressions
        self.assertIn("r['exit_code']==23",Path(run_r4_regressions.__file__).read_text())
    def test_single_config_utls_warns(self):
        c=cfg();cs(c)['tlsSettings']['minVersion']='1.3';self.assertIn('UTLS_FIELDS_NOT_COPIED',codes(c))
    def test_go_tls_single_not_utls(self):
        c=cfg();cs(c)['tlsSettings'].update(minVersion='1.3',fingerprint='unsafe');self.assertNotIn('UTLS_FIELDS_NOT_COPIED',codes(c))
    def test_root_malformed_no_uncaught(self):
        vals=[None,False,True,0,-1,1,2**100,1.5,float('inf'),'test',[],[None],{}, {'x':None}]
        for k in ['log','policy','api','metrics','dns','routing','env','inbounds','outbounds','stats','fakeDns','version','geodata']:
            for x in vals:
                with self.subTest(field=k,value_type=type(x).__name__):
                    self.assertIsInstance(Validator().config({k:x}),list);self.assertIsInstance(check_pair({k:x},{k:x},None,None),list)
    def test_broken_integrity_blocks_install_before_write(self):
        with tempfile.TemporaryDirectory() as directory:
            r=Path(directory);src=r/'src';(src/'skills/xray-test').mkdir(parents=True);(src/'skills/xray-test/SKILL.md').write_text('test');manifest(src);(src/'skills/xray-test/SKILL.md').write_text('changed');self.assertRaises(ValueError,installer.install,src,r/'target');self.assertFalse((r/'target').exists())
    def test_peer_cli_correct_option_names(self):
        import subprocess
        p=subprocess.run([sys.executable,str(ROOT/'skills/xray-source-audit/scripts/validate.py'),'--help'],capture_output=True,text=True,timeout=5);self.assertIn('--outbound-tag',p.stdout);self.assertIn('--inbound-tag',p.stdout)

class R4ControlGuards(unittest.TestCase):
    def test_control_no_execution_before_hash(self):
        import run_control_lab as runner
        with tempfile.TemporaryDirectory() as d,mock.patch.object(runner,'capture') as execute:
            r=Path(d);p=r/'fake';p.write_bytes(b'test');self.assertRaises(ValueError,runner.run,p,r/'out','0'*64);execute.assert_not_called();self.assertFalse((r/'out').exists())
    def test_ci_has_opt_in_flags(self):
        import subprocess
        p=subprocess.run([sys.executable,str(ROOT/'ci/verify.py'),'--help'],capture_output=True,text=True,timeout=5);self.assertIn('--run-regressions',p.stdout);self.assertIn('--run-control',p.stdout)
