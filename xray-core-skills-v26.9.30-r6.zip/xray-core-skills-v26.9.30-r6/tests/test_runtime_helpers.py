"""Local socket helper tests. The fixture below is a tiny test double, NOT Xray."""
from __future__ import annotations
import contextlib, socket, socketserver, struct, sys, threading, time, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'skills/xray-source-audit/scripts'))
from run_lab import read_exact,tcp_probe,udp_probe,echo_servers,socks_address

class SocksDouble(socketserver.BaseRequestHandler):
    def handle(self):
        c=self.request;c.settimeout(3)
        try:
            if read_exact(c,3)!=b'\x05\x01\x00':return
            if self.server.mode=='reject_greeting':c.sendall(b'\x05\xff');return
            c.sendall(b'\x05\x00');h=read_exact(c,4);host,port=socks_address(c,h[3])
            if host!='127.0.0.1':return
            if h[1]==1:
                if self.server.mode=='reject_request':c.sendall(b'\x05\x01\x00\x01'+b'\x00'*6);return
                with socket.create_connection((host,port),timeout=3) as remote:
                    remote.settimeout(3);c.sendall(b'\x05\x00\x00\x01'+socket.inet_aton(host)+struct.pack('!H',port))
                    # One request is enough; account for TCP segmentation with repeated rounds.
                    while True:
                        data=c.recv(65536)
                        if not data:return
                        remote.sendall(data);reply=read_exact(remote,len(data))
                        if self.server.mode=='corrupt_tcp':reply=bytes([reply[0]^1])+reply[1:]
                        c.sendall(reply)
            elif h[1]==3:
                with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as relay:
                    relay.bind(('127.0.0.1',0));relay.settimeout(3)
                    c.sendall(b'\x05\x00\x00\x01'+socket.inet_aton('127.0.0.1')+struct.pack('!H',relay.getsockname()[1]))
                    data,peer=relay.recvfrom(4096)
                    if data[:4]!=b'\x00\x00\x00\x01':return
                    dest=socket.inet_ntoa(data[4:8]),struct.unpack('!H',data[8:10])[0]
                    if dest[0]!='127.0.0.1':return
                    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as upstream:
                        upstream.settimeout(3);upstream.sendto(data[10:],dest);reply,_=upstream.recvfrom(4096)
                    header=data[:10]
                    if self.server.mode=='fragment_udp':header=b'\x00\x00\x01'+header[3:]
                    if self.server.mode=='corrupt_udp':reply=b'bad'
                    relay.sendto(header+reply,peer)
        except (OSError,ConnectionError):return
class Threaded(socketserver.ThreadingTCPServer):
    daemon_threads=True
@contextlib.contextmanager
def fake_socks(mode='normal'):
    s=Threaded(('127.0.0.1',0),SocksDouble);s.mode=mode
    t=threading.Thread(target=s.serve_forever,kwargs={'poll_interval':0.05},daemon=True);t.start()
    try:yield s.server_address[1]
    finally:s.shutdown();s.server_close();t.join(1)
class Helpers(unittest.TestCase):
    def test_tcp_payload_roundtrip_harness_only(self):
        with echo_servers() as (tcp,udp),fake_socks() as socks:tcp_probe(socks,tcp,payload_bytes=16384)
    def test_udp_payload_roundtrip_harness_only(self):
        with echo_servers() as (tcp,udp),fake_socks() as socks:udp_probe(socks,udp)
    def test_detect_tcp_corruption(self):
        with echo_servers() as (tcp,udp),fake_socks('corrupt_tcp') as socks:
            with self.assertRaises(ConnectionError):tcp_probe(socks,tcp,256)
    def test_detect_udp_corruption(self):
        with echo_servers() as (tcp,udp),fake_socks('corrupt_udp') as socks:
            with self.assertRaises(ConnectionError):udp_probe(socks,udp)
    def test_reject_fragmented_udp(self):
        with echo_servers() as (tcp,udp),fake_socks('fragment_udp') as socks:
            with self.assertRaises(ConnectionError):udp_probe(socks,udp)
    def test_greeting_rejected(self):
        with fake_socks('reject_greeting') as socks:
            with self.assertRaises(ConnectionError):tcp_probe(socks,12345,256)
    def test_request_rejected(self):
        with fake_socks('reject_request') as socks:
            with self.assertRaises(ConnectionError):tcp_probe(socks,12345,256)
    def test_premature_eof(self):
        a,b=socket.socketpair()
        try:
            a.sendall(b'ab');a.close()
            with self.assertRaises(ConnectionError):read_exact(b,3)
        finally:a.close();b.close()
if __name__=='__main__':unittest.main()
