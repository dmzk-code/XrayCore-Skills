"""Offline tests for r3 inventory, runner safeguards, and authoring regressions."""
from __future__ import annotations
import copy
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'skills/xray-source-audit/scripts'))
from lab_trust import verify_binary
import run_extended_lab as extended
import run_dns_lab as dns_lab
from validate import Validator
from test_extended import mask,codes

class R3Release(unittest.TestCase):
    def test_binary_hash_match(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'binary';p.write_bytes(b'test-not-executable')
            h=hashlib.sha256(p.read_bytes()).hexdigest();self.assertEqual(verify_binary(p,h),h)
    def test_binary_hash_uppercase(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'binary';p.write_bytes(b'test');h=hashlib.sha256(b'test').hexdigest();self.assertEqual(verify_binary(p,h.upper()),h)
    def test_binary_hash_mismatch(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'binary';p.write_bytes(b'unit');self.assertRaises(ValueError,verify_binary,p,'0'*64)
    def test_binary_hash_required(self):self.assertRaises(ValueError,verify_binary,Path('/missing'),None)
    def test_binary_hash_malformed(self):self.assertRaises(ValueError,verify_binary,Path('/missing'),'x'*64)
    def test_binary_missing(self):self.assertRaises(OSError,verify_binary,Path('/definitely-missing-unit-xray'),'0'*64)
    def test_no_extended_execution_before_trust(self):
        with tempfile.TemporaryDirectory() as d,mock.patch.object(extended.subprocess,'run') as proc:
            p=Path(d)/'binary';p.write_bytes(b'unit');out=Path(d)/'lab'
            self.assertRaises(ValueError,extended.run,p,out,None,'0'*64);proc.assert_not_called();self.assertFalse(out.exists())
    def test_no_dns_execution_before_trust(self):
        with tempfile.TemporaryDirectory() as d,mock.patch.object(dns_lab.subprocess,'run') as proc:
            p=Path(d)/'binary';p.write_bytes(b'unit');out=Path(d)/'lab'
            self.assertRaises(ValueError,dns_lab.run,p,out,'0'*64);proc.assert_not_called();self.assertFalse(out.exists())
    def test_extended_cli_list(self):
        import subprocess
        p=subprocess.run([sys.executable,str(ROOT/'skills/xray-source-audit/scripts/run_extended_lab.py'),'--list'],capture_output=True,text=True,timeout=5)
        self.assertEqual(p.returncode,0,p.stderr);self.assertEqual(len(p.stdout.splitlines()),40)
    def test_dns_cli_help(self):
        import subprocess
        p=subprocess.run([sys.executable,str(ROOT/'skills/xray-source-audit/scripts/run_dns_lab.py'),'--help'],capture_output=True,text=True,timeout=5)
        self.assertEqual(p.returncode,0,p.stderr);self.assertIn('--sha256',p.stdout)
    def test_ci_cli_help(self):
        import subprocess
        p=subprocess.run([sys.executable,str(ROOT/'ci/verify.py'),'--help'],capture_output=True,text=True,timeout=5)
        self.assertEqual(p.returncode,0,p.stderr);self.assertIn('--run-extended',p.stdout);self.assertIn('--run-dns',p.stdout)
    def test_inventory_pinned(self):
        index=json.loads((ROOT/'skills/xray-source-audit/references/knowledge-index.json').read_text());lock=json.loads((ROOT/'VERSION.lock.json').read_text());self.assertEqual(index['commit'],lock['commit'])
    def test_inventory_counts(self):
        index=json.loads((ROOT/'skills/xray-source-audit/references/knowledge-index.json').read_text());lock=json.loads((ROOT/'VERSION.lock.json').read_text());self.assertEqual(len(index['objects']),lock['inventory']['objects']);self.assertEqual(sum(len(v['fields']) for v in index['objects'].values()),lock['inventory']['field_slots'])
    def test_variants_unique(self):
        cases=extended.variants();self.assertEqual(len(cases),40);self.assertEqual(len({c['name'] for c in cases}),40)
    def test_variants_no_alias_mutation(self):
        cases=extended.variants();cases[0]['client_patch']['finalmask']['tcp'][0]['settings']['clients'].clear();self.assertTrue(cases[0]['server_patch']['finalmask']['tcp'][0]['settings']['clients'])
    def test_merge_keeps_unrelated_fields(self):
        d={'a':{'b':1,'keep':2},'keep':3};extended.merge(d,{'a':{'b':5}});self.assertEqual(d,{'a':{'b':5,'keep':2},'keep':3})
    def test_noise_empty_bytes_rejected(self):self.assertIn('NOISE_EXPRESSION',codes(mask('noise',{'noise':[{'type':'exp','packet':'<b >'}]},'udp')))
    def test_noise_bound_rejected(self):self.assertIn('NOISE_EXPRESSION',codes(mask('noise',{'noise':[{'type':'exp','packet':'<r 65536>'}]},'udp')))
    def test_noise_reverse_bound_rejected(self):self.assertIn('NOISE_EXPRESSION',codes(mask('noise',{'noise':[{'type':'exp','packet':'<rc 9-2>'}]},'udp')))
    def test_noise_valid_bound(self):self.assertNotIn('NOISE_EXPRESSION',codes(mask('noise',{'noise':[{'type':'exp','packet':'<r 0-65535>'}]},'udp')))
    def test_dns_wrong_shape_fails_closed(self):
        out=Validator().config({'dns':{'queryStrategy':{},'servers':[{'address':'localhost'}]}});self.assertTrue(any(i['severity']=='ERROR' for i in out))
    def test_all_implementation_links(self):
        for p in (ROOT/'skills').glob('xray-transport-*/SKILL.md'):
            self.assertIn('references/implementation.md',p.read_text());self.assertTrue((p.parent/'references/implementation.md').is_file())
    def test_no_untyped_field_placeholder(self):
        index=json.loads((ROOT/'skills/xray-source-audit/references/knowledge-index.json').read_text())
        for o in index['objects'].values():
            for t in o['fields'].values():self.assertNotIn('TODO',t);self.assertNotEqual(t,'')

if __name__=='__main__':unittest.main()
