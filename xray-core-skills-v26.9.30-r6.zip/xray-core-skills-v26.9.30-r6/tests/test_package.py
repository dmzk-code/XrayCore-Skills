"""Offline release contract tests. These are not executions of Xray."""
from __future__ import annotations
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'skills/xray-source-audit/scripts'))
from verify_package import verify
from core_config_cases import CASES, mutate
spec = importlib.util.spec_from_file_location('release_installer', ROOT / 'install.py')
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)

class ReleaseContract(unittest.TestCase):
    def test_package_shape_and_links(self):
        result = verify(ROOT)
        self.assertEqual(result['errors'], [])
        self.assertEqual(result['status'], 'PASS')

    def test_core_case_inventory(self):
        self.assertEqual(len(CASES), 24)
        self.assertEqual(len({c[0] for c in CASES}), 24)
        self.assertEqual(sum(c[-1] == 'REJECT_CORE' for c in CASES), 19)
        self.assertEqual(sum(c[-1] == 'ACCEPT_CORE' for c in CASES), 5)

    def test_case_mutation_deep_copies_values(self):
        target = {'outbounds': [{'settings': {}}]}
        value = {'values': [1]}
        mutate(target, ['outbounds', 0, 'settings', 'new'], value)
        value['values'].append(2)
        self.assertEqual(target['outbounds'][0]['settings']['new']['values'], [1])

    def test_runtime_failures_are_not_relabelled_pass(self):
        report = json.loads((ROOT / 'skills/xray-runtime-validation/references/runtime-evidence.json').read_text())
        self.assertEqual(report['status'], 'FAIL')
        # This historical measurement is immutable; new tests must create a new report.
        raw = (ROOT / 'skills/xray-runtime-validation/references/known-issues.md').read_text()
        self.assertIn('gRPC', raw)
        self.assertIn('XHTTP', raw)

    def test_source_skill_symlink_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'skills').mkdir()
            real = root / 'external'
            real.mkdir()
            (real / 'SKILL.md').write_text('not trusted')
            try:
                (root / 'skills/xray-external').symlink_to(real, target_is_directory=True)
            except (OSError, NotImplementedError):
                self.skipTest('symlink creation unavailable')
            with self.assertRaises(ValueError):
                installer.safe_source(root)

if __name__ == '__main__':
    unittest.main()
