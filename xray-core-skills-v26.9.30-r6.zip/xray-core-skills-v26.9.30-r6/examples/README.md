# Transport templates — НЕ готовые конфиги сервера

Девять файлов *.stream.template.json — только объекты StreamConfig для изучения формы JSON и передачи агенту. В каждом transport-папке есть references/recipes.md для полной сборки. Это не server.json/client.json и не программа автоматического развёртывания.

Домены example.invalid и строки REPLACE_… обязательны к замене. Не отправлять эти шаблоны в production. Здесь нет полного protocol/auth/routing, сертификатов сервера, ключей или проверенных сетевых маршрутов. MASQUE/Hysteria требуют также согласованного native protocol settings. RAW/KCP security=none или local XDRIVE не гарантируют конфиденциальность payload: внутренний protocol и модель хранения анализируются отдельно.

XHTTP пример показывает размещение расширенных параметров в extra и отдельное download-плечо. Оба домена должны вести к согласованному серверному контексту сессии; это не два независимых серверных приложения. Значения xmux иллюстративные, не измеренный профиль производительности.

WS/HTTPUpgrade ed=2048 иллюстрирует синтаксис. Семантика early data различается; величина не является универсальным оптимумом.

Проверить только транспортный lint:
```bash
python3 skills/xray-source-audit/scripts/lint_config.py examples/xhttp.stream.template.json --stream
```
Все девять примеров прошли наш transport lint без ERROR. Deprecated warnings для WS/gRPC/HTTPUpgrade ожидаемы. Для этих старых stream-only snippets core/network не запускались. В r2 добавлены отдельные полные пары и их настоящий runtime: [результаты](../VALIDATION.md).
