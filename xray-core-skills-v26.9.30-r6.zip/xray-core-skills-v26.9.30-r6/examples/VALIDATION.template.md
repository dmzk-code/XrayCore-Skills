# Проверка конкретной конфигурации

## Среда
Server core/version/commit: UNVERIFIED
Client core/version/commit: UNVERIFIED
Platform/container/frontend/client wrapper: UNVERIFIED
Credentials: generated locally / placeholders remain

## Ledger
| Проверка | Статус | Команда / доказательство / ограничения |
|---|---|---|
| Source field trace | NOT_RUN | JSON path → builder → runtime → peer |
| JSON/transport lint | NOT_RUN | Локальный lint не заменяет core |
| Binary version identity | NOT_RUN | Доверенный бинарник и установленная версия |
| Core configuration test | NOT_RUN | xray run -test -config FILE |
| Listener/bind/permissions | NOT_RUN | Изолированная среда |
| TLS/REALITY/protocol auth | NOT_RUN | Успешный и отрицательный тест |
| TCP payload | NOT_RUN | Фактическая передача |
| UDP payload/DNS | NOT_RUN | Не выводить результат из TCP теста |
| Reconnect and restart | NOT_RUN | Проверить каждое плечо |
| Load/CPU/RAM/FD/quota | NOT_RUN | Целевая среда, измеренная нагрузка |

## Вывод
Перечислить блокирующие предпосылки. Результат TESTED выставляется только после реального выполнения строки. Успех загрузки конфигурации не подтверждает передачу пользовательского трафика.
