#!/usr/bin/env python3
"""Offline package shape/link/JSON/source-pin checks. No core or network execution."""
from __future__ import annotations
import argparse,ast,json,re,sys,math
from package_integrity import verify_integrity
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def strict_json(text):
    def pairs(items):
        out={}
        for key,value in items:
            if key in out:raise ValueError('duplicate JSON key')
            out[key]=value
        return out
    def bad(value):raise ValueError('nonfinite JSON number')
    def finite(value):
        n=float(value)
        if not math.isfinite(n):raise ValueError('nonfinite JSON number')
        return n
    return json.loads(text,object_pairs_hook=pairs,parse_constant=bad,parse_float=finite)

def verify(root: Path=ROOT, *, check_integrity: bool=True) -> dict:
    errors=verify_integrity(root) if check_integrity else [];root=root.resolve();lock=strict_json((root/'VERSION.lock.json').read_text());skills=list((root/'skills').glob('*/SKILL.md'))
    if len(skills)!=lock['inventory']['skills']:errors.append('expected 17 SKILL.md files')
    for p in skills:
        text=p.read_text(encoding='utf-8');parts=text.split('---',2)
        if not text.startswith('---\n') or len(parts)<3:errors.append(str(p.relative_to(root))+': frontmatter missing');continue
        name=re.search(r'^name:\s*([a-z0-9-]+)\s*$',parts[1],re.M)
        desc=re.search(r'^description:\s*(.+)$',parts[1],re.M)
        if not name or name[1]!=p.parent.name or len(name[1])>64:errors.append(p.parent.name+': invalid name')
        if not desc or not 1<=len(desc[1])<=1024:errors.append(p.parent.name+': invalid description')
        if ('version: "'+lock['package_version']+'"') not in parts[1]:errors.append(p.parent.name+': unexpected skill version')
        if len(text.splitlines())>500:errors.append(p.parent.name+': split long main instructions into references')
    json_count=0;py_count=0;link_count=0
    for p in sorted(root.rglob('*')):
        if p.is_symlink():errors.append('symlink: '+str(p.relative_to(root)))
        if not p.is_file() or '__pycache__' in p.parts:continue
        if p.suffix=='.json':
            try:strict_json(p.read_text(encoding='utf-8'));json_count+=1
            except (ValueError,UnicodeError):errors.append('invalid JSON: '+str(p.relative_to(root)))
        if p.suffix=='.py':
            try:ast.parse(p.read_text(encoding='utf-8'));py_count+=1
            except SyntaxError:errors.append('invalid Python: '+str(p.relative_to(root)))
        if p.suffix=='.md':
            for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
                if target.startswith(('http://','https://','#','mailto:')):continue
                target=target.split('#',1)[0]
                if not target:continue
                dest=(p.parent/target).resolve();link_count+=1
                if not dest.is_relative_to(root) or not dest.exists():errors.append(f'broken local link in {p.relative_to(root)}: {target}')
        if p.suffix.lower() in ('.pem','.key','.p12','.pfx'):errors.append('private/runtime key material must not ship: '+str(p.relative_to(root)))
    prov=strict_json((root/'skills/xray-source-audit/references/provenance.json').read_text())
    for r in prov['files']:
        if not re.fullmatch('[0-9a-f]{40}',r.get('git_blob_sha') or ''):errors.append('unlocked source blob: '+r['path'])
        if prov['commit'] not in r['url']:errors.append('unpinned source URL: '+r['path'])
    index=strict_json((root/'skills/xray-source-audit/references/knowledge-index.json').read_text())
    objects=index['objects']
    if index['commit']!=prov['commit']:errors.append('knowledge index/source commit mismatch')
    fields=sum(len(o['fields']) for o in objects.values())
    if index.get('revision')!=lock.get('revision'):errors.append('knowledge index revision mismatch')
    if index.get('counts')!={'objects':len(objects),'field_slots':fields}:errors.append('stale knowledge index counts')
    if len(objects)!=lock['inventory']['objects'] or fields!=lock['inventory']['field_slots']:errors.append('unexpected configuration inventory counts')
    for name,definition in objects.items():
        if not isinstance(definition.get('fields'),dict) or not definition.get('references'):errors.append('empty knowledge object: '+name)
        for typ in definition.get('fields',{}).values():
            if not isinstance(typ,str) or not typ.strip():errors.append('empty field type: '+name)
        if prov['commit'] not in definition.get('source',''):errors.append('unpinned knowledge source: '+name)
        for reference in definition.get('references',[]):
            dest=(root/'skills'/reference).resolve()
            if not dest.is_relative_to(root/'skills') or not dest.is_file():errors.append('broken knowledge reference: '+reference)
    lock=strict_json((root/'VERSION.lock.json').read_text())
    if lock.get('commit')!=prov['commit'] or lock.get('revision')!='r6':errors.append('version lock mismatch')
    examples=root/'skills/xray-config-orchestrator/assets/scenarios'
    configs=list(examples.glob('*/server.json'))+list(examples.glob('*/client.json'))+list(examples.glob('*/relay.json'))
    if len(configs)!=lock['inventory']['full_templates']:errors.append('expected 45 full configuration templates')
    return {'status':'PASS' if not errors else 'FAIL','scope':'offline structure and '+('SHA256 manifest consistency' if check_integrity else 'shape only; hashes not checked')+', not Xray runtime or publisher authentication','skills':len(skills),'json_files':json_count,'python_files':py_count,'relative_links':link_count,'reviewed_source_files':len(prov['files']),'knowledge_objects':len(objects),'field_slots':fields,'full_config_templates':len(configs),'errors':errors}

def main():
    result=verify();print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
