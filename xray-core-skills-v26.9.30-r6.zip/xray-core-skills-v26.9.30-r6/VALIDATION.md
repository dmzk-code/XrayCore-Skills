# Фактическая проверка r6 — 7 октября 2026

## Среда и источник исполняемого кода

Бинарник проверен по SHA256 **до исполнения**: `96efb28b8b2086275598dc46e73b5dc340da948b4e1ccc4f1719f83f67b793a7`. Вывод version: Xray 26.9.30, b26a91d, go1.27.1 linux/amd64. Рабочая среда: Linux-6.18.44-x86_64-with-glibc2.41, Python 3.13.5. Ядро не патчилось; использован ранее полученный официальный CI artifact. Исходники исследовались через pinned GitHub reads, не подменой checkout рабочей инфраструктуры.

Локальные отдельные процессы, TCP/UDP echo и временные данные. Реальные cloud accounts, публичные endpoints, системные маршруты и firewall не затрагивались.

## Unit и release checks

**564/564 теста инструментов и контракта прошли**, в том числе **75 новых методов r6**. [Фактический unit-log](ci/unit-tests-r6.txt). Это не 564 интеграционных сценария ядра и не штатный Go-suite.

Проверяются role-specific proxy fields, auth aliases, HTTP header override, byte lengths, direct topology, listener collisions, virtual tags, actual FinalMask construction, secret redaction, environment sanitization, CLI and digest-before-execution. Дополнительно проверяются текущие registry counts/revision и версия общего контракта.

[Registry/release summary](ci/r6-summary.json): 17 скиллов, 97 объектов / 584 позиции полей, 128 source records, 45 базовых полноформатных конфигурационных шаблонов. Наличие записи в provenance означает указанный объём чтения, не исчерпывающее покрытие ветвей исполнения.

## Новая отдельная нативная серия

[Полный отчёт](skills/xray-runtime-validation/references/r6-regressions.json).

| Группа | Фактический результат | Что именно подтверждено |
|---|---|---|
| Parser/build | 8/8 ожиданий совпали | Принимаемые, но опасные auth-конфиги отделены от отвергаемых типов. REJECT засчитывается по exit23, не по crash/timeout. |
| Auth edge-cases | 8/8 ожиданий совпали | На пяти небезопасных вариантах наблюдались unauthenticated CONNECT200 и echo payload; три защищённых варианта дали407, неправильный пароль отвергнут, правильный передал данные. |
| Полные proxy-пары | 8/8 прошли | В каждой TCP и отказ с неверными credentials, затем успешный положительный контроль. У четырёх SOCKS-пар UDP PASS; у четырёх HTTP-пар UDP явно UNSUPPORTED, не PASS. |
| Environment isolation | 2/2 прошли | Dotted и underscore confdir действительно учитываются ядром в контроле и исключаются очищенным runner. |
| gRPC после server-only restart | 0/2 восстановились в budget5s | Empty finalmask и quicParams-only: FAIL_KNOWN. После рестарта клиента — 2/2 положительных controls. |

Опасные auth fixtures используются **только для воспроизведения ошибки ожиданий**. PASS такого случая не разрешает публиковать listener и не утверждает, что ядро исправлено. Валидатор r6 отвергает эти варианты политикой безопасной генерации.

Итог диагностической серии: **PASS_EXPECTATIONS_WITH_KNOWN_RUNTIME_FAILURES**. Общая приёмка безотказного gRPC из него не следует. Прежние 45-секундные измерения сохранены в [known-issues](skills/xray-runtime-validation/references/known-issues.md); текущая серия использует другой, явно указанный budget5s.

## Регрессионный повтор прежнего runner в текущей ревизии

[Новый физический запуск старого runner](skills/xray-runtime-validation/references/r6-repeat-r5.json): **21/21 wire, 9/9 composition, 10/10 parser/build expectations — PASS**. Проверены XHTTP active/case/default semantics, MASQUE URI/H2–H3, VMess/Trojan credentials, X25519/ML-KEM Encryption и сравнение объединения файлов с `xray run -dump`.

Внутреннее поле `revision:r5` — версия самого повторно запущенного runner, не дата старого измерения. Этот файл получен в новой test directory в ходе r6; его checksum и источник включены в manifest исполнения. Сохранённый `r5-regressions.json` при этом не переписан.

## Доставка

`verify_package.py` проверяет структуру, относительные ссылки, корректность Python/JSON, pinned URLs, согласованность inventory и SHA256 manifest. Архив собирается без caches/binary/generated keys. Файловая установка всех 17 скиллов, повторная установка с backup и CLI из установленной папки фиксируются отдельным [smoke-report](ci/install-smoke-r6.json). Это **не** проверка активации в UI Claude/Codex.

[Повтор новой нативной серии через CI](skills/xray-runtime-validation/references/r6-ci-native-repeat.json) совпал с отдельным прогоном. [CI r6](ci/r6-ci-report.json) сохраняет runtime_acceptance=KNOWN_FAILURES отдельно от прохождения проверочных ожиданий. [Manifest исполнения](ci/r6-execution-manifest.json) различает отчёты новых запусков и унаследованные файлы.

## Что не выполнялось в этой ревизии

Полный baseline22 с restart/load и extended40, DNS/control-plane suites не перезапускались в r6; их результаты доступны в [историческом отчёте r5](HISTORY-r5-VALIDATION.md). Не запускались Go-suite, сборка ядра из исходников, реальные внешние CDN/NAT/cloud credentials, Android/macOS/Windows, UI activation и длительные нагрузочные/ресурсные испытания. Эти пункты имеют **NOT_RUN**, а не неявный успех.

r6 устраняет перечисленные ошибки пакета и добавляет подтверждённые правила. Пакет скиллов не заявлен математически полным анализатором любого значения, сторонней зависимости и произвольной сети.
